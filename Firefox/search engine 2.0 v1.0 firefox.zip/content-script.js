"use strict";
(() => {
  var cc = Object.create;
  var pn = Object.defineProperty;
  var sc = Object.getOwnPropertyDescriptor;
  var uc = Object.getOwnPropertyNames;
  var dc = Object.getPrototypeOf,
    pc = Object.prototype.hasOwnProperty;
  var tt = (e, t) => () => (
      t || e((t = { exports: {} }).exports, t), t.exports
    ),
    wa = (e, t) => {
      for (var n in t) pn(e, n, { get: t[n], enumerable: !0 });
    },
    mc = (e, t, n, a) => {
      if ((t && typeof t == "object") || typeof t == "function")
        for (let r of uc(t))
          !pc.call(e, r) &&
            r !== n &&
            pn(e, r, {
              get: () => t[r],
              enumerable: !(a = sc(t, r)) || a.enumerable,
            });
      return e;
    };
  var pt = (e, t, n) => (
    (n = e != null ? cc(dc(e)) : {}),
    mc(
      t || !e || !e.__esModule
        ? pn(n, "default", { value: e, enumerable: !0 })
        : n,
      e
    )
  );
  var n1 = tt((wn, Mr) => {
    (function (e, t) {
      if (typeof define == "function" && define.amd)
        define("webextension-polyfill", ["module"], t);
      else if (typeof wn < "u") t(Mr);
      else {
        var n = { exports: {} };
        t(n), (e.browser = n.exports);
      }
    })(
      typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : wn,
      function (e) {
        "use strict";
        if (!globalThis.chrome?.runtime?.id)
          throw new Error(
            "This script should only be loaded in a browser extension."
          );
        if (
          typeof globalThis.browser > "u" ||
          Object.getPrototypeOf(globalThis.browser) !== Object.prototype
        ) {
          let t = "The message port closed before a response was received.",
            n = (a) => {
              let r = {
                alarms: {
                  clear: { minArgs: 0, maxArgs: 1 },
                  clearAll: { minArgs: 0, maxArgs: 0 },
                  get: { minArgs: 0, maxArgs: 1 },
                  getAll: { minArgs: 0, maxArgs: 0 },
                },
                bookmarks: {
                  create: { minArgs: 1, maxArgs: 1 },
                  get: { minArgs: 1, maxArgs: 1 },
                  getChildren: { minArgs: 1, maxArgs: 1 },
                  getRecent: { minArgs: 1, maxArgs: 1 },
                  getSubTree: { minArgs: 1, maxArgs: 1 },
                  getTree: { minArgs: 0, maxArgs: 0 },
                  move: { minArgs: 2, maxArgs: 2 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  removeTree: { minArgs: 1, maxArgs: 1 },
                  search: { minArgs: 1, maxArgs: 1 },
                  update: { minArgs: 2, maxArgs: 2 },
                },
                browserAction: {
                  disable: { minArgs: 0, maxArgs: 1, fallbackToNoCallback: !0 },
                  enable: { minArgs: 0, maxArgs: 1, fallbackToNoCallback: !0 },
                  getBadgeBackgroundColor: { minArgs: 1, maxArgs: 1 },
                  getBadgeText: { minArgs: 1, maxArgs: 1 },
                  getPopup: { minArgs: 1, maxArgs: 1 },
                  getTitle: { minArgs: 1, maxArgs: 1 },
                  openPopup: { minArgs: 0, maxArgs: 0 },
                  setBadgeBackgroundColor: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0,
                  },
                  setBadgeText: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0,
                  },
                  setIcon: { minArgs: 1, maxArgs: 1 },
                  setPopup: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0,
                  },
                  setTitle: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0,
                  },
                },
                browsingData: {
                  remove: { minArgs: 2, maxArgs: 2 },
                  removeCache: { minArgs: 1, maxArgs: 1 },
                  removeCookies: { minArgs: 1, maxArgs: 1 },
                  removeDownloads: { minArgs: 1, maxArgs: 1 },
                  removeFormData: { minArgs: 1, maxArgs: 1 },
                  removeHistory: { minArgs: 1, maxArgs: 1 },
                  removeLocalStorage: { minArgs: 1, maxArgs: 1 },
                  removePasswords: { minArgs: 1, maxArgs: 1 },
                  removePluginData: { minArgs: 1, maxArgs: 1 },
                  settings: { minArgs: 0, maxArgs: 0 },
                },
                commands: { getAll: { minArgs: 0, maxArgs: 0 } },
                contextMenus: {
                  remove: { minArgs: 1, maxArgs: 1 },
                  removeAll: { minArgs: 0, maxArgs: 0 },
                  update: { minArgs: 2, maxArgs: 2 },
                },
                cookies: {
                  get: { minArgs: 1, maxArgs: 1 },
                  getAll: { minArgs: 1, maxArgs: 1 },
                  getAllCookieStores: { minArgs: 0, maxArgs: 0 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  set: { minArgs: 1, maxArgs: 1 },
                },
                devtools: {
                  inspectedWindow: {
                    eval: { minArgs: 1, maxArgs: 2, singleCallbackArg: !1 },
                  },
                  panels: {
                    create: { minArgs: 3, maxArgs: 3, singleCallbackArg: !0 },
                    elements: { createSidebarPane: { minArgs: 1, maxArgs: 1 } },
                  },
                },
                downloads: {
                  cancel: { minArgs: 1, maxArgs: 1 },
                  download: { minArgs: 1, maxArgs: 1 },
                  erase: { minArgs: 1, maxArgs: 1 },
                  getFileIcon: { minArgs: 1, maxArgs: 2 },
                  open: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                  pause: { minArgs: 1, maxArgs: 1 },
                  removeFile: { minArgs: 1, maxArgs: 1 },
                  resume: { minArgs: 1, maxArgs: 1 },
                  search: { minArgs: 1, maxArgs: 1 },
                  show: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                },
                extension: {
                  isAllowedFileSchemeAccess: { minArgs: 0, maxArgs: 0 },
                  isAllowedIncognitoAccess: { minArgs: 0, maxArgs: 0 },
                },
                history: {
                  addUrl: { minArgs: 1, maxArgs: 1 },
                  deleteAll: { minArgs: 0, maxArgs: 0 },
                  deleteRange: { minArgs: 1, maxArgs: 1 },
                  deleteUrl: { minArgs: 1, maxArgs: 1 },
                  getVisits: { minArgs: 1, maxArgs: 1 },
                  search: { minArgs: 1, maxArgs: 1 },
                },
                i18n: {
                  detectLanguage: { minArgs: 1, maxArgs: 1 },
                  getAcceptLanguages: { minArgs: 0, maxArgs: 0 },
                },
                identity: { launchWebAuthFlow: { minArgs: 1, maxArgs: 1 } },
                idle: { queryState: { minArgs: 1, maxArgs: 1 } },
                management: {
                  get: { minArgs: 1, maxArgs: 1 },
                  getAll: { minArgs: 0, maxArgs: 0 },
                  getSelf: { minArgs: 0, maxArgs: 0 },
                  setEnabled: { minArgs: 2, maxArgs: 2 },
                  uninstallSelf: { minArgs: 0, maxArgs: 1 },
                },
                notifications: {
                  clear: { minArgs: 1, maxArgs: 1 },
                  create: { minArgs: 1, maxArgs: 2 },
                  getAll: { minArgs: 0, maxArgs: 0 },
                  getPermissionLevel: { minArgs: 0, maxArgs: 0 },
                  update: { minArgs: 2, maxArgs: 2 },
                },
                pageAction: {
                  getPopup: { minArgs: 1, maxArgs: 1 },
                  getTitle: { minArgs: 1, maxArgs: 1 },
                  hide: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                  setIcon: { minArgs: 1, maxArgs: 1 },
                  setPopup: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0,
                  },
                  setTitle: {
                    minArgs: 1,
                    maxArgs: 1,
                    fallbackToNoCallback: !0,
                  },
                  show: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                },
                permissions: {
                  contains: { minArgs: 1, maxArgs: 1 },
                  getAll: { minArgs: 0, maxArgs: 0 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  request: { minArgs: 1, maxArgs: 1 },
                },
                runtime: {
                  getBackgroundPage: { minArgs: 0, maxArgs: 0 },
                  getPlatformInfo: { minArgs: 0, maxArgs: 0 },
                  openOptionsPage: { minArgs: 0, maxArgs: 0 },
                  requestUpdateCheck: { minArgs: 0, maxArgs: 0 },
                  sendMessage: { minArgs: 1, maxArgs: 3 },
                  sendNativeMessage: { minArgs: 2, maxArgs: 2 },
                  setUninstallURL: { minArgs: 1, maxArgs: 1 },
                },
                sessions: {
                  getDevices: { minArgs: 0, maxArgs: 1 },
                  getRecentlyClosed: { minArgs: 0, maxArgs: 1 },
                  restore: { minArgs: 0, maxArgs: 1 },
                },
                storage: {
                  local: {
                    clear: { minArgs: 0, maxArgs: 0 },
                    get: { minArgs: 0, maxArgs: 1 },
                    getBytesInUse: { minArgs: 0, maxArgs: 1 },
                    remove: { minArgs: 1, maxArgs: 1 },
                    set: { minArgs: 1, maxArgs: 1 },
                  },
                  managed: {
                    get: { minArgs: 0, maxArgs: 1 },
                    getBytesInUse: { minArgs: 0, maxArgs: 1 },
                  },
                  sync: {
                    clear: { minArgs: 0, maxArgs: 0 },
                    get: { minArgs: 0, maxArgs: 1 },
                    getBytesInUse: { minArgs: 0, maxArgs: 1 },
                    remove: { minArgs: 1, maxArgs: 1 },
                    set: { minArgs: 1, maxArgs: 1 },
                  },
                },
                tabs: {
                  captureVisibleTab: { minArgs: 0, maxArgs: 2 },
                  create: { minArgs: 1, maxArgs: 1 },
                  detectLanguage: { minArgs: 0, maxArgs: 1 },
                  discard: { minArgs: 0, maxArgs: 1 },
                  duplicate: { minArgs: 1, maxArgs: 1 },
                  executeScript: { minArgs: 1, maxArgs: 2 },
                  get: { minArgs: 1, maxArgs: 1 },
                  getCurrent: { minArgs: 0, maxArgs: 0 },
                  getZoom: { minArgs: 0, maxArgs: 1 },
                  getZoomSettings: { minArgs: 0, maxArgs: 1 },
                  goBack: { minArgs: 0, maxArgs: 1 },
                  goForward: { minArgs: 0, maxArgs: 1 },
                  highlight: { minArgs: 1, maxArgs: 1 },
                  insertCSS: { minArgs: 1, maxArgs: 2 },
                  move: { minArgs: 2, maxArgs: 2 },
                  query: { minArgs: 1, maxArgs: 1 },
                  reload: { minArgs: 0, maxArgs: 2 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  removeCSS: { minArgs: 1, maxArgs: 2 },
                  sendMessage: { minArgs: 2, maxArgs: 3 },
                  setZoom: { minArgs: 1, maxArgs: 2 },
                  setZoomSettings: { minArgs: 1, maxArgs: 2 },
                  update: { minArgs: 1, maxArgs: 2 },
                },
                topSites: { get: { minArgs: 0, maxArgs: 0 } },
                webNavigation: {
                  getAllFrames: { minArgs: 1, maxArgs: 1 },
                  getFrame: { minArgs: 1, maxArgs: 1 },
                },
                webRequest: {
                  handlerBehaviorChanged: { minArgs: 0, maxArgs: 0 },
                },
                windows: {
                  create: { minArgs: 0, maxArgs: 1 },
                  get: { minArgs: 1, maxArgs: 2 },
                  getAll: { minArgs: 0, maxArgs: 1 },
                  getCurrent: { minArgs: 0, maxArgs: 1 },
                  getLastFocused: { minArgs: 0, maxArgs: 1 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  update: { minArgs: 2, maxArgs: 2 },
                },
              };
              if (Object.keys(r).length === 0)
                throw new Error(
                  "api-metadata.json has not been included in browser-polyfill"
                );
              class o extends WeakMap {
                constructor(M, E = void 0) {
                  super(E), (this.createItem = M);
                }
                get(M) {
                  return (
                    this.has(M) || this.set(M, this.createItem(M)), super.get(M)
                  );
                }
              }
              let i = (w) =>
                  w && typeof w == "object" && typeof w.then == "function",
                l =
                  (w, M) =>
                  (...E) => {
                    a.runtime.lastError
                      ? w.reject(new Error(a.runtime.lastError.message))
                      : M.singleCallbackArg ||
                        (E.length <= 1 && M.singleCallbackArg !== !1)
                      ? w.resolve(E[0])
                      : w.resolve(E);
                  },
                s = (w) => (w == 1 ? "argument" : "arguments"),
                u = (w, M) =>
                  function (z, ...k) {
                    if (k.length < M.minArgs)
                      throw new Error(
                        `Expected at least ${M.minArgs} ${s(
                          M.minArgs
                        )} for ${w}(), got ${k.length}`
                      );
                    if (k.length > M.maxArgs)
                      throw new Error(
                        `Expected at most ${M.maxArgs} ${s(
                          M.maxArgs
                        )} for ${w}(), got ${k.length}`
                      );
                    return new Promise((O, K) => {
                      if (M.fallbackToNoCallback)
                        try {
                          z[w](...k, l({ resolve: O, reject: K }, M));
                        } catch (H) {
                          console.warn(
                            `${w} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,
                            H
                          ),
                            z[w](...k),
                            (M.fallbackToNoCallback = !1),
                            (M.noCallback = !0),
                            O();
                        }
                      else
                        M.noCallback
                          ? (z[w](...k), O())
                          : z[w](...k, l({ resolve: O, reject: K }, M));
                    });
                  },
                c = (w, M, E) =>
                  new Proxy(M, {
                    apply(z, k, O) {
                      return E.call(k, w, ...O);
                    },
                  }),
                d = Function.call.bind(Object.prototype.hasOwnProperty),
                p = (w, M = {}, E = {}) => {
                  let z = Object.create(null),
                    k = {
                      has(K, H) {
                        return H in w || H in z;
                      },
                      get(K, H, V) {
                        if (H in z) return z[H];
                        if (!(H in w)) return;
                        let I = w[H];
                        if (typeof I == "function")
                          if (typeof M[H] == "function") I = c(w, w[H], M[H]);
                          else if (d(E, H)) {
                            let D = u(H, E[H]);
                            I = c(w, w[H], D);
                          } else I = I.bind(w);
                        else if (
                          typeof I == "object" &&
                          I !== null &&
                          (d(M, H) || d(E, H))
                        )
                          I = p(I, M[H], E[H]);
                        else if (d(E, "*")) I = p(I, M[H], E["*"]);
                        else
                          return (
                            Object.defineProperty(z, H, {
                              configurable: !0,
                              enumerable: !0,
                              get() {
                                return w[H];
                              },
                              set(D) {
                                w[H] = D;
                              },
                            }),
                            I
                          );
                        return (z[H] = I), I;
                      },
                      set(K, H, V, I) {
                        return H in z ? (z[H] = V) : (w[H] = V), !0;
                      },
                      defineProperty(K, H, V) {
                        return Reflect.defineProperty(z, H, V);
                      },
                      deleteProperty(K, H) {
                        return Reflect.deleteProperty(z, H);
                      },
                    },
                    O = Object.create(w);
                  return new Proxy(O, k);
                },
                m = (w) => ({
                  addListener(M, E, ...z) {
                    M.addListener(w.get(E), ...z);
                  },
                  hasListener(M, E) {
                    return M.hasListener(w.get(E));
                  },
                  removeListener(M, E) {
                    M.removeListener(w.get(E));
                  },
                }),
                f = new o((w) =>
                  typeof w != "function"
                    ? w
                    : function (E) {
                        let z = p(
                          E,
                          {},
                          { getContent: { minArgs: 0, maxArgs: 0 } }
                        );
                        w(z);
                      }
                ),
                v = new o((w) =>
                  typeof w != "function"
                    ? w
                    : function (E, z, k) {
                        let O = !1,
                          K,
                          H = new Promise((J) => {
                            K = function (R) {
                              (O = !0), J(R);
                            };
                          }),
                          V;
                        try {
                          V = w(E, z, K);
                        } catch (J) {
                          V = Promise.reject(J);
                        }
                        let I = V !== !0 && i(V);
                        if (V !== !0 && !I && !O) return !1;
                        let D = (J) => {
                          J.then(
                            (R) => {
                              k(R);
                            },
                            (R) => {
                              let T;
                              R &&
                              (R instanceof Error ||
                                typeof R.message == "string")
                                ? (T = R.message)
                                : (T = "An unexpected error occurred"),
                                k({
                                  __mozWebExtensionPolyfillReject__: !0,
                                  message: T,
                                });
                            }
                          ).catch((R) => {
                            console.error(
                              "Failed to send onMessage rejected reply",
                              R
                            );
                          });
                        };
                        return D(I ? V : H), !0;
                      }
                ),
                g = ({ reject: w, resolve: M }, E) => {
                  a.runtime.lastError
                    ? a.runtime.lastError.message === t
                      ? M()
                      : w(new Error(a.runtime.lastError.message))
                    : E && E.__mozWebExtensionPolyfillReject__
                    ? w(new Error(E.message))
                    : M(E);
                },
                _ = (w, M, E, ...z) => {
                  if (z.length < M.minArgs)
                    throw new Error(
                      `Expected at least ${M.minArgs} ${s(
                        M.minArgs
                      )} for ${w}(), got ${z.length}`
                    );
                  if (z.length > M.maxArgs)
                    throw new Error(
                      `Expected at most ${M.maxArgs} ${s(
                        M.maxArgs
                      )} for ${w}(), got ${z.length}`
                    );
                  return new Promise((k, O) => {
                    let K = g.bind(null, { resolve: k, reject: O });
                    z.push(K), E.sendMessage(...z);
                  });
                },
                C = {
                  devtools: { network: { onRequestFinished: m(f) } },
                  runtime: {
                    onMessage: m(v),
                    onMessageExternal: m(v),
                    sendMessage: _.bind(null, "sendMessage", {
                      minArgs: 1,
                      maxArgs: 3,
                    }),
                  },
                  tabs: {
                    sendMessage: _.bind(null, "sendMessage", {
                      minArgs: 2,
                      maxArgs: 3,
                    }),
                  },
                },
                y = {
                  clear: { minArgs: 1, maxArgs: 1 },
                  get: { minArgs: 1, maxArgs: 1 },
                  set: { minArgs: 1, maxArgs: 1 },
                };
              return (
                (r.privacy = {
                  network: { "*": y },
                  services: { "*": y },
                  websites: { "*": y },
                }),
                p(a, C, r)
              );
            };
          e.exports = n(chrome);
        } else e.exports = globalThis.browser;
      }
    );
  });
  var Ln = tt((ef, io) => {
    io.exports = function (t) {
      return (
        t != null &&
        t.constructor != null &&
        typeof t.constructor.isBuffer == "function" &&
        t.constructor.isBuffer(t)
      );
    };
  });
  var xo = tt((_f, yo) => {
    "use strict";
    var s1 = Object.prototype.hasOwnProperty,
      Eo = Object.prototype.toString,
      ho = Object.defineProperty,
      fo = Object.getOwnPropertyDescriptor,
      go = function (t) {
        return typeof Array.isArray == "function"
          ? Array.isArray(t)
          : Eo.call(t) === "[object Array]";
      },
      vo = function (t) {
        if (!t || Eo.call(t) !== "[object Object]") return !1;
        var n = s1.call(t, "constructor"),
          a =
            t.constructor &&
            t.constructor.prototype &&
            s1.call(t.constructor.prototype, "isPrototypeOf");
        if (t.constructor && !n && !a) return !1;
        var r;
        for (r in t);
        return typeof r > "u" || s1.call(t, r);
      },
      bo = function (t, n) {
        ho && n.name === "__proto__"
          ? ho(t, n.name, {
              enumerable: !0,
              configurable: !0,
              value: n.newValue,
              writable: !0,
            })
          : (t[n.name] = n.newValue);
      },
      _o = function (t, n) {
        if (n === "__proto__")
          if (s1.call(t, n)) {
            if (fo) return fo(t, n).value;
          } else return;
        return t[n];
      };
    yo.exports = function e() {
      var t,
        n,
        a,
        r,
        o,
        i,
        l = arguments[0],
        s = 1,
        u = arguments.length,
        c = !1;
      for (
        typeof l == "boolean" && ((c = l), (l = arguments[1] || {}), (s = 2)),
          (l == null || (typeof l != "object" && typeof l != "function")) &&
            (l = {});
        s < u;
        ++s
      )
        if (((t = arguments[s]), t != null))
          for (n in t)
            (a = _o(l, n)),
              (r = _o(t, n)),
              l !== r &&
                (c && r && (vo(r) || (o = go(r)))
                  ? (o
                      ? ((o = !1), (i = a && go(a) ? a : []))
                      : (i = a && vo(a) ? a : {}),
                    bo(l, { name: n, newValue: e(c, i, r) }))
                  : typeof r < "u" && bo(l, { name: n, newValue: r }));
      return l;
    };
  });
  var Vi = tt((Z_, Fi) => {
    "use strict";
    var $4 = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
    Fi.exports = $4;
  });
  var $i = tt((X_, Gi) => {
    "use strict";
    var q4 = Vi();
    function Bi() {}
    function Ui() {}
    Ui.resetWarningCache = Bi;
    Gi.exports = function () {
      function e(a, r, o, i, l, s) {
        if (s !== q4) {
          var u = new Error(
            "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
          );
          throw ((u.name = "Invariant Violation"), u);
        }
      }
      e.isRequired = e;
      function t() {
        return e;
      }
      var n = {
        array: e,
        bigint: e,
        bool: e,
        func: e,
        number: e,
        object: e,
        string: e,
        symbol: e,
        any: e,
        arrayOf: t,
        element: e,
        elementType: e,
        instanceOf: t,
        node: e,
        objectOf: t,
        oneOf: t,
        oneOfType: t,
        shape: t,
        exact: t,
        checkPropTypes: Ui,
        resetWarningCache: Bi,
      };
      return (n.PropTypes = n), n;
    };
  });
  var Wi = tt((tE, qi) => {
    qi.exports = $i()();
    var J_, eE;
  });
  var e2 = tt((fe) => {
    "use strict";
    var E0 = Symbol.for("react.element"),
      y0 = Symbol.for("react.portal"),
      I1 = Symbol.for("react.fragment"),
      T1 = Symbol.for("react.strict_mode"),
      N1 = Symbol.for("react.profiler"),
      L1 = Symbol.for("react.provider"),
      O1 = Symbol.for("react.context"),
      X4 = Symbol.for("react.server_context"),
      H1 = Symbol.for("react.forward_ref"),
      D1 = Symbol.for("react.suspense"),
      P1 = Symbol.for("react.suspense_list"),
      F1 = Symbol.for("react.memo"),
      V1 = Symbol.for("react.lazy"),
      J4 = Symbol.for("react.offscreen"),
      Ji;
    Ji = Symbol.for("react.module.reference");
    function it(e) {
      if (typeof e == "object" && e !== null) {
        var t = e.$$typeof;
        switch (t) {
          case E0:
            switch (((e = e.type), e)) {
              case I1:
              case N1:
              case T1:
              case D1:
              case P1:
                return e;
              default:
                switch (((e = e && e.$$typeof), e)) {
                  case X4:
                  case O1:
                  case H1:
                  case V1:
                  case F1:
                  case L1:
                    return e;
                  default:
                    return t;
                }
            }
          case y0:
            return t;
        }
      }
    }
    fe.ContextConsumer = O1;
    fe.ContextProvider = L1;
    fe.Element = E0;
    fe.ForwardRef = H1;
    fe.Fragment = I1;
    fe.Lazy = V1;
    fe.Memo = F1;
    fe.Portal = y0;
    fe.Profiler = N1;
    fe.StrictMode = T1;
    fe.Suspense = D1;
    fe.SuspenseList = P1;
    fe.isAsyncMode = function () {
      return !1;
    };
    fe.isConcurrentMode = function () {
      return !1;
    };
    fe.isContextConsumer = function (e) {
      return it(e) === O1;
    };
    fe.isContextProvider = function (e) {
      return it(e) === L1;
    };
    fe.isElement = function (e) {
      return typeof e == "object" && e !== null && e.$$typeof === E0;
    };
    fe.isForwardRef = function (e) {
      return it(e) === H1;
    };
    fe.isFragment = function (e) {
      return it(e) === I1;
    };
    fe.isLazy = function (e) {
      return it(e) === V1;
    };
    fe.isMemo = function (e) {
      return it(e) === F1;
    };
    fe.isPortal = function (e) {
      return it(e) === y0;
    };
    fe.isProfiler = function (e) {
      return it(e) === N1;
    };
    fe.isStrictMode = function (e) {
      return it(e) === T1;
    };
    fe.isSuspense = function (e) {
      return it(e) === D1;
    };
    fe.isSuspenseList = function (e) {
      return it(e) === P1;
    };
    fe.isValidElementType = function (e) {
      return (
        typeof e == "string" ||
        typeof e == "function" ||
        e === I1 ||
        e === N1 ||
        e === T1 ||
        e === D1 ||
        e === P1 ||
        e === J4 ||
        (typeof e == "object" &&
          e !== null &&
          (e.$$typeof === V1 ||
            e.$$typeof === F1 ||
            e.$$typeof === L1 ||
            e.$$typeof === O1 ||
            e.$$typeof === H1 ||
            e.$$typeof === Ji ||
            e.getModuleId !== void 0))
      );
    };
    fe.typeOf = it;
  });
  var n2 = tt((XE, t2) => {
    "use strict";
    t2.exports = e2();
  });
  var d2 = tt((ny, u2) => {
    var i2 = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//g,
      e6 = /\n/g,
      t6 = /^\s*/,
      n6 = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/,
      a6 = /^:\s*/,
      r6 = /^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/,
      o6 = /^[;\s]*/,
      i6 = /^\s+|\s+$/g,
      l6 = `
`,
      l2 = "/",
      c2 = "*",
      $t = "",
      c6 = "comment",
      s6 = "declaration";
    u2.exports = function (e, t) {
      if (typeof e != "string")
        throw new TypeError("First argument must be a string");
      if (!e) return [];
      t = t || {};
      var n = 1,
        a = 1;
      function r(v) {
        var g = v.match(e6);
        g && (n += g.length);
        var _ = v.lastIndexOf(l6);
        a = ~_ ? v.length - _ : a + v.length;
      }
      function o() {
        var v = { line: n, column: a };
        return function (g) {
          return (g.position = new i(v)), c(), g;
        };
      }
      function i(v) {
        (this.start = v),
          (this.end = { line: n, column: a }),
          (this.source = t.source);
      }
      i.prototype.content = e;
      var l = [];
      function s(v) {
        var g = new Error(t.source + ":" + n + ":" + a + ": " + v);
        if (
          ((g.reason = v),
          (g.filename = t.source),
          (g.line = n),
          (g.column = a),
          (g.source = e),
          t.silent)
        )
          l.push(g);
        else throw g;
      }
      function u(v) {
        var g = v.exec(e);
        if (!!g) {
          var _ = g[0];
          return r(_), (e = e.slice(_.length)), g;
        }
      }
      function c() {
        u(t6);
      }
      function d(v) {
        var g;
        for (v = v || []; (g = p()); ) g !== !1 && v.push(g);
        return v;
      }
      function p() {
        var v = o();
        if (!(l2 != e.charAt(0) || c2 != e.charAt(1))) {
          for (
            var g = 2;
            $t != e.charAt(g) && (c2 != e.charAt(g) || l2 != e.charAt(g + 1));

          )
            ++g;
          if (((g += 2), $t === e.charAt(g - 1)))
            return s("End of comment missing");
          var _ = e.slice(2, g - 2);
          return (
            (a += 2),
            r(_),
            (e = e.slice(g)),
            (a += 2),
            v({ type: c6, comment: _ })
          );
        }
      }
      function m() {
        var v = o(),
          g = u(n6);
        if (!!g) {
          if ((p(), !u(a6))) return s("property missing ':'");
          var _ = u(r6),
            C = v({
              type: s6,
              property: s2(g[0].replace(i2, $t)),
              value: _ ? s2(_[0].replace(i2, $t)) : $t,
            });
          return u(o6), C;
        }
      }
      function f() {
        var v = [];
        d(v);
        for (var g; (g = m()); ) g !== !1 && (v.push(g), d(v));
        return v;
      }
      return c(), f();
    };
    function s2(e) {
      return e ? e.replace(i6, $t) : $t;
    }
  });
  var m2 = tt((ay, p2) => {
    var u6 = d2();
    function d6(e, t) {
      var n = null;
      if (!e || typeof e != "string") return n;
      for (
        var a, r = u6(e), o = typeof t == "function", i, l, s = 0, u = r.length;
        s < u;
        s++
      )
        (a = r[s]),
          (i = a.property),
          (l = a.value),
          o ? t(i, l, a) : l && (n || (n = {}), (n[i] = l));
      return n;
    }
    p2.exports = d6;
  });
  var Fl = tt((ox, Pl) => {
    var N0 = { exports: {} };
    function L0(e) {
      return (
        e instanceof Map
          ? (e.clear =
              e.delete =
              e.set =
                function () {
                  throw new Error("map is read-only");
                })
          : e instanceof Set &&
            (e.add =
              e.clear =
              e.delete =
                function () {
                  throw new Error("set is read-only");
                }),
        Object.freeze(e),
        Object.getOwnPropertyNames(e).forEach(function (t) {
          var n = e[t];
          typeof n == "object" && !Object.isFrozen(n) && L0(n);
        }),
        e
      );
    }
    N0.exports = L0;
    N0.exports.default = L0;
    var Q1 = class {
      constructor(t) {
        t.data === void 0 && (t.data = {}),
          (this.data = t.data),
          (this.isMatchIgnored = !1);
      }
      ignoreMatch() {
        this.isMatchIgnored = !0;
      }
    };
    function Cl(e) {
      return e
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#x27;");
    }
    function Lt(e, ...t) {
      let n = Object.create(null);
      for (let a in e) n[a] = e[a];
      return (
        t.forEach(function (a) {
          for (let r in a) n[r] = a[r];
        }),
        n
      );
    }
    var Z6 = "</span>",
      xl = (e) => !!e.scope || (e.sublanguage && e.language),
      X6 = (e, { prefix: t }) => {
        if (e.includes(".")) {
          let n = e.split(".");
          return [
            `${t}${n.shift()}`,
            ...n.map((a, r) => `${a}${"_".repeat(r + 1)}`),
          ].join(" ");
        }
        return `${t}${e}`;
      },
      R0 = class {
        constructor(t, n) {
          (this.buffer = ""), (this.classPrefix = n.classPrefix), t.walk(this);
        }
        addText(t) {
          this.buffer += Cl(t);
        }
        openNode(t) {
          if (!xl(t)) return;
          let n = "";
          t.sublanguage
            ? (n = `language-${t.language}`)
            : (n = X6(t.scope, { prefix: this.classPrefix })),
            this.span(n);
        }
        closeNode(t) {
          !xl(t) || (this.buffer += Z6);
        }
        value() {
          return this.buffer;
        }
        span(t) {
          this.buffer += `<span class="${t}">`;
        }
      },
      wl = (e = {}) => {
        let t = { children: [] };
        return Object.assign(t, e), t;
      },
      O5 = class {
        constructor() {
          (this.rootNode = wl()), (this.stack = [this.rootNode]);
        }
        get top() {
          return this.stack[this.stack.length - 1];
        }
        get root() {
          return this.rootNode;
        }
        add(t) {
          this.top.children.push(t);
        }
        openNode(t) {
          let n = wl({ scope: t });
          this.add(n), this.stack.push(n);
        }
        closeNode() {
          if (this.stack.length > 1) return this.stack.pop();
        }
        closeAllNodes() {
          for (; this.closeNode(); );
        }
        toJSON() {
          return JSON.stringify(this.rootNode, null, 4);
        }
        walk(t) {
          return this.constructor._walk(t, this.rootNode);
        }
        static _walk(t, n) {
          return (
            typeof n == "string"
              ? t.addText(n)
              : n.children &&
                (t.openNode(n),
                n.children.forEach((a) => this._walk(t, a)),
                t.closeNode(n)),
            t
          );
        }
        static _collapse(t) {
          typeof t != "string" &&
            (!t.children ||
              (t.children.every((n) => typeof n == "string")
                ? (t.children = [t.children.join("")])
                : t.children.forEach((n) => {
                    O5._collapse(n);
                  })));
        }
      },
      I0 = class extends O5 {
        constructor(t) {
          super(), (this.options = t);
        }
        addKeyword(t, n) {
          t !== "" && (this.openNode(n), this.addText(t), this.closeNode());
        }
        addText(t) {
          t !== "" && this.add(t);
        }
        addSublanguage(t, n) {
          let a = t.root;
          (a.sublanguage = !0), (a.language = n), this.add(a);
        }
        toHTML() {
          return new R0(this, this.options).value();
        }
        finalize() {
          return !0;
        }
      };
    function H5(e) {
      return e ? (typeof e == "string" ? e : e.source) : null;
    }
    function kl(e) {
      return Wt("(?=", e, ")");
    }
    function J6(e) {
      return Wt("(?:", e, ")*");
    }
    function ed(e) {
      return Wt("(?:", e, ")?");
    }
    function Wt(...e) {
      return e.map((n) => H5(n)).join("");
    }
    function td(e) {
      let t = e[e.length - 1];
      return typeof t == "object" && t.constructor === Object
        ? (e.splice(e.length - 1, 1), t)
        : {};
    }
    function O0(...e) {
      return (
        "(" + (td(e).capture ? "" : "?:") + e.map((a) => H5(a)).join("|") + ")"
      );
    }
    function Rl(e) {
      return new RegExp(e.toString() + "|").exec("").length - 1;
    }
    function nd(e, t) {
      let n = e && e.exec(t);
      return n && n.index === 0;
    }
    var ad = /\[(?:[^\\\]]|\\.)*\]|\(\??|\\([1-9][0-9]*)|\\./;
    function H0(e, { joinWith: t }) {
      let n = 0;
      return e
        .map((a) => {
          n += 1;
          let r = n,
            o = H5(a),
            i = "";
          for (; o.length > 0; ) {
            let l = ad.exec(o);
            if (!l) {
              i += o;
              break;
            }
            (i += o.substring(0, l.index)),
              (o = o.substring(l.index + l[0].length)),
              l[0][0] === "\\" && l[1]
                ? (i += "\\" + String(Number(l[1]) + r))
                : ((i += l[0]), l[0] === "(" && n++);
          }
          return i;
        })
        .map((a) => `(${a})`)
        .join(t);
    }
    var rd = /\b\B/,
      Il = "[a-zA-Z]\\w*",
      D0 = "[a-zA-Z_]\\w*",
      Tl = "\\b\\d+(\\.\\d+)?",
      Nl =
        "(-?)(\\b0[xX][a-fA-F0-9]+|(\\b\\d+(\\.\\d*)?|\\.\\d+)([eE][-+]?\\d+)?)",
      Ll = "\\b(0b[01]+)",
      od =
        "!|!=|!==|%|%=|&|&&|&=|\\*|\\*=|\\+|\\+=|,|-|-=|/=|/|:|;|<<|<<=|<=|<|===|==|=|>>>=|>>=|>=|>>>|>>|>|\\?|\\[|\\{|\\(|\\^|\\^=|\\||\\|=|\\|\\||~",
      id = (e = {}) => {
        let t = /^#![ ]*\//;
        return (
          e.binary && (e.begin = Wt(t, /.*\b/, e.binary, /\b.*/)),
          Lt(
            {
              scope: "meta",
              begin: t,
              end: /$/,
              relevance: 0,
              "on:begin": (n, a) => {
                n.index !== 0 && a.ignoreMatch();
              },
            },
            e
          )
        );
      },
      D5 = { begin: "\\\\[\\s\\S]", relevance: 0 },
      ld = {
        scope: "string",
        begin: "'",
        end: "'",
        illegal: "\\n",
        contains: [D5],
      },
      cd = {
        scope: "string",
        begin: '"',
        end: '"',
        illegal: "\\n",
        contains: [D5],
      },
      sd = {
        begin:
          /\b(a|an|the|are|I'm|isn't|don't|doesn't|won't|but|just|should|pretty|simply|enough|gonna|going|wtf|so|such|will|you|your|they|like|more)\b/,
      },
      X1 = function (e, t, n = {}) {
        let a = Lt({ scope: "comment", begin: e, end: t, contains: [] }, n);
        a.contains.push({
          scope: "doctag",
          begin: "[ ]*(?=(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):)",
          end: /(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):/,
          excludeBegin: !0,
          relevance: 0,
        });
        let r = O0(
          "I",
          "a",
          "is",
          "so",
          "us",
          "to",
          "at",
          "if",
          "in",
          "it",
          "on",
          /[A-Za-z]+['](d|ve|re|ll|t|s|n)/,
          /[A-Za-z]+[-][a-z]+/,
          /[A-Za-z][a-z]{2,}/
        );
        return (
          a.contains.push({
            begin: Wt(/[ ]+/, "(", r, /[.]?[:]?([.][ ]|[ ])/, "){3}"),
          }),
          a
        );
      },
      ud = X1("//", "$"),
      dd = X1("/\\*", "\\*/"),
      pd = X1("#", "$"),
      md = { scope: "number", begin: Tl, relevance: 0 },
      hd = { scope: "number", begin: Nl, relevance: 0 },
      fd = { scope: "number", begin: Ll, relevance: 0 },
      gd = {
        begin: /(?=\/[^/\n]*\/)/,
        contains: [
          {
            scope: "regexp",
            begin: /\//,
            end: /\/[gimuy]*/,
            illegal: /\n/,
            contains: [
              D5,
              { begin: /\[/, end: /\]/, relevance: 0, contains: [D5] },
            ],
          },
        ],
      },
      vd = { scope: "title", begin: Il, relevance: 0 },
      bd = { scope: "title", begin: D0, relevance: 0 },
      _d = { begin: "\\.\\s*" + D0, relevance: 0 },
      Ed = function (e) {
        return Object.assign(e, {
          "on:begin": (t, n) => {
            n.data._beginMatch = t[1];
          },
          "on:end": (t, n) => {
            n.data._beginMatch !== t[1] && n.ignoreMatch();
          },
        });
      },
      Y1 = Object.freeze({
        __proto__: null,
        MATCH_NOTHING_RE: rd,
        IDENT_RE: Il,
        UNDERSCORE_IDENT_RE: D0,
        NUMBER_RE: Tl,
        C_NUMBER_RE: Nl,
        BINARY_NUMBER_RE: Ll,
        RE_STARTERS_RE: od,
        SHEBANG: id,
        BACKSLASH_ESCAPE: D5,
        APOS_STRING_MODE: ld,
        QUOTE_STRING_MODE: cd,
        PHRASAL_WORDS_MODE: sd,
        COMMENT: X1,
        C_LINE_COMMENT_MODE: ud,
        C_BLOCK_COMMENT_MODE: dd,
        HASH_COMMENT_MODE: pd,
        NUMBER_MODE: md,
        C_NUMBER_MODE: hd,
        BINARY_NUMBER_MODE: fd,
        REGEXP_MODE: gd,
        TITLE_MODE: vd,
        UNDERSCORE_TITLE_MODE: bd,
        METHOD_GUARD: _d,
        END_SAME_AS_BEGIN: Ed,
      });
    function yd(e, t) {
      e.input[e.index - 1] === "." && t.ignoreMatch();
    }
    function xd(e, t) {
      e.className !== void 0 && ((e.scope = e.className), delete e.className);
    }
    function wd(e, t) {
      !t ||
        !e.beginKeywords ||
        ((e.begin =
          "\\b(" +
          e.beginKeywords.split(" ").join("|") +
          ")(?!\\.)(?=\\b|\\s)"),
        (e.__beforeBegin = yd),
        (e.keywords = e.keywords || e.beginKeywords),
        delete e.beginKeywords,
        e.relevance === void 0 && (e.relevance = 0));
    }
    function Ad(e, t) {
      !Array.isArray(e.illegal) || (e.illegal = O0(...e.illegal));
    }
    function Md(e, t) {
      if (!!e.match) {
        if (e.begin || e.end)
          throw new Error("begin & end are not supported with match");
        (e.begin = e.match), delete e.match;
      }
    }
    function zd(e, t) {
      e.relevance === void 0 && (e.relevance = 1);
    }
    var Sd = (e, t) => {
        if (!e.beforeMatch) return;
        if (e.starts) throw new Error("beforeMatch cannot be used with starts");
        let n = Object.assign({}, e);
        Object.keys(e).forEach((a) => {
          delete e[a];
        }),
          (e.keywords = n.keywords),
          (e.begin = Wt(n.beforeMatch, kl(n.begin))),
          (e.starts = {
            relevance: 0,
            contains: [Object.assign(n, { endsParent: !0 })],
          }),
          (e.relevance = 0),
          delete n.beforeMatch;
      },
      Cd = [
        "of",
        "and",
        "for",
        "in",
        "not",
        "or",
        "if",
        "then",
        "parent",
        "list",
        "value",
      ],
      kd = "keyword";
    function Ol(e, t, n = kd) {
      let a = Object.create(null);
      return (
        typeof e == "string"
          ? r(n, e.split(" "))
          : Array.isArray(e)
          ? r(n, e)
          : Object.keys(e).forEach(function (o) {
              Object.assign(a, Ol(e[o], t, o));
            }),
        a
      );
      function r(o, i) {
        t && (i = i.map((l) => l.toLowerCase())),
          i.forEach(function (l) {
            let s = l.split("|");
            a[s[0]] = [o, Rd(s[0], s[1])];
          });
      }
    }
    function Rd(e, t) {
      return t ? Number(t) : Id(e) ? 0 : 1;
    }
    function Id(e) {
      return Cd.includes(e.toLowerCase());
    }
    var Al = {},
      qt = (e) => {
        console.error(e);
      },
      Ml = (e, ...t) => {
        console.log(`WARN: ${e}`, ...t);
      },
      s5 = (e, t) => {
        Al[`${e}/${t}`] ||
          (console.log(`Deprecated as of ${e}. ${t}`), (Al[`${e}/${t}`] = !0));
      },
      Z1 = new Error();
    function Hl(e, t, { key: n }) {
      let a = 0,
        r = e[n],
        o = {},
        i = {};
      for (let l = 1; l <= t.length; l++)
        (i[l + a] = r[l]), (o[l + a] = !0), (a += Rl(t[l - 1]));
      (e[n] = i), (e[n]._emit = o), (e[n]._multi = !0);
    }
    function Td(e) {
      if (!!Array.isArray(e.begin)) {
        if (e.skip || e.excludeBegin || e.returnBegin)
          throw (
            (qt(
              "skip, excludeBegin, returnBegin not compatible with beginScope: {}"
            ),
            Z1)
          );
        if (typeof e.beginScope != "object" || e.beginScope === null)
          throw (qt("beginScope must be object"), Z1);
        Hl(e, e.begin, { key: "beginScope" }),
          (e.begin = H0(e.begin, { joinWith: "" }));
      }
    }
    function Nd(e) {
      if (!!Array.isArray(e.end)) {
        if (e.skip || e.excludeEnd || e.returnEnd)
          throw (
            (qt("skip, excludeEnd, returnEnd not compatible with endScope: {}"),
            Z1)
          );
        if (typeof e.endScope != "object" || e.endScope === null)
          throw (qt("endScope must be object"), Z1);
        Hl(e, e.end, { key: "endScope" }),
          (e.end = H0(e.end, { joinWith: "" }));
      }
    }
    function Ld(e) {
      e.scope &&
        typeof e.scope == "object" &&
        e.scope !== null &&
        ((e.beginScope = e.scope), delete e.scope);
    }
    function Od(e) {
      Ld(e),
        typeof e.beginScope == "string" &&
          (e.beginScope = { _wrap: e.beginScope }),
        typeof e.endScope == "string" && (e.endScope = { _wrap: e.endScope }),
        Td(e),
        Nd(e);
    }
    function Hd(e) {
      function t(i, l) {
        return new RegExp(
          H5(i),
          "m" +
            (e.case_insensitive ? "i" : "") +
            (e.unicodeRegex ? "u" : "") +
            (l ? "g" : "")
        );
      }
      class n {
        constructor() {
          (this.matchIndexes = {}),
            (this.regexes = []),
            (this.matchAt = 1),
            (this.position = 0);
        }
        addRule(l, s) {
          (s.position = this.position++),
            (this.matchIndexes[this.matchAt] = s),
            this.regexes.push([s, l]),
            (this.matchAt += Rl(l) + 1);
        }
        compile() {
          this.regexes.length === 0 && (this.exec = () => null);
          let l = this.regexes.map((s) => s[1]);
          (this.matcherRe = t(H0(l, { joinWith: "|" }), !0)),
            (this.lastIndex = 0);
        }
        exec(l) {
          this.matcherRe.lastIndex = this.lastIndex;
          let s = this.matcherRe.exec(l);
          if (!s) return null;
          let u = s.findIndex((d, p) => p > 0 && d !== void 0),
            c = this.matchIndexes[u];
          return s.splice(0, u), Object.assign(s, c);
        }
      }
      class a {
        constructor() {
          (this.rules = []),
            (this.multiRegexes = []),
            (this.count = 0),
            (this.lastIndex = 0),
            (this.regexIndex = 0);
        }
        getMatcher(l) {
          if (this.multiRegexes[l]) return this.multiRegexes[l];
          let s = new n();
          return (
            this.rules.slice(l).forEach(([u, c]) => s.addRule(u, c)),
            s.compile(),
            (this.multiRegexes[l] = s),
            s
          );
        }
        resumingScanAtSamePosition() {
          return this.regexIndex !== 0;
        }
        considerAll() {
          this.regexIndex = 0;
        }
        addRule(l, s) {
          this.rules.push([l, s]), s.type === "begin" && this.count++;
        }
        exec(l) {
          let s = this.getMatcher(this.regexIndex);
          s.lastIndex = this.lastIndex;
          let u = s.exec(l);
          if (
            this.resumingScanAtSamePosition() &&
            !(u && u.index === this.lastIndex)
          ) {
            let c = this.getMatcher(0);
            (c.lastIndex = this.lastIndex + 1), (u = c.exec(l));
          }
          return (
            u &&
              ((this.regexIndex += u.position + 1),
              this.regexIndex === this.count && this.considerAll()),
            u
          );
        }
      }
      function r(i) {
        let l = new a();
        return (
          i.contains.forEach((s) =>
            l.addRule(s.begin, { rule: s, type: "begin" })
          ),
          i.terminatorEnd && l.addRule(i.terminatorEnd, { type: "end" }),
          i.illegal && l.addRule(i.illegal, { type: "illegal" }),
          l
        );
      }
      function o(i, l) {
        let s = i;
        if (i.isCompiled) return s;
        [xd, Md, Od, Sd].forEach((c) => c(i, l)),
          e.compilerExtensions.forEach((c) => c(i, l)),
          (i.__beforeBegin = null),
          [wd, Ad, zd].forEach((c) => c(i, l)),
          (i.isCompiled = !0);
        let u = null;
        return (
          typeof i.keywords == "object" &&
            i.keywords.$pattern &&
            ((i.keywords = Object.assign({}, i.keywords)),
            (u = i.keywords.$pattern),
            delete i.keywords.$pattern),
          (u = u || /\w+/),
          i.keywords && (i.keywords = Ol(i.keywords, e.case_insensitive)),
          (s.keywordPatternRe = t(u, !0)),
          l &&
            (i.begin || (i.begin = /\B|\b/),
            (s.beginRe = t(s.begin)),
            !i.end && !i.endsWithParent && (i.end = /\B|\b/),
            i.end && (s.endRe = t(s.end)),
            (s.terminatorEnd = H5(s.end) || ""),
            i.endsWithParent &&
              l.terminatorEnd &&
              (s.terminatorEnd += (i.end ? "|" : "") + l.terminatorEnd)),
          i.illegal && (s.illegalRe = t(i.illegal)),
          i.contains || (i.contains = []),
          (i.contains = [].concat(
            ...i.contains.map(function (c) {
              return Dd(c === "self" ? i : c);
            })
          )),
          i.contains.forEach(function (c) {
            o(c, s);
          }),
          i.starts && o(i.starts, l),
          (s.matcher = r(s)),
          s
        );
      }
      if (
        (e.compilerExtensions || (e.compilerExtensions = []),
        e.contains && e.contains.includes("self"))
      )
        throw new Error(
          "ERR: contains `self` is not supported at the top-level of a language.  See documentation."
        );
      return (e.classNameAliases = Lt(e.classNameAliases || {})), o(e);
    }
    function Dl(e) {
      return e ? e.endsWithParent || Dl(e.starts) : !1;
    }
    function Dd(e) {
      return (
        e.variants &&
          !e.cachedVariants &&
          (e.cachedVariants = e.variants.map(function (t) {
            return Lt(e, { variants: null }, t);
          })),
        e.cachedVariants
          ? e.cachedVariants
          : Dl(e)
          ? Lt(e, { starts: e.starts ? Lt(e.starts) : null })
          : Object.isFrozen(e)
          ? Lt(e)
          : e
      );
    }
    var Pd = "11.7.0",
      T0 = class extends Error {
        constructor(t, n) {
          super(t), (this.name = "HTMLInjectionError"), (this.html = n);
        }
      },
      k0 = Cl,
      zl = Lt,
      Sl = Symbol("nomatch"),
      Fd = 7,
      Vd = function (e) {
        let t = Object.create(null),
          n = Object.create(null),
          a = [],
          r = !0,
          o =
            "Could not find the language '{}', did you forget to load/include a language module?",
          i = { disableAutodetect: !0, name: "Plain text", contains: [] },
          l = {
            ignoreUnescapedHTML: !1,
            throwUnescapedHTML: !1,
            noHighlightRe: /^(no-?highlight)$/i,
            languageDetectRe: /\blang(?:uage)?-([\w-]+)\b/i,
            classPrefix: "hljs-",
            cssSelector: "pre code",
            languages: null,
            __emitter: I0,
          };
        function s(R) {
          return l.noHighlightRe.test(R);
        }
        function u(R) {
          let T = R.className + " ";
          T += R.parentNode ? R.parentNode.className : "";
          let P = l.languageDetectRe.exec(T);
          if (P) {
            let B = O(P[1]);
            return (
              B ||
                (Ml(o.replace("{}", P[1])),
                Ml("Falling back to no-highlight mode for this block.", R)),
              B ? P[1] : "no-highlight"
            );
          }
          return T.split(/\s+/).find((B) => s(B) || O(B));
        }
        function c(R, T, P) {
          let B = "",
            $ = "";
          typeof T == "object"
            ? ((B = R), (P = T.ignoreIllegals), ($ = T.language))
            : (s5(
                "10.7.0",
                "highlight(lang, code, ...args) has been deprecated."
              ),
              s5(
                "10.7.0",
                `Please use highlight(code, options) instead.
https://github.com/highlightjs/highlight.js/issues/2277`
              ),
              ($ = R),
              (B = T)),
            P === void 0 && (P = !0);
          let b = { code: B, language: $ };
          D("before:highlight", b);
          let h = b.result ? b.result : d(b.language, b.code, P);
          return (h.code = b.code), D("after:highlight", h), h;
        }
        function d(R, T, P, B) {
          let $ = Object.create(null);
          function b(F, G) {
            return F.keywords[G];
          }
          function h() {
            if (!j.keywords) {
              _e.addText(de);
              return;
            }
            let F = 0;
            j.keywordPatternRe.lastIndex = 0;
            let G = j.keywordPatternRe.exec(de),
              ee = "";
            for (; G; ) {
              ee += de.substring(F, G.index);
              let A = $e.case_insensitive ? G[0].toLowerCase() : G[0],
                N = b(j, A);
              if (N) {
                let [q, re] = N;
                if (
                  (_e.addText(ee),
                  (ee = ""),
                  ($[A] = ($[A] || 0) + 1),
                  $[A] <= Fd && (Xe += re),
                  q.startsWith("_"))
                )
                  ee += G[0];
                else {
                  let Oe = $e.classNameAliases[q] || q;
                  _e.addKeyword(G[0], Oe);
                }
              } else ee += G[0];
              (F = j.keywordPatternRe.lastIndex),
                (G = j.keywordPatternRe.exec(de));
            }
            (ee += de.substring(F)), _e.addText(ee);
          }
          function Le() {
            if (de === "") return;
            let F = null;
            if (typeof j.subLanguage == "string") {
              if (!t[j.subLanguage]) {
                _e.addText(de);
                return;
              }
              (F = d(j.subLanguage, de, !0, zt[j.subLanguage])),
                (zt[j.subLanguage] = F._top);
            } else F = m(de, j.subLanguage.length ? j.subLanguage : null);
            j.relevance > 0 && (Xe += F.relevance),
              _e.addSublanguage(F._emitter, F.language);
          }
          function le() {
            j.subLanguage != null ? Le() : h(), (de = "");
          }
          function me(F, G) {
            let ee = 1,
              A = G.length - 1;
            for (; ee <= A; ) {
              if (!F._emit[ee]) {
                ee++;
                continue;
              }
              let N = $e.classNameAliases[F[ee]] || F[ee],
                q = G[ee];
              N ? _e.addKeyword(q, N) : ((de = q), h(), (de = "")), ee++;
            }
          }
          function Ge(F, G) {
            return (
              F.scope &&
                typeof F.scope == "string" &&
                _e.openNode($e.classNameAliases[F.scope] || F.scope),
              F.beginScope &&
                (F.beginScope._wrap
                  ? (_e.addKeyword(
                      de,
                      $e.classNameAliases[F.beginScope._wrap] ||
                        F.beginScope._wrap
                    ),
                    (de = ""))
                  : F.beginScope._multi && (me(F.beginScope, G), (de = ""))),
              (j = Object.create(F, { parent: { value: j } })),
              j
            );
          }
          function Me(F, G, ee) {
            let A = nd(F.endRe, ee);
            if (A) {
              if (F["on:end"]) {
                let N = new Q1(F);
                F["on:end"](G, N), N.isMatchIgnored && (A = !1);
              }
              if (A) {
                for (; F.endsParent && F.parent; ) F = F.parent;
                return F;
              }
            }
            if (F.endsWithParent) return Me(F.parent, G, ee);
          }
          function be(F) {
            return j.matcher.regexIndex === 0
              ? ((de += F[0]), 1)
              : ((dt = !0), 0);
          }
          function ae(F) {
            let G = F[0],
              ee = F.rule,
              A = new Q1(ee),
              N = [ee.__beforeBegin, ee["on:begin"]];
            for (let q of N)
              if (!!q && (q(F, A), A.isMatchIgnored)) return be(G);
            return (
              ee.skip
                ? (de += G)
                : (ee.excludeBegin && (de += G),
                  le(),
                  !ee.returnBegin && !ee.excludeBegin && (de = G)),
              Ge(ee, F),
              ee.returnBegin ? 0 : G.length
            );
          }
          function ze(F) {
            let G = F[0],
              ee = T.substring(F.index),
              A = Me(j, F, ee);
            if (!A) return Sl;
            let N = j;
            j.endScope && j.endScope._wrap
              ? (le(), _e.addKeyword(G, j.endScope._wrap))
              : j.endScope && j.endScope._multi
              ? (le(), me(j.endScope, F))
              : N.skip
              ? (de += G)
              : (N.returnEnd || N.excludeEnd || (de += G),
                le(),
                N.excludeEnd && (de = G));
            do
              j.scope && _e.closeNode(),
                !j.skip && !j.subLanguage && (Xe += j.relevance),
                (j = j.parent);
            while (j !== A.parent);
            return A.starts && Ge(A.starts, F), N.returnEnd ? 0 : G.length;
          }
          function Ce() {
            let F = [];
            for (let G = j; G !== $e; G = G.parent)
              G.scope && F.unshift(G.scope);
            F.forEach((G) => _e.openNode(G));
          }
          let Te = {};
          function Pe(F, G) {
            let ee = G && G[0];
            if (((de += F), ee == null)) return le(), 0;
            if (
              Te.type === "begin" &&
              G.type === "end" &&
              Te.index === G.index &&
              ee === ""
            ) {
              if (((de += T.slice(G.index, G.index + 1)), !r)) {
                let A = new Error(`0 width match regex (${R})`);
                throw ((A.languageName = R), (A.badRule = Te.rule), A);
              }
              return 1;
            }
            if (((Te = G), G.type === "begin")) return ae(G);
            if (G.type === "illegal" && !P) {
              let A = new Error(
                'Illegal lexeme "' +
                  ee +
                  '" for mode "' +
                  (j.scope || "<unnamed>") +
                  '"'
              );
              throw ((A.mode = j), A);
            } else if (G.type === "end") {
              let A = ze(G);
              if (A !== Sl) return A;
            }
            if (G.type === "illegal" && ee === "") return 1;
            if (ut > 1e5 && ut > G.index * 3)
              throw new Error(
                "potential infinite loop, way more iterations than matches"
              );
            return (de += ee), ee.length;
          }
          let $e = O(R);
          if (!$e)
            throw (
              (qt(o.replace("{}", R)),
              new Error('Unknown language: "' + R + '"'))
            );
          let st = Hd($e),
            Mt = "",
            j = B || st,
            zt = {},
            _e = new l.__emitter(l);
          Ce();
          let de = "",
            Xe = 0,
            Fe = 0,
            ut = 0,
            dt = !1;
          try {
            for (j.matcher.considerAll(); ; ) {
              ut++,
                dt ? (dt = !1) : j.matcher.considerAll(),
                (j.matcher.lastIndex = Fe);
              let F = j.matcher.exec(T);
              if (!F) break;
              let G = T.substring(Fe, F.index),
                ee = Pe(G, F);
              Fe = F.index + ee;
            }
            return (
              Pe(T.substring(Fe)),
              _e.closeAllNodes(),
              _e.finalize(),
              (Mt = _e.toHTML()),
              {
                language: R,
                value: Mt,
                relevance: Xe,
                illegal: !1,
                _emitter: _e,
                _top: j,
              }
            );
          } catch (F) {
            if (F.message && F.message.includes("Illegal"))
              return {
                language: R,
                value: k0(T),
                illegal: !0,
                relevance: 0,
                _illegalBy: {
                  message: F.message,
                  index: Fe,
                  context: T.slice(Fe - 100, Fe + 100),
                  mode: F.mode,
                  resultSoFar: Mt,
                },
                _emitter: _e,
              };
            if (r)
              return {
                language: R,
                value: k0(T),
                illegal: !1,
                relevance: 0,
                errorRaised: F,
                _emitter: _e,
                _top: j,
              };
            throw F;
          }
        }
        function p(R) {
          let T = {
            value: k0(R),
            illegal: !1,
            relevance: 0,
            _top: i,
            _emitter: new l.__emitter(l),
          };
          return T._emitter.addText(R), T;
        }
        function m(R, T) {
          T = T || l.languages || Object.keys(t);
          let P = p(R),
            B = T.filter(O)
              .filter(H)
              .map((le) => d(le, R, !1));
          B.unshift(P);
          let $ = B.sort((le, me) => {
              if (le.relevance !== me.relevance)
                return me.relevance - le.relevance;
              if (le.language && me.language) {
                if (O(le.language).supersetOf === me.language) return 1;
                if (O(me.language).supersetOf === le.language) return -1;
              }
              return 0;
            }),
            [b, h] = $,
            Le = b;
          return (Le.secondBest = h), Le;
        }
        function f(R, T, P) {
          let B = (T && n[T]) || P;
          R.classList.add("hljs"), R.classList.add(`language-${B}`);
        }
        function v(R) {
          let T = null,
            P = u(R);
          if (s(P)) return;
          if (
            (D("before:highlightElement", { el: R, language: P }),
            R.children.length > 0 &&
              (l.ignoreUnescapedHTML ||
                (console.warn(
                  "One of your code blocks includes unescaped HTML. This is a potentially serious security risk."
                ),
                console.warn(
                  "https://github.com/highlightjs/highlight.js/wiki/security"
                ),
                console.warn("The element with unescaped HTML:"),
                console.warn(R)),
              l.throwUnescapedHTML))
          )
            throw new T0(
              "One of your code blocks includes unescaped HTML.",
              R.innerHTML
            );
          T = R;
          let B = T.textContent,
            $ = P ? c(B, { language: P, ignoreIllegals: !0 }) : m(B);
          (R.innerHTML = $.value),
            f(R, P, $.language),
            (R.result = {
              language: $.language,
              re: $.relevance,
              relevance: $.relevance,
            }),
            $.secondBest &&
              (R.secondBest = {
                language: $.secondBest.language,
                relevance: $.secondBest.relevance,
              }),
            D("after:highlightElement", { el: R, result: $, text: B });
        }
        function g(R) {
          l = zl(l, R);
        }
        let _ = () => {
          w(),
            s5(
              "10.6.0",
              "initHighlighting() deprecated.  Use highlightAll() now."
            );
        };
        function C() {
          w(),
            s5(
              "10.6.0",
              "initHighlightingOnLoad() deprecated.  Use highlightAll() now."
            );
        }
        let y = !1;
        function w() {
          if (document.readyState === "loading") {
            y = !0;
            return;
          }
          document.querySelectorAll(l.cssSelector).forEach(v);
        }
        function M() {
          y && w();
        }
        typeof window < "u" &&
          window.addEventListener &&
          window.addEventListener("DOMContentLoaded", M, !1);
        function E(R, T) {
          let P = null;
          try {
            P = T(e);
          } catch (B) {
            if (
              (qt(
                "Language definition for '{}' could not be registered.".replace(
                  "{}",
                  R
                )
              ),
              r)
            )
              qt(B);
            else throw B;
            P = i;
          }
          P.name || (P.name = R),
            (t[R] = P),
            (P.rawDefinition = T.bind(null, e)),
            P.aliases && K(P.aliases, { languageName: R });
        }
        function z(R) {
          delete t[R];
          for (let T of Object.keys(n)) n[T] === R && delete n[T];
        }
        function k() {
          return Object.keys(t);
        }
        function O(R) {
          return (R = (R || "").toLowerCase()), t[R] || t[n[R]];
        }
        function K(R, { languageName: T }) {
          typeof R == "string" && (R = [R]),
            R.forEach((P) => {
              n[P.toLowerCase()] = T;
            });
        }
        function H(R) {
          let T = O(R);
          return T && !T.disableAutodetect;
        }
        function V(R) {
          R["before:highlightBlock"] &&
            !R["before:highlightElement"] &&
            (R["before:highlightElement"] = (T) => {
              R["before:highlightBlock"](Object.assign({ block: T.el }, T));
            }),
            R["after:highlightBlock"] &&
              !R["after:highlightElement"] &&
              (R["after:highlightElement"] = (T) => {
                R["after:highlightBlock"](Object.assign({ block: T.el }, T));
              });
        }
        function I(R) {
          V(R), a.push(R);
        }
        function D(R, T) {
          let P = R;
          a.forEach(function (B) {
            B[P] && B[P](T);
          });
        }
        function J(R) {
          return (
            s5("10.7.0", "highlightBlock will be removed entirely in v12.0"),
            s5("10.7.0", "Please use highlightElement now."),
            v(R)
          );
        }
        Object.assign(e, {
          highlight: c,
          highlightAuto: m,
          highlightAll: w,
          highlightElement: v,
          highlightBlock: J,
          configure: g,
          initHighlighting: _,
          initHighlightingOnLoad: C,
          registerLanguage: E,
          unregisterLanguage: z,
          listLanguages: k,
          getLanguage: O,
          registerAliases: K,
          autoDetection: H,
          inherit: zl,
          addPlugin: I,
        }),
          (e.debugMode = function () {
            r = !1;
          }),
          (e.safeMode = function () {
            r = !0;
          }),
          (e.versionString = Pd),
          (e.regex = {
            concat: Wt,
            lookahead: kl,
            either: O0,
            optional: ed,
            anyNumberOfTimes: J6,
          });
        for (let R in Y1) typeof Y1[R] == "object" && N0.exports(Y1[R]);
        return Object.assign(e, Y1), e;
      },
      P5 = Vd({});
    Pl.exports = P5;
    P5.HighlightJS = P5;
    P5.default = P5;
  });
  var Bl = tt((lx, P0) => {
    (function () {
      var e;
      typeof P0 < "u"
        ? (e = P0.exports = a)
        : (e = (function () {
            return this || (0, eval)("this");
          })()),
        (e.format = a),
        (e.vsprintf = n),
        typeof console < "u" &&
          typeof console.log == "function" &&
          (e.printf = t);
      function t() {
        console.log(a.apply(null, arguments));
      }
      function n(r, o) {
        return a.apply(null, [r].concat(o));
      }
      function a(r) {
        for (
          var o = 1,
            i = [].slice.call(arguments),
            l = 0,
            s = r.length,
            u = "",
            c,
            d = !1,
            p,
            m,
            f = !1,
            v,
            g = function () {
              return i[o++];
            },
            _ = function () {
              for (var C = ""; /\d/.test(r[l]); ) (C += r[l++]), (c = r[l]);
              return C.length > 0 ? parseInt(C) : null;
            };
          l < s;
          ++l
        )
          if (((c = r[l]), d))
            switch (
              ((d = !1),
              c == "."
                ? ((f = !1), (c = r[++l]))
                : c == "0" && r[l + 1] == "."
                ? ((f = !0), (l += 2), (c = r[l]))
                : (f = !0),
              (v = _()),
              c)
            ) {
              case "b":
                u += parseInt(g(), 10).toString(2);
                break;
              case "c":
                (p = g()),
                  typeof p == "string" || p instanceof String
                    ? (u += p)
                    : (u += String.fromCharCode(parseInt(p, 10)));
                break;
              case "d":
                u += parseInt(g(), 10);
                break;
              case "f":
                (m = String(parseFloat(g()).toFixed(v || 6))),
                  (u += f ? m : m.replace(/^0/, ""));
                break;
              case "j":
                u += JSON.stringify(g());
                break;
              case "o":
                u += "0" + parseInt(g(), 10).toString(8);
                break;
              case "s":
                u += g();
                break;
              case "x":
                u += "0x" + parseInt(g(), 10).toString(16);
                break;
              case "X":
                u += "0x" + parseInt(g(), 10).toString(16).toUpperCase();
                break;
              default:
                u += c;
                break;
            }
          else c === "%" ? (d = !0) : (u += c);
        return u;
      }
    })();
  });
  var g5,
    W,
    Ca,
    hc,
    m5,
    Aa,
    ka,
    q5 = {},
    Ra = [],
    fc = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
  function Et(e, t) {
    for (var n in t) e[n] = t[n];
    return e;
  }
  function Ia(e) {
    var t = e.parentNode;
    t && t.removeChild(e);
  }
  function mt(e, t, n) {
    var a,
      r,
      o,
      i = {};
    for (o in t)
      o == "key" ? (a = t[o]) : o == "ref" ? (r = t[o]) : (i[o] = t[o]);
    if (
      (arguments.length > 2 &&
        (i.children = arguments.length > 3 ? g5.call(arguments, 2) : n),
      typeof e == "function" && e.defaultProps != null)
    )
      for (o in e.defaultProps) i[o] === void 0 && (i[o] = e.defaultProps[o]);
    return h5(e, i, a, r, null);
  }
  function h5(e, t, n, a, r) {
    var o = {
      type: e,
      props: t,
      key: n,
      ref: a,
      __k: null,
      __: null,
      __b: 0,
      __e: null,
      __d: void 0,
      __c: null,
      __h: null,
      constructor: void 0,
      __v: r ?? ++Ca,
    };
    return r == null && W.vnode != null && W.vnode(o), o;
  }
  function hn() {
    return { current: null };
  }
  function ht(e) {
    return e.children;
  }
  function nt(e, t) {
    (this.props = e), (this.context = t);
  }
  function f5(e, t) {
    if (t == null) return e.__ ? f5(e.__, e.__.__k.indexOf(e) + 1) : null;
    for (var n; t < e.__k.length; t++)
      if ((n = e.__k[t]) != null && n.__e != null) return n.__e;
    return typeof e.type == "function" ? f5(e) : null;
  }
  function Ta(e) {
    var t, n;
    if ((e = e.__) != null && e.__c != null) {
      for (e.__e = e.__c.base = null, t = 0; t < e.__k.length; t++)
        if ((n = e.__k[t]) != null && n.__e != null) {
          e.__e = e.__c.base = n.__e;
          break;
        }
      return Ta(e);
    }
  }
  function mn(e) {
    ((!e.__d && (e.__d = !0) && m5.push(e) && !W5.__r++) ||
      Aa !== W.debounceRendering) &&
      ((Aa = W.debounceRendering) || setTimeout)(W5);
  }
  function W5() {
    for (var e; (W5.__r = m5.length); )
      (e = m5.sort(function (t, n) {
        return t.__v.__b - n.__v.__b;
      })),
        (m5 = []),
        e.some(function (t) {
          var n, a, r, o, i, l;
          t.__d &&
            ((i = (o = (n = t).__v).__e),
            (l = n.__P) &&
              ((a = []),
              ((r = Et({}, o)).__v = o.__v + 1),
              fn(
                l,
                o,
                r,
                n.__n,
                l.ownerSVGElement !== void 0,
                o.__h != null ? [i] : null,
                a,
                i ?? f5(o),
                o.__h
              ),
              Ha(a, o),
              o.__e != i && Ta(o)));
        });
  }
  function Na(e, t, n, a, r, o, i, l, s, u) {
    var c,
      d,
      p,
      m,
      f,
      v,
      g,
      _ = (a && a.__k) || Ra,
      C = _.length;
    for (n.__k = [], c = 0; c < t.length; c++)
      if (
        (m = n.__k[c] =
          (m = t[c]) == null || typeof m == "boolean"
            ? null
            : typeof m == "string" ||
              typeof m == "number" ||
              typeof m == "bigint"
            ? h5(null, m, null, null, m)
            : Array.isArray(m)
            ? h5(ht, { children: m }, null, null, null)
            : m.__b > 0
            ? h5(m.type, m.props, m.key, m.ref ? m.ref : null, m.__v)
            : m) != null
      ) {
        if (
          ((m.__ = n),
          (m.__b = n.__b + 1),
          (p = _[c]) === null || (p && m.key == p.key && m.type === p.type))
        )
          _[c] = void 0;
        else
          for (d = 0; d < C; d++) {
            if ((p = _[d]) && m.key == p.key && m.type === p.type) {
              _[d] = void 0;
              break;
            }
            p = null;
          }
        fn(e, m, (p = p || q5), r, o, i, l, s, u),
          (f = m.__e),
          (d = m.ref) &&
            p.ref != d &&
            (g || (g = []),
            p.ref && g.push(p.ref, null, m),
            g.push(d, m.__c || f, m)),
          f != null
            ? (v == null && (v = f),
              typeof m.type == "function" && m.__k === p.__k
                ? (m.__d = s = La(m, s, e))
                : (s = Oa(e, m, p, _, f, s)),
              typeof n.type == "function" && (n.__d = s))
            : s && p.__e == s && s.parentNode != e && (s = f5(p));
      }
    for (n.__e = v, c = C; c--; ) _[c] != null && Pa(_[c], _[c]);
    if (g) for (c = 0; c < g.length; c++) Da(g[c], g[++c], g[++c]);
  }
  function La(e, t, n) {
    for (var a, r = e.__k, o = 0; r && o < r.length; o++)
      (a = r[o]) &&
        ((a.__ = e),
        (t =
          typeof a.type == "function"
            ? La(a, t, n)
            : Oa(n, a, a, r, a.__e, t)));
    return t;
  }
  function gt(e, t) {
    return (
      (t = t || []),
      e == null ||
        typeof e == "boolean" ||
        (Array.isArray(e)
          ? e.some(function (n) {
              gt(n, t);
            })
          : t.push(e)),
      t
    );
  }
  function Oa(e, t, n, a, r, o) {
    var i, l, s;
    if (t.__d !== void 0) (i = t.__d), (t.__d = void 0);
    else if (n == null || r != o || r.parentNode == null)
      e: if (o == null || o.parentNode !== e) e.appendChild(r), (i = null);
      else {
        for (l = o, s = 0; (l = l.nextSibling) && s < a.length; s += 1)
          if (l == r) break e;
        e.insertBefore(r, o), (i = o);
      }
    return i !== void 0 ? i : r.nextSibling;
  }
  function gc(e, t, n, a, r) {
    var o;
    for (o in n)
      o === "children" || o === "key" || o in t || K5(e, o, null, n[o], a);
    for (o in t)
      (r && typeof t[o] != "function") ||
        o === "children" ||
        o === "key" ||
        o === "value" ||
        o === "checked" ||
        n[o] === t[o] ||
        K5(e, o, t[o], n[o], a);
  }
  function Ma(e, t, n) {
    t[0] === "-"
      ? e.setProperty(t, n)
      : (e[t] =
          n == null ? "" : typeof n != "number" || fc.test(t) ? n : n + "px");
  }
  function K5(e, t, n, a, r) {
    var o;
    e: if (t === "style")
      if (typeof n == "string") e.style.cssText = n;
      else {
        if ((typeof a == "string" && (e.style.cssText = a = ""), a))
          for (t in a) (n && t in n) || Ma(e.style, t, "");
        if (n) for (t in n) (a && n[t] === a[t]) || Ma(e.style, t, n[t]);
      }
    else if (t[0] === "o" && t[1] === "n")
      (o = t !== (t = t.replace(/Capture$/, ""))),
        (t = t.toLowerCase() in e ? t.toLowerCase().slice(2) : t.slice(2)),
        e.l || (e.l = {}),
        (e.l[t + o] = n),
        n
          ? a || e.addEventListener(t, o ? Sa : za, o)
          : e.removeEventListener(t, o ? Sa : za, o);
    else if (t !== "dangerouslySetInnerHTML") {
      if (r) t = t.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
      else if (
        t !== "href" &&
        t !== "list" &&
        t !== "form" &&
        t !== "tabIndex" &&
        t !== "download" &&
        t in e
      )
        try {
          e[t] = n ?? "";
          break e;
        } catch {}
      typeof n == "function" ||
        (n == null || (n === !1 && t.indexOf("-") == -1)
          ? e.removeAttribute(t)
          : e.setAttribute(t, n));
    }
  }
  function za(e) {
    this.l[e.type + !1](W.event ? W.event(e) : e);
  }
  function Sa(e) {
    this.l[e.type + !0](W.event ? W.event(e) : e);
  }
  function fn(e, t, n, a, r, o, i, l, s) {
    var u,
      c,
      d,
      p,
      m,
      f,
      v,
      g,
      _,
      C,
      y,
      w,
      M,
      E,
      z,
      k = t.type;
    if (t.constructor !== void 0) return null;
    n.__h != null &&
      ((s = n.__h), (l = t.__e = n.__e), (t.__h = null), (o = [l])),
      (u = W.__b) && u(t);
    try {
      e: if (typeof k == "function") {
        if (
          ((g = t.props),
          (_ = (u = k.contextType) && a[u.__c]),
          (C = u ? (_ ? _.props.value : u.__) : a),
          n.__c
            ? (v = (c = t.__c = n.__c).__ = c.__E)
            : ("prototype" in k && k.prototype.render
                ? (t.__c = c = new k(g, C))
                : ((t.__c = c = new nt(g, C)),
                  (c.constructor = k),
                  (c.render = bc)),
              _ && _.sub(c),
              (c.props = g),
              c.state || (c.state = {}),
              (c.context = C),
              (c.__n = a),
              (d = c.__d = !0),
              (c.__h = []),
              (c._sb = [])),
          c.__s == null && (c.__s = c.state),
          k.getDerivedStateFromProps != null &&
            (c.__s == c.state && (c.__s = Et({}, c.__s)),
            Et(c.__s, k.getDerivedStateFromProps(g, c.__s))),
          (p = c.props),
          (m = c.state),
          d)
        )
          k.getDerivedStateFromProps == null &&
            c.componentWillMount != null &&
            c.componentWillMount(),
            c.componentDidMount != null && c.__h.push(c.componentDidMount);
        else {
          if (
            (k.getDerivedStateFromProps == null &&
              g !== p &&
              c.componentWillReceiveProps != null &&
              c.componentWillReceiveProps(g, C),
            (!c.__e &&
              c.shouldComponentUpdate != null &&
              c.shouldComponentUpdate(g, c.__s, C) === !1) ||
              t.__v === n.__v)
          ) {
            for (
              c.props = g,
                c.state = c.__s,
                t.__v !== n.__v && (c.__d = !1),
                c.__v = t,
                t.__e = n.__e,
                t.__k = n.__k,
                t.__k.forEach(function (O) {
                  O && (O.__ = t);
                }),
                y = 0;
              y < c._sb.length;
              y++
            )
              c.__h.push(c._sb[y]);
            (c._sb = []), c.__h.length && i.push(c);
            break e;
          }
          c.componentWillUpdate != null && c.componentWillUpdate(g, c.__s, C),
            c.componentDidUpdate != null &&
              c.__h.push(function () {
                c.componentDidUpdate(p, m, f);
              });
        }
        if (
          ((c.context = C),
          (c.props = g),
          (c.__v = t),
          (c.__P = e),
          (w = W.__r),
          (M = 0),
          "prototype" in k && k.prototype.render)
        ) {
          for (
            c.state = c.__s,
              c.__d = !1,
              w && w(t),
              u = c.render(c.props, c.state, c.context),
              E = 0;
            E < c._sb.length;
            E++
          )
            c.__h.push(c._sb[E]);
          c._sb = [];
        } else
          do
            (c.__d = !1),
              w && w(t),
              (u = c.render(c.props, c.state, c.context)),
              (c.state = c.__s);
          while (c.__d && ++M < 25);
        (c.state = c.__s),
          c.getChildContext != null && (a = Et(Et({}, a), c.getChildContext())),
          d ||
            c.getSnapshotBeforeUpdate == null ||
            (f = c.getSnapshotBeforeUpdate(p, m)),
          (z =
            u != null && u.type === ht && u.key == null ? u.props.children : u),
          Na(e, Array.isArray(z) ? z : [z], t, n, a, r, o, i, l, s),
          (c.base = t.__e),
          (t.__h = null),
          c.__h.length && i.push(c),
          v && (c.__E = c.__ = null),
          (c.__e = !1);
      } else
        o == null && t.__v === n.__v
          ? ((t.__k = n.__k), (t.__e = n.__e))
          : (t.__e = vc(n.__e, t, n, a, r, o, i, s));
      (u = W.diffed) && u(t);
    } catch (O) {
      (t.__v = null),
        (s || o != null) &&
          ((t.__e = l), (t.__h = !!s), (o[o.indexOf(l)] = null)),
        W.__e(O, t, n);
    }
  }
  function Ha(e, t) {
    W.__c && W.__c(t, e),
      e.some(function (n) {
        try {
          (e = n.__h),
            (n.__h = []),
            e.some(function (a) {
              a.call(n);
            });
        } catch (a) {
          W.__e(a, n.__v);
        }
      });
  }
  function vc(e, t, n, a, r, o, i, l) {
    var s,
      u,
      c,
      d = n.props,
      p = t.props,
      m = t.type,
      f = 0;
    if ((m === "svg" && (r = !0), o != null)) {
      for (; f < o.length; f++)
        if (
          (s = o[f]) &&
          "setAttribute" in s == !!m &&
          (m ? s.localName === m : s.nodeType === 3)
        ) {
          (e = s), (o[f] = null);
          break;
        }
    }
    if (e == null) {
      if (m === null) return document.createTextNode(p);
      (e = r
        ? document.createElementNS("http://www.w3.org/2000/svg", m)
        : document.createElement(m, p.is && p)),
        (o = null),
        (l = !1);
    }
    if (m === null) d === p || (l && e.data === p) || (e.data = p);
    else {
      if (
        ((o = o && g5.call(e.childNodes)),
        (u = (d = n.props || q5).dangerouslySetInnerHTML),
        (c = p.dangerouslySetInnerHTML),
        !l)
      ) {
        if (o != null)
          for (d = {}, f = 0; f < e.attributes.length; f++)
            d[e.attributes[f].name] = e.attributes[f].value;
        (c || u) &&
          ((c && ((u && c.__html == u.__html) || c.__html === e.innerHTML)) ||
            (e.innerHTML = (c && c.__html) || ""));
      }
      if ((gc(e, p, d, r, l), c)) t.__k = [];
      else if (
        ((f = t.props.children),
        Na(
          e,
          Array.isArray(f) ? f : [f],
          t,
          n,
          a,
          r && m !== "foreignObject",
          o,
          i,
          o ? o[0] : n.__k && f5(n, 0),
          l
        ),
        o != null)
      )
        for (f = o.length; f--; ) o[f] != null && Ia(o[f]);
      l ||
        ("value" in p &&
          (f = p.value) !== void 0 &&
          (f !== e.value ||
            (m === "progress" && !f) ||
            (m === "option" && f !== d.value)) &&
          K5(e, "value", f, d.value, !1),
        "checked" in p &&
          (f = p.checked) !== void 0 &&
          f !== e.checked &&
          K5(e, "checked", f, d.checked, !1));
    }
    return e;
  }
  function Da(e, t, n) {
    try {
      typeof e == "function" ? e(t) : (e.current = t);
    } catch (a) {
      W.__e(a, n);
    }
  }
  function Pa(e, t, n) {
    var a, r;
    if (
      (W.unmount && W.unmount(e),
      (a = e.ref) && ((a.current && a.current !== e.__e) || Da(a, null, t)),
      (a = e.__c) != null)
    ) {
      if (a.componentWillUnmount)
        try {
          a.componentWillUnmount();
        } catch (o) {
          W.__e(o, t);
        }
      (a.base = a.__P = null), (e.__c = void 0);
    }
    if ((a = e.__k))
      for (r = 0; r < a.length; r++)
        a[r] && Pa(a[r], t, n || typeof e.type != "function");
    n || e.__e == null || Ia(e.__e), (e.__ = e.__e = e.__d = void 0);
  }
  function bc(e, t, n) {
    return this.constructor(e, n);
  }
  function Ct(e, t, n) {
    var a, r, o;
    W.__ && W.__(e, t),
      (r = (a = typeof n == "function") ? null : (n && n.__k) || t.__k),
      (o = []),
      fn(
        t,
        (e = ((!a && n) || t).__k = mt(ht, null, [e])),
        r || q5,
        q5,
        t.ownerSVGElement !== void 0,
        !a && n ? [n] : r ? null : t.firstChild ? g5.call(t.childNodes) : null,
        o,
        !a && n ? n : r ? r.__e : t.firstChild,
        a
      ),
      Ha(o, e);
  }
  function gn(e, t) {
    Ct(e, t, gn);
  }
  function Fa(e, t, n) {
    var a,
      r,
      o,
      i = Et({}, e.props);
    for (o in t)
      o == "key" ? (a = t[o]) : o == "ref" ? (r = t[o]) : (i[o] = t[o]);
    return (
      arguments.length > 2 &&
        (i.children = arguments.length > 3 ? g5.call(arguments, 2) : n),
      h5(e.type, i, a || e.key, r || e.ref, null)
    );
  }
  function vn(e, t) {
    var n = {
      __c: (t = "__cC" + ka++),
      __: e,
      Consumer: function (a, r) {
        return a.children(r);
      },
      Provider: function (a) {
        var r, o;
        return (
          this.getChildContext ||
            ((r = []),
            ((o = {})[t] = this),
            (this.getChildContext = function () {
              return o;
            }),
            (this.shouldComponentUpdate = function (i) {
              this.props.value !== i.value && r.some(mn);
            }),
            (this.sub = function (i) {
              r.push(i);
              var l = i.componentWillUnmount;
              i.componentWillUnmount = function () {
                r.splice(r.indexOf(i), 1), l && l.call(i);
              };
            })),
          a.children
        );
      },
    };
    return (n.Provider.__ = n.Consumer.contextType = n);
  }
  (g5 = Ra.slice),
    (W = {
      __e: function (e, t, n, a) {
        for (var r, o, i; (t = t.__); )
          if ((r = t.__c) && !r.__)
            try {
              if (
                ((o = r.constructor) &&
                  o.getDerivedStateFromError != null &&
                  (r.setState(o.getDerivedStateFromError(e)), (i = r.__d)),
                r.componentDidCatch != null &&
                  (r.componentDidCatch(e, a || {}), (i = r.__d)),
                i)
              )
                return (r.__E = r);
            } catch (l) {
              e = l;
            }
        throw e;
      },
    }),
    (Ca = 0),
    (hc = function (e) {
      return e != null && e.constructor === void 0;
    }),
    (nt.prototype.setState = function (e, t) {
      var n;
      (n =
        this.__s != null && this.__s !== this.state
          ? this.__s
          : (this.__s = Et({}, this.state))),
        typeof e == "function" && (e = e(Et({}, n), this.props)),
        e && Et(n, e),
        e != null && this.__v && (t && this._sb.push(t), mn(this));
    }),
    (nt.prototype.forceUpdate = function (e) {
      this.__v && ((this.__e = !0), e && this.__h.push(e), mn(this));
    }),
    (nt.prototype.render = ht),
    (m5 = []),
    (W5.__r = 0),
    (ka = 0);
  var _c =
      typeof global == "object" && global && global.Object === Object && global,
    j5 = _c;
  var Ec = typeof self == "object" && self && self.Object === Object && self,
    yc = j5 || Ec || Function("return this")(),
    Zt = yc;
  var xc = Zt.Symbol,
    Xt = xc;
  var Va = Object.prototype,
    wc = Va.hasOwnProperty,
    Ac = Va.toString,
    v5 = Xt ? Xt.toStringTag : void 0;
  function Mc(e) {
    var t = wc.call(e, v5),
      n = e[v5];
    try {
      e[v5] = void 0;
      var a = !0;
    } catch {}
    var r = Ac.call(e);
    return a && (t ? (e[v5] = n) : delete e[v5]), r;
  }
  var Ba = Mc;
  var zc = Object.prototype,
    Sc = zc.toString;
  function Cc(e) {
    return Sc.call(e);
  }
  var Ua = Cc;
  var kc = "[object Null]",
    Rc = "[object Undefined]",
    Ga = Xt ? Xt.toStringTag : void 0;
  function Ic(e) {
    return e == null
      ? e === void 0
        ? Rc
        : kc
      : Ga && Ga in Object(e)
      ? Ba(e)
      : Ua(e);
  }
  var Jt = Ic;
  function Tc(e) {
    return e != null && typeof e == "object";
  }
  var e5 = Tc;
  var Nc = Array.isArray,
    $a = Nc;
  function Lc(e) {
    var t = typeof e;
    return e != null && (t == "object" || t == "function");
  }
  var kt = Lc;
  function Oc(e) {
    return e;
  }
  var Y5 = Oc;
  var Hc = "[object AsyncFunction]",
    Dc = "[object Function]",
    Pc = "[object GeneratorFunction]",
    Fc = "[object Proxy]";
  function Vc(e) {
    if (!kt(e)) return !1;
    var t = Jt(e);
    return t == Dc || t == Pc || t == Hc || t == Fc;
  }
  var Q5 = Vc;
  var Bc = Zt["__core-js_shared__"],
    Z5 = Bc;
  var qa = (function () {
    var e = /[^.]+$/.exec((Z5 && Z5.keys && Z5.keys.IE_PROTO) || "");
    return e ? "Symbol(src)_1." + e : "";
  })();
  function Uc(e) {
    return !!qa && qa in e;
  }
  var Wa = Uc;
  var Gc = Function.prototype,
    $c = Gc.toString;
  function qc(e) {
    if (e != null) {
      try {
        return $c.call(e);
      } catch {}
      try {
        return e + "";
      } catch {}
    }
    return "";
  }
  var Ka = qc;
  var Wc = /[\\^$.*+?()[\]{}|]/g,
    Kc = /^\[object .+?Constructor\]$/,
    jc = Function.prototype,
    Yc = Object.prototype,
    Qc = jc.toString,
    Zc = Yc.hasOwnProperty,
    Xc = RegExp(
      "^" +
        Qc.call(Zc)
          .replace(Wc, "\\$&")
          .replace(
            /hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,
            "$1.*?"
          ) +
        "$"
    );
  function Jc(e) {
    if (!kt(e) || Wa(e)) return !1;
    var t = Q5(e) ? Xc : Kc;
    return t.test(Ka(e));
  }
  var ja = Jc;
  function es(e, t) {
    return e?.[t];
  }
  var Ya = es;
  function ts(e, t) {
    var n = Ya(e, t);
    return ja(n) ? n : void 0;
  }
  var Qa = ts;
  function ns(e, t, n) {
    switch (n.length) {
      case 0:
        return e.call(t);
      case 1:
        return e.call(t, n[0]);
      case 2:
        return e.call(t, n[0], n[1]);
      case 3:
        return e.call(t, n[0], n[1], n[2]);
    }
    return e.apply(t, n);
  }
  var Za = ns;
  var as = 800,
    rs = 16,
    os = Date.now;
  function is(e) {
    var t = 0,
      n = 0;
    return function () {
      var a = os(),
        r = rs - (a - n);
      if (((n = a), r > 0)) {
        if (++t >= as) return arguments[0];
      } else t = 0;
      return e.apply(void 0, arguments);
    };
  }
  var Xa = is;
  function ls(e) {
    return function () {
      return e;
    };
  }
  var Ja = ls;
  var cs = (function () {
      try {
        var e = Qa(Object, "defineProperty");
        return e({}, "", {}), e;
      } catch {}
    })(),
    bn = cs;
  var ss = bn
      ? function (e, t) {
          return bn(e, "toString", {
            configurable: !0,
            enumerable: !1,
            value: Ja(t),
            writable: !0,
          });
        }
      : Y5,
    er = ss;
  var us = Xa(er),
    tr = us;
  var ds = 9007199254740991,
    ps = /^(?:0|[1-9]\d*)$/;
  function ms(e, t) {
    var n = typeof e;
    return (
      (t = t ?? ds),
      !!t &&
        (n == "number" || (n != "symbol" && ps.test(e))) &&
        e > -1 &&
        e % 1 == 0 &&
        e < t
    );
  }
  var X5 = ms;
  function hs(e, t) {
    return e === t || (e !== e && t !== t);
  }
  var J5 = hs;
  var nr = Math.max;
  function fs(e, t, n) {
    return (
      (t = nr(t === void 0 ? e.length - 1 : t, 0)),
      function () {
        for (
          var a = arguments, r = -1, o = nr(a.length - t, 0), i = Array(o);
          ++r < o;

        )
          i[r] = a[t + r];
        r = -1;
        for (var l = Array(t + 1); ++r < t; ) l[r] = a[r];
        return (l[t] = n(i)), Za(e, this, l);
      }
    );
  }
  var ar = fs;
  function gs(e, t) {
    return tr(ar(e, t, Y5), e + "");
  }
  var rr = gs;
  var vs = 9007199254740991;
  function bs(e) {
    return typeof e == "number" && e > -1 && e % 1 == 0 && e <= vs;
  }
  var e1 = bs;
  function _s(e) {
    return e != null && e1(e.length) && !Q5(e);
  }
  var t1 = _s;
  function Es(e, t, n) {
    if (!kt(n)) return !1;
    var a = typeof t;
    return (a == "number" ? t1(n) && X5(t, n.length) : a == "string" && t in n)
      ? J5(n[t], e)
      : !1;
  }
  var or = Es;
  var ys = Object.prototype;
  function xs(e) {
    var t = e && e.constructor,
      n = (typeof t == "function" && t.prototype) || ys;
    return e === n;
  }
  var ir = xs;
  function ws(e, t) {
    for (var n = -1, a = Array(e); ++n < e; ) a[n] = t(n);
    return a;
  }
  var lr = ws;
  var As = "[object Arguments]";
  function Ms(e) {
    return e5(e) && Jt(e) == As;
  }
  var _n = Ms;
  var cr = Object.prototype,
    zs = cr.hasOwnProperty,
    Ss = cr.propertyIsEnumerable,
    Cs = _n(
      (function () {
        return arguments;
      })()
    )
      ? _n
      : function (e) {
          return e5(e) && zs.call(e, "callee") && !Ss.call(e, "callee");
        },
    sr = Cs;
  function ks() {
    return !1;
  }
  var ur = ks;
  var mr =
      typeof exports == "object" && exports && !exports.nodeType && exports,
    dr =
      mr && typeof module == "object" && module && !module.nodeType && module,
    Rs = dr && dr.exports === mr,
    pr = Rs ? Zt.Buffer : void 0,
    Is = pr ? pr.isBuffer : void 0,
    Ts = Is || ur,
    hr = Ts;
  var Ns = "[object Arguments]",
    Ls = "[object Array]",
    Os = "[object Boolean]",
    Hs = "[object Date]",
    Ds = "[object Error]",
    Ps = "[object Function]",
    Fs = "[object Map]",
    Vs = "[object Number]",
    Bs = "[object Object]",
    Us = "[object RegExp]",
    Gs = "[object Set]",
    $s = "[object String]",
    qs = "[object WeakMap]",
    Ws = "[object ArrayBuffer]",
    Ks = "[object DataView]",
    js = "[object Float32Array]",
    Ys = "[object Float64Array]",
    Qs = "[object Int8Array]",
    Zs = "[object Int16Array]",
    Xs = "[object Int32Array]",
    Js = "[object Uint8Array]",
    eu = "[object Uint8ClampedArray]",
    tu = "[object Uint16Array]",
    nu = "[object Uint32Array]",
    ye = {};
  ye[js] =
    ye[Ys] =
    ye[Qs] =
    ye[Zs] =
    ye[Xs] =
    ye[Js] =
    ye[eu] =
    ye[tu] =
    ye[nu] =
      !0;
  ye[Ns] =
    ye[Ls] =
    ye[Ws] =
    ye[Os] =
    ye[Ks] =
    ye[Hs] =
    ye[Ds] =
    ye[Ps] =
    ye[Fs] =
    ye[Vs] =
    ye[Bs] =
    ye[Us] =
    ye[Gs] =
    ye[$s] =
    ye[qs] =
      !1;
  function au(e) {
    return e5(e) && e1(e.length) && !!ye[Jt(e)];
  }
  var fr = au;
  function ru(e) {
    return function (t) {
      return e(t);
    };
  }
  var gr = ru;
  var vr =
      typeof exports == "object" && exports && !exports.nodeType && exports,
    b5 =
      vr && typeof module == "object" && module && !module.nodeType && module,
    ou = b5 && b5.exports === vr,
    En = ou && j5.process,
    iu = (function () {
      try {
        var e = b5 && b5.require && b5.require("util").types;
        return e || (En && En.binding && En.binding("util"));
      } catch {}
    })(),
    yn = iu;
  var br = yn && yn.isTypedArray,
    lu = br ? gr(br) : fr,
    _r = lu;
  var cu = Object.prototype,
    su = cu.hasOwnProperty;
  function uu(e, t) {
    var n = $a(e),
      a = !n && sr(e),
      r = !n && !a && hr(e),
      o = !n && !a && !r && _r(e),
      i = n || a || r || o,
      l = i ? lr(e.length, String) : [],
      s = l.length;
    for (var u in e)
      (t || su.call(e, u)) &&
        !(
          i &&
          (u == "length" ||
            (r && (u == "offset" || u == "parent")) ||
            (o && (u == "buffer" || u == "byteLength" || u == "byteOffset")) ||
            X5(u, s))
        ) &&
        l.push(u);
    return l;
  }
  var Er = uu;
  function du(e) {
    var t = [];
    if (e != null) for (var n in Object(e)) t.push(n);
    return t;
  }
  var yr = du;
  var pu = Object.prototype,
    mu = pu.hasOwnProperty;
  function hu(e) {
    if (!kt(e)) return yr(e);
    var t = ir(e),
      n = [];
    for (var a in e) (a == "constructor" && (t || !mu.call(e, a))) || n.push(a);
    return n;
  }
  var xr = hu;
  function fu(e) {
    return t1(e) ? Er(e, !0) : xr(e);
  }
  var wr = fu;
  var Ar = Object.prototype,
    gu = Ar.hasOwnProperty,
    vu = rr(function (e, t) {
      e = Object(e);
      var n = -1,
        a = t.length,
        r = a > 2 ? t[2] : void 0;
      for (r && or(t[0], t[1], r) && (a = 1); ++n < a; )
        for (var o = t[n], i = wr(o), l = -1, s = i.length; ++l < s; ) {
          var u = i[l],
            c = e[u];
          (c === void 0 || (J5(c, Ar[u]) && !gu.call(e, u))) && (e[u] = o[u]);
        }
      return e;
    }),
    xn = vu;
  var An = pt(n1());
  var Sr = {
      ["always"]: "Always",
      ["questionMark"]: "Question",
      ["manually"]: "Manually",
    },
    Cr = {
      ["always"]: "ChatGPT is available whenever you search",
      ["questionMark"]: "When query ends with question mark (?)",
      ["manually"]: "ChatGPT is only active when you click the icon",
    },
    _5 = ((a) => (
      (a.Auto = "auto"), (a.Light = "light"), (a.Dark = "dark"), a
    ))(_5 || {}),
    zr = { triggerMode: "always", theme: "auto", clearConversation: !1 };
  async function yt() {
    let e = await An.default.storage.local.get(Object.keys(zr));
    return xn(e, zr);
  }
  async function a1(e) {
    return console.debug("update configs", e), An.default.storage.local.set(e);
  }
  var t5 = { conversationId: null };
  function r1() {
    return window.matchMedia &&
      window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "light";
  }
  var Ht,
    we,
    Mn,
    kr,
    n5 = 0,
    Hr = [],
    o1 = [],
    Rr = W.__b,
    Ir = W.__r,
    Tr = W.diffed,
    Nr = W.__c,
    Lr = W.unmount;
  function a5(e, t) {
    W.__h && W.__h(we, e, n5 || t), (n5 = 0);
    var n = we.__H || (we.__H = { __: [], __h: [] });
    return e >= n.__.length && n.__.push({ __V: o1 }), n.__[e];
  }
  function ne(e) {
    return (n5 = 1), Sn(Vr, e);
  }
  function Sn(e, t, n) {
    var a = a5(Ht++, 2);
    if (
      ((a.t = e),
      !a.__c &&
        ((a.__ = [
          n ? n(t) : Vr(void 0, t),
          function (o) {
            var i = a.__N ? a.__N[0] : a.__[0],
              l = a.t(i, o);
            i !== l && ((a.__N = [l, a.__[1]]), a.__c.setState({}));
          },
        ]),
        (a.__c = we),
        !we.u))
    ) {
      we.u = !0;
      var r = we.shouldComponentUpdate;
      we.shouldComponentUpdate = function (o, i, l) {
        if (!a.__c.__H) return !0;
        var s = a.__c.__H.__.filter(function (c) {
          return c.__c;
        });
        if (
          s.every(function (c) {
            return !c.__N;
          })
        )
          return !r || r.call(this, o, i, l);
        var u = !1;
        return (
          s.forEach(function (c) {
            if (c.__N) {
              var d = c.__[0];
              (c.__ = c.__N), (c.__N = void 0), d !== c.__[0] && (u = !0);
            }
          }),
          !(!u && a.__c.props === o) && (!r || r.call(this, o, i, l))
        );
      };
    }
    return a.__N || a.__;
  }
  function ie(e, t) {
    var n = a5(Ht++, 3);
    !W.__s && Cn(n.__H, t) && ((n.__ = e), (n.i = t), we.__H.__h.push(n));
  }
  function E5(e, t) {
    var n = a5(Ht++, 4);
    !W.__s && Cn(n.__H, t) && ((n.__ = e), (n.i = t), we.__h.push(n));
  }
  function at(e) {
    return (
      (n5 = 5),
      ce(function () {
        return { current: e };
      }, [])
    );
  }
  function l1(e, t, n) {
    (n5 = 6),
      E5(
        function () {
          return typeof e == "function"
            ? (e(t()),
              function () {
                return e(null);
              })
            : e
            ? ((e.current = t()),
              function () {
                return (e.current = null);
              })
            : void 0;
        },
        n == null ? n : n.concat(e)
      );
  }
  function ce(e, t) {
    var n = a5(Ht++, 7);
    return Cn(n.__H, t) ? ((n.__V = e()), (n.i = t), (n.__h = e), n.__V) : n.__;
  }
  function vt(e, t) {
    return (
      (n5 = 8),
      ce(function () {
        return e;
      }, t)
    );
  }
  function Dr(e) {
    var t = we.context[e.__c],
      n = a5(Ht++, 9);
    return (
      (n.c = e),
      t ? (n.__ == null && ((n.__ = !0), t.sub(we)), t.props.value) : e.__
    );
  }
  function Pr(e, t) {
    W.useDebugValue && W.useDebugValue(t ? t(e) : e);
  }
  function Fr() {
    var e = a5(Ht++, 11);
    if (!e.__) {
      for (var t = we.__v; t !== null && !t.__m && t.__ !== null; ) t = t.__;
      var n = t.__m || (t.__m = [0, 0]);
      e.__ = "P" + n[0] + "-" + n[1]++;
    }
    return e.__;
  }
  function bu() {
    for (var e; (e = Hr.shift()); )
      if (e.__P && e.__H)
        try {
          e.__H.__h.forEach(i1), e.__H.__h.forEach(zn), (e.__H.__h = []);
        } catch (t) {
          (e.__H.__h = []), W.__e(t, e.__v);
        }
  }
  (W.__b = function (e) {
    (we = null), Rr && Rr(e);
  }),
    (W.__r = function (e) {
      Ir && Ir(e), (Ht = 0);
      var t = (we = e.__c).__H;
      t &&
        (Mn === we
          ? ((t.__h = []),
            (we.__h = []),
            t.__.forEach(function (n) {
              n.__N && (n.__ = n.__N), (n.__V = o1), (n.__N = n.i = void 0);
            }))
          : (t.__h.forEach(i1), t.__h.forEach(zn), (t.__h = []))),
        (Mn = we);
    }),
    (W.diffed = function (e) {
      Tr && Tr(e);
      var t = e.__c;
      t &&
        t.__H &&
        (t.__H.__h.length &&
          ((Hr.push(t) !== 1 && kr === W.requestAnimationFrame) ||
            ((kr = W.requestAnimationFrame) || _u)(bu)),
        t.__H.__.forEach(function (n) {
          n.i && (n.__H = n.i),
            n.__V !== o1 && (n.__ = n.__V),
            (n.i = void 0),
            (n.__V = o1);
        })),
        (Mn = we = null);
    }),
    (W.__c = function (e, t) {
      t.some(function (n) {
        try {
          n.__h.forEach(i1),
            (n.__h = n.__h.filter(function (a) {
              return !a.__ || zn(a);
            }));
        } catch (a) {
          t.some(function (r) {
            r.__h && (r.__h = []);
          }),
            (t = []),
            W.__e(a, n.__v);
        }
      }),
        Nr && Nr(e, t);
    }),
    (W.unmount = function (e) {
      Lr && Lr(e);
      var t,
        n = e.__c;
      n &&
        n.__H &&
        (n.__H.__.forEach(function (a) {
          try {
            i1(a);
          } catch (r) {
            t = r;
          }
        }),
        (n.__H = void 0),
        t && W.__e(t, n.__v));
    });
  var Or = typeof requestAnimationFrame == "function";
  function _u(e) {
    var t,
      n = function () {
        clearTimeout(a), Or && cancelAnimationFrame(t), setTimeout(e);
      },
      a = setTimeout(n, 100);
    Or && (t = requestAnimationFrame(n));
  }
  function i1(e) {
    var t = we,
      n = e.__c;
    typeof n == "function" && ((e.__c = void 0), n()), (we = t);
  }
  function zn(e) {
    var t = we;
    (e.__c = e.__()), (we = t);
  }
  function Cn(e, t) {
    return (
      !e ||
      e.length !== t.length ||
      t.some(function (n, a) {
        return n !== e[a];
      })
    );
  }
  function Vr(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function Yr(e, t) {
    for (var n in t) e[n] = t[n];
    return e;
  }
  function Rn(e, t) {
    for (var n in e) if (n !== "__source" && !(n in t)) return !0;
    for (var a in t) if (a !== "__source" && e[a] !== t[a]) return !0;
    return !1;
  }
  function kn(e, t) {
    return (e === t && (e !== 0 || 1 / e == 1 / t)) || (e != e && t != t);
  }
  function In(e) {
    this.props = e;
  }
  function Tn(e, t) {
    function n(r) {
      var o = this.props.ref,
        i = o == r.ref;
      return (
        !i && o && (o.call ? o(null) : (o.current = null)),
        t ? !t(this.props, r) || !i : Rn(this.props, r)
      );
    }
    function a(r) {
      return (this.shouldComponentUpdate = n), mt(e, r);
    }
    return (
      (a.displayName = "Memo(" + (e.displayName || e.name) + ")"),
      (a.prototype.isReactComponent = !0),
      (a.__f = !0),
      a
    );
  }
  ((In.prototype = new nt()).isPureReactComponent = !0),
    (In.prototype.shouldComponentUpdate = function (e, t) {
      return Rn(this.props, e) || Rn(this.state, t);
    });
  var Br = W.__b;
  W.__b = function (e) {
    e.type && e.type.__f && e.ref && ((e.props.ref = e.ref), (e.ref = null)),
      Br && Br(e);
  };
  var Eu =
    (typeof Symbol < "u" && Symbol.for && Symbol.for("react.forward_ref")) ||
    3911;
  function x5(e) {
    function t(n) {
      var a = Yr({}, n);
      return delete a.ref, e(a, n.ref || null);
    }
    return (
      (t.$$typeof = Eu),
      (t.render = t),
      (t.prototype.isReactComponent = t.__f = !0),
      (t.displayName = "ForwardRef(" + (e.displayName || e.name) + ")"),
      t
    );
  }
  var Ur = function (e, t) {
      return e == null ? null : gt(gt(e).map(t));
    },
    yu = {
      map: Ur,
      forEach: Ur,
      count: function (e) {
        return e ? gt(e).length : 0;
      },
      only: function (e) {
        var t = gt(e);
        if (t.length !== 1) throw "Children.only";
        return t[0];
      },
      toArray: gt,
    },
    xu = W.__e;
  W.__e = function (e, t, n, a) {
    if (e.then) {
      for (var r, o = t; (o = o.__); )
        if ((r = o.__c) && r.__c)
          return (
            t.__e == null && ((t.__e = n.__e), (t.__k = n.__k)), r.__c(e, t)
          );
    }
    xu(e, t, n, a);
  };
  var Gr = W.unmount;
  function Qr(e, t, n) {
    return (
      e &&
        (e.__c &&
          e.__c.__H &&
          (e.__c.__H.__.forEach(function (a) {
            typeof a.__c == "function" && a.__c();
          }),
          (e.__c.__H = null)),
        (e = Yr({}, e)).__c != null &&
          (e.__c.__P === n && (e.__c.__P = t), (e.__c = null)),
        (e.__k =
          e.__k &&
          e.__k.map(function (a) {
            return Qr(a, t, n);
          }))),
      e
    );
  }
  function Zr(e, t, n) {
    return (
      e &&
        ((e.__v = null),
        (e.__k =
          e.__k &&
          e.__k.map(function (a) {
            return Zr(a, t, n);
          })),
        e.__c &&
          e.__c.__P === t &&
          (e.__e && n.insertBefore(e.__e, e.__d),
          (e.__c.__e = !0),
          (e.__c.__P = n))),
      e
    );
  }
  function c1() {
    (this.__u = 0), (this.t = null), (this.__b = null);
  }
  function Xr(e) {
    var t = e.__.__c;
    return t && t.__a && t.__a(e);
  }
  function wu(e) {
    var t, n, a;
    function r(o) {
      if (
        (t ||
          (t = e()).then(
            function (i) {
              n = i.default || i;
            },
            function (i) {
              a = i;
            }
          ),
        a)
      )
        throw a;
      if (!n) throw t;
      return mt(n, o);
    }
    return (r.displayName = "Lazy"), (r.__f = !0), r;
  }
  function y5() {
    (this.u = null), (this.o = null);
  }
  (W.unmount = function (e) {
    var t = e.__c;
    t && t.__R && t.__R(), t && e.__h === !0 && (e.type = null), Gr && Gr(e);
  }),
    ((c1.prototype = new nt()).__c = function (e, t) {
      var n = t.__c,
        a = this;
      a.t == null && (a.t = []), a.t.push(n);
      var r = Xr(a.__v),
        o = !1,
        i = function () {
          o || ((o = !0), (n.__R = null), r ? r(l) : l());
        };
      n.__R = i;
      var l = function () {
          if (!--a.__u) {
            if (a.state.__a) {
              var u = a.state.__a;
              a.__v.__k[0] = Zr(u, u.__c.__P, u.__c.__O);
            }
            var c;
            for (a.setState({ __a: (a.__b = null) }); (c = a.t.pop()); )
              c.forceUpdate();
          }
        },
        s = t.__h === !0;
      a.__u++ || s || a.setState({ __a: (a.__b = a.__v.__k[0]) }), e.then(i, i);
    }),
    (c1.prototype.componentWillUnmount = function () {
      this.t = [];
    }),
    (c1.prototype.render = function (e, t) {
      if (this.__b) {
        if (this.__v.__k) {
          var n = document.createElement("div"),
            a = this.__v.__k[0].__c;
          this.__v.__k[0] = Qr(this.__b, n, (a.__O = a.__P));
        }
        this.__b = null;
      }
      var r = t.__a && mt(ht, null, e.fallback);
      return r && (r.__h = null), [mt(ht, null, t.__a ? null : e.children), r];
    });
  var $r = function (e, t, n) {
    if (
      (++n[1] === n[0] && e.o.delete(t),
      e.props.revealOrder && (e.props.revealOrder[0] !== "t" || !e.o.size))
    )
      for (n = e.u; n; ) {
        for (; n.length > 3; ) n.pop()();
        if (n[1] < n[0]) break;
        e.u = n = n[2];
      }
  };
  function Au(e) {
    return (
      (this.getChildContext = function () {
        return e.context;
      }),
      e.children
    );
  }
  function Mu(e) {
    var t = this,
      n = e.i;
    (t.componentWillUnmount = function () {
      Ct(null, t.l), (t.l = null), (t.i = null);
    }),
      t.i && t.i !== n && t.componentWillUnmount(),
      e.__v
        ? (t.l ||
            ((t.i = n),
            (t.l = {
              nodeType: 1,
              parentNode: n,
              childNodes: [],
              appendChild: function (a) {
                this.childNodes.push(a), t.i.appendChild(a);
              },
              insertBefore: function (a, r) {
                this.childNodes.push(a), t.i.appendChild(a);
              },
              removeChild: function (a) {
                this.childNodes.splice(this.childNodes.indexOf(a) >>> 1, 1),
                  t.i.removeChild(a);
              },
            })),
          Ct(mt(Au, { context: t.context }, e.__v), t.l))
        : t.l && t.componentWillUnmount();
  }
  function Nn(e, t) {
    var n = mt(Mu, { __v: e, i: t });
    return (n.containerInfo = t), n;
  }
  ((y5.prototype = new nt()).__a = function (e) {
    var t = this,
      n = Xr(t.__v),
      a = t.o.get(e);
    return (
      a[0]++,
      function (r) {
        var o = function () {
          t.props.revealOrder ? (a.push(r), $r(t, e, a)) : r();
        };
        n ? n(o) : o();
      }
    );
  }),
    (y5.prototype.render = function (e) {
      (this.u = null), (this.o = new Map());
      var t = gt(e.children);
      e.revealOrder && e.revealOrder[0] === "b" && t.reverse();
      for (var n = t.length; n--; ) this.o.set(t[n], (this.u = [1, 0, this.u]));
      return e.children;
    }),
    (y5.prototype.componentDidUpdate = y5.prototype.componentDidMount =
      function () {
        var e = this;
        this.o.forEach(function (t, n) {
          $r(e, n, t);
        });
      });
  var Jr =
      (typeof Symbol < "u" && Symbol.for && Symbol.for("react.element")) ||
      60103,
    zu =
      /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,
    Su = typeof document < "u",
    Cu = function (e) {
      return (
        typeof Symbol < "u" && typeof Symbol() == "symbol"
          ? /fil|che|rad/i
          : /fil|che|ra/i
      ).test(e);
    };
  function ku(e, t, n) {
    return (
      t.__k == null && (t.textContent = ""),
      Ct(e, t),
      typeof n == "function" && n(),
      e ? e.__c : null
    );
  }
  function Ru(e, t, n) {
    return gn(e, t), typeof n == "function" && n(), e ? e.__c : null;
  }
  (nt.prototype.isReactComponent = {}),
    [
      "componentWillMount",
      "componentWillReceiveProps",
      "componentWillUpdate",
    ].forEach(function (e) {
      Object.defineProperty(nt.prototype, e, {
        configurable: !0,
        get: function () {
          return this["UNSAFE_" + e];
        },
        set: function (t) {
          Object.defineProperty(this, e, {
            configurable: !0,
            writable: !0,
            value: t,
          });
        },
      });
    });
  var qr = W.event;
  function Iu() {}
  function Tu() {
    return this.cancelBubble;
  }
  function Nu() {
    return this.defaultPrevented;
  }
  W.event = function (e) {
    return (
      qr && (e = qr(e)),
      (e.persist = Iu),
      (e.isPropagationStopped = Tu),
      (e.isDefaultPrevented = Nu),
      (e.nativeEvent = e)
    );
  };
  var eo,
    Wr = {
      configurable: !0,
      get: function () {
        return this.class;
      },
    },
    Kr = W.vnode;
  W.vnode = function (e) {
    var t = e.type,
      n = e.props,
      a = n;
    if (typeof t == "string") {
      var r = t.indexOf("-") === -1;
      for (var o in ((a = {}), n)) {
        var i = n[o];
        (Su && o === "children" && t === "noscript") ||
          (o === "value" && "defaultValue" in n && i == null) ||
          (o === "defaultValue" && "value" in n && n.value == null
            ? (o = "value")
            : o === "download" && i === !0
            ? (i = "")
            : /ondoubleclick/i.test(o)
            ? (o = "ondblclick")
            : /^onchange(textarea|input)/i.test(o + t) && !Cu(n.type)
            ? (o = "oninput")
            : /^onfocus$/i.test(o)
            ? (o = "onfocusin")
            : /^onblur$/i.test(o)
            ? (o = "onfocusout")
            : /^on(Ani|Tra|Tou|BeforeInp|Compo)/.test(o)
            ? (o = o.toLowerCase())
            : r && zu.test(o)
            ? (o = o.replace(/[A-Z0-9]/g, "-$&").toLowerCase())
            : i === null && (i = void 0),
          /^oninput$/i.test(o) &&
            ((o = o.toLowerCase()), a[o] && (o = "oninputCapture")),
          (a[o] = i));
      }
      t == "select" &&
        a.multiple &&
        Array.isArray(a.value) &&
        (a.value = gt(n.children).forEach(function (l) {
          l.props.selected = a.value.indexOf(l.props.value) != -1;
        })),
        t == "select" &&
          a.defaultValue != null &&
          (a.value = gt(n.children).forEach(function (l) {
            l.props.selected = a.multiple
              ? a.defaultValue.indexOf(l.props.value) != -1
              : a.defaultValue == l.props.value;
          })),
        (e.props = a),
        n.class != n.className &&
          ((Wr.enumerable = "className" in n),
          n.className != null && (a.class = n.className),
          Object.defineProperty(a, "className", Wr));
    }
    (e.$$typeof = Jr), Kr && Kr(e);
  };
  var jr = W.__r;
  W.__r = function (e) {
    jr && jr(e), (eo = e.__c);
  };
  var Lu = {
    ReactCurrentDispatcher: {
      current: {
        readContext: function (e) {
          return eo.__n[e.__c].props.value;
        },
      },
    },
  };
  function Ou(e) {
    return mt.bind(null, e);
  }
  function to(e) {
    return !!e && e.$$typeof === Jr;
  }
  function Hu(e) {
    return to(e) ? Fa.apply(null, arguments) : e;
  }
  function Du(e) {
    return !!e.__k && (Ct(null, e), !0);
  }
  function Pu(e) {
    return (e && (e.base || (e.nodeType === 1 && e))) || null;
  }
  var Fu = function (e, t) {
      return e(t);
    },
    Vu = function (e, t) {
      return e(t);
    },
    Bu = ht;
  function no(e) {
    e();
  }
  function Uu(e) {
    return e;
  }
  function Gu() {
    return [!1, no];
  }
  var $u = E5;
  function qu(e, t) {
    var n = t(),
      a = ne({ h: { __: n, v: t } }),
      r = a[0].h,
      o = a[1];
    return (
      E5(
        function () {
          (r.__ = n), (r.v = t), kn(r.__, t()) || o({ h: r });
        },
        [e, n, t]
      ),
      ie(
        function () {
          return (
            kn(r.__, r.v()) || o({ h: r }),
            e(function () {
              kn(r.__, r.v()) || o({ h: r });
            })
          );
        },
        [e]
      ),
      n
    );
  }
  var S = {
    useState: ne,
    useId: Fr,
    useReducer: Sn,
    useEffect: ie,
    useLayoutEffect: E5,
    useInsertionEffect: $u,
    useTransition: Gu,
    useDeferredValue: Uu,
    useSyncExternalStore: qu,
    startTransition: no,
    useRef: at,
    useImperativeHandle: l1,
    useMemo: ce,
    useCallback: vt,
    useContext: Dr,
    useDebugValue: Pr,
    version: "17.0.2",
    Children: yu,
    render: ku,
    hydrate: Ru,
    unmountComponentAtNode: Du,
    createPortal: Nn,
    createElement: mt,
    createContext: vn,
    createFactory: Ou,
    cloneElement: Hu,
    createRef: hn,
    Fragment: ht,
    isValidElement: to,
    findDOMNode: Pu,
    Component: nt,
    PureComponent: In,
    memo: Tn,
    forwardRef: x5,
    flushSync: Vu,
    unstable_batchedUpdates: Fu,
    StrictMode: Bu,
    Suspense: c1,
    SuspenseList: y5,
    lazy: wu,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: Lu,
  };
  var Wu = { small: 16, medium: 32, large: 64 };
  function Ku(e, t, n) {
    var a = n(),
      r = Object.keys(a);
    function o(i) {
      var l = i["aria-label"],
        s = i.tabIndex,
        u = i.className,
        c = i.fill,
        d = c === void 0 ? "currentColor" : c,
        p = i.size,
        m = i.verticalAlign,
        f = Wu[p] || p,
        v = ju(r, f),
        g = a[v].width,
        _ = f * (g / v),
        C = a[v].path;
      return S.createElement(
        "svg",
        {
          "aria-hidden": l ? "false" : "true",
          tabIndex: s,
          focusable: s >= 0 ? "true" : "false",
          "aria-label": l,
          role: "img",
          className: u,
          viewBox: "0 0 ".concat(g, " ").concat(v),
          width: _,
          height: f,
          fill: d,
          style: {
            display: "inline-block",
            userSelect: "none",
            verticalAlign: m,
            overflow: "visible",
          },
        },
        C
      );
    }
    return (
      (o.displayName = e),
      (o.defaultProps = {
        className: t,
        size: 16,
        verticalAlign: "text-bottom",
      }),
      o
    );
  }
  function ju(e, t) {
    return e
      .map(function (n) {
        return parseInt(n, 10);
      })
      .reduce(function (n, a) {
        return a <= t ? a : n;
      }, e[0]);
  }
  var ao = Ku("ArrowRightIcon", "octicon octicon-arrow-right", function () {
    return {
      16: {
        width: 16,
        path: S.createElement("path", {
          fillRule: "evenodd",
          d: "M8.22 2.97a.75.75 0 011.06 0l4.25 4.25a.75.75 0 010 1.06l-4.25 4.25a.75.75 0 01-1.06-1.06l2.97-2.97H3.75a.75.75 0 010-1.5h7.44L8.22 4.03a.75.75 0 010-1.06z",
        }),
      },
      24: {
        width: 24,
        path: S.createElement("path", {
          fillRule: "evenodd",
          d: "M13.22 19.03a.75.75 0 001.06 0l6.25-6.25a.75.75 0 000-1.06l-6.25-6.25a.75.75 0 10-1.06 1.06l4.97 4.97H3.75a.75.75 0 000 1.5h14.44l-4.97 4.97a.75.75 0 000 1.06z",
        }),
      },
    };
  });
  var ro = ["http", "https", "mailto", "tel"];
  function oo(e) {
    let t = (e || "").trim(),
      n = t.charAt(0);
    if (n === "#" || n === "/") return t;
    let a = t.indexOf(":");
    if (a === -1) return t;
    let r = -1;
    for (; ++r < ro.length; ) {
      let o = ro[r];
      if (a === o.length && t.slice(0, o.length).toLowerCase() === o) return t;
    }
    return (
      (r = t.indexOf("?")),
      (r !== -1 && a > r) || ((r = t.indexOf("#")), r !== -1 && a > r)
        ? t
        : "javascript:void(0)"
    );
  }
  var mo = pt(Ln(), 1);
  function Dt(e) {
    return !e || typeof e != "object"
      ? ""
      : "position" in e || "type" in e
      ? lo(e.position)
      : "start" in e || "end" in e
      ? lo(e)
      : "line" in e || "column" in e
      ? On(e)
      : "";
  }
  function On(e) {
    return co(e && e.line) + ":" + co(e && e.column);
  }
  function lo(e) {
    return On(e && e.start) + "-" + On(e && e.end);
  }
  function co(e) {
    return e && typeof e == "number" ? e : 1;
  }
  var qe = class extends Error {
    constructor(t, n, a) {
      let r = [null, null],
        o = {
          start: { line: null, column: null },
          end: { line: null, column: null },
        };
      if (
        (super(),
        typeof n == "string" && ((a = n), (n = void 0)),
        typeof a == "string")
      ) {
        let i = a.indexOf(":");
        i === -1
          ? (r[1] = a)
          : ((r[0] = a.slice(0, i)), (r[1] = a.slice(i + 1)));
      }
      n &&
        ("type" in n || "position" in n
          ? n.position && (o = n.position)
          : "start" in n || "end" in n
          ? (o = n)
          : ("line" in n || "column" in n) && (o.start = n)),
        (this.name = Dt(n) || "1:1"),
        (this.message = typeof t == "object" ? t.message : t),
        (this.stack = ""),
        typeof t == "object" && t.stack && (this.stack = t.stack),
        (this.reason = this.message),
        this.fatal,
        (this.line = o.start.line),
        (this.column = o.start.column),
        (this.position = o),
        (this.source = r[0]),
        (this.ruleId = r[1]),
        this.file,
        this.actual,
        this.expected,
        this.url,
        this.note;
    }
  };
  qe.prototype.file = "";
  qe.prototype.name = "";
  qe.prototype.reason = "";
  qe.prototype.message = "";
  qe.prototype.stack = "";
  qe.prototype.fatal = null;
  qe.prototype.column = null;
  qe.prototype.line = null;
  qe.prototype.source = null;
  qe.prototype.ruleId = null;
  qe.prototype.position = null;
  var ft = { basename: Yu, dirname: Qu, extname: Zu, join: Xu, sep: "/" };
  function Yu(e, t) {
    if (t !== void 0 && typeof t != "string")
      throw new TypeError('"ext" argument must be a string');
    w5(e);
    let n = 0,
      a = -1,
      r = e.length,
      o;
    if (t === void 0 || t.length === 0 || t.length > e.length) {
      for (; r--; )
        if (e.charCodeAt(r) === 47) {
          if (o) {
            n = r + 1;
            break;
          }
        } else a < 0 && ((o = !0), (a = r + 1));
      return a < 0 ? "" : e.slice(n, a);
    }
    if (t === e) return "";
    let i = -1,
      l = t.length - 1;
    for (; r--; )
      if (e.charCodeAt(r) === 47) {
        if (o) {
          n = r + 1;
          break;
        }
      } else
        i < 0 && ((o = !0), (i = r + 1)),
          l > -1 &&
            (e.charCodeAt(r) === t.charCodeAt(l--)
              ? l < 0 && (a = r)
              : ((l = -1), (a = i)));
    return n === a ? (a = i) : a < 0 && (a = e.length), e.slice(n, a);
  }
  function Qu(e) {
    if ((w5(e), e.length === 0)) return ".";
    let t = -1,
      n = e.length,
      a;
    for (; --n; )
      if (e.charCodeAt(n) === 47) {
        if (a) {
          t = n;
          break;
        }
      } else a || (a = !0);
    return t < 0
      ? e.charCodeAt(0) === 47
        ? "/"
        : "."
      : t === 1 && e.charCodeAt(0) === 47
      ? "//"
      : e.slice(0, t);
  }
  function Zu(e) {
    w5(e);
    let t = e.length,
      n = -1,
      a = 0,
      r = -1,
      o = 0,
      i;
    for (; t--; ) {
      let l = e.charCodeAt(t);
      if (l === 47) {
        if (i) {
          a = t + 1;
          break;
        }
        continue;
      }
      n < 0 && ((i = !0), (n = t + 1)),
        l === 46 ? (r < 0 ? (r = t) : o !== 1 && (o = 1)) : r > -1 && (o = -1);
    }
    return r < 0 || n < 0 || o === 0 || (o === 1 && r === n - 1 && r === a + 1)
      ? ""
      : e.slice(r, n);
  }
  function Xu(...e) {
    let t = -1,
      n;
    for (; ++t < e.length; )
      w5(e[t]), e[t] && (n = n === void 0 ? e[t] : n + "/" + e[t]);
    return n === void 0 ? "." : Ju(n);
  }
  function Ju(e) {
    w5(e);
    let t = e.charCodeAt(0) === 47,
      n = e3(e, !t);
    return (
      n.length === 0 && !t && (n = "."),
      n.length > 0 && e.charCodeAt(e.length - 1) === 47 && (n += "/"),
      t ? "/" + n : n
    );
  }
  function e3(e, t) {
    let n = "",
      a = 0,
      r = -1,
      o = 0,
      i = -1,
      l,
      s;
    for (; ++i <= e.length; ) {
      if (i < e.length) l = e.charCodeAt(i);
      else {
        if (l === 47) break;
        l = 47;
      }
      if (l === 47) {
        if (!(r === i - 1 || o === 1))
          if (r !== i - 1 && o === 2) {
            if (
              n.length < 2 ||
              a !== 2 ||
              n.charCodeAt(n.length - 1) !== 46 ||
              n.charCodeAt(n.length - 2) !== 46
            ) {
              if (n.length > 2) {
                if (((s = n.lastIndexOf("/")), s !== n.length - 1)) {
                  s < 0
                    ? ((n = ""), (a = 0))
                    : ((n = n.slice(0, s)),
                      (a = n.length - 1 - n.lastIndexOf("/"))),
                    (r = i),
                    (o = 0);
                  continue;
                }
              } else if (n.length > 0) {
                (n = ""), (a = 0), (r = i), (o = 0);
                continue;
              }
            }
            t && ((n = n.length > 0 ? n + "/.." : ".."), (a = 2));
          } else
            n.length > 0
              ? (n += "/" + e.slice(r + 1, i))
              : (n = e.slice(r + 1, i)),
              (a = i - r - 1);
        (r = i), (o = 0);
      } else l === 46 && o > -1 ? o++ : (o = -1);
    }
    return n;
  }
  function w5(e) {
    if (typeof e != "string")
      throw new TypeError(
        "Path must be a string. Received " + JSON.stringify(e)
      );
  }
  var so = { cwd: t3 };
  function t3() {
    return "/";
  }
  function r5(e) {
    return e !== null && typeof e == "object" && e.href && e.origin;
  }
  function uo(e) {
    if (typeof e == "string") e = new URL(e);
    else if (!r5(e)) {
      let t = new TypeError(
        'The "path" argument must be of type string or an instance of URL. Received `' +
          e +
          "`"
      );
      throw ((t.code = "ERR_INVALID_ARG_TYPE"), t);
    }
    if (e.protocol !== "file:") {
      let t = new TypeError("The URL must be of scheme file");
      throw ((t.code = "ERR_INVALID_URL_SCHEME"), t);
    }
    return n3(e);
  }
  function n3(e) {
    if (e.hostname !== "") {
      let a = new TypeError(
        'File URL host must be "localhost" or empty on darwin'
      );
      throw ((a.code = "ERR_INVALID_FILE_URL_HOST"), a);
    }
    let t = e.pathname,
      n = -1;
    for (; ++n < t.length; )
      if (t.charCodeAt(n) === 37 && t.charCodeAt(n + 1) === 50) {
        let a = t.charCodeAt(n + 2);
        if (a === 70 || a === 102) {
          let r = new TypeError(
            "File URL path must not include encoded / characters"
          );
          throw ((r.code = "ERR_INVALID_FILE_URL_PATH"), r);
        }
      }
    return decodeURIComponent(t);
  }
  var Hn = ["history", "path", "basename", "stem", "extname", "dirname"],
    Pt = class {
      constructor(t) {
        let n;
        t
          ? typeof t == "string" || (0, mo.default)(t)
            ? (n = { value: t })
            : r5(t)
            ? (n = { path: t })
            : (n = t)
          : (n = {}),
          (this.data = {}),
          (this.messages = []),
          (this.history = []),
          (this.cwd = so.cwd()),
          this.value,
          this.stored,
          this.result,
          this.map;
        let a = -1;
        for (; ++a < Hn.length; ) {
          let o = Hn[a];
          o in n &&
            n[o] !== void 0 &&
            (this[o] = o === "history" ? [...n[o]] : n[o]);
        }
        let r;
        for (r in n) Hn.includes(r) || (this[r] = n[r]);
      }
      get path() {
        return this.history[this.history.length - 1];
      }
      set path(t) {
        r5(t) && (t = uo(t)),
          Pn(t, "path"),
          this.path !== t && this.history.push(t);
      }
      get dirname() {
        return typeof this.path == "string" ? ft.dirname(this.path) : void 0;
      }
      set dirname(t) {
        po(this.basename, "dirname"),
          (this.path = ft.join(t || "", this.basename));
      }
      get basename() {
        return typeof this.path == "string" ? ft.basename(this.path) : void 0;
      }
      set basename(t) {
        Pn(t, "basename"),
          Dn(t, "basename"),
          (this.path = ft.join(this.dirname || "", t));
      }
      get extname() {
        return typeof this.path == "string" ? ft.extname(this.path) : void 0;
      }
      set extname(t) {
        if ((Dn(t, "extname"), po(this.dirname, "extname"), t)) {
          if (t.charCodeAt(0) !== 46)
            throw new Error("`extname` must start with `.`");
          if (t.includes(".", 1))
            throw new Error("`extname` cannot contain multiple dots");
        }
        this.path = ft.join(this.dirname, this.stem + (t || ""));
      }
      get stem() {
        return typeof this.path == "string"
          ? ft.basename(this.path, this.extname)
          : void 0;
      }
      set stem(t) {
        Pn(t, "stem"),
          Dn(t, "stem"),
          (this.path = ft.join(this.dirname || "", t + (this.extname || "")));
      }
      toString(t) {
        return (this.value || "").toString(t);
      }
      message(t, n, a) {
        let r = new qe(t, n, a);
        return (
          this.path &&
            ((r.name = this.path + ":" + r.name), (r.file = this.path)),
          (r.fatal = !1),
          this.messages.push(r),
          r
        );
      }
      info(t, n, a) {
        let r = this.message(t, n, a);
        return (r.fatal = null), r;
      }
      fail(t, n, a) {
        let r = this.message(t, n, a);
        throw ((r.fatal = !0), r);
      }
    };
  function Dn(e, t) {
    if (e && e.includes(ft.sep))
      throw new Error(
        "`" + t + "` cannot be a path: did not expect `" + ft.sep + "`"
      );
  }
  function Pn(e, t) {
    if (!e) throw new Error("`" + t + "` cannot be empty");
  }
  function po(e, t) {
    if (!e)
      throw new Error("Setting `" + t + "` requires `path` to be set too");
  }
  function Fn(e) {
    if (e) throw e;
  }
  var So = pt(Ln(), 1),
    Gn = pt(xo(), 1);
  function A5(e) {
    if (typeof e != "object" || e === null) return !1;
    let t = Object.getPrototypeOf(e);
    return (
      (t === null ||
        t === Object.prototype ||
        Object.getPrototypeOf(t) === null) &&
      !(Symbol.toStringTag in e) &&
      !(Symbol.iterator in e)
    );
  }
  function wo() {
    let e = [],
      t = { run: n, use: a };
    return t;
    function n(...r) {
      let o = -1,
        i = r.pop();
      if (typeof i != "function")
        throw new TypeError("Expected function as last argument, not " + i);
      l(null, ...r);
      function l(s, ...u) {
        let c = e[++o],
          d = -1;
        if (s) {
          i(s);
          return;
        }
        for (; ++d < r.length; )
          (u[d] === null || u[d] === void 0) && (u[d] = r[d]);
        (r = u), c ? a3(c, l)(...u) : i(null, ...u);
      }
    }
    function a(r) {
      if (typeof r != "function")
        throw new TypeError("Expected `middelware` to be a function, not " + r);
      return e.push(r), t;
    }
  }
  function a3(e, t) {
    let n;
    return a;
    function a(...i) {
      let l = e.length > i.length,
        s;
      l && i.push(r);
      try {
        s = e.apply(this, i);
      } catch (u) {
        let c = u;
        if (l && n) throw c;
        return r(c);
      }
      l ||
        (s instanceof Promise
          ? s.then(o, r)
          : s instanceof Error
          ? r(s)
          : o(s));
    }
    function r(i, ...l) {
      n || ((n = !0), t(i, ...l));
    }
    function o(i) {
      r(null, i);
    }
  }
  var $n = ko().freeze(),
    Co = {}.hasOwnProperty;
  function ko() {
    let e = wo(),
      t = [],
      n = {},
      a,
      r = -1;
    return (
      (o.data = i),
      (o.Parser = void 0),
      (o.Compiler = void 0),
      (o.freeze = l),
      (o.attachers = t),
      (o.use = s),
      (o.parse = u),
      (o.stringify = c),
      (o.run = d),
      (o.runSync = p),
      (o.process = m),
      (o.processSync = f),
      o
    );
    function o() {
      let v = ko(),
        g = -1;
      for (; ++g < t.length; ) v.use(...t[g]);
      return v.data((0, Gn.default)(!0, {}, n)), v;
    }
    function i(v, g) {
      return typeof v == "string"
        ? arguments.length === 2
          ? (Un("data", a), (n[v] = g), o)
          : (Co.call(n, v) && n[v]) || null
        : v
        ? (Un("data", a), (n = v), o)
        : n;
    }
    function l() {
      if (a) return o;
      for (; ++r < t.length; ) {
        let [v, ...g] = t[r];
        if (g[0] === !1) continue;
        g[0] === !0 && (g[0] = void 0);
        let _ = v.call(o, ...g);
        typeof _ == "function" && e.use(_);
      }
      return (a = !0), (r = Number.POSITIVE_INFINITY), o;
    }
    function s(v, ...g) {
      let _;
      if ((Un("use", a), v != null))
        if (typeof v == "function") M(v, ...g);
        else if (typeof v == "object") Array.isArray(v) ? w(v) : y(v);
        else throw new TypeError("Expected usable value, not `" + v + "`");
      return _ && (n.settings = Object.assign(n.settings || {}, _)), o;
      function C(E) {
        if (typeof E == "function") M(E);
        else if (typeof E == "object")
          if (Array.isArray(E)) {
            let [z, ...k] = E;
            M(z, ...k);
          } else y(E);
        else throw new TypeError("Expected usable value, not `" + E + "`");
      }
      function y(E) {
        w(E.plugins), E.settings && (_ = Object.assign(_ || {}, E.settings));
      }
      function w(E) {
        let z = -1;
        if (E != null)
          if (Array.isArray(E))
            for (; ++z < E.length; ) {
              let k = E[z];
              C(k);
            }
          else
            throw new TypeError("Expected a list of plugins, not `" + E + "`");
      }
      function M(E, z) {
        let k = -1,
          O;
        for (; ++k < t.length; )
          if (t[k][0] === E) {
            O = t[k];
            break;
          }
        O
          ? (A5(O[1]) && A5(z) && (z = (0, Gn.default)(!0, O[1], z)),
            (O[1] = z))
          : t.push([...arguments]);
      }
    }
    function u(v) {
      o.freeze();
      let g = M5(v),
        _ = o.Parser;
      return (
        Vn("parse", _),
        Ao(_, "parse") ? new _(String(g), g).parse() : _(String(g), g)
      );
    }
    function c(v, g) {
      o.freeze();
      let _ = M5(g),
        C = o.Compiler;
      return (
        Bn("stringify", C),
        Mo(v),
        Ao(C, "compile") ? new C(v, _).compile() : C(v, _)
      );
    }
    function d(v, g, _) {
      if (
        (Mo(v),
        o.freeze(),
        !_ && typeof g == "function" && ((_ = g), (g = void 0)),
        !_)
      )
        return new Promise(C);
      C(null, _);
      function C(y, w) {
        e.run(v, M5(g), M);
        function M(E, z, k) {
          (z = z || v), E ? w(E) : y ? y(z) : _(null, z, k);
        }
      }
    }
    function p(v, g) {
      let _, C;
      return o.run(v, g, y), zo("runSync", "run", C), _;
      function y(w, M) {
        Fn(w), (_ = M), (C = !0);
      }
    }
    function m(v, g) {
      if ((o.freeze(), Vn("process", o.Parser), Bn("process", o.Compiler), !g))
        return new Promise(_);
      _(null, g);
      function _(C, y) {
        let w = M5(v);
        o.run(o.parse(w), w, (E, z, k) => {
          if (E || !z || !k) M(E);
          else {
            let O = o.stringify(z, k);
            O == null || (i3(O) ? (k.value = O) : (k.result = O)), M(E, k);
          }
        });
        function M(E, z) {
          E || !z ? y(E) : C ? C(z) : g(null, z);
        }
      }
    }
    function f(v) {
      let g;
      o.freeze(), Vn("processSync", o.Parser), Bn("processSync", o.Compiler);
      let _ = M5(v);
      return o.process(_, C), zo("processSync", "process", g), _;
      function C(y) {
        (g = !0), Fn(y);
      }
    }
  }
  function Ao(e, t) {
    return (
      typeof e == "function" &&
      e.prototype &&
      (r3(e.prototype) || t in e.prototype)
    );
  }
  function r3(e) {
    let t;
    for (t in e) if (Co.call(e, t)) return !0;
    return !1;
  }
  function Vn(e, t) {
    if (typeof t != "function")
      throw new TypeError("Cannot `" + e + "` without `Parser`");
  }
  function Bn(e, t) {
    if (typeof t != "function")
      throw new TypeError("Cannot `" + e + "` without `Compiler`");
  }
  function Un(e, t) {
    if (t)
      throw new Error(
        "Cannot call `" +
          e +
          "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`."
      );
  }
  function Mo(e) {
    if (!A5(e) || typeof e.type != "string")
      throw new TypeError("Expected node, got `" + e + "`");
  }
  function zo(e, t, n) {
    if (!n)
      throw new Error("`" + e + "` finished async. Use `" + t + "` instead");
  }
  function M5(e) {
    return o3(e) ? e : new Pt(e);
  }
  function o3(e) {
    return Boolean(
      e && typeof e == "object" && "message" in e && "messages" in e
    );
  }
  function i3(e) {
    return typeof e == "string" || (0, So.default)(e);
  }
  function Io(e, t) {
    var { includeImageAlt: n = !0 } = t || {};
    return To(e, n);
  }
  function To(e, t) {
    return (
      (e &&
        typeof e == "object" &&
        (e.value ||
          (t ? e.alt : "") ||
          ("children" in e && Ro(e.children, t)) ||
          (Array.isArray(e) && Ro(e, t)))) ||
      ""
    );
  }
  function Ro(e, t) {
    for (var n = [], a = -1; ++a < e.length; ) n[a] = To(e[a], t);
    return n.join("");
  }
  function He(e, t, n, a) {
    let r = e.length,
      o = 0,
      i;
    if (
      (t < 0 ? (t = -t > r ? 0 : r + t) : (t = t > r ? r : t),
      (n = n > 0 ? n : 0),
      a.length < 1e4)
    )
      (i = Array.from(a)), i.unshift(t, n), [].splice.apply(e, i);
    else
      for (n && [].splice.apply(e, [t, n]); o < a.length; )
        (i = a.slice(o, o + 1e4)),
          i.unshift(t, 0),
          [].splice.apply(e, i),
          (o += 1e4),
          (t += 1e4);
  }
  function We(e, t) {
    return e.length > 0 ? (He(e, e.length, 0, t), e) : t;
  }
  var No = {}.hasOwnProperty;
  function Lo(e) {
    let t = {},
      n = -1;
    for (; ++n < e.length; ) l3(t, e[n]);
    return t;
  }
  function l3(e, t) {
    let n;
    for (n in t) {
      let r = (No.call(e, n) ? e[n] : void 0) || (e[n] = {}),
        o = t[n],
        i;
      for (i in o) {
        No.call(r, i) || (r[i] = []);
        let l = o[i];
        c3(r[i], Array.isArray(l) ? l : l ? [l] : []);
      }
    }
  }
  function c3(e, t) {
    let n = -1,
      a = [];
    for (; ++n < t.length; ) (t[n].add === "after" ? e : a).push(t[n]);
    He(e, 0, 0, a);
  }
  var Oo =
    /[!-/:-@[-`{-~\u00A1\u00A7\u00AB\u00B6\u00B7\u00BB\u00BF\u037E\u0387\u055A-\u055F\u0589\u058A\u05BE\u05C0\u05C3\u05C6\u05F3\u05F4\u0609\u060A\u060C\u060D\u061B\u061E\u061F\u066A-\u066D\u06D4\u0700-\u070D\u07F7-\u07F9\u0830-\u083E\u085E\u0964\u0965\u0970\u09FD\u0A76\u0AF0\u0C77\u0C84\u0DF4\u0E4F\u0E5A\u0E5B\u0F04-\u0F12\u0F14\u0F3A-\u0F3D\u0F85\u0FD0-\u0FD4\u0FD9\u0FDA\u104A-\u104F\u10FB\u1360-\u1368\u1400\u166E\u169B\u169C\u16EB-\u16ED\u1735\u1736\u17D4-\u17D6\u17D8-\u17DA\u1800-\u180A\u1944\u1945\u1A1E\u1A1F\u1AA0-\u1AA6\u1AA8-\u1AAD\u1B5A-\u1B60\u1BFC-\u1BFF\u1C3B-\u1C3F\u1C7E\u1C7F\u1CC0-\u1CC7\u1CD3\u2010-\u2027\u2030-\u2043\u2045-\u2051\u2053-\u205E\u207D\u207E\u208D\u208E\u2308-\u230B\u2329\u232A\u2768-\u2775\u27C5\u27C6\u27E6-\u27EF\u2983-\u2998\u29D8-\u29DB\u29FC\u29FD\u2CF9-\u2CFC\u2CFE\u2CFF\u2D70\u2E00-\u2E2E\u2E30-\u2E4F\u2E52\u3001-\u3003\u3008-\u3011\u3014-\u301F\u3030\u303D\u30A0\u30FB\uA4FE\uA4FF\uA60D-\uA60F\uA673\uA67E\uA6F2-\uA6F7\uA874-\uA877\uA8CE\uA8CF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA95F\uA9C1-\uA9CD\uA9DE\uA9DF\uAA5C-\uAA5F\uAADE\uAADF\uAAF0\uAAF1\uABEB\uFD3E\uFD3F\uFE10-\uFE19\uFE30-\uFE52\uFE54-\uFE61\uFE63\uFE68\uFE6A\uFE6B\uFF01-\uFF03\uFF05-\uFF0A\uFF0C-\uFF0F\uFF1A\uFF1B\uFF1F\uFF20\uFF3B-\uFF3D\uFF3F\uFF5B\uFF5D\uFF5F-\uFF65]/;
  var Je = Rt(/[A-Za-z]/),
    z5 = Rt(/\d/),
    Ho = Rt(/[\dA-Fa-f]/),
    Ne = Rt(/[\dA-Za-z]/),
    Do = Rt(/[!-/:-@[-`{-~]/),
    qn = Rt(/[#-'*+\--9=?A-Z^-~]/);
  function S5(e) {
    return e !== null && (e < 32 || e === 127);
  }
  function ke(e) {
    return e !== null && (e < 0 || e === 32);
  }
  function U(e) {
    return e !== null && e < -2;
  }
  function he(e) {
    return e === -2 || e === -1 || e === 32;
  }
  var Po = Rt(/\s/),
    Fo = Rt(Oo);
  function Rt(e) {
    return t;
    function t(n) {
      return n !== null && e.test(String.fromCharCode(n));
    }
  }
  function X(e, t, n, a) {
    let r = a ? a - 1 : Number.POSITIVE_INFINITY,
      o = 0;
    return i;
    function i(s) {
      return he(s) ? (e.enter(n), l(s)) : t(s);
    }
    function l(s) {
      return he(s) && o++ < r ? (e.consume(s), l) : (e.exit(n), t(s));
    }
  }
  var Vo = { tokenize: s3 };
  function s3(e) {
    let t = e.attempt(this.parser.constructs.contentInitial, a, r),
      n;
    return t;
    function a(l) {
      if (l === null) {
        e.consume(l);
        return;
      }
      return (
        e.enter("lineEnding"),
        e.consume(l),
        e.exit("lineEnding"),
        X(e, t, "linePrefix")
      );
    }
    function r(l) {
      return e.enter("paragraph"), o(l);
    }
    function o(l) {
      let s = e.enter("chunkText", { contentType: "text", previous: n });
      return n && (n.next = s), (n = s), i(l);
    }
    function i(l) {
      if (l === null) {
        e.exit("chunkText"), e.exit("paragraph"), e.consume(l);
        return;
      }
      return U(l) ? (e.consume(l), e.exit("chunkText"), o) : (e.consume(l), i);
    }
  }
  var Uo = { tokenize: u3 },
    Bo = { tokenize: d3 };
  function u3(e) {
    let t = this,
      n = [],
      a = 0,
      r,
      o,
      i;
    return l;
    function l(y) {
      if (a < n.length) {
        let w = n[a];
        return (t.containerState = w[1]), e.attempt(w[0].continuation, s, u)(y);
      }
      return u(y);
    }
    function s(y) {
      if ((a++, t.containerState._closeFlow)) {
        (t.containerState._closeFlow = void 0), r && C();
        let w = t.events.length,
          M = w,
          E;
        for (; M--; )
          if (
            t.events[M][0] === "exit" &&
            t.events[M][1].type === "chunkFlow"
          ) {
            E = t.events[M][1].end;
            break;
          }
        _(a);
        let z = w;
        for (; z < t.events.length; )
          (t.events[z][1].end = Object.assign({}, E)), z++;
        return (
          He(t.events, M + 1, 0, t.events.slice(w)), (t.events.length = z), u(y)
        );
      }
      return l(y);
    }
    function u(y) {
      if (a === n.length) {
        if (!r) return p(y);
        if (r.currentConstruct && r.currentConstruct.concrete) return f(y);
        t.interrupt = Boolean(
          r.currentConstruct && !r._gfmTableDynamicInterruptHack
        );
      }
      return (t.containerState = {}), e.check(Bo, c, d)(y);
    }
    function c(y) {
      return r && C(), _(a), p(y);
    }
    function d(y) {
      return (
        (t.parser.lazy[t.now().line] = a !== n.length),
        (i = t.now().offset),
        f(y)
      );
    }
    function p(y) {
      return (t.containerState = {}), e.attempt(Bo, m, f)(y);
    }
    function m(y) {
      return a++, n.push([t.currentConstruct, t.containerState]), p(y);
    }
    function f(y) {
      if (y === null) {
        r && C(), _(0), e.consume(y);
        return;
      }
      return (
        (r = r || t.parser.flow(t.now())),
        e.enter("chunkFlow", {
          contentType: "flow",
          previous: o,
          _tokenizer: r,
        }),
        v(y)
      );
    }
    function v(y) {
      if (y === null) {
        g(e.exit("chunkFlow"), !0), _(0), e.consume(y);
        return;
      }
      return U(y)
        ? (e.consume(y),
          g(e.exit("chunkFlow")),
          (a = 0),
          (t.interrupt = void 0),
          l)
        : (e.consume(y), v);
    }
    function g(y, w) {
      let M = t.sliceStream(y);
      if (
        (w && M.push(null),
        (y.previous = o),
        o && (o.next = y),
        (o = y),
        r.defineSkip(y.start),
        r.write(M),
        t.parser.lazy[y.start.line])
      ) {
        let E = r.events.length;
        for (; E--; )
          if (
            r.events[E][1].start.offset < i &&
            (!r.events[E][1].end || r.events[E][1].end.offset > i)
          )
            return;
        let z = t.events.length,
          k = z,
          O,
          K;
        for (; k--; )
          if (
            t.events[k][0] === "exit" &&
            t.events[k][1].type === "chunkFlow"
          ) {
            if (O) {
              K = t.events[k][1].end;
              break;
            }
            O = !0;
          }
        for (_(a), E = z; E < t.events.length; )
          (t.events[E][1].end = Object.assign({}, K)), E++;
        He(t.events, k + 1, 0, t.events.slice(z)), (t.events.length = E);
      }
    }
    function _(y) {
      let w = n.length;
      for (; w-- > y; ) {
        let M = n[w];
        (t.containerState = M[1]), M[0].exit.call(t, e);
      }
      n.length = y;
    }
    function C() {
      r.write([null]),
        (o = void 0),
        (r = void 0),
        (t.containerState._closeFlow = void 0);
    }
  }
  function d3(e, t, n) {
    return X(
      e,
      e.attempt(this.parser.constructs.document, t, n),
      "linePrefix",
      this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4
    );
  }
  function Wn(e) {
    if (e === null || ke(e) || Po(e)) return 1;
    if (Fo(e)) return 2;
  }
  function o5(e, t, n) {
    let a = [],
      r = -1;
    for (; ++r < e.length; ) {
      let o = e[r].resolveAll;
      o && !a.includes(o) && ((t = o(t, n)), a.push(o));
    }
    return t;
  }
  var C5 = { name: "attention", tokenize: m3, resolveAll: p3 };
  function p3(e, t) {
    let n = -1,
      a,
      r,
      o,
      i,
      l,
      s,
      u,
      c;
    for (; ++n < e.length; )
      if (
        e[n][0] === "enter" &&
        e[n][1].type === "attentionSequence" &&
        e[n][1]._close
      ) {
        for (a = n; a--; )
          if (
            e[a][0] === "exit" &&
            e[a][1].type === "attentionSequence" &&
            e[a][1]._open &&
            t.sliceSerialize(e[a][1]).charCodeAt(0) ===
              t.sliceSerialize(e[n][1]).charCodeAt(0)
          ) {
            if (
              (e[a][1]._close || e[n][1]._open) &&
              (e[n][1].end.offset - e[n][1].start.offset) % 3 &&
              !(
                (e[a][1].end.offset -
                  e[a][1].start.offset +
                  e[n][1].end.offset -
                  e[n][1].start.offset) %
                3
              )
            )
              continue;
            s =
              e[a][1].end.offset - e[a][1].start.offset > 1 &&
              e[n][1].end.offset - e[n][1].start.offset > 1
                ? 2
                : 1;
            let d = Object.assign({}, e[a][1].end),
              p = Object.assign({}, e[n][1].start);
            Go(d, -s),
              Go(p, s),
              (i = {
                type: s > 1 ? "strongSequence" : "emphasisSequence",
                start: d,
                end: Object.assign({}, e[a][1].end),
              }),
              (l = {
                type: s > 1 ? "strongSequence" : "emphasisSequence",
                start: Object.assign({}, e[n][1].start),
                end: p,
              }),
              (o = {
                type: s > 1 ? "strongText" : "emphasisText",
                start: Object.assign({}, e[a][1].end),
                end: Object.assign({}, e[n][1].start),
              }),
              (r = {
                type: s > 1 ? "strong" : "emphasis",
                start: Object.assign({}, i.start),
                end: Object.assign({}, l.end),
              }),
              (e[a][1].end = Object.assign({}, i.start)),
              (e[n][1].start = Object.assign({}, l.end)),
              (u = []),
              e[a][1].end.offset - e[a][1].start.offset &&
                (u = We(u, [
                  ["enter", e[a][1], t],
                  ["exit", e[a][1], t],
                ])),
              (u = We(u, [
                ["enter", r, t],
                ["enter", i, t],
                ["exit", i, t],
                ["enter", o, t],
              ])),
              (u = We(
                u,
                o5(t.parser.constructs.insideSpan.null, e.slice(a + 1, n), t)
              )),
              (u = We(u, [
                ["exit", o, t],
                ["enter", l, t],
                ["exit", l, t],
                ["exit", r, t],
              ])),
              e[n][1].end.offset - e[n][1].start.offset
                ? ((c = 2),
                  (u = We(u, [
                    ["enter", e[n][1], t],
                    ["exit", e[n][1], t],
                  ])))
                : (c = 0),
              He(e, a - 1, n - a + 3, u),
              (n = a + u.length - c - 2);
            break;
          }
      }
    for (n = -1; ++n < e.length; )
      e[n][1].type === "attentionSequence" && (e[n][1].type = "data");
    return e;
  }
  function m3(e, t) {
    let n = this.parser.constructs.attentionMarkers.null,
      a = this.previous,
      r = Wn(a),
      o;
    return i;
    function i(s) {
      return e.enter("attentionSequence"), (o = s), l(s);
    }
    function l(s) {
      if (s === o) return e.consume(s), l;
      let u = e.exit("attentionSequence"),
        c = Wn(s),
        d = !c || (c === 2 && r) || n.includes(s),
        p = !r || (r === 2 && c) || n.includes(a);
      return (
        (u._open = Boolean(o === 42 ? d : d && (r || !p))),
        (u._close = Boolean(o === 42 ? p : p && (c || !d))),
        t(s)
      );
    }
  }
  function Go(e, t) {
    (e.column += t), (e.offset += t), (e._bufferIndex += t);
  }
  var Kn = { name: "autolink", tokenize: h3 };
  function h3(e, t, n) {
    let a = 1;
    return r;
    function r(f) {
      return (
        e.enter("autolink"),
        e.enter("autolinkMarker"),
        e.consume(f),
        e.exit("autolinkMarker"),
        e.enter("autolinkProtocol"),
        o
      );
    }
    function o(f) {
      return Je(f) ? (e.consume(f), i) : qn(f) ? u(f) : n(f);
    }
    function i(f) {
      return f === 43 || f === 45 || f === 46 || Ne(f) ? l(f) : u(f);
    }
    function l(f) {
      return f === 58
        ? (e.consume(f), s)
        : (f === 43 || f === 45 || f === 46 || Ne(f)) && a++ < 32
        ? (e.consume(f), l)
        : u(f);
    }
    function s(f) {
      return f === 62
        ? (e.exit("autolinkProtocol"), m(f))
        : f === null || f === 32 || f === 60 || S5(f)
        ? n(f)
        : (e.consume(f), s);
    }
    function u(f) {
      return f === 64
        ? (e.consume(f), (a = 0), c)
        : qn(f)
        ? (e.consume(f), u)
        : n(f);
    }
    function c(f) {
      return Ne(f) ? d(f) : n(f);
    }
    function d(f) {
      return f === 46
        ? (e.consume(f), (a = 0), c)
        : f === 62
        ? ((e.exit("autolinkProtocol").type = "autolinkEmail"), m(f))
        : p(f);
    }
    function p(f) {
      return (f === 45 || Ne(f)) && a++ < 63
        ? (e.consume(f), f === 45 ? p : d)
        : n(f);
    }
    function m(f) {
      return (
        e.enter("autolinkMarker"),
        e.consume(f),
        e.exit("autolinkMarker"),
        e.exit("autolink"),
        t
      );
    }
  }
  var It = { tokenize: f3, partial: !0 };
  function f3(e, t, n) {
    return X(e, a, "linePrefix");
    function a(r) {
      return r === null || U(r) ? t(r) : n(r);
    }
  }
  var u1 = {
    name: "blockQuote",
    tokenize: g3,
    continuation: { tokenize: v3 },
    exit: b3,
  };
  function g3(e, t, n) {
    let a = this;
    return r;
    function r(i) {
      if (i === 62) {
        let l = a.containerState;
        return (
          l.open || (e.enter("blockQuote", { _container: !0 }), (l.open = !0)),
          e.enter("blockQuotePrefix"),
          e.enter("blockQuoteMarker"),
          e.consume(i),
          e.exit("blockQuoteMarker"),
          o
        );
      }
      return n(i);
    }
    function o(i) {
      return he(i)
        ? (e.enter("blockQuotePrefixWhitespace"),
          e.consume(i),
          e.exit("blockQuotePrefixWhitespace"),
          e.exit("blockQuotePrefix"),
          t)
        : (e.exit("blockQuotePrefix"), t(i));
    }
  }
  function v3(e, t, n) {
    return X(
      e,
      e.attempt(u1, t, n),
      "linePrefix",
      this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4
    );
  }
  function b3(e) {
    e.exit("blockQuote");
  }
  var d1 = { name: "characterEscape", tokenize: _3 };
  function _3(e, t, n) {
    return a;
    function a(o) {
      return (
        e.enter("characterEscape"),
        e.enter("escapeMarker"),
        e.consume(o),
        e.exit("escapeMarker"),
        r
      );
    }
    function r(o) {
      return Do(o)
        ? (e.enter("characterEscapeValue"),
          e.consume(o),
          e.exit("characterEscapeValue"),
          e.exit("characterEscape"),
          t)
        : n(o);
    }
  }
  var $o = document.createElement("i");
  function i5(e) {
    let t = "&" + e + ";";
    $o.innerHTML = t;
    let n = $o.textContent;
    return (n.charCodeAt(n.length - 1) === 59 && e !== "semi") || n === t
      ? !1
      : n;
  }
  var p1 = { name: "characterReference", tokenize: E3 };
  function E3(e, t, n) {
    let a = this,
      r = 0,
      o,
      i;
    return l;
    function l(d) {
      return (
        e.enter("characterReference"),
        e.enter("characterReferenceMarker"),
        e.consume(d),
        e.exit("characterReferenceMarker"),
        s
      );
    }
    function s(d) {
      return d === 35
        ? (e.enter("characterReferenceMarkerNumeric"),
          e.consume(d),
          e.exit("characterReferenceMarkerNumeric"),
          u)
        : (e.enter("characterReferenceValue"), (o = 31), (i = Ne), c(d));
    }
    function u(d) {
      return d === 88 || d === 120
        ? (e.enter("characterReferenceMarkerHexadecimal"),
          e.consume(d),
          e.exit("characterReferenceMarkerHexadecimal"),
          e.enter("characterReferenceValue"),
          (o = 6),
          (i = Ho),
          c)
        : (e.enter("characterReferenceValue"), (o = 7), (i = z5), c(d));
    }
    function c(d) {
      let p;
      return d === 59 && r
        ? ((p = e.exit("characterReferenceValue")),
          i === Ne && !i5(a.sliceSerialize(p))
            ? n(d)
            : (e.enter("characterReferenceMarker"),
              e.consume(d),
              e.exit("characterReferenceMarker"),
              e.exit("characterReference"),
              t))
        : i(d) && r++ < o
        ? (e.consume(d), c)
        : n(d);
    }
  }
  var m1 = { name: "codeFenced", tokenize: y3, concrete: !0 };
  function y3(e, t, n) {
    let a = this,
      r = { tokenize: M, partial: !0 },
      o = { tokenize: w, partial: !0 },
      i = this.events[this.events.length - 1],
      l =
        i && i[1].type === "linePrefix"
          ? i[2].sliceSerialize(i[1], !0).length
          : 0,
      s = 0,
      u;
    return c;
    function c(E) {
      return (
        e.enter("codeFenced"),
        e.enter("codeFencedFence"),
        e.enter("codeFencedFenceSequence"),
        (u = E),
        d(E)
      );
    }
    function d(E) {
      return E === u
        ? (e.consume(E), s++, d)
        : (e.exit("codeFencedFenceSequence"),
          s < 3 ? n(E) : X(e, p, "whitespace")(E));
    }
    function p(E) {
      return E === null || U(E)
        ? g(E)
        : (e.enter("codeFencedFenceInfo"),
          e.enter("chunkString", { contentType: "string" }),
          m(E));
    }
    function m(E) {
      return E === null || ke(E)
        ? (e.exit("chunkString"),
          e.exit("codeFencedFenceInfo"),
          X(e, f, "whitespace")(E))
        : E === 96 && E === u
        ? n(E)
        : (e.consume(E), m);
    }
    function f(E) {
      return E === null || U(E)
        ? g(E)
        : (e.enter("codeFencedFenceMeta"),
          e.enter("chunkString", { contentType: "string" }),
          v(E));
    }
    function v(E) {
      return E === null || U(E)
        ? (e.exit("chunkString"), e.exit("codeFencedFenceMeta"), g(E))
        : E === 96 && E === u
        ? n(E)
        : (e.consume(E), v);
    }
    function g(E) {
      return e.exit("codeFencedFence"), a.interrupt ? t(E) : _(E);
    }
    function _(E) {
      return E === null
        ? y(E)
        : U(E)
        ? e.attempt(
            o,
            e.attempt(r, y, l ? X(e, _, "linePrefix", l + 1) : _),
            y
          )(E)
        : (e.enter("codeFlowValue"), C(E));
    }
    function C(E) {
      return E === null || U(E)
        ? (e.exit("codeFlowValue"), _(E))
        : (e.consume(E), C);
    }
    function y(E) {
      return e.exit("codeFenced"), t(E);
    }
    function w(E, z, k) {
      let O = this;
      return K;
      function K(V) {
        return E.enter("lineEnding"), E.consume(V), E.exit("lineEnding"), H;
      }
      function H(V) {
        return O.parser.lazy[O.now().line] ? k(V) : z(V);
      }
    }
    function M(E, z, k) {
      let O = 0;
      return X(
        E,
        K,
        "linePrefix",
        this.parser.constructs.disable.null.includes("codeIndented")
          ? void 0
          : 4
      );
      function K(I) {
        return (
          E.enter("codeFencedFence"), E.enter("codeFencedFenceSequence"), H(I)
        );
      }
      function H(I) {
        return I === u
          ? (E.consume(I), O++, H)
          : O < s
          ? k(I)
          : (E.exit("codeFencedFenceSequence"), X(E, V, "whitespace")(I));
      }
      function V(I) {
        return I === null || U(I) ? (E.exit("codeFencedFence"), z(I)) : k(I);
      }
    }
  }
  var k5 = { name: "codeIndented", tokenize: w3 },
    x3 = { tokenize: A3, partial: !0 };
  function w3(e, t, n) {
    let a = this;
    return r;
    function r(u) {
      return e.enter("codeIndented"), X(e, o, "linePrefix", 4 + 1)(u);
    }
    function o(u) {
      let c = a.events[a.events.length - 1];
      return c &&
        c[1].type === "linePrefix" &&
        c[2].sliceSerialize(c[1], !0).length >= 4
        ? i(u)
        : n(u);
    }
    function i(u) {
      return u === null
        ? s(u)
        : U(u)
        ? e.attempt(x3, i, s)(u)
        : (e.enter("codeFlowValue"), l(u));
    }
    function l(u) {
      return u === null || U(u)
        ? (e.exit("codeFlowValue"), i(u))
        : (e.consume(u), l);
    }
    function s(u) {
      return e.exit("codeIndented"), t(u);
    }
  }
  function A3(e, t, n) {
    let a = this;
    return r;
    function r(i) {
      return a.parser.lazy[a.now().line]
        ? n(i)
        : U(i)
        ? (e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), r)
        : X(e, o, "linePrefix", 4 + 1)(i);
    }
    function o(i) {
      let l = a.events[a.events.length - 1];
      return l &&
        l[1].type === "linePrefix" &&
        l[2].sliceSerialize(l[1], !0).length >= 4
        ? t(i)
        : U(i)
        ? r(i)
        : n(i);
    }
  }
  var jn = { name: "codeText", tokenize: S3, resolve: M3, previous: z3 };
  function M3(e) {
    let t = e.length - 4,
      n = 3,
      a,
      r;
    if (
      (e[n][1].type === "lineEnding" || e[n][1].type === "space") &&
      (e[t][1].type === "lineEnding" || e[t][1].type === "space")
    ) {
      for (a = n; ++a < t; )
        if (e[a][1].type === "codeTextData") {
          (e[n][1].type = "codeTextPadding"),
            (e[t][1].type = "codeTextPadding"),
            (n += 2),
            (t -= 2);
          break;
        }
    }
    for (a = n - 1, t++; ++a <= t; )
      r === void 0
        ? a !== t && e[a][1].type !== "lineEnding" && (r = a)
        : (a === t || e[a][1].type === "lineEnding") &&
          ((e[r][1].type = "codeTextData"),
          a !== r + 2 &&
            ((e[r][1].end = e[a - 1][1].end),
            e.splice(r + 2, a - r - 2),
            (t -= a - r - 2),
            (a = r + 2)),
          (r = void 0));
    return e;
  }
  function z3(e) {
    return (
      e !== 96 ||
      this.events[this.events.length - 1][1].type === "characterEscape"
    );
  }
  function S3(e, t, n) {
    let a = this,
      r = 0,
      o,
      i;
    return l;
    function l(p) {
      return e.enter("codeText"), e.enter("codeTextSequence"), s(p);
    }
    function s(p) {
      return p === 96
        ? (e.consume(p), r++, s)
        : (e.exit("codeTextSequence"), u(p));
    }
    function u(p) {
      return p === null
        ? n(p)
        : p === 96
        ? ((i = e.enter("codeTextSequence")), (o = 0), d(p))
        : p === 32
        ? (e.enter("space"), e.consume(p), e.exit("space"), u)
        : U(p)
        ? (e.enter("lineEnding"), e.consume(p), e.exit("lineEnding"), u)
        : (e.enter("codeTextData"), c(p));
    }
    function c(p) {
      return p === null || p === 32 || p === 96 || U(p)
        ? (e.exit("codeTextData"), u(p))
        : (e.consume(p), c);
    }
    function d(p) {
      return p === 96
        ? (e.consume(p), o++, d)
        : o === r
        ? (e.exit("codeTextSequence"), e.exit("codeText"), t(p))
        : ((i.type = "codeTextData"), c(p));
    }
  }
  function h1(e) {
    let t = {},
      n = -1,
      a,
      r,
      o,
      i,
      l,
      s,
      u;
    for (; ++n < e.length; ) {
      for (; n in t; ) n = t[n];
      if (
        ((a = e[n]),
        n &&
          a[1].type === "chunkFlow" &&
          e[n - 1][1].type === "listItemPrefix" &&
          ((s = a[1]._tokenizer.events),
          (o = 0),
          o < s.length && s[o][1].type === "lineEndingBlank" && (o += 2),
          o < s.length && s[o][1].type === "content"))
      )
        for (; ++o < s.length && s[o][1].type !== "content"; )
          s[o][1].type === "chunkText" &&
            ((s[o][1]._isInFirstContentOfListItem = !0), o++);
      if (a[0] === "enter")
        a[1].contentType && (Object.assign(t, C3(e, n)), (n = t[n]), (u = !0));
      else if (a[1]._container) {
        for (
          o = n, r = void 0;
          o-- &&
          ((i = e[o]),
          i[1].type === "lineEnding" || i[1].type === "lineEndingBlank");

        )
          i[0] === "enter" &&
            (r && (e[r][1].type = "lineEndingBlank"),
            (i[1].type = "lineEnding"),
            (r = o));
        r &&
          ((a[1].end = Object.assign({}, e[r][1].start)),
          (l = e.slice(r, n)),
          l.unshift(a),
          He(e, r, n - r + 1, l));
      }
    }
    return !u;
  }
  function C3(e, t) {
    let n = e[t][1],
      a = e[t][2],
      r = t - 1,
      o = [],
      i = n._tokenizer || a.parser[n.contentType](n.start),
      l = i.events,
      s = [],
      u = {},
      c,
      d,
      p = -1,
      m = n,
      f = 0,
      v = 0,
      g = [v];
    for (; m; ) {
      for (; e[++r][1] !== m; );
      o.push(r),
        m._tokenizer ||
          ((c = a.sliceStream(m)),
          m.next || c.push(null),
          d && i.defineSkip(m.start),
          m._isInFirstContentOfListItem &&
            (i._gfmTasklistFirstContentOfListItem = !0),
          i.write(c),
          m._isInFirstContentOfListItem &&
            (i._gfmTasklistFirstContentOfListItem = void 0)),
        (d = m),
        (m = m.next);
    }
    for (m = n; ++p < l.length; )
      l[p][0] === "exit" &&
        l[p - 1][0] === "enter" &&
        l[p][1].type === l[p - 1][1].type &&
        l[p][1].start.line !== l[p][1].end.line &&
        ((v = p + 1),
        g.push(v),
        (m._tokenizer = void 0),
        (m.previous = void 0),
        (m = m.next));
    for (
      i.events = [],
        m ? ((m._tokenizer = void 0), (m.previous = void 0)) : g.pop(),
        p = g.length;
      p--;

    ) {
      let _ = l.slice(g[p], g[p + 1]),
        C = o.pop();
      s.unshift([C, C + _.length - 1]), He(e, C, 2, _);
    }
    for (p = -1; ++p < s.length; )
      (u[f + s[p][0]] = f + s[p][1]), (f += s[p][1] - s[p][0] - 1);
    return u;
  }
  var Yn = { tokenize: I3, resolve: R3 },
    k3 = { tokenize: T3, partial: !0 };
  function R3(e) {
    return h1(e), e;
  }
  function I3(e, t) {
    let n;
    return a;
    function a(l) {
      return (
        e.enter("content"),
        (n = e.enter("chunkContent", { contentType: "content" })),
        r(l)
      );
    }
    function r(l) {
      return l === null
        ? o(l)
        : U(l)
        ? e.check(k3, i, o)(l)
        : (e.consume(l), r);
    }
    function o(l) {
      return e.exit("chunkContent"), e.exit("content"), t(l);
    }
    function i(l) {
      return (
        e.consume(l),
        e.exit("chunkContent"),
        (n.next = e.enter("chunkContent", {
          contentType: "content",
          previous: n,
        })),
        (n = n.next),
        r
      );
    }
  }
  function T3(e, t, n) {
    let a = this;
    return r;
    function r(i) {
      return (
        e.exit("chunkContent"),
        e.enter("lineEnding"),
        e.consume(i),
        e.exit("lineEnding"),
        X(e, o, "linePrefix")
      );
    }
    function o(i) {
      if (i === null || U(i)) return n(i);
      let l = a.events[a.events.length - 1];
      return !a.parser.constructs.disable.null.includes("codeIndented") &&
        l &&
        l[1].type === "linePrefix" &&
        l[2].sliceSerialize(l[1], !0).length >= 4
        ? t(i)
        : e.interrupt(a.parser.constructs.flow, n, t)(i);
    }
  }
  function f1(e, t, n, a, r, o, i, l, s) {
    let u = s || Number.POSITIVE_INFINITY,
      c = 0;
    return d;
    function d(_) {
      return _ === 60
        ? (e.enter(a), e.enter(r), e.enter(o), e.consume(_), e.exit(o), p)
        : _ === null || _ === 41 || S5(_)
        ? n(_)
        : (e.enter(a),
          e.enter(i),
          e.enter(l),
          e.enter("chunkString", { contentType: "string" }),
          v(_));
    }
    function p(_) {
      return _ === 62
        ? (e.enter(o), e.consume(_), e.exit(o), e.exit(r), e.exit(a), t)
        : (e.enter(l), e.enter("chunkString", { contentType: "string" }), m(_));
    }
    function m(_) {
      return _ === 62
        ? (e.exit("chunkString"), e.exit(l), p(_))
        : _ === null || _ === 60 || U(_)
        ? n(_)
        : (e.consume(_), _ === 92 ? f : m);
    }
    function f(_) {
      return _ === 60 || _ === 62 || _ === 92 ? (e.consume(_), m) : m(_);
    }
    function v(_) {
      return _ === 40
        ? ++c > u
          ? n(_)
          : (e.consume(_), v)
        : _ === 41
        ? c--
          ? (e.consume(_), v)
          : (e.exit("chunkString"), e.exit(l), e.exit(i), e.exit(a), t(_))
        : _ === null || ke(_)
        ? c
          ? n(_)
          : (e.exit("chunkString"), e.exit(l), e.exit(i), e.exit(a), t(_))
        : S5(_)
        ? n(_)
        : (e.consume(_), _ === 92 ? g : v);
    }
    function g(_) {
      return _ === 40 || _ === 41 || _ === 92 ? (e.consume(_), v) : v(_);
    }
  }
  function g1(e, t, n, a, r, o) {
    let i = this,
      l = 0,
      s;
    return u;
    function u(m) {
      return e.enter(a), e.enter(r), e.consume(m), e.exit(r), e.enter(o), c;
    }
    function c(m) {
      return m === null ||
        m === 91 ||
        (m === 93 && !s) ||
        (m === 94 && !l && "_hiddenFootnoteSupport" in i.parser.constructs) ||
        l > 999
        ? n(m)
        : m === 93
        ? (e.exit(o), e.enter(r), e.consume(m), e.exit(r), e.exit(a), t)
        : U(m)
        ? (e.enter("lineEnding"), e.consume(m), e.exit("lineEnding"), c)
        : (e.enter("chunkString", { contentType: "string" }), d(m));
    }
    function d(m) {
      return m === null || m === 91 || m === 93 || U(m) || l++ > 999
        ? (e.exit("chunkString"), c(m))
        : (e.consume(m), (s = s || !he(m)), m === 92 ? p : d);
    }
    function p(m) {
      return m === 91 || m === 92 || m === 93 ? (e.consume(m), l++, d) : d(m);
    }
  }
  function v1(e, t, n, a, r, o) {
    let i;
    return l;
    function l(p) {
      return (
        e.enter(a),
        e.enter(r),
        e.consume(p),
        e.exit(r),
        (i = p === 40 ? 41 : p),
        s
      );
    }
    function s(p) {
      return p === i
        ? (e.enter(r), e.consume(p), e.exit(r), e.exit(a), t)
        : (e.enter(o), u(p));
    }
    function u(p) {
      return p === i
        ? (e.exit(o), s(i))
        : p === null
        ? n(p)
        : U(p)
        ? (e.enter("lineEnding"),
          e.consume(p),
          e.exit("lineEnding"),
          X(e, u, "linePrefix"))
        : (e.enter("chunkString", { contentType: "string" }), c(p));
    }
    function c(p) {
      return p === i || p === null || U(p)
        ? (e.exit("chunkString"), u(p))
        : (e.consume(p), p === 92 ? d : c);
    }
    function d(p) {
      return p === i || p === 92 ? (e.consume(p), c) : c(p);
    }
  }
  function Ft(e, t) {
    let n;
    return a;
    function a(r) {
      return U(r)
        ? (e.enter("lineEnding"),
          e.consume(r),
          e.exit("lineEnding"),
          (n = !0),
          a)
        : he(r)
        ? X(e, a, n ? "linePrefix" : "lineSuffix")(r)
        : t(r);
    }
  }
  function xt(e) {
    return e
      .replace(/[\t\n\r ]+/g, " ")
      .replace(/^ | $/g, "")
      .toLowerCase()
      .toUpperCase();
  }
  var Qn = { name: "definition", tokenize: L3 },
    N3 = { tokenize: O3, partial: !0 };
  function L3(e, t, n) {
    let a = this,
      r;
    return o;
    function o(s) {
      return (
        e.enter("definition"),
        g1.call(
          a,
          e,
          i,
          n,
          "definitionLabel",
          "definitionLabelMarker",
          "definitionLabelString"
        )(s)
      );
    }
    function i(s) {
      return (
        (r = xt(
          a.sliceSerialize(a.events[a.events.length - 1][1]).slice(1, -1)
        )),
        s === 58
          ? (e.enter("definitionMarker"),
            e.consume(s),
            e.exit("definitionMarker"),
            Ft(
              e,
              f1(
                e,
                e.attempt(N3, X(e, l, "whitespace"), X(e, l, "whitespace")),
                n,
                "definitionDestination",
                "definitionDestinationLiteral",
                "definitionDestinationLiteralMarker",
                "definitionDestinationRaw",
                "definitionDestinationString"
              )
            ))
          : n(s)
      );
    }
    function l(s) {
      return s === null || U(s)
        ? (e.exit("definition"),
          a.parser.defined.includes(r) || a.parser.defined.push(r),
          t(s))
        : n(s);
    }
  }
  function O3(e, t, n) {
    return a;
    function a(i) {
      return ke(i) ? Ft(e, r)(i) : n(i);
    }
    function r(i) {
      return i === 34 || i === 39 || i === 40
        ? v1(
            e,
            X(e, o, "whitespace"),
            n,
            "definitionTitle",
            "definitionTitleMarker",
            "definitionTitleString"
          )(i)
        : n(i);
    }
    function o(i) {
      return i === null || U(i) ? t(i) : n(i);
    }
  }
  var Zn = { name: "hardBreakEscape", tokenize: H3 };
  function H3(e, t, n) {
    return a;
    function a(o) {
      return (
        e.enter("hardBreakEscape"), e.enter("escapeMarker"), e.consume(o), r
      );
    }
    function r(o) {
      return U(o)
        ? (e.exit("escapeMarker"), e.exit("hardBreakEscape"), t(o))
        : n(o);
    }
  }
  var Xn = { name: "headingAtx", tokenize: P3, resolve: D3 };
  function D3(e, t) {
    let n = e.length - 2,
      a = 3,
      r,
      o;
    return (
      e[a][1].type === "whitespace" && (a += 2),
      n - 2 > a && e[n][1].type === "whitespace" && (n -= 2),
      e[n][1].type === "atxHeadingSequence" &&
        (a === n - 1 || (n - 4 > a && e[n - 2][1].type === "whitespace")) &&
        (n -= a + 1 === n ? 2 : 4),
      n > a &&
        ((r = {
          type: "atxHeadingText",
          start: e[a][1].start,
          end: e[n][1].end,
        }),
        (o = {
          type: "chunkText",
          start: e[a][1].start,
          end: e[n][1].end,
          contentType: "text",
        }),
        He(e, a, n - a + 1, [
          ["enter", r, t],
          ["enter", o, t],
          ["exit", o, t],
          ["exit", r, t],
        ])),
      e
    );
  }
  function P3(e, t, n) {
    let a = this,
      r = 0;
    return o;
    function o(c) {
      return e.enter("atxHeading"), e.enter("atxHeadingSequence"), i(c);
    }
    function i(c) {
      return c === 35 && r++ < 6
        ? (e.consume(c), i)
        : c === null || ke(c)
        ? (e.exit("atxHeadingSequence"), a.interrupt ? t(c) : l(c))
        : n(c);
    }
    function l(c) {
      return c === 35
        ? (e.enter("atxHeadingSequence"), s(c))
        : c === null || U(c)
        ? (e.exit("atxHeading"), t(c))
        : he(c)
        ? X(e, l, "whitespace")(c)
        : (e.enter("atxHeadingText"), u(c));
    }
    function s(c) {
      return c === 35
        ? (e.consume(c), s)
        : (e.exit("atxHeadingSequence"), l(c));
    }
    function u(c) {
      return c === null || c === 35 || ke(c)
        ? (e.exit("atxHeadingText"), l(c))
        : (e.consume(c), u);
    }
  }
  var qo = [
      "address",
      "article",
      "aside",
      "base",
      "basefont",
      "blockquote",
      "body",
      "caption",
      "center",
      "col",
      "colgroup",
      "dd",
      "details",
      "dialog",
      "dir",
      "div",
      "dl",
      "dt",
      "fieldset",
      "figcaption",
      "figure",
      "footer",
      "form",
      "frame",
      "frameset",
      "h1",
      "h2",
      "h3",
      "h4",
      "h5",
      "h6",
      "head",
      "header",
      "hr",
      "html",
      "iframe",
      "legend",
      "li",
      "link",
      "main",
      "menu",
      "menuitem",
      "nav",
      "noframes",
      "ol",
      "optgroup",
      "option",
      "p",
      "param",
      "section",
      "summary",
      "table",
      "tbody",
      "td",
      "tfoot",
      "th",
      "thead",
      "title",
      "tr",
      "track",
      "ul",
    ],
    Jn = ["pre", "script", "style", "textarea"];
  var e0 = { name: "htmlFlow", tokenize: B3, resolveTo: V3, concrete: !0 },
    F3 = { tokenize: U3, partial: !0 };
  function V3(e) {
    let t = e.length;
    for (; t-- && !(e[t][0] === "enter" && e[t][1].type === "htmlFlow"); );
    return (
      t > 1 &&
        e[t - 2][1].type === "linePrefix" &&
        ((e[t][1].start = e[t - 2][1].start),
        (e[t + 1][1].start = e[t - 2][1].start),
        e.splice(t - 2, 2)),
      e
    );
  }
  function B3(e, t, n) {
    let a = this,
      r,
      o,
      i,
      l,
      s;
    return u;
    function u(h) {
      return e.enter("htmlFlow"), e.enter("htmlFlowData"), e.consume(h), c;
    }
    function c(h) {
      return h === 33
        ? (e.consume(h), d)
        : h === 47
        ? (e.consume(h), f)
        : h === 63
        ? (e.consume(h), (r = 3), a.interrupt ? t : B)
        : Je(h)
        ? (e.consume(h), (i = String.fromCharCode(h)), (o = !0), v)
        : n(h);
    }
    function d(h) {
      return h === 45
        ? (e.consume(h), (r = 2), p)
        : h === 91
        ? (e.consume(h), (r = 5), (i = "CDATA["), (l = 0), m)
        : Je(h)
        ? (e.consume(h), (r = 4), a.interrupt ? t : B)
        : n(h);
    }
    function p(h) {
      return h === 45 ? (e.consume(h), a.interrupt ? t : B) : n(h);
    }
    function m(h) {
      return h === i.charCodeAt(l++)
        ? (e.consume(h), l === i.length ? (a.interrupt ? t : H) : m)
        : n(h);
    }
    function f(h) {
      return Je(h) ? (e.consume(h), (i = String.fromCharCode(h)), v) : n(h);
    }
    function v(h) {
      return h === null || h === 47 || h === 62 || ke(h)
        ? h !== 47 && o && Jn.includes(i.toLowerCase())
          ? ((r = 1), a.interrupt ? t(h) : H(h))
          : qo.includes(i.toLowerCase())
          ? ((r = 6), h === 47 ? (e.consume(h), g) : a.interrupt ? t(h) : H(h))
          : ((r = 7),
            a.interrupt && !a.parser.lazy[a.now().line]
              ? n(h)
              : o
              ? C(h)
              : _(h))
        : h === 45 || Ne(h)
        ? (e.consume(h), (i += String.fromCharCode(h)), v)
        : n(h);
    }
    function g(h) {
      return h === 62 ? (e.consume(h), a.interrupt ? t : H) : n(h);
    }
    function _(h) {
      return he(h) ? (e.consume(h), _) : O(h);
    }
    function C(h) {
      return h === 47
        ? (e.consume(h), O)
        : h === 58 || h === 95 || Je(h)
        ? (e.consume(h), y)
        : he(h)
        ? (e.consume(h), C)
        : O(h);
    }
    function y(h) {
      return h === 45 || h === 46 || h === 58 || h === 95 || Ne(h)
        ? (e.consume(h), y)
        : w(h);
    }
    function w(h) {
      return h === 61 ? (e.consume(h), M) : he(h) ? (e.consume(h), w) : C(h);
    }
    function M(h) {
      return h === null || h === 60 || h === 61 || h === 62 || h === 96
        ? n(h)
        : h === 34 || h === 39
        ? (e.consume(h), (s = h), E)
        : he(h)
        ? (e.consume(h), M)
        : ((s = null), z(h));
    }
    function E(h) {
      return h === null || U(h)
        ? n(h)
        : h === s
        ? (e.consume(h), k)
        : (e.consume(h), E);
    }
    function z(h) {
      return h === null ||
        h === 34 ||
        h === 39 ||
        h === 60 ||
        h === 61 ||
        h === 62 ||
        h === 96 ||
        ke(h)
        ? w(h)
        : (e.consume(h), z);
    }
    function k(h) {
      return h === 47 || h === 62 || he(h) ? C(h) : n(h);
    }
    function O(h) {
      return h === 62 ? (e.consume(h), K) : n(h);
    }
    function K(h) {
      return he(h) ? (e.consume(h), K) : h === null || U(h) ? H(h) : n(h);
    }
    function H(h) {
      return h === 45 && r === 2
        ? (e.consume(h), J)
        : h === 60 && r === 1
        ? (e.consume(h), R)
        : h === 62 && r === 4
        ? (e.consume(h), $)
        : h === 63 && r === 3
        ? (e.consume(h), B)
        : h === 93 && r === 5
        ? (e.consume(h), P)
        : U(h) && (r === 6 || r === 7)
        ? e.check(F3, $, V)(h)
        : h === null || U(h)
        ? V(h)
        : (e.consume(h), H);
    }
    function V(h) {
      return e.exit("htmlFlowData"), I(h);
    }
    function I(h) {
      return h === null
        ? b(h)
        : U(h)
        ? e.attempt({ tokenize: D, partial: !0 }, I, b)(h)
        : (e.enter("htmlFlowData"), H(h));
    }
    function D(h, Le, le) {
      return me;
      function me(Me) {
        return h.enter("lineEnding"), h.consume(Me), h.exit("lineEnding"), Ge;
      }
      function Ge(Me) {
        return a.parser.lazy[a.now().line] ? le(Me) : Le(Me);
      }
    }
    function J(h) {
      return h === 45 ? (e.consume(h), B) : H(h);
    }
    function R(h) {
      return h === 47 ? (e.consume(h), (i = ""), T) : H(h);
    }
    function T(h) {
      return h === 62 && Jn.includes(i.toLowerCase())
        ? (e.consume(h), $)
        : Je(h) && i.length < 8
        ? (e.consume(h), (i += String.fromCharCode(h)), T)
        : H(h);
    }
    function P(h) {
      return h === 93 ? (e.consume(h), B) : H(h);
    }
    function B(h) {
      return h === 62
        ? (e.consume(h), $)
        : h === 45 && r === 2
        ? (e.consume(h), B)
        : H(h);
    }
    function $(h) {
      return h === null || U(h)
        ? (e.exit("htmlFlowData"), b(h))
        : (e.consume(h), $);
    }
    function b(h) {
      return e.exit("htmlFlow"), t(h);
    }
  }
  function U3(e, t, n) {
    return a;
    function a(r) {
      return (
        e.exit("htmlFlowData"),
        e.enter("lineEndingBlank"),
        e.consume(r),
        e.exit("lineEndingBlank"),
        e.attempt(It, t, n)
      );
    }
  }
  var t0 = { name: "htmlText", tokenize: G3 };
  function G3(e, t, n) {
    let a = this,
      r,
      o,
      i,
      l;
    return s;
    function s(b) {
      return e.enter("htmlText"), e.enter("htmlTextData"), e.consume(b), u;
    }
    function u(b) {
      return b === 33
        ? (e.consume(b), c)
        : b === 47
        ? (e.consume(b), z)
        : b === 63
        ? (e.consume(b), M)
        : Je(b)
        ? (e.consume(b), K)
        : n(b);
    }
    function c(b) {
      return b === 45
        ? (e.consume(b), d)
        : b === 91
        ? (e.consume(b), (o = "CDATA["), (i = 0), g)
        : Je(b)
        ? (e.consume(b), w)
        : n(b);
    }
    function d(b) {
      return b === 45 ? (e.consume(b), p) : n(b);
    }
    function p(b) {
      return b === null || b === 62
        ? n(b)
        : b === 45
        ? (e.consume(b), m)
        : f(b);
    }
    function m(b) {
      return b === null || b === 62 ? n(b) : f(b);
    }
    function f(b) {
      return b === null
        ? n(b)
        : b === 45
        ? (e.consume(b), v)
        : U(b)
        ? ((l = f), P(b))
        : (e.consume(b), f);
    }
    function v(b) {
      return b === 45 ? (e.consume(b), $) : f(b);
    }
    function g(b) {
      return b === o.charCodeAt(i++)
        ? (e.consume(b), i === o.length ? _ : g)
        : n(b);
    }
    function _(b) {
      return b === null
        ? n(b)
        : b === 93
        ? (e.consume(b), C)
        : U(b)
        ? ((l = _), P(b))
        : (e.consume(b), _);
    }
    function C(b) {
      return b === 93 ? (e.consume(b), y) : _(b);
    }
    function y(b) {
      return b === 62 ? $(b) : b === 93 ? (e.consume(b), y) : _(b);
    }
    function w(b) {
      return b === null || b === 62
        ? $(b)
        : U(b)
        ? ((l = w), P(b))
        : (e.consume(b), w);
    }
    function M(b) {
      return b === null
        ? n(b)
        : b === 63
        ? (e.consume(b), E)
        : U(b)
        ? ((l = M), P(b))
        : (e.consume(b), M);
    }
    function E(b) {
      return b === 62 ? $(b) : M(b);
    }
    function z(b) {
      return Je(b) ? (e.consume(b), k) : n(b);
    }
    function k(b) {
      return b === 45 || Ne(b) ? (e.consume(b), k) : O(b);
    }
    function O(b) {
      return U(b) ? ((l = O), P(b)) : he(b) ? (e.consume(b), O) : $(b);
    }
    function K(b) {
      return b === 45 || Ne(b)
        ? (e.consume(b), K)
        : b === 47 || b === 62 || ke(b)
        ? H(b)
        : n(b);
    }
    function H(b) {
      return b === 47
        ? (e.consume(b), $)
        : b === 58 || b === 95 || Je(b)
        ? (e.consume(b), V)
        : U(b)
        ? ((l = H), P(b))
        : he(b)
        ? (e.consume(b), H)
        : $(b);
    }
    function V(b) {
      return b === 45 || b === 46 || b === 58 || b === 95 || Ne(b)
        ? (e.consume(b), V)
        : I(b);
    }
    function I(b) {
      return b === 61
        ? (e.consume(b), D)
        : U(b)
        ? ((l = I), P(b))
        : he(b)
        ? (e.consume(b), I)
        : H(b);
    }
    function D(b) {
      return b === null || b === 60 || b === 61 || b === 62 || b === 96
        ? n(b)
        : b === 34 || b === 39
        ? (e.consume(b), (r = b), J)
        : U(b)
        ? ((l = D), P(b))
        : he(b)
        ? (e.consume(b), D)
        : (e.consume(b), (r = void 0), T);
    }
    function J(b) {
      return b === r
        ? (e.consume(b), R)
        : b === null
        ? n(b)
        : U(b)
        ? ((l = J), P(b))
        : (e.consume(b), J);
    }
    function R(b) {
      return b === 62 || b === 47 || ke(b) ? H(b) : n(b);
    }
    function T(b) {
      return b === null ||
        b === 34 ||
        b === 39 ||
        b === 60 ||
        b === 61 ||
        b === 96
        ? n(b)
        : b === 62 || ke(b)
        ? H(b)
        : (e.consume(b), T);
    }
    function P(b) {
      return (
        e.exit("htmlTextData"),
        e.enter("lineEnding"),
        e.consume(b),
        e.exit("lineEnding"),
        X(
          e,
          B,
          "linePrefix",
          a.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4
        )
      );
    }
    function B(b) {
      return e.enter("htmlTextData"), l(b);
    }
    function $(b) {
      return b === 62
        ? (e.consume(b), e.exit("htmlTextData"), e.exit("htmlText"), t)
        : n(b);
    }
  }
  var Vt = { name: "labelEnd", tokenize: Y3, resolveTo: j3, resolveAll: K3 },
    $3 = { tokenize: Q3 },
    q3 = { tokenize: Z3 },
    W3 = { tokenize: X3 };
  function K3(e) {
    let t = -1,
      n;
    for (; ++t < e.length; )
      (n = e[t][1]),
        (n.type === "labelImage" ||
          n.type === "labelLink" ||
          n.type === "labelEnd") &&
          (e.splice(t + 1, n.type === "labelImage" ? 4 : 2),
          (n.type = "data"),
          t++);
    return e;
  }
  function j3(e, t) {
    let n = e.length,
      a = 0,
      r,
      o,
      i,
      l;
    for (; n--; )
      if (((r = e[n][1]), o)) {
        if (r.type === "link" || (r.type === "labelLink" && r._inactive)) break;
        e[n][0] === "enter" && r.type === "labelLink" && (r._inactive = !0);
      } else if (i) {
        if (
          e[n][0] === "enter" &&
          (r.type === "labelImage" || r.type === "labelLink") &&
          !r._balanced &&
          ((o = n), r.type !== "labelLink")
        ) {
          a = 2;
          break;
        }
      } else r.type === "labelEnd" && (i = n);
    let s = {
        type: e[o][1].type === "labelLink" ? "link" : "image",
        start: Object.assign({}, e[o][1].start),
        end: Object.assign({}, e[e.length - 1][1].end),
      },
      u = {
        type: "label",
        start: Object.assign({}, e[o][1].start),
        end: Object.assign({}, e[i][1].end),
      },
      c = {
        type: "labelText",
        start: Object.assign({}, e[o + a + 2][1].end),
        end: Object.assign({}, e[i - 2][1].start),
      };
    return (
      (l = [
        ["enter", s, t],
        ["enter", u, t],
      ]),
      (l = We(l, e.slice(o + 1, o + a + 3))),
      (l = We(l, [["enter", c, t]])),
      (l = We(
        l,
        o5(t.parser.constructs.insideSpan.null, e.slice(o + a + 4, i - 3), t)
      )),
      (l = We(l, [["exit", c, t], e[i - 2], e[i - 1], ["exit", u, t]])),
      (l = We(l, e.slice(i + 1))),
      (l = We(l, [["exit", s, t]])),
      He(e, o, e.length, l),
      e
    );
  }
  function Y3(e, t, n) {
    let a = this,
      r = a.events.length,
      o,
      i;
    for (; r--; )
      if (
        (a.events[r][1].type === "labelImage" ||
          a.events[r][1].type === "labelLink") &&
        !a.events[r][1]._balanced
      ) {
        o = a.events[r][1];
        break;
      }
    return l;
    function l(c) {
      return o
        ? o._inactive
          ? u(c)
          : ((i = a.parser.defined.includes(
              xt(a.sliceSerialize({ start: o.end, end: a.now() }))
            )),
            e.enter("labelEnd"),
            e.enter("labelMarker"),
            e.consume(c),
            e.exit("labelMarker"),
            e.exit("labelEnd"),
            s)
        : n(c);
    }
    function s(c) {
      return c === 40
        ? e.attempt($3, t, i ? t : u)(c)
        : c === 91
        ? e.attempt(q3, t, i ? e.attempt(W3, t, u) : u)(c)
        : i
        ? t(c)
        : u(c);
    }
    function u(c) {
      return (o._balanced = !0), n(c);
    }
  }
  function Q3(e, t, n) {
    return a;
    function a(s) {
      return (
        e.enter("resource"),
        e.enter("resourceMarker"),
        e.consume(s),
        e.exit("resourceMarker"),
        Ft(e, r)
      );
    }
    function r(s) {
      return s === 41
        ? l(s)
        : f1(
            e,
            o,
            n,
            "resourceDestination",
            "resourceDestinationLiteral",
            "resourceDestinationLiteralMarker",
            "resourceDestinationRaw",
            "resourceDestinationString",
            32
          )(s);
    }
    function o(s) {
      return ke(s) ? Ft(e, i)(s) : l(s);
    }
    function i(s) {
      return s === 34 || s === 39 || s === 40
        ? v1(
            e,
            Ft(e, l),
            n,
            "resourceTitle",
            "resourceTitleMarker",
            "resourceTitleString"
          )(s)
        : l(s);
    }
    function l(s) {
      return s === 41
        ? (e.enter("resourceMarker"),
          e.consume(s),
          e.exit("resourceMarker"),
          e.exit("resource"),
          t)
        : n(s);
    }
  }
  function Z3(e, t, n) {
    let a = this;
    return r;
    function r(i) {
      return g1.call(
        a,
        e,
        o,
        n,
        "reference",
        "referenceMarker",
        "referenceString"
      )(i);
    }
    function o(i) {
      return a.parser.defined.includes(
        xt(a.sliceSerialize(a.events[a.events.length - 1][1]).slice(1, -1))
      )
        ? t(i)
        : n(i);
    }
  }
  function X3(e, t, n) {
    return a;
    function a(o) {
      return (
        e.enter("reference"),
        e.enter("referenceMarker"),
        e.consume(o),
        e.exit("referenceMarker"),
        r
      );
    }
    function r(o) {
      return o === 93
        ? (e.enter("referenceMarker"),
          e.consume(o),
          e.exit("referenceMarker"),
          e.exit("reference"),
          t)
        : n(o);
    }
  }
  var n0 = { name: "labelStartImage", tokenize: J3, resolveAll: Vt.resolveAll };
  function J3(e, t, n) {
    let a = this;
    return r;
    function r(l) {
      return (
        e.enter("labelImage"),
        e.enter("labelImageMarker"),
        e.consume(l),
        e.exit("labelImageMarker"),
        o
      );
    }
    function o(l) {
      return l === 91
        ? (e.enter("labelMarker"),
          e.consume(l),
          e.exit("labelMarker"),
          e.exit("labelImage"),
          i)
        : n(l);
    }
    function i(l) {
      return l === 94 && "_hiddenFootnoteSupport" in a.parser.constructs
        ? n(l)
        : t(l);
    }
  }
  var a0 = { name: "labelStartLink", tokenize: e4, resolveAll: Vt.resolveAll };
  function e4(e, t, n) {
    let a = this;
    return r;
    function r(i) {
      return (
        e.enter("labelLink"),
        e.enter("labelMarker"),
        e.consume(i),
        e.exit("labelMarker"),
        e.exit("labelLink"),
        o
      );
    }
    function o(i) {
      return i === 94 && "_hiddenFootnoteSupport" in a.parser.constructs
        ? n(i)
        : t(i);
    }
  }
  var R5 = { name: "lineEnding", tokenize: t4 };
  function t4(e, t) {
    return n;
    function n(a) {
      return (
        e.enter("lineEnding"),
        e.consume(a),
        e.exit("lineEnding"),
        X(e, t, "linePrefix")
      );
    }
  }
  var Bt = { name: "thematicBreak", tokenize: n4 };
  function n4(e, t, n) {
    let a = 0,
      r;
    return o;
    function o(s) {
      return e.enter("thematicBreak"), (r = s), i(s);
    }
    function i(s) {
      return s === r
        ? (e.enter("thematicBreakSequence"), l(s))
        : he(s)
        ? X(e, i, "whitespace")(s)
        : a < 3 || (s !== null && !U(s))
        ? n(s)
        : (e.exit("thematicBreak"), t(s));
    }
    function l(s) {
      return s === r
        ? (e.consume(s), a++, l)
        : (e.exit("thematicBreakSequence"), i(s));
    }
  }
  var Ve = {
      name: "list",
      tokenize: o4,
      continuation: { tokenize: i4 },
      exit: c4,
    },
    a4 = { tokenize: s4, partial: !0 },
    r4 = { tokenize: l4, partial: !0 };
  function o4(e, t, n) {
    let a = this,
      r = a.events[a.events.length - 1],
      o =
        r && r[1].type === "linePrefix"
          ? r[2].sliceSerialize(r[1], !0).length
          : 0,
      i = 0;
    return l;
    function l(m) {
      let f =
        a.containerState.type ||
        (m === 42 || m === 43 || m === 45 ? "listUnordered" : "listOrdered");
      if (
        f === "listUnordered"
          ? !a.containerState.marker || m === a.containerState.marker
          : z5(m)
      ) {
        if (
          (a.containerState.type ||
            ((a.containerState.type = f), e.enter(f, { _container: !0 })),
          f === "listUnordered")
        )
          return (
            e.enter("listItemPrefix"),
            m === 42 || m === 45 ? e.check(Bt, n, u)(m) : u(m)
          );
        if (!a.interrupt || m === 49)
          return e.enter("listItemPrefix"), e.enter("listItemValue"), s(m);
      }
      return n(m);
    }
    function s(m) {
      return z5(m) && ++i < 10
        ? (e.consume(m), s)
        : (!a.interrupt || i < 2) &&
          (a.containerState.marker
            ? m === a.containerState.marker
            : m === 41 || m === 46)
        ? (e.exit("listItemValue"), u(m))
        : n(m);
    }
    function u(m) {
      return (
        e.enter("listItemMarker"),
        e.consume(m),
        e.exit("listItemMarker"),
        (a.containerState.marker = a.containerState.marker || m),
        e.check(It, a.interrupt ? n : c, e.attempt(a4, p, d))
      );
    }
    function c(m) {
      return (a.containerState.initialBlankLine = !0), o++, p(m);
    }
    function d(m) {
      return he(m)
        ? (e.enter("listItemPrefixWhitespace"),
          e.consume(m),
          e.exit("listItemPrefixWhitespace"),
          p)
        : n(m);
    }
    function p(m) {
      return (
        (a.containerState.size =
          o + a.sliceSerialize(e.exit("listItemPrefix"), !0).length),
        t(m)
      );
    }
  }
  function i4(e, t, n) {
    let a = this;
    return (a.containerState._closeFlow = void 0), e.check(It, r, o);
    function r(l) {
      return (
        (a.containerState.furtherBlankLines =
          a.containerState.furtherBlankLines ||
          a.containerState.initialBlankLine),
        X(e, t, "listItemIndent", a.containerState.size + 1)(l)
      );
    }
    function o(l) {
      return a.containerState.furtherBlankLines || !he(l)
        ? ((a.containerState.furtherBlankLines = void 0),
          (a.containerState.initialBlankLine = void 0),
          i(l))
        : ((a.containerState.furtherBlankLines = void 0),
          (a.containerState.initialBlankLine = void 0),
          e.attempt(r4, t, i)(l));
    }
    function i(l) {
      return (
        (a.containerState._closeFlow = !0),
        (a.interrupt = void 0),
        X(
          e,
          e.attempt(Ve, t, n),
          "linePrefix",
          a.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4
        )(l)
      );
    }
  }
  function l4(e, t, n) {
    let a = this;
    return X(e, r, "listItemIndent", a.containerState.size + 1);
    function r(o) {
      let i = a.events[a.events.length - 1];
      return i &&
        i[1].type === "listItemIndent" &&
        i[2].sliceSerialize(i[1], !0).length === a.containerState.size
        ? t(o)
        : n(o);
    }
  }
  function c4(e) {
    e.exit(this.containerState.type);
  }
  function s4(e, t, n) {
    let a = this;
    return X(
      e,
      r,
      "listItemPrefixWhitespace",
      a.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4 + 1
    );
    function r(o) {
      let i = a.events[a.events.length - 1];
      return !he(o) && i && i[1].type === "listItemPrefixWhitespace"
        ? t(o)
        : n(o);
    }
  }
  var b1 = { name: "setextUnderline", tokenize: d4, resolveTo: u4 };
  function u4(e, t) {
    let n = e.length,
      a,
      r,
      o;
    for (; n--; )
      if (e[n][0] === "enter") {
        if (e[n][1].type === "content") {
          a = n;
          break;
        }
        e[n][1].type === "paragraph" && (r = n);
      } else
        e[n][1].type === "content" && e.splice(n, 1),
          !o && e[n][1].type === "definition" && (o = n);
    let i = {
      type: "setextHeading",
      start: Object.assign({}, e[r][1].start),
      end: Object.assign({}, e[e.length - 1][1].end),
    };
    return (
      (e[r][1].type = "setextHeadingText"),
      o
        ? (e.splice(r, 0, ["enter", i, t]),
          e.splice(o + 1, 0, ["exit", e[a][1], t]),
          (e[a][1].end = Object.assign({}, e[o][1].end)))
        : (e[a][1] = i),
      e.push(["exit", i, t]),
      e
    );
  }
  function d4(e, t, n) {
    let a = this,
      r = a.events.length,
      o,
      i;
    for (; r--; )
      if (
        a.events[r][1].type !== "lineEnding" &&
        a.events[r][1].type !== "linePrefix" &&
        a.events[r][1].type !== "content"
      ) {
        i = a.events[r][1].type === "paragraph";
        break;
      }
    return l;
    function l(c) {
      return !a.parser.lazy[a.now().line] && (a.interrupt || i)
        ? (e.enter("setextHeadingLine"),
          e.enter("setextHeadingLineSequence"),
          (o = c),
          s(c))
        : n(c);
    }
    function s(c) {
      return c === o
        ? (e.consume(c), s)
        : (e.exit("setextHeadingLineSequence"), X(e, u, "lineSuffix")(c));
    }
    function u(c) {
      return c === null || U(c) ? (e.exit("setextHeadingLine"), t(c)) : n(c);
    }
  }
  var Wo = { tokenize: p4 };
  function p4(e) {
    let t = this,
      n = e.attempt(
        It,
        a,
        e.attempt(
          this.parser.constructs.flowInitial,
          r,
          X(
            e,
            e.attempt(this.parser.constructs.flow, r, e.attempt(Yn, r)),
            "linePrefix"
          )
        )
      );
    return n;
    function a(o) {
      if (o === null) {
        e.consume(o);
        return;
      }
      return (
        e.enter("lineEndingBlank"),
        e.consume(o),
        e.exit("lineEndingBlank"),
        (t.currentConstruct = void 0),
        n
      );
    }
    function r(o) {
      if (o === null) {
        e.consume(o);
        return;
      }
      return (
        e.enter("lineEnding"),
        e.consume(o),
        e.exit("lineEnding"),
        (t.currentConstruct = void 0),
        n
      );
    }
  }
  var Ko = { resolveAll: Zo() },
    jo = Qo("string"),
    Yo = Qo("text");
  function Qo(e) {
    return { tokenize: t, resolveAll: Zo(e === "text" ? m4 : void 0) };
    function t(n) {
      let a = this,
        r = this.parser.constructs[e],
        o = n.attempt(r, i, l);
      return i;
      function i(c) {
        return u(c) ? o(c) : l(c);
      }
      function l(c) {
        if (c === null) {
          n.consume(c);
          return;
        }
        return n.enter("data"), n.consume(c), s;
      }
      function s(c) {
        return u(c) ? (n.exit("data"), o(c)) : (n.consume(c), s);
      }
      function u(c) {
        if (c === null) return !0;
        let d = r[c],
          p = -1;
        if (d)
          for (; ++p < d.length; ) {
            let m = d[p];
            if (!m.previous || m.previous.call(a, a.previous)) return !0;
          }
        return !1;
      }
    }
  }
  function Zo(e) {
    return t;
    function t(n, a) {
      let r = -1,
        o;
      for (; ++r <= n.length; )
        o === void 0
          ? n[r] && n[r][1].type === "data" && ((o = r), r++)
          : (!n[r] || n[r][1].type !== "data") &&
            (r !== o + 2 &&
              ((n[o][1].end = n[r - 1][1].end),
              n.splice(o + 2, r - o - 2),
              (r = o + 2)),
            (o = void 0));
      return e ? e(n, a) : n;
    }
  }
  function m4(e, t) {
    let n = 0;
    for (; ++n <= e.length; )
      if (
        (n === e.length || e[n][1].type === "lineEnding") &&
        e[n - 1][1].type === "data"
      ) {
        let a = e[n - 1][1],
          r = t.sliceStream(a),
          o = r.length,
          i = -1,
          l = 0,
          s;
        for (; o--; ) {
          let u = r[o];
          if (typeof u == "string") {
            for (i = u.length; u.charCodeAt(i - 1) === 32; ) l++, i--;
            if (i) break;
            i = -1;
          } else if (u === -2) (s = !0), l++;
          else if (u !== -1) {
            o++;
            break;
          }
        }
        if (l) {
          let u = {
            type:
              n === e.length || s || l < 2 ? "lineSuffix" : "hardBreakTrailing",
            start: {
              line: a.end.line,
              column: a.end.column - l,
              offset: a.end.offset - l,
              _index: a.start._index + o,
              _bufferIndex: o ? i : a.start._bufferIndex + i,
            },
            end: Object.assign({}, a.end),
          };
          (a.end = Object.assign({}, u.start)),
            a.start.offset === a.end.offset
              ? Object.assign(a, u)
              : (e.splice(n, 0, ["enter", u, t], ["exit", u, t]), (n += 2));
        }
        n++;
      }
    return e;
  }
  function Xo(e, t, n) {
    let a = Object.assign(
        n ? Object.assign({}, n) : { line: 1, column: 1, offset: 0 },
        { _index: 0, _bufferIndex: -1 }
      ),
      r = {},
      o = [],
      i = [],
      l = [],
      s = !0,
      u = {
        consume: w,
        enter: M,
        exit: E,
        attempt: O(z),
        check: O(k),
        interrupt: O(k, { interrupt: !0 }),
      },
      c = {
        previous: null,
        code: null,
        containerState: {},
        events: [],
        parser: e,
        sliceStream: v,
        sliceSerialize: f,
        now: g,
        defineSkip: _,
        write: m,
      },
      d = t.tokenize.call(c, u),
      p;
    return t.resolveAll && o.push(t), c;
    function m(I) {
      return (
        (i = We(i, I)),
        C(),
        i[i.length - 1] !== null
          ? []
          : (K(t, 0), (c.events = o5(o, c.events, c)), c.events)
      );
    }
    function f(I, D) {
      return f4(v(I), D);
    }
    function v(I) {
      return h4(i, I);
    }
    function g() {
      return Object.assign({}, a);
    }
    function _(I) {
      (r[I.line] = I.column), V();
    }
    function C() {
      let I;
      for (; a._index < i.length; ) {
        let D = i[a._index];
        if (typeof D == "string")
          for (
            I = a._index, a._bufferIndex < 0 && (a._bufferIndex = 0);
            a._index === I && a._bufferIndex < D.length;

          )
            y(D.charCodeAt(a._bufferIndex));
        else y(D);
      }
    }
    function y(I) {
      (s = void 0), (p = I), (d = d(I));
    }
    function w(I) {
      U(I)
        ? (a.line++, (a.column = 1), (a.offset += I === -3 ? 2 : 1), V())
        : I !== -1 && (a.column++, a.offset++),
        a._bufferIndex < 0
          ? a._index++
          : (a._bufferIndex++,
            a._bufferIndex === i[a._index].length &&
              ((a._bufferIndex = -1), a._index++)),
        (c.previous = I),
        (s = !0);
    }
    function M(I, D) {
      let J = D || {};
      return (
        (J.type = I),
        (J.start = g()),
        c.events.push(["enter", J, c]),
        l.push(J),
        J
      );
    }
    function E(I) {
      let D = l.pop();
      return (D.end = g()), c.events.push(["exit", D, c]), D;
    }
    function z(I, D) {
      K(I, D.from);
    }
    function k(I, D) {
      D.restore();
    }
    function O(I, D) {
      return J;
      function J(R, T, P) {
        let B, $, b, h;
        return Array.isArray(R) ? le(R) : "tokenize" in R ? le([R]) : Le(R);
        function Le(be) {
          return ae;
          function ae(ze) {
            let Ce = ze !== null && be[ze],
              Te = ze !== null && be.null,
              Pe = [
                ...(Array.isArray(Ce) ? Ce : Ce ? [Ce] : []),
                ...(Array.isArray(Te) ? Te : Te ? [Te] : []),
              ];
            return le(Pe)(ze);
          }
        }
        function le(be) {
          return (B = be), ($ = 0), be.length === 0 ? P : me(be[$]);
        }
        function me(be) {
          return ae;
          function ae(ze) {
            return (
              (h = H()),
              (b = be),
              be.partial || (c.currentConstruct = be),
              be.name && c.parser.constructs.disable.null.includes(be.name)
                ? Me(ze)
                : be.tokenize.call(
                    D ? Object.assign(Object.create(c), D) : c,
                    u,
                    Ge,
                    Me
                  )(ze)
            );
          }
        }
        function Ge(be) {
          return (s = !0), I(b, h), T;
        }
        function Me(be) {
          return (s = !0), h.restore(), ++$ < B.length ? me(B[$]) : P;
        }
      }
    }
    function K(I, D) {
      I.resolveAll && !o.includes(I) && o.push(I),
        I.resolve &&
          He(c.events, D, c.events.length - D, I.resolve(c.events.slice(D), c)),
        I.resolveTo && (c.events = I.resolveTo(c.events, c));
    }
    function H() {
      let I = g(),
        D = c.previous,
        J = c.currentConstruct,
        R = c.events.length,
        T = Array.from(l);
      return { restore: P, from: R };
      function P() {
        (a = I),
          (c.previous = D),
          (c.currentConstruct = J),
          (c.events.length = R),
          (l = T),
          V();
      }
    }
    function V() {
      a.line in r &&
        a.column < 2 &&
        ((a.column = r[a.line]), (a.offset += r[a.line] - 1));
    }
  }
  function h4(e, t) {
    let n = t.start._index,
      a = t.start._bufferIndex,
      r = t.end._index,
      o = t.end._bufferIndex,
      i;
    return (
      n === r
        ? (i = [e[n].slice(a, o)])
        : ((i = e.slice(n, r)),
          a > -1 && (i[0] = i[0].slice(a)),
          o > 0 && i.push(e[r].slice(0, o))),
      i
    );
  }
  function f4(e, t) {
    let n = -1,
      a = [],
      r;
    for (; ++n < e.length; ) {
      let o = e[n],
        i;
      if (typeof o == "string") i = o;
      else
        switch (o) {
          case -5: {
            i = "\r";
            break;
          }
          case -4: {
            i = `
`;
            break;
          }
          case -3: {
            i = `\r
`;
            break;
          }
          case -2: {
            i = t ? " " : "	";
            break;
          }
          case -1: {
            if (!t && r) continue;
            i = " ";
            break;
          }
          default:
            i = String.fromCharCode(o);
        }
      (r = o === -2), a.push(i);
    }
    return a.join("");
  }
  var r0 = {};
  wa(r0, {
    attentionMarkers: () => w4,
    contentInitial: () => v4,
    disable: () => A4,
    document: () => g4,
    flow: () => _4,
    flowInitial: () => b4,
    insideSpan: () => x4,
    string: () => E4,
    text: () => y4,
  });
  var g4 = {
      [42]: Ve,
      [43]: Ve,
      [45]: Ve,
      [48]: Ve,
      [49]: Ve,
      [50]: Ve,
      [51]: Ve,
      [52]: Ve,
      [53]: Ve,
      [54]: Ve,
      [55]: Ve,
      [56]: Ve,
      [57]: Ve,
      [62]: u1,
    },
    v4 = { [91]: Qn },
    b4 = { [-2]: k5, [-1]: k5, [32]: k5 },
    _4 = {
      [35]: Xn,
      [42]: Bt,
      [45]: [b1, Bt],
      [60]: e0,
      [61]: b1,
      [95]: Bt,
      [96]: m1,
      [126]: m1,
    },
    E4 = { [38]: p1, [92]: d1 },
    y4 = {
      [-5]: R5,
      [-4]: R5,
      [-3]: R5,
      [33]: n0,
      [38]: p1,
      [42]: C5,
      [60]: [Kn, t0],
      [91]: a0,
      [92]: [Zn, d1],
      [93]: Vt,
      [95]: C5,
      [96]: jn,
    },
    x4 = { null: [C5, Ko] },
    w4 = { null: [42, 95] },
    A4 = { null: [] };
  function Jo(e = {}) {
    let t = Lo([r0].concat(e.extensions || [])),
      n = {
        defined: [],
        lazy: {},
        constructs: t,
        content: a(Vo),
        document: a(Uo),
        flow: a(Wo),
        string: a(jo),
        text: a(Yo),
      };
    return n;
    function a(r) {
      return o;
      function o(i) {
        return Xo(n, r, i);
      }
    }
  }
  var ei = /[\0\t\n\r]/g;
  function ti() {
    let e = 1,
      t = "",
      n = !0,
      a;
    return r;
    function r(o, i, l) {
      let s = [],
        u,
        c,
        d,
        p,
        m;
      for (
        o = t + o.toString(i),
          d = 0,
          t = "",
          n && (o.charCodeAt(0) === 65279 && d++, (n = void 0));
        d < o.length;

      ) {
        if (
          ((ei.lastIndex = d),
          (u = ei.exec(o)),
          (p = u && u.index !== void 0 ? u.index : o.length),
          (m = o.charCodeAt(p)),
          !u)
        ) {
          t = o.slice(d);
          break;
        }
        if (m === 10 && d === p && a) s.push(-3), (a = void 0);
        else
          switch (
            (a && (s.push(-5), (a = void 0)),
            d < p && (s.push(o.slice(d, p)), (e += p - d)),
            m)
          ) {
            case 0: {
              s.push(65533), e++;
              break;
            }
            case 9: {
              for (c = Math.ceil(e / 4) * 4, s.push(-2); e++ < c; ) s.push(-1);
              break;
            }
            case 10: {
              s.push(-4), (e = 1);
              break;
            }
            default:
              (a = !0), (e = 1);
          }
        d = p + 1;
      }
      return l && (a && s.push(-5), t && s.push(t), s.push(null)), s;
    }
  }
  function ni(e) {
    for (; !h1(e); );
    return e;
  }
  function _1(e, t) {
    let n = Number.parseInt(e, t);
    return n < 9 ||
      n === 11 ||
      (n > 13 && n < 32) ||
      (n > 126 && n < 160) ||
      (n > 55295 && n < 57344) ||
      (n > 64975 && n < 65008) ||
      (n & 65535) === 65535 ||
      (n & 65535) === 65534 ||
      n > 1114111
      ? "\uFFFD"
      : String.fromCharCode(n);
  }
  var M4 = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;
  function ai(e) {
    return e.replace(M4, z4);
  }
  function z4(e, t, n) {
    if (t) return t;
    if (n.charCodeAt(0) === 35) {
      let r = n.charCodeAt(1),
        o = r === 120 || r === 88;
      return _1(n.slice(o ? 2 : 1), o ? 16 : 10);
    }
    return i5(n) || e;
  }
  var o0 = {}.hasOwnProperty,
    i0 = function (e, t, n) {
      return (
        typeof t != "string" && ((n = t), (t = void 0)),
        S4(n)(ni(Jo(n).document().write(ti()(e, t, !0))))
      );
    };
  function S4(e = {}) {
    let t = oi(
        {
          transforms: [],
          canContainEols: [
            "emphasis",
            "fragment",
            "heading",
            "paragraph",
            "strong",
          ],
          enter: {
            autolink: s(Xe),
            autolinkProtocol: V,
            autolinkEmail: V,
            atxHeading: s(j),
            blockQuote: s(Te),
            characterEscape: V,
            characterReference: V,
            codeFenced: s(Pe),
            codeFencedFenceInfo: u,
            codeFencedFenceMeta: u,
            codeIndented: s(Pe, u),
            codeText: s($e, u),
            codeTextData: V,
            data: V,
            codeFlowValue: V,
            definition: s(st),
            definitionDestinationString: u,
            definitionLabelString: u,
            definitionTitleString: u,
            emphasis: s(Mt),
            hardBreakEscape: s(zt),
            hardBreakTrailing: s(zt),
            htmlFlow: s(_e, u),
            htmlFlowData: V,
            htmlText: s(_e, u),
            htmlTextData: V,
            image: s(de),
            label: u,
            link: s(Xe),
            listItem: s(ut),
            listItemValue: v,
            listOrdered: s(Fe, f),
            listUnordered: s(Fe),
            paragraph: s(dt),
            reference: Ge,
            referenceString: u,
            resourceDestinationString: u,
            resourceTitleString: u,
            setextHeading: s(j),
            strong: s(F),
            thematicBreak: s(ee),
          },
          exit: {
            atxHeading: d(),
            atxHeadingSequence: k,
            autolink: d(),
            autolinkEmail: Ce,
            autolinkProtocol: ze,
            blockQuote: d(),
            characterEscapeValue: I,
            characterReferenceMarkerHexadecimal: be,
            characterReferenceMarkerNumeric: be,
            characterReferenceValue: ae,
            codeFenced: d(y),
            codeFencedFence: C,
            codeFencedFenceInfo: g,
            codeFencedFenceMeta: _,
            codeFlowValue: I,
            codeIndented: d(w),
            codeText: d(P),
            codeTextData: I,
            data: I,
            definition: d(),
            definitionDestinationString: z,
            definitionLabelString: M,
            definitionTitleString: E,
            emphasis: d(),
            hardBreakEscape: d(J),
            hardBreakTrailing: d(J),
            htmlFlow: d(R),
            htmlFlowData: I,
            htmlText: d(T),
            htmlTextData: I,
            image: d($),
            label: h,
            labelText: b,
            lineEnding: D,
            link: d(B),
            listItem: d(),
            listOrdered: d(),
            listUnordered: d(),
            paragraph: d(),
            referenceString: Me,
            resourceDestinationString: Le,
            resourceTitleString: le,
            resource: me,
            setextHeading: d(H),
            setextHeadingLineSequence: K,
            setextHeadingText: O,
            strong: d(),
            thematicBreak: d(),
          },
        },
        e.mdastExtensions || []
      ),
      n = {};
    return a;
    function a(A) {
      let N = { type: "root", children: [] },
        q = [N],
        re = [],
        Oe = [],
        _t = {
          stack: q,
          tokenStack: re,
          config: t,
          enter: c,
          exit: p,
          buffer: u,
          resume: m,
          setData: o,
          getData: i,
        },
        ge = -1;
      for (; ++ge < A.length; )
        if (
          A[ge][1].type === "listOrdered" ||
          A[ge][1].type === "listUnordered"
        )
          if (A[ge][0] === "enter") Oe.push(ge);
          else {
            let Ie = Oe.pop();
            ge = r(A, Ie, ge);
          }
      for (ge = -1; ++ge < A.length; ) {
        let Ie = t[A[ge][0]];
        o0.call(Ie, A[ge][1].type) &&
          Ie[A[ge][1].type].call(
            Object.assign({ sliceSerialize: A[ge][2].sliceSerialize }, _t),
            A[ge][1]
          );
      }
      if (re.length > 0) {
        let Ie = re[re.length - 1];
        (Ie[1] || ri).call(_t, void 0, Ie[0]);
      }
      for (
        N.position = {
          start: l(
            A.length > 0 ? A[0][1].start : { line: 1, column: 1, offset: 0 }
          ),
          end: l(
            A.length > 0
              ? A[A.length - 2][1].end
              : { line: 1, column: 1, offset: 0 }
          ),
        },
          ge = -1;
        ++ge < t.transforms.length;

      )
        N = t.transforms[ge](N) || N;
      return N;
    }
    function r(A, N, q) {
      let re = N - 1,
        Oe = -1,
        _t = !1,
        ge,
        Ie,
        St,
        Se;
      for (; ++re <= q; ) {
        let xe = A[re];
        if (
          (xe[1].type === "listUnordered" ||
          xe[1].type === "listOrdered" ||
          xe[1].type === "blockQuote"
            ? (xe[0] === "enter" ? Oe++ : Oe--, (Se = void 0))
            : xe[1].type === "lineEndingBlank"
            ? xe[0] === "enter" &&
              (ge && !Se && !Oe && !St && (St = re), (Se = void 0))
            : xe[1].type === "linePrefix" ||
              xe[1].type === "listItemValue" ||
              xe[1].type === "listItemMarker" ||
              xe[1].type === "listItemPrefix" ||
              xe[1].type === "listItemPrefixWhitespace" ||
              (Se = void 0),
          (!Oe && xe[0] === "enter" && xe[1].type === "listItemPrefix") ||
            (Oe === -1 &&
              xe[0] === "exit" &&
              (xe[1].type === "listUnordered" || xe[1].type === "listOrdered")))
        ) {
          if (ge) {
            let G5 = re;
            for (Ie = void 0; G5--; ) {
              let je = A[G5];
              if (
                je[1].type === "lineEnding" ||
                je[1].type === "lineEndingBlank"
              ) {
                if (je[0] === "exit") continue;
                Ie && ((A[Ie][1].type = "lineEndingBlank"), (_t = !0)),
                  (je[1].type = "lineEnding"),
                  (Ie = G5);
              } else if (
                !(
                  je[1].type === "linePrefix" ||
                  je[1].type === "blockQuotePrefix" ||
                  je[1].type === "blockQuotePrefixWhitespace" ||
                  je[1].type === "blockQuoteMarker" ||
                  je[1].type === "listItemIndent"
                )
              )
                break;
            }
            St && (!Ie || St < Ie) && (ge._spread = !0),
              (ge.end = Object.assign({}, Ie ? A[Ie][1].start : xe[1].end)),
              A.splice(Ie || re, 0, ["exit", ge, xe[2]]),
              re++,
              q++;
          }
          xe[1].type === "listItemPrefix" &&
            ((ge = {
              type: "listItem",
              _spread: !1,
              start: Object.assign({}, xe[1].start),
            }),
            A.splice(re, 0, ["enter", ge, xe[2]]),
            re++,
            q++,
            (St = void 0),
            (Se = !0));
        }
      }
      return (A[N][1]._spread = _t), q;
    }
    function o(A, N) {
      n[A] = N;
    }
    function i(A) {
      return n[A];
    }
    function l(A) {
      return { line: A.line, column: A.column, offset: A.offset };
    }
    function s(A, N) {
      return q;
      function q(re) {
        c.call(this, A(re), re), N && N.call(this, re);
      }
    }
    function u() {
      this.stack.push({ type: "fragment", children: [] });
    }
    function c(A, N, q) {
      return (
        this.stack[this.stack.length - 1].children.push(A),
        this.stack.push(A),
        this.tokenStack.push([N, q]),
        (A.position = { start: l(N.start) }),
        A
      );
    }
    function d(A) {
      return N;
      function N(q) {
        A && A.call(this, q), p.call(this, q);
      }
    }
    function p(A, N) {
      let q = this.stack.pop(),
        re = this.tokenStack.pop();
      if (re)
        re[0].type !== A.type &&
          (N ? N.call(this, A, re[0]) : (re[1] || ri).call(this, A, re[0]));
      else
        throw new Error(
          "Cannot close `" +
            A.type +
            "` (" +
            Dt({ start: A.start, end: A.end }) +
            "): it\u2019s not open"
        );
      return (q.position.end = l(A.end)), q;
    }
    function m() {
      return Io(this.stack.pop());
    }
    function f() {
      o("expectingFirstListItemValue", !0);
    }
    function v(A) {
      if (i("expectingFirstListItemValue")) {
        let N = this.stack[this.stack.length - 2];
        (N.start = Number.parseInt(this.sliceSerialize(A), 10)),
          o("expectingFirstListItemValue");
      }
    }
    function g() {
      let A = this.resume(),
        N = this.stack[this.stack.length - 1];
      N.lang = A;
    }
    function _() {
      let A = this.resume(),
        N = this.stack[this.stack.length - 1];
      N.meta = A;
    }
    function C() {
      i("flowCodeInside") || (this.buffer(), o("flowCodeInside", !0));
    }
    function y() {
      let A = this.resume(),
        N = this.stack[this.stack.length - 1];
      (N.value = A.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, "")),
        o("flowCodeInside");
    }
    function w() {
      let A = this.resume(),
        N = this.stack[this.stack.length - 1];
      N.value = A.replace(/(\r?\n|\r)$/g, "");
    }
    function M(A) {
      let N = this.resume(),
        q = this.stack[this.stack.length - 1];
      (q.label = N), (q.identifier = xt(this.sliceSerialize(A)).toLowerCase());
    }
    function E() {
      let A = this.resume(),
        N = this.stack[this.stack.length - 1];
      N.title = A;
    }
    function z() {
      let A = this.resume(),
        N = this.stack[this.stack.length - 1];
      N.url = A;
    }
    function k(A) {
      let N = this.stack[this.stack.length - 1];
      if (!N.depth) {
        let q = this.sliceSerialize(A).length;
        N.depth = q;
      }
    }
    function O() {
      o("setextHeadingSlurpLineEnding", !0);
    }
    function K(A) {
      let N = this.stack[this.stack.length - 1];
      N.depth = this.sliceSerialize(A).charCodeAt(0) === 61 ? 1 : 2;
    }
    function H() {
      o("setextHeadingSlurpLineEnding");
    }
    function V(A) {
      let N = this.stack[this.stack.length - 1],
        q = N.children[N.children.length - 1];
      (!q || q.type !== "text") &&
        ((q = G()), (q.position = { start: l(A.start) }), N.children.push(q)),
        this.stack.push(q);
    }
    function I(A) {
      let N = this.stack.pop();
      (N.value += this.sliceSerialize(A)), (N.position.end = l(A.end));
    }
    function D(A) {
      let N = this.stack[this.stack.length - 1];
      if (i("atHardBreak")) {
        let q = N.children[N.children.length - 1];
        (q.position.end = l(A.end)), o("atHardBreak");
        return;
      }
      !i("setextHeadingSlurpLineEnding") &&
        t.canContainEols.includes(N.type) &&
        (V.call(this, A), I.call(this, A));
    }
    function J() {
      o("atHardBreak", !0);
    }
    function R() {
      let A = this.resume(),
        N = this.stack[this.stack.length - 1];
      N.value = A;
    }
    function T() {
      let A = this.resume(),
        N = this.stack[this.stack.length - 1];
      N.value = A;
    }
    function P() {
      let A = this.resume(),
        N = this.stack[this.stack.length - 1];
      N.value = A;
    }
    function B() {
      let A = this.stack[this.stack.length - 1];
      i("inReference")
        ? ((A.type += "Reference"),
          (A.referenceType = i("referenceType") || "shortcut"),
          delete A.url,
          delete A.title)
        : (delete A.identifier, delete A.label),
        o("referenceType");
    }
    function $() {
      let A = this.stack[this.stack.length - 1];
      i("inReference")
        ? ((A.type += "Reference"),
          (A.referenceType = i("referenceType") || "shortcut"),
          delete A.url,
          delete A.title)
        : (delete A.identifier, delete A.label),
        o("referenceType");
    }
    function b(A) {
      let N = this.stack[this.stack.length - 2],
        q = this.sliceSerialize(A);
      (N.label = ai(q)), (N.identifier = xt(q).toLowerCase());
    }
    function h() {
      let A = this.stack[this.stack.length - 1],
        N = this.resume(),
        q = this.stack[this.stack.length - 1];
      o("inReference", !0),
        q.type === "link" ? (q.children = A.children) : (q.alt = N);
    }
    function Le() {
      let A = this.resume(),
        N = this.stack[this.stack.length - 1];
      N.url = A;
    }
    function le() {
      let A = this.resume(),
        N = this.stack[this.stack.length - 1];
      N.title = A;
    }
    function me() {
      o("inReference");
    }
    function Ge() {
      o("referenceType", "collapsed");
    }
    function Me(A) {
      let N = this.resume(),
        q = this.stack[this.stack.length - 1];
      (q.label = N),
        (q.identifier = xt(this.sliceSerialize(A)).toLowerCase()),
        o("referenceType", "full");
    }
    function be(A) {
      o("characterReferenceType", A.type);
    }
    function ae(A) {
      let N = this.sliceSerialize(A),
        q = i("characterReferenceType"),
        re;
      q
        ? ((re = _1(N, q === "characterReferenceMarkerNumeric" ? 10 : 16)),
          o("characterReferenceType"))
        : (re = i5(N));
      let Oe = this.stack.pop();
      (Oe.value += re), (Oe.position.end = l(A.end));
    }
    function ze(A) {
      I.call(this, A);
      let N = this.stack[this.stack.length - 1];
      N.url = this.sliceSerialize(A);
    }
    function Ce(A) {
      I.call(this, A);
      let N = this.stack[this.stack.length - 1];
      N.url = "mailto:" + this.sliceSerialize(A);
    }
    function Te() {
      return { type: "blockquote", children: [] };
    }
    function Pe() {
      return { type: "code", lang: null, meta: null, value: "" };
    }
    function $e() {
      return { type: "inlineCode", value: "" };
    }
    function st() {
      return {
        type: "definition",
        identifier: "",
        label: null,
        title: null,
        url: "",
      };
    }
    function Mt() {
      return { type: "emphasis", children: [] };
    }
    function j() {
      return { type: "heading", depth: void 0, children: [] };
    }
    function zt() {
      return { type: "break" };
    }
    function _e() {
      return { type: "html", value: "" };
    }
    function de() {
      return { type: "image", title: null, url: "", alt: null };
    }
    function Xe() {
      return { type: "link", title: null, url: "", children: [] };
    }
    function Fe(A) {
      return {
        type: "list",
        ordered: A.type === "listOrdered",
        start: null,
        spread: A._spread,
        children: [],
      };
    }
    function ut(A) {
      return {
        type: "listItem",
        spread: A._spread,
        checked: null,
        children: [],
      };
    }
    function dt() {
      return { type: "paragraph", children: [] };
    }
    function F() {
      return { type: "strong", children: [] };
    }
    function G() {
      return { type: "text", value: "" };
    }
    function ee() {
      return { type: "thematicBreak" };
    }
  }
  function oi(e, t) {
    let n = -1;
    for (; ++n < t.length; ) {
      let a = t[n];
      Array.isArray(a) ? oi(e, a) : C4(e, a);
    }
    return e;
  }
  function C4(e, t) {
    let n;
    for (n in t)
      if (o0.call(t, n)) {
        let a = n === "canContainEols" || n === "transforms",
          o = (o0.call(e, n) ? e[n] : void 0) || (e[n] = a ? [] : {}),
          i = t[n];
        i && (a ? (e[n] = [...o, ...i]) : Object.assign(o, i));
      }
  }
  function ri(e, t) {
    throw e
      ? new Error(
          "Cannot close `" +
            e.type +
            "` (" +
            Dt({ start: e.start, end: e.end }) +
            "): a different token (`" +
            t.type +
            "`, " +
            Dt({ start: t.start, end: t.end }) +
            ") is open"
        )
      : new Error(
          "Cannot close document, a token (`" +
            t.type +
            "`, " +
            Dt({ start: t.start, end: t.end }) +
            ") is still open"
        );
  }
  function l0(e) {
    Object.assign(this, {
      Parser: (n) => {
        let a = this.data("settings");
        return i0(
          n,
          Object.assign({}, a, e, {
            extensions: this.data("micromarkExtensions") || [],
            mdastExtensions: this.data("fromMarkdownExtensions") || [],
          })
        );
      },
    });
  }
  var ii = l0;
  var se = function (e, t, n) {
    var a = { type: String(e) };
    return (
      n == null && (typeof t == "string" || Array.isArray(t))
        ? (n = t)
        : Object.assign(a, t),
      Array.isArray(n) ? (a.children = n) : n != null && (a.value = String(n)),
      a
    );
  };
  var E1 = {}.hasOwnProperty;
  function k4(e, t) {
    let n = t.data || {};
    return "value" in t &&
      !(
        E1.call(n, "hName") ||
        E1.call(n, "hProperties") ||
        E1.call(n, "hChildren")
      )
      ? e.augment(t, se("text", t.value))
      : e(t, "div", pe(e, t));
  }
  function c0(e, t, n) {
    let a = t && t.type,
      r;
    if (!a) throw new Error("Expected node, got `" + t + "`");
    return (
      E1.call(e.handlers, a)
        ? (r = e.handlers[a])
        : e.passThrough && e.passThrough.includes(a)
        ? (r = R4)
        : (r = e.unknownHandler),
      (typeof r == "function" ? r : k4)(e, t, n)
    );
  }
  function R4(e, t) {
    return "children" in t ? { ...t, children: pe(e, t) } : t;
  }
  function pe(e, t) {
    let n = [];
    if ("children" in t) {
      let a = t.children,
        r = -1;
      for (; ++r < a.length; ) {
        let o = c0(e, a[r], t);
        if (o) {
          if (
            r &&
            a[r - 1].type === "break" &&
            (!Array.isArray(o) &&
              o.type === "text" &&
              (o.value = o.value.replace(/^\s+/, "")),
            !Array.isArray(o) && o.type === "element")
          ) {
            let i = o.children[0];
            i && i.type === "text" && (i.value = i.value.replace(/^\s+/, ""));
          }
          Array.isArray(o) ? n.push(...o) : n.push(o);
        }
      }
    }
    return n;
  }
  var I5 = function (e) {
    if (e == null) return L4;
    if (typeof e == "string") return N4(e);
    if (typeof e == "object") return Array.isArray(e) ? I4(e) : T4(e);
    if (typeof e == "function") return y1(e);
    throw new Error("Expected function, string, or object as test");
  };
  function I4(e) {
    let t = [],
      n = -1;
    for (; ++n < e.length; ) t[n] = I5(e[n]);
    return y1(a);
    function a(...r) {
      let o = -1;
      for (; ++o < t.length; ) if (t[o].call(this, ...r)) return !0;
      return !1;
    }
  }
  function T4(e) {
    return y1(t);
    function t(n) {
      let a;
      for (a in e) if (n[a] !== e[a]) return !1;
      return !0;
    }
  }
  function N4(e) {
    return y1(t);
    function t(n) {
      return n && n.type === e;
    }
  }
  function y1(e) {
    return t;
    function t(...n) {
      return Boolean(e.call(this, ...n));
    }
  }
  function L4() {
    return !0;
  }
  var O4 = !0,
    H4 = "skip",
    li = !1,
    ci = function (e, t, n, a) {
      typeof t == "function" &&
        typeof n != "function" &&
        ((a = n), (n = t), (t = null));
      let r = I5(t),
        o = a ? -1 : 1;
      i(e, null, [])();
      function i(l, s, u) {
        let c = typeof l == "object" && l !== null ? l : {},
          d;
        return (
          typeof c.type == "string" &&
            ((d =
              typeof c.tagName == "string"
                ? c.tagName
                : typeof c.name == "string"
                ? c.name
                : void 0),
            Object.defineProperty(p, "name", {
              value: "node (" + (c.type + (d ? "<" + d + ">" : "")) + ")",
            })),
          p
        );
        function p() {
          let m = [],
            f,
            v,
            g;
          if (
            (!t || r(l, s, u[u.length - 1] || null)) &&
            ((m = D4(n(l, u))), m[0] === li)
          )
            return m;
          if (l.children && m[0] !== H4)
            for (
              v = (a ? l.children.length : -1) + o, g = u.concat(l);
              v > -1 && v < l.children.length;

            ) {
              if (((f = i(l.children[v], v, g)()), f[0] === li)) return f;
              v = typeof f[1] == "number" ? f[1] : v + o;
            }
          return m;
        }
      }
    };
  function D4(e) {
    return Array.isArray(e) ? e : typeof e == "number" ? [O4, e] : [e];
  }
  var Tt = function (e, t, n, a) {
    typeof t == "function" &&
      typeof n != "function" &&
      ((a = n), (n = t), (t = null)),
      ci(e, t, r, a);
    function r(o, i) {
      let l = i[i.length - 1];
      return n(o, l ? l.children.indexOf(o) : null, l);
    }
  };
  var x1 = si("start"),
    w1 = si("end");
  function si(e) {
    return t;
    function t(n) {
      let a = (n && n.position && n.position[e]) || {};
      return {
        line: a.line || null,
        column: a.column || null,
        offset: a.offset > -1 ? a.offset : null,
      };
    }
  }
  function ui(e) {
    return (
      !e ||
      !e.position ||
      !e.position.start ||
      !e.position.start.line ||
      !e.position.start.column ||
      !e.position.end ||
      !e.position.end.line ||
      !e.position.end.column
    );
  }
  var di = {}.hasOwnProperty;
  function mi(e) {
    let t = Object.create(null);
    if (!e || !e.type) throw new Error("mdast-util-definitions expected node");
    return (
      Tt(e, "definition", (a) => {
        let r = pi(a.identifier);
        r && !di.call(t, r) && (t[r] = a);
      }),
      n
    );
    function n(a) {
      let r = pi(a);
      return r && di.call(t, r) ? t[r] : null;
    }
  }
  function pi(e) {
    return String(e || "").toUpperCase();
  }
  function rt(e) {
    let t = [],
      n = -1,
      a = 0,
      r = 0;
    for (; ++n < e.length; ) {
      let o = e.charCodeAt(n),
        i = "";
      if (o === 37 && Ne(e.charCodeAt(n + 1)) && Ne(e.charCodeAt(n + 2))) r = 2;
      else if (o < 128)
        /[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(o)) ||
          (i = String.fromCharCode(o));
      else if (o > 55295 && o < 57344) {
        let l = e.charCodeAt(n + 1);
        o < 56320 && l > 56319 && l < 57344
          ? ((i = String.fromCharCode(o, l)), (r = 1))
          : (i = "\uFFFD");
      } else i = String.fromCharCode(o);
      i &&
        (t.push(e.slice(a, n), encodeURIComponent(i)),
        (a = n + r + 1),
        (i = "")),
        r && ((n += r), (r = 0));
    }
    return t.join("") + e.slice(a);
  }
  function Ye(e, t) {
    let n = [],
      a = -1;
    for (
      t &&
      n.push(
        se(
          "text",
          `
`
        )
      );
      ++a < e.length;

    )
      a &&
        n.push(
          se(
            "text",
            `
`
          )
        ),
        n.push(e[a]);
    return (
      t &&
        e.length > 0 &&
        n.push(
          se(
            "text",
            `
`
          )
        ),
      n
    );
  }
  function hi(e) {
    let t = -1,
      n = [];
    for (; ++t < e.footnoteOrder.length; ) {
      let a = e.footnoteById[e.footnoteOrder[t].toUpperCase()];
      if (!a) continue;
      let r = pe(e, a),
        o = String(a.identifier),
        i = rt(o.toLowerCase()),
        l = 0,
        s = [];
      for (; ++l <= e.footnoteCounts[o]; ) {
        let d = {
          type: "element",
          tagName: "a",
          properties: {
            href: "#" + e.clobberPrefix + "fnref-" + i + (l > 1 ? "-" + l : ""),
            dataFootnoteBackref: !0,
            className: ["data-footnote-backref"],
            ariaLabel: e.footnoteBackLabel,
          },
          children: [{ type: "text", value: "\u21A9" }],
        };
        l > 1 &&
          d.children.push({
            type: "element",
            tagName: "sup",
            children: [{ type: "text", value: String(l) }],
          }),
          s.length > 0 && s.push({ type: "text", value: " " }),
          s.push(d);
      }
      let u = r[r.length - 1];
      if (u && u.type === "element" && u.tagName === "p") {
        let d = u.children[u.children.length - 1];
        d && d.type === "text"
          ? (d.value += " ")
          : u.children.push({ type: "text", value: " " }),
          u.children.push(...s);
      } else r.push(...s);
      let c = {
        type: "element",
        tagName: "li",
        properties: { id: e.clobberPrefix + "fn-" + i },
        children: Ye(r, !0),
      };
      a.position && (c.position = a.position), n.push(c);
    }
    return n.length === 0
      ? null
      : {
          type: "element",
          tagName: "section",
          properties: { dataFootnotes: !0, className: ["footnotes"] },
          children: [
            {
              type: "element",
              tagName: e.footnoteLabelTagName,
              properties: {
                ...JSON.parse(JSON.stringify(e.footnoteLabelProperties)),
                id: "footnote-label",
              },
              children: [se("text", e.footnoteLabel)],
            },
            {
              type: "text",
              value: `
`,
            },
            {
              type: "element",
              tagName: "ol",
              properties: {},
              children: Ye(n, !0),
            },
            {
              type: "text",
              value: `
`,
            },
          ],
        };
  }
  function fi(e, t) {
    return e(t, "blockquote", Ye(pe(e, t), !0));
  }
  function gi(e, t) {
    return [
      e(t, "br"),
      se(
        "text",
        `
`
      ),
    ];
  }
  function vi(e, t) {
    let n = t.value
        ? t.value +
          `
`
        : "",
      a = t.lang && t.lang.match(/^[^ \t]+(?=[ \t]|$)/),
      r = {};
    a && (r.className = ["language-" + a]);
    let o = e(t, "code", r, [se("text", n)]);
    return t.meta && (o.data = { meta: t.meta }), e(t.position, "pre", [o]);
  }
  function bi(e, t) {
    return e(t, "del", pe(e, t));
  }
  function _i(e, t) {
    return e(t, "em", pe(e, t));
  }
  function A1(e, t) {
    let n = String(t.identifier),
      a = rt(n.toLowerCase()),
      r = e.footnoteOrder.indexOf(n),
      o;
    r === -1
      ? (e.footnoteOrder.push(n),
        (e.footnoteCounts[n] = 1),
        (o = e.footnoteOrder.length))
      : (e.footnoteCounts[n]++, (o = r + 1));
    let i = e.footnoteCounts[n];
    return e(t, "sup", [
      e(
        t.position,
        "a",
        {
          href: "#" + e.clobberPrefix + "fn-" + a,
          id: e.clobberPrefix + "fnref-" + a + (i > 1 ? "-" + i : ""),
          dataFootnoteRef: !0,
          ariaDescribedBy: "footnote-label",
        },
        [se("text", String(o))]
      ),
    ]);
  }
  function Ei(e, t) {
    let n = e.footnoteById,
      a = 1;
    for (; a in n; ) a++;
    let r = String(a);
    return (
      (n[r] = {
        type: "footnoteDefinition",
        identifier: r,
        children: [{ type: "paragraph", children: t.children }],
        position: t.position,
      }),
      A1(e, { type: "footnoteReference", identifier: r, position: t.position })
    );
  }
  function yi(e, t) {
    return e(t, "h" + t.depth, pe(e, t));
  }
  function xi(e, t) {
    return e.dangerous ? e.augment(t, se("raw", t.value)) : null;
  }
  function M1(e, t) {
    let n = t.referenceType,
      a = "]";
    if (
      (n === "collapsed"
        ? (a += "[]")
        : n === "full" && (a += "[" + (t.label || t.identifier) + "]"),
      t.type === "imageReference")
    )
      return se("text", "![" + t.alt + a);
    let r = pe(e, t),
      o = r[0];
    o && o.type === "text"
      ? (o.value = "[" + o.value)
      : r.unshift(se("text", "["));
    let i = r[r.length - 1];
    return i && i.type === "text" ? (i.value += a) : r.push(se("text", a)), r;
  }
  function wi(e, t) {
    let n = e.definition(t.identifier);
    if (!n) return M1(e, t);
    let a = { src: rt(n.url || ""), alt: t.alt };
    return (
      n.title !== null && n.title !== void 0 && (a.title = n.title),
      e(t, "img", a)
    );
  }
  function Ai(e, t) {
    let n = { src: rt(t.url), alt: t.alt };
    return (
      t.title !== null && t.title !== void 0 && (n.title = t.title),
      e(t, "img", n)
    );
  }
  function Mi(e, t) {
    return e(t, "code", [se("text", t.value.replace(/\r?\n|\r/g, " "))]);
  }
  function zi(e, t) {
    let n = e.definition(t.identifier);
    if (!n) return M1(e, t);
    let a = { href: rt(n.url || "") };
    return (
      n.title !== null && n.title !== void 0 && (a.title = n.title),
      e(t, "a", a, pe(e, t))
    );
  }
  function Si(e, t) {
    let n = { href: rt(t.url) };
    return (
      t.title !== null && t.title !== void 0 && (n.title = t.title),
      e(t, "a", n, pe(e, t))
    );
  }
  function Ci(e, t, n) {
    let a = pe(e, t),
      r = n ? P4(n) : ki(t),
      o = {},
      i = [];
    if (typeof t.checked == "boolean") {
      let u;
      a[0] && a[0].type === "element" && a[0].tagName === "p"
        ? (u = a[0])
        : ((u = e(null, "p", [])), a.unshift(u)),
        u.children.length > 0 && u.children.unshift(se("text", " ")),
        u.children.unshift(
          e(null, "input", {
            type: "checkbox",
            checked: t.checked,
            disabled: !0,
          })
        ),
        (o.className = ["task-list-item"]);
    }
    let l = -1;
    for (; ++l < a.length; ) {
      let u = a[l];
      (r || l !== 0 || u.type !== "element" || u.tagName !== "p") &&
        i.push(
          se(
            "text",
            `
`
          )
        ),
        u.type === "element" && u.tagName === "p" && !r
          ? i.push(...u.children)
          : i.push(u);
    }
    let s = a[a.length - 1];
    return (
      s &&
        (r || !("tagName" in s) || s.tagName !== "p") &&
        i.push(
          se(
            "text",
            `
`
          )
        ),
      e(t, "li", o, i)
    );
  }
  function P4(e) {
    let t = e.spread,
      n = e.children,
      a = -1;
    for (; !t && ++a < n.length; ) t = ki(n[a]);
    return Boolean(t);
  }
  function ki(e) {
    let t = e.spread;
    return t ?? e.children.length > 1;
  }
  function Ri(e, t) {
    let n = {},
      a = t.ordered ? "ol" : "ul",
      r = pe(e, t),
      o = -1;
    for (
      typeof t.start == "number" && t.start !== 1 && (n.start = t.start);
      ++o < r.length;

    ) {
      let i = r[o];
      if (
        i.type === "element" &&
        i.tagName === "li" &&
        i.properties &&
        Array.isArray(i.properties.className) &&
        i.properties.className.includes("task-list-item")
      ) {
        n.className = ["contains-task-list"];
        break;
      }
    }
    return e(t, a, n, Ye(r, !0));
  }
  function Ii(e, t) {
    return e(t, "p", pe(e, t));
  }
  function Ti(e, t) {
    return e.augment(t, se("root", Ye(pe(e, t))));
  }
  function Ni(e, t) {
    return e(t, "strong", pe(e, t));
  }
  function Li(e, t) {
    let n = t.children,
      a = -1,
      r = t.align || [],
      o = [];
    for (; ++a < n.length; ) {
      let i = n[a].children,
        l = a === 0 ? "th" : "td",
        s = [],
        u = -1,
        c = t.align ? r.length : i.length;
      for (; ++u < c; ) {
        let d = i[u];
        s.push(e(d, l, { align: r[u] }, d ? pe(e, d) : []));
      }
      o[a] = e(n[a], "tr", Ye(s, !0));
    }
    return e(
      t,
      "table",
      Ye(
        [e(o[0].position, "thead", Ye([o[0]], !0))].concat(
          o[1]
            ? e(
                { start: x1(o[1]), end: w1(o[o.length - 1]) },
                "tbody",
                Ye(o.slice(1), !0)
              )
            : []
        ),
        !0
      )
    );
  }
  function Hi(e) {
    let t = String(e),
      n = /\r?\n|\r/g,
      a = n.exec(t),
      r = 0,
      o = [];
    for (; a; )
      o.push(Oi(t.slice(r, a.index), r > 0, !0), a[0]),
        (r = a.index + a[0].length),
        (a = n.exec(t));
    return o.push(Oi(t.slice(r), r > 0, !1)), o.join("");
  }
  function Oi(e, t, n) {
    let a = 0,
      r = e.length;
    if (t) {
      let o = e.codePointAt(a);
      for (; o === 9 || o === 32; ) a++, (o = e.codePointAt(a));
    }
    if (n) {
      let o = e.codePointAt(r - 1);
      for (; o === 9 || o === 32; ) r--, (o = e.codePointAt(r - 1));
    }
    return r > a ? e.slice(a, r) : "";
  }
  function Di(e, t) {
    return e.augment(t, se("text", Hi(String(t.value))));
  }
  function Pi(e, t) {
    return e(t, "hr");
  }
  var s0 = {
    blockquote: fi,
    break: gi,
    code: vi,
    delete: bi,
    emphasis: _i,
    footnoteReference: A1,
    footnote: Ei,
    heading: yi,
    html: xi,
    imageReference: wi,
    image: Ai,
    inlineCode: Mi,
    linkReference: zi,
    link: Si,
    listItem: Ci,
    list: Ri,
    paragraph: Ii,
    root: Ti,
    strong: Ni,
    table: Li,
    text: Di,
    thematicBreak: Pi,
    toml: z1,
    yaml: z1,
    definition: z1,
    footnoteDefinition: z1,
  };
  function z1() {
    return null;
  }
  var F4 = {}.hasOwnProperty;
  function V4(e, t) {
    let n = t || {},
      a = n.allowDangerousHtml || !1,
      r = {};
    return (
      (i.dangerous = a),
      (i.clobberPrefix =
        n.clobberPrefix === void 0 || n.clobberPrefix === null
          ? "user-content-"
          : n.clobberPrefix),
      (i.footnoteLabel = n.footnoteLabel || "Footnotes"),
      (i.footnoteLabelTagName = n.footnoteLabelTagName || "h2"),
      (i.footnoteLabelProperties = n.footnoteLabelProperties || {
        className: ["sr-only"],
      }),
      (i.footnoteBackLabel = n.footnoteBackLabel || "Back to content"),
      (i.definition = mi(e)),
      (i.footnoteById = r),
      (i.footnoteOrder = []),
      (i.footnoteCounts = {}),
      (i.augment = o),
      (i.handlers = { ...s0, ...n.handlers }),
      (i.unknownHandler = n.unknownHandler),
      (i.passThrough = n.passThrough),
      Tt(e, "footnoteDefinition", (l) => {
        let s = String(l.identifier).toUpperCase();
        F4.call(r, s) || (r[s] = l);
      }),
      i
    );
    function o(l, s) {
      if (l && "data" in l && l.data) {
        let u = l.data;
        u.hName &&
          (s.type !== "element" &&
            (s = {
              type: "element",
              tagName: "",
              properties: {},
              children: [],
            }),
          (s.tagName = u.hName)),
          s.type === "element" &&
            u.hProperties &&
            (s.properties = { ...s.properties, ...u.hProperties }),
          "children" in s &&
            s.children &&
            u.hChildren &&
            (s.children = u.hChildren);
      }
      if (l) {
        let u = "type" in l ? l : { position: l };
        ui(u) || (s.position = { start: x1(u), end: w1(u) });
      }
      return s;
    }
    function i(l, s, u, c) {
      return (
        Array.isArray(u) && ((c = u), (u = {})),
        o(l, {
          type: "element",
          tagName: s,
          properties: u || {},
          children: c || [],
        })
      );
    }
  }
  function S1(e, t) {
    let n = V4(e, t),
      a = c0(n, e, null),
      r = hi(n);
    return (
      r &&
        a.children.push(
          se(
            "text",
            `
`
          ),
          r
        ),
      Array.isArray(a) ? { type: "root", children: a } : a
    );
  }
  var B4 = function (e, t) {
      return e && "run" in e ? U4(e, t) : G4(e || t);
    },
    u0 = B4;
  function U4(e, t) {
    return (n, a, r) => {
      e.run(S1(n, t), a, (o) => {
        r(o);
      });
    };
  }
  function G4(e) {
    return (t) => S1(t, e);
  }
  var Q = pt(Wi(), 1);
  var wt = class {
    constructor(t, n, a) {
      (this.property = t), (this.normal = n), a && (this.space = a);
    }
  };
  wt.prototype.property = {};
  wt.prototype.normal = {};
  wt.prototype.space = null;
  function d0(e, t) {
    let n = {},
      a = {},
      r = -1;
    for (; ++r < e.length; )
      Object.assign(n, e[r].property), Object.assign(a, e[r].normal);
    return new wt(n, a, t);
  }
  function T5(e) {
    return e.toLowerCase();
  }
  var Be = class {
    constructor(t, n) {
      (this.property = t), (this.attribute = n);
    }
  };
  Be.prototype.space = null;
  Be.prototype.boolean = !1;
  Be.prototype.booleanish = !1;
  Be.prototype.overloadedBoolean = !1;
  Be.prototype.number = !1;
  Be.prototype.commaSeparated = !1;
  Be.prototype.spaceSeparated = !1;
  Be.prototype.commaOrSpaceSeparated = !1;
  Be.prototype.mustUseProperty = !1;
  Be.prototype.defined = !1;
  var N5 = {};
  wa(N5, {
    boolean: () => te,
    booleanish: () => Ae,
    commaOrSpaceSeparated: () => Qe,
    commaSeparated: () => Nt,
    number: () => L,
    overloadedBoolean: () => p0,
    spaceSeparated: () => ve,
  });
  var W4 = 0,
    te = Ut(),
    Ae = Ut(),
    p0 = Ut(),
    L = Ut(),
    ve = Ut(),
    Nt = Ut(),
    Qe = Ut();
  function Ut() {
    return 2 ** ++W4;
  }
  var m0 = Object.keys(N5),
    Gt = class extends Be {
      constructor(t, n, a, r) {
        let o = -1;
        if ((super(t, n), Ki(this, "space", r), typeof a == "number"))
          for (; ++o < m0.length; ) {
            let i = m0[o];
            Ki(this, m0[o], (a & N5[i]) === N5[i]);
          }
      }
    };
  Gt.prototype.defined = !0;
  function Ki(e, t, n) {
    n && (e[t] = n);
  }
  var K4 = {}.hasOwnProperty;
  function ot(e) {
    let t = {},
      n = {},
      a;
    for (a in e.properties)
      if (K4.call(e.properties, a)) {
        let r = e.properties[a],
          o = new Gt(a, e.transform(e.attributes || {}, a), r, e.space);
        e.mustUseProperty &&
          e.mustUseProperty.includes(a) &&
          (o.mustUseProperty = !0),
          (t[a] = o),
          (n[T5(a)] = a),
          (n[T5(o.attribute)] = a);
      }
    return new wt(t, n, e.space);
  }
  var h0 = ot({
    space: "xlink",
    transform(e, t) {
      return "xlink:" + t.slice(5).toLowerCase();
    },
    properties: {
      xLinkActuate: null,
      xLinkArcRole: null,
      xLinkHref: null,
      xLinkRole: null,
      xLinkShow: null,
      xLinkTitle: null,
      xLinkType: null,
    },
  });
  var f0 = ot({
    space: "xml",
    transform(e, t) {
      return "xml:" + t.slice(3).toLowerCase();
    },
    properties: { xmlLang: null, xmlBase: null, xmlSpace: null },
  });
  function C1(e, t) {
    return t in e ? e[t] : t;
  }
  function k1(e, t) {
    return C1(e, t.toLowerCase());
  }
  var g0 = ot({
    space: "xmlns",
    attributes: { xmlnsxlink: "xmlns:xlink" },
    transform: k1,
    properties: { xmlns: null, xmlnsXLink: null },
  });
  var v0 = ot({
    transform(e, t) {
      return t === "role" ? t : "aria-" + t.slice(4).toLowerCase();
    },
    properties: {
      ariaActiveDescendant: null,
      ariaAtomic: Ae,
      ariaAutoComplete: null,
      ariaBusy: Ae,
      ariaChecked: Ae,
      ariaColCount: L,
      ariaColIndex: L,
      ariaColSpan: L,
      ariaControls: ve,
      ariaCurrent: null,
      ariaDescribedBy: ve,
      ariaDetails: null,
      ariaDisabled: Ae,
      ariaDropEffect: ve,
      ariaErrorMessage: null,
      ariaExpanded: Ae,
      ariaFlowTo: ve,
      ariaGrabbed: Ae,
      ariaHasPopup: null,
      ariaHidden: Ae,
      ariaInvalid: null,
      ariaKeyShortcuts: null,
      ariaLabel: null,
      ariaLabelledBy: ve,
      ariaLevel: L,
      ariaLive: null,
      ariaModal: Ae,
      ariaMultiLine: Ae,
      ariaMultiSelectable: Ae,
      ariaOrientation: null,
      ariaOwns: ve,
      ariaPlaceholder: null,
      ariaPosInSet: L,
      ariaPressed: Ae,
      ariaReadOnly: Ae,
      ariaRelevant: null,
      ariaRequired: Ae,
      ariaRoleDescription: ve,
      ariaRowCount: L,
      ariaRowIndex: L,
      ariaRowSpan: L,
      ariaSelected: Ae,
      ariaSetSize: L,
      ariaSort: null,
      ariaValueMax: L,
      ariaValueMin: L,
      ariaValueNow: L,
      ariaValueText: null,
      role: null,
    },
  });
  var ji = ot({
    space: "html",
    attributes: {
      acceptcharset: "accept-charset",
      classname: "class",
      htmlfor: "for",
      httpequiv: "http-equiv",
    },
    transform: k1,
    mustUseProperty: ["checked", "multiple", "muted", "selected"],
    properties: {
      abbr: null,
      accept: Nt,
      acceptCharset: ve,
      accessKey: ve,
      action: null,
      allow: null,
      allowFullScreen: te,
      allowPaymentRequest: te,
      allowUserMedia: te,
      alt: null,
      as: null,
      async: te,
      autoCapitalize: null,
      autoComplete: ve,
      autoFocus: te,
      autoPlay: te,
      capture: te,
      charSet: null,
      checked: te,
      cite: null,
      className: ve,
      cols: L,
      colSpan: null,
      content: null,
      contentEditable: Ae,
      controls: te,
      controlsList: ve,
      coords: L | Nt,
      crossOrigin: null,
      data: null,
      dateTime: null,
      decoding: null,
      default: te,
      defer: te,
      dir: null,
      dirName: null,
      disabled: te,
      download: p0,
      draggable: Ae,
      encType: null,
      enterKeyHint: null,
      form: null,
      formAction: null,
      formEncType: null,
      formMethod: null,
      formNoValidate: te,
      formTarget: null,
      headers: ve,
      height: L,
      hidden: te,
      high: L,
      href: null,
      hrefLang: null,
      htmlFor: ve,
      httpEquiv: ve,
      id: null,
      imageSizes: null,
      imageSrcSet: null,
      inputMode: null,
      integrity: null,
      is: null,
      isMap: te,
      itemId: null,
      itemProp: ve,
      itemRef: ve,
      itemScope: te,
      itemType: ve,
      kind: null,
      label: null,
      lang: null,
      language: null,
      list: null,
      loading: null,
      loop: te,
      low: L,
      manifest: null,
      max: null,
      maxLength: L,
      media: null,
      method: null,
      min: null,
      minLength: L,
      multiple: te,
      muted: te,
      name: null,
      nonce: null,
      noModule: te,
      noValidate: te,
      onAbort: null,
      onAfterPrint: null,
      onAuxClick: null,
      onBeforeMatch: null,
      onBeforePrint: null,
      onBeforeUnload: null,
      onBlur: null,
      onCancel: null,
      onCanPlay: null,
      onCanPlayThrough: null,
      onChange: null,
      onClick: null,
      onClose: null,
      onContextLost: null,
      onContextMenu: null,
      onContextRestored: null,
      onCopy: null,
      onCueChange: null,
      onCut: null,
      onDblClick: null,
      onDrag: null,
      onDragEnd: null,
      onDragEnter: null,
      onDragExit: null,
      onDragLeave: null,
      onDragOver: null,
      onDragStart: null,
      onDrop: null,
      onDurationChange: null,
      onEmptied: null,
      onEnded: null,
      onError: null,
      onFocus: null,
      onFormData: null,
      onHashChange: null,
      onInput: null,
      onInvalid: null,
      onKeyDown: null,
      onKeyPress: null,
      onKeyUp: null,
      onLanguageChange: null,
      onLoad: null,
      onLoadedData: null,
      onLoadedMetadata: null,
      onLoadEnd: null,
      onLoadStart: null,
      onMessage: null,
      onMessageError: null,
      onMouseDown: null,
      onMouseEnter: null,
      onMouseLeave: null,
      onMouseMove: null,
      onMouseOut: null,
      onMouseOver: null,
      onMouseUp: null,
      onOffline: null,
      onOnline: null,
      onPageHide: null,
      onPageShow: null,
      onPaste: null,
      onPause: null,
      onPlay: null,
      onPlaying: null,
      onPopState: null,
      onProgress: null,
      onRateChange: null,
      onRejectionHandled: null,
      onReset: null,
      onResize: null,
      onScroll: null,
      onScrollEnd: null,
      onSecurityPolicyViolation: null,
      onSeeked: null,
      onSeeking: null,
      onSelect: null,
      onSlotChange: null,
      onStalled: null,
      onStorage: null,
      onSubmit: null,
      onSuspend: null,
      onTimeUpdate: null,
      onToggle: null,
      onUnhandledRejection: null,
      onUnload: null,
      onVolumeChange: null,
      onWaiting: null,
      onWheel: null,
      open: te,
      optimum: L,
      pattern: null,
      ping: ve,
      placeholder: null,
      playsInline: te,
      poster: null,
      preload: null,
      readOnly: te,
      referrerPolicy: null,
      rel: ve,
      required: te,
      reversed: te,
      rows: L,
      rowSpan: L,
      sandbox: ve,
      scope: null,
      scoped: te,
      seamless: te,
      selected: te,
      shape: null,
      size: L,
      sizes: null,
      slot: null,
      span: L,
      spellCheck: Ae,
      src: null,
      srcDoc: null,
      srcLang: null,
      srcSet: null,
      start: L,
      step: null,
      style: null,
      tabIndex: L,
      target: null,
      title: null,
      translate: null,
      type: null,
      typeMustMatch: te,
      useMap: null,
      value: Ae,
      width: L,
      wrap: null,
      align: null,
      aLink: null,
      archive: ve,
      axis: null,
      background: null,
      bgColor: null,
      border: L,
      borderColor: null,
      bottomMargin: L,
      cellPadding: null,
      cellSpacing: null,
      char: null,
      charOff: null,
      classId: null,
      clear: null,
      code: null,
      codeBase: null,
      codeType: null,
      color: null,
      compact: te,
      declare: te,
      event: null,
      face: null,
      frame: null,
      frameBorder: null,
      hSpace: L,
      leftMargin: L,
      link: null,
      longDesc: null,
      lowSrc: null,
      marginHeight: L,
      marginWidth: L,
      noResize: te,
      noHref: te,
      noShade: te,
      noWrap: te,
      object: null,
      profile: null,
      prompt: null,
      rev: null,
      rightMargin: L,
      rules: null,
      scheme: null,
      scrolling: Ae,
      standby: null,
      summary: null,
      text: null,
      topMargin: L,
      valueType: null,
      version: null,
      vAlign: null,
      vLink: null,
      vSpace: L,
      allowTransparency: null,
      autoCorrect: null,
      autoSave: null,
      disablePictureInPicture: te,
      disableRemotePlayback: te,
      prefix: null,
      property: null,
      results: L,
      security: null,
      unselectable: null,
    },
  });
  var Yi = ot({
    space: "svg",
    attributes: {
      accentHeight: "accent-height",
      alignmentBaseline: "alignment-baseline",
      arabicForm: "arabic-form",
      baselineShift: "baseline-shift",
      capHeight: "cap-height",
      className: "class",
      clipPath: "clip-path",
      clipRule: "clip-rule",
      colorInterpolation: "color-interpolation",
      colorInterpolationFilters: "color-interpolation-filters",
      colorProfile: "color-profile",
      colorRendering: "color-rendering",
      crossOrigin: "crossorigin",
      dataType: "datatype",
      dominantBaseline: "dominant-baseline",
      enableBackground: "enable-background",
      fillOpacity: "fill-opacity",
      fillRule: "fill-rule",
      floodColor: "flood-color",
      floodOpacity: "flood-opacity",
      fontFamily: "font-family",
      fontSize: "font-size",
      fontSizeAdjust: "font-size-adjust",
      fontStretch: "font-stretch",
      fontStyle: "font-style",
      fontVariant: "font-variant",
      fontWeight: "font-weight",
      glyphName: "glyph-name",
      glyphOrientationHorizontal: "glyph-orientation-horizontal",
      glyphOrientationVertical: "glyph-orientation-vertical",
      hrefLang: "hreflang",
      horizAdvX: "horiz-adv-x",
      horizOriginX: "horiz-origin-x",
      horizOriginY: "horiz-origin-y",
      imageRendering: "image-rendering",
      letterSpacing: "letter-spacing",
      lightingColor: "lighting-color",
      markerEnd: "marker-end",
      markerMid: "marker-mid",
      markerStart: "marker-start",
      navDown: "nav-down",
      navDownLeft: "nav-down-left",
      navDownRight: "nav-down-right",
      navLeft: "nav-left",
      navNext: "nav-next",
      navPrev: "nav-prev",
      navRight: "nav-right",
      navUp: "nav-up",
      navUpLeft: "nav-up-left",
      navUpRight: "nav-up-right",
      onAbort: "onabort",
      onActivate: "onactivate",
      onAfterPrint: "onafterprint",
      onBeforePrint: "onbeforeprint",
      onBegin: "onbegin",
      onCancel: "oncancel",
      onCanPlay: "oncanplay",
      onCanPlayThrough: "oncanplaythrough",
      onChange: "onchange",
      onClick: "onclick",
      onClose: "onclose",
      onCopy: "oncopy",
      onCueChange: "oncuechange",
      onCut: "oncut",
      onDblClick: "ondblclick",
      onDrag: "ondrag",
      onDragEnd: "ondragend",
      onDragEnter: "ondragenter",
      onDragExit: "ondragexit",
      onDragLeave: "ondragleave",
      onDragOver: "ondragover",
      onDragStart: "ondragstart",
      onDrop: "ondrop",
      onDurationChange: "ondurationchange",
      onEmptied: "onemptied",
      onEnd: "onend",
      onEnded: "onended",
      onError: "onerror",
      onFocus: "onfocus",
      onFocusIn: "onfocusin",
      onFocusOut: "onfocusout",
      onHashChange: "onhashchange",
      onInput: "oninput",
      onInvalid: "oninvalid",
      onKeyDown: "onkeydown",
      onKeyPress: "onkeypress",
      onKeyUp: "onkeyup",
      onLoad: "onload",
      onLoadedData: "onloadeddata",
      onLoadedMetadata: "onloadedmetadata",
      onLoadStart: "onloadstart",
      onMessage: "onmessage",
      onMouseDown: "onmousedown",
      onMouseEnter: "onmouseenter",
      onMouseLeave: "onmouseleave",
      onMouseMove: "onmousemove",
      onMouseOut: "onmouseout",
      onMouseOver: "onmouseover",
      onMouseUp: "onmouseup",
      onMouseWheel: "onmousewheel",
      onOffline: "onoffline",
      onOnline: "ononline",
      onPageHide: "onpagehide",
      onPageShow: "onpageshow",
      onPaste: "onpaste",
      onPause: "onpause",
      onPlay: "onplay",
      onPlaying: "onplaying",
      onPopState: "onpopstate",
      onProgress: "onprogress",
      onRateChange: "onratechange",
      onRepeat: "onrepeat",
      onReset: "onreset",
      onResize: "onresize",
      onScroll: "onscroll",
      onSeeked: "onseeked",
      onSeeking: "onseeking",
      onSelect: "onselect",
      onShow: "onshow",
      onStalled: "onstalled",
      onStorage: "onstorage",
      onSubmit: "onsubmit",
      onSuspend: "onsuspend",
      onTimeUpdate: "ontimeupdate",
      onToggle: "ontoggle",
      onUnload: "onunload",
      onVolumeChange: "onvolumechange",
      onWaiting: "onwaiting",
      onZoom: "onzoom",
      overlinePosition: "overline-position",
      overlineThickness: "overline-thickness",
      paintOrder: "paint-order",
      panose1: "panose-1",
      pointerEvents: "pointer-events",
      referrerPolicy: "referrerpolicy",
      renderingIntent: "rendering-intent",
      shapeRendering: "shape-rendering",
      stopColor: "stop-color",
      stopOpacity: "stop-opacity",
      strikethroughPosition: "strikethrough-position",
      strikethroughThickness: "strikethrough-thickness",
      strokeDashArray: "stroke-dasharray",
      strokeDashOffset: "stroke-dashoffset",
      strokeLineCap: "stroke-linecap",
      strokeLineJoin: "stroke-linejoin",
      strokeMiterLimit: "stroke-miterlimit",
      strokeOpacity: "stroke-opacity",
      strokeWidth: "stroke-width",
      tabIndex: "tabindex",
      textAnchor: "text-anchor",
      textDecoration: "text-decoration",
      textRendering: "text-rendering",
      typeOf: "typeof",
      underlinePosition: "underline-position",
      underlineThickness: "underline-thickness",
      unicodeBidi: "unicode-bidi",
      unicodeRange: "unicode-range",
      unitsPerEm: "units-per-em",
      vAlphabetic: "v-alphabetic",
      vHanging: "v-hanging",
      vIdeographic: "v-ideographic",
      vMathematical: "v-mathematical",
      vectorEffect: "vector-effect",
      vertAdvY: "vert-adv-y",
      vertOriginX: "vert-origin-x",
      vertOriginY: "vert-origin-y",
      wordSpacing: "word-spacing",
      writingMode: "writing-mode",
      xHeight: "x-height",
      playbackOrder: "playbackorder",
      timelineBegin: "timelinebegin",
    },
    transform: C1,
    properties: {
      about: Qe,
      accentHeight: L,
      accumulate: null,
      additive: null,
      alignmentBaseline: null,
      alphabetic: L,
      amplitude: L,
      arabicForm: null,
      ascent: L,
      attributeName: null,
      attributeType: null,
      azimuth: L,
      bandwidth: null,
      baselineShift: null,
      baseFrequency: null,
      baseProfile: null,
      bbox: null,
      begin: null,
      bias: L,
      by: null,
      calcMode: null,
      capHeight: L,
      className: ve,
      clip: null,
      clipPath: null,
      clipPathUnits: null,
      clipRule: null,
      color: null,
      colorInterpolation: null,
      colorInterpolationFilters: null,
      colorProfile: null,
      colorRendering: null,
      content: null,
      contentScriptType: null,
      contentStyleType: null,
      crossOrigin: null,
      cursor: null,
      cx: null,
      cy: null,
      d: null,
      dataType: null,
      defaultAction: null,
      descent: L,
      diffuseConstant: L,
      direction: null,
      display: null,
      dur: null,
      divisor: L,
      dominantBaseline: null,
      download: te,
      dx: null,
      dy: null,
      edgeMode: null,
      editable: null,
      elevation: L,
      enableBackground: null,
      end: null,
      event: null,
      exponent: L,
      externalResourcesRequired: null,
      fill: null,
      fillOpacity: L,
      fillRule: null,
      filter: null,
      filterRes: null,
      filterUnits: null,
      floodColor: null,
      floodOpacity: null,
      focusable: null,
      focusHighlight: null,
      fontFamily: null,
      fontSize: null,
      fontSizeAdjust: null,
      fontStretch: null,
      fontStyle: null,
      fontVariant: null,
      fontWeight: null,
      format: null,
      fr: null,
      from: null,
      fx: null,
      fy: null,
      g1: Nt,
      g2: Nt,
      glyphName: Nt,
      glyphOrientationHorizontal: null,
      glyphOrientationVertical: null,
      glyphRef: null,
      gradientTransform: null,
      gradientUnits: null,
      handler: null,
      hanging: L,
      hatchContentUnits: null,
      hatchUnits: null,
      height: null,
      href: null,
      hrefLang: null,
      horizAdvX: L,
      horizOriginX: L,
      horizOriginY: L,
      id: null,
      ideographic: L,
      imageRendering: null,
      initialVisibility: null,
      in: null,
      in2: null,
      intercept: L,
      k: L,
      k1: L,
      k2: L,
      k3: L,
      k4: L,
      kernelMatrix: Qe,
      kernelUnitLength: null,
      keyPoints: null,
      keySplines: null,
      keyTimes: null,
      kerning: null,
      lang: null,
      lengthAdjust: null,
      letterSpacing: null,
      lightingColor: null,
      limitingConeAngle: L,
      local: null,
      markerEnd: null,
      markerMid: null,
      markerStart: null,
      markerHeight: null,
      markerUnits: null,
      markerWidth: null,
      mask: null,
      maskContentUnits: null,
      maskUnits: null,
      mathematical: null,
      max: null,
      media: null,
      mediaCharacterEncoding: null,
      mediaContentEncodings: null,
      mediaSize: L,
      mediaTime: null,
      method: null,
      min: null,
      mode: null,
      name: null,
      navDown: null,
      navDownLeft: null,
      navDownRight: null,
      navLeft: null,
      navNext: null,
      navPrev: null,
      navRight: null,
      navUp: null,
      navUpLeft: null,
      navUpRight: null,
      numOctaves: null,
      observer: null,
      offset: null,
      onAbort: null,
      onActivate: null,
      onAfterPrint: null,
      onBeforePrint: null,
      onBegin: null,
      onCancel: null,
      onCanPlay: null,
      onCanPlayThrough: null,
      onChange: null,
      onClick: null,
      onClose: null,
      onCopy: null,
      onCueChange: null,
      onCut: null,
      onDblClick: null,
      onDrag: null,
      onDragEnd: null,
      onDragEnter: null,
      onDragExit: null,
      onDragLeave: null,
      onDragOver: null,
      onDragStart: null,
      onDrop: null,
      onDurationChange: null,
      onEmptied: null,
      onEnd: null,
      onEnded: null,
      onError: null,
      onFocus: null,
      onFocusIn: null,
      onFocusOut: null,
      onHashChange: null,
      onInput: null,
      onInvalid: null,
      onKeyDown: null,
      onKeyPress: null,
      onKeyUp: null,
      onLoad: null,
      onLoadedData: null,
      onLoadedMetadata: null,
      onLoadStart: null,
      onMessage: null,
      onMouseDown: null,
      onMouseEnter: null,
      onMouseLeave: null,
      onMouseMove: null,
      onMouseOut: null,
      onMouseOver: null,
      onMouseUp: null,
      onMouseWheel: null,
      onOffline: null,
      onOnline: null,
      onPageHide: null,
      onPageShow: null,
      onPaste: null,
      onPause: null,
      onPlay: null,
      onPlaying: null,
      onPopState: null,
      onProgress: null,
      onRateChange: null,
      onRepeat: null,
      onReset: null,
      onResize: null,
      onScroll: null,
      onSeeked: null,
      onSeeking: null,
      onSelect: null,
      onShow: null,
      onStalled: null,
      onStorage: null,
      onSubmit: null,
      onSuspend: null,
      onTimeUpdate: null,
      onToggle: null,
      onUnload: null,
      onVolumeChange: null,
      onWaiting: null,
      onZoom: null,
      opacity: null,
      operator: null,
      order: null,
      orient: null,
      orientation: null,
      origin: null,
      overflow: null,
      overlay: null,
      overlinePosition: L,
      overlineThickness: L,
      paintOrder: null,
      panose1: null,
      path: null,
      pathLength: L,
      patternContentUnits: null,
      patternTransform: null,
      patternUnits: null,
      phase: null,
      ping: ve,
      pitch: null,
      playbackOrder: null,
      pointerEvents: null,
      points: null,
      pointsAtX: L,
      pointsAtY: L,
      pointsAtZ: L,
      preserveAlpha: null,
      preserveAspectRatio: null,
      primitiveUnits: null,
      propagate: null,
      property: Qe,
      r: null,
      radius: null,
      referrerPolicy: null,
      refX: null,
      refY: null,
      rel: Qe,
      rev: Qe,
      renderingIntent: null,
      repeatCount: null,
      repeatDur: null,
      requiredExtensions: Qe,
      requiredFeatures: Qe,
      requiredFonts: Qe,
      requiredFormats: Qe,
      resource: null,
      restart: null,
      result: null,
      rotate: null,
      rx: null,
      ry: null,
      scale: null,
      seed: null,
      shapeRendering: null,
      side: null,
      slope: null,
      snapshotTime: null,
      specularConstant: L,
      specularExponent: L,
      spreadMethod: null,
      spacing: null,
      startOffset: null,
      stdDeviation: null,
      stemh: null,
      stemv: null,
      stitchTiles: null,
      stopColor: null,
      stopOpacity: null,
      strikethroughPosition: L,
      strikethroughThickness: L,
      string: null,
      stroke: null,
      strokeDashArray: Qe,
      strokeDashOffset: null,
      strokeLineCap: null,
      strokeLineJoin: null,
      strokeMiterLimit: L,
      strokeOpacity: L,
      strokeWidth: null,
      style: null,
      surfaceScale: L,
      syncBehavior: null,
      syncBehaviorDefault: null,
      syncMaster: null,
      syncTolerance: null,
      syncToleranceDefault: null,
      systemLanguage: Qe,
      tabIndex: L,
      tableValues: null,
      target: null,
      targetX: L,
      targetY: L,
      textAnchor: null,
      textDecoration: null,
      textRendering: null,
      textLength: null,
      timelineBegin: null,
      title: null,
      transformBehavior: null,
      type: null,
      typeOf: Qe,
      to: null,
      transform: null,
      u1: null,
      u2: null,
      underlinePosition: L,
      underlineThickness: L,
      unicode: null,
      unicodeBidi: null,
      unicodeRange: null,
      unitsPerEm: L,
      values: null,
      vAlphabetic: L,
      vMathematical: L,
      vectorEffect: null,
      vHanging: L,
      vIdeographic: L,
      version: null,
      vertAdvY: L,
      vertOriginX: L,
      vertOriginY: L,
      viewBox: null,
      viewTarget: null,
      visibility: null,
      width: null,
      widths: null,
      wordSpacing: null,
      writingMode: null,
      x: null,
      x1: null,
      x2: null,
      xChannelSelector: null,
      xHeight: L,
      y: null,
      y1: null,
      y2: null,
      yChannelSelector: null,
      z: null,
      zoomAndPan: null,
    },
  });
  var j4 = /^data[-\w.:]+$/i,
    Qi = /-[a-z]/g,
    Y4 = /[A-Z]/g;
  function b0(e, t) {
    let n = T5(t),
      a = t,
      r = Be;
    if (n in e.normal) return e.property[e.normal[n]];
    if (n.length > 4 && n.slice(0, 4) === "data" && j4.test(t)) {
      if (t.charAt(4) === "-") {
        let o = t.slice(5).replace(Qi, Z4);
        a = "data" + o.charAt(0).toUpperCase() + o.slice(1);
      } else {
        let o = t.slice(4);
        if (!Qi.test(o)) {
          let i = o.replace(Y4, Q4);
          i.charAt(0) !== "-" && (i = "-" + i), (t = "data" + i);
        }
      }
      r = Gt;
    }
    return new r(a, t);
  }
  function Q4(e) {
    return "-" + e.toLowerCase();
  }
  function Z4(e) {
    return e.charAt(1).toUpperCase();
  }
  var R1 = {
    classId: "classID",
    dataType: "datatype",
    itemId: "itemID",
    strokeDashArray: "strokeDasharray",
    strokeDashOffset: "strokeDashoffset",
    strokeLineCap: "strokeLinecap",
    strokeLineJoin: "strokeLinejoin",
    strokeMiterLimit: "strokeMiterlimit",
    typeOf: "typeof",
    xLinkActuate: "xlinkActuate",
    xLinkArcRole: "xlinkArcrole",
    xLinkHref: "xlinkHref",
    xLinkRole: "xlinkRole",
    xLinkShow: "xlinkShow",
    xLinkTitle: "xlinkTitle",
    xLinkType: "xlinkType",
    xmlnsXLink: "xmlnsXlink",
  };
  var Zi = d0([f0, h0, g0, v0, ji], "html"),
    Xi = d0([f0, h0, g0, v0, Yi], "svg");
  function _0(e) {
    if (e.allowedElements && e.disallowedElements)
      throw new TypeError(
        "Only one of `allowedElements` and `disallowedElements` should be defined"
      );
    if (e.allowedElements || e.disallowedElements || e.allowElement)
      return (t) => {
        Tt(t, "element", (n, a, r) => {
          let o = r,
            i;
          if (
            (e.allowedElements
              ? (i = !e.allowedElements.includes(n.tagName))
              : e.disallowedElements &&
                (i = e.disallowedElements.includes(n.tagName)),
            !i &&
              e.allowElement &&
              typeof a == "number" &&
              (i = !e.allowElement(n, a, o)),
            i && typeof a == "number")
          )
            return (
              e.unwrapDisallowed && n.children
                ? o.children.splice(a, 1, ...n.children)
                : o.children.splice(a, 1),
              a
            );
        });
      };
  }
  var h2 = pt(n2(), 1);
  function a2(e) {
    var t = e && typeof e == "object" && e.type === "text" ? e.value || "" : e;
    return typeof t == "string" && t.replace(/[ \t\n\f\r]/g, "") === "";
  }
  function r2(e) {
    return e.join(" ").trim();
  }
  function o2(e, t) {
    let n = t || {};
    return (e[e.length - 1] === "" ? [...e, ""] : e)
      .join((n.padRight ? " " : "") + "," + (n.padLeft === !1 ? "" : " "))
      .trim();
  }
  var f2 = pt(m2(), 1),
    w0 = {}.hasOwnProperty,
    p6 = new Set(["table", "thead", "tbody", "tfoot", "tr"]);
  function A0(e, t) {
    let n = [],
      a = -1,
      r;
    for (; ++a < t.children.length; )
      (r = t.children[a]),
        r.type === "element"
          ? n.push(m6(e, r, a, t))
          : r.type === "text"
          ? (t.type !== "element" || !p6.has(t.tagName) || !a2(r)) &&
            n.push(r.value)
          : r.type === "raw" && !e.options.skipHtml && n.push(r.value);
    return n;
  }
  function m6(e, t, n, a) {
    let r = e.options,
      o = e.schema,
      i = t.tagName,
      l = {},
      s = o,
      u;
    if (
      (o.space === "html" && i === "svg" && ((s = Xi), (e.schema = s)),
      t.properties)
    )
      for (u in t.properties)
        w0.call(t.properties, u) && f6(l, u, t.properties[u], e);
    (i === "ol" || i === "ul") && e.listDepth++;
    let c = A0(e, t);
    (i === "ol" || i === "ul") && e.listDepth--, (e.schema = o);
    let d = t.position || {
        start: { line: null, column: null, offset: null },
        end: { line: null, column: null, offset: null },
      },
      p = r.components && w0.call(r.components, i) ? r.components[i] : i,
      m = typeof p == "string" || p === S.Fragment;
    if (!h2.default.isValidElementType(p))
      throw new TypeError(
        `Component for name \`${i}\` not defined or is not renderable`
      );
    if (
      ((l.key = [i, d.start.line, d.start.column, n].join("-")),
      i === "a" &&
        r.linkTarget &&
        (l.target =
          typeof r.linkTarget == "function"
            ? r.linkTarget(
                String(l.href || ""),
                t.children,
                typeof l.title == "string" ? l.title : null
              )
            : r.linkTarget),
      i === "a" &&
        r.transformLinkUri &&
        (l.href = r.transformLinkUri(
          String(l.href || ""),
          t.children,
          typeof l.title == "string" ? l.title : null
        )),
      !m &&
        i === "code" &&
        a.type === "element" &&
        a.tagName !== "pre" &&
        (l.inline = !0),
      !m &&
        (i === "h1" ||
          i === "h2" ||
          i === "h3" ||
          i === "h4" ||
          i === "h5" ||
          i === "h6") &&
        (l.level = Number.parseInt(i.charAt(1), 10)),
      i === "img" &&
        r.transformImageUri &&
        (l.src = r.transformImageUri(
          String(l.src || ""),
          String(l.alt || ""),
          typeof l.title == "string" ? l.title : null
        )),
      !m && i === "li" && a.type === "element")
    ) {
      let f = h6(t);
      (l.checked = f && f.properties ? Boolean(f.properties.checked) : null),
        (l.index = x0(a, t)),
        (l.ordered = a.tagName === "ol");
    }
    return (
      !m &&
        (i === "ol" || i === "ul") &&
        ((l.ordered = i === "ol"), (l.depth = e.listDepth)),
      (i === "td" || i === "th") &&
        (l.align &&
          (l.style || (l.style = {}),
          (l.style.textAlign = l.align),
          delete l.align),
        m || (l.isHeader = i === "th")),
      !m &&
        i === "tr" &&
        a.type === "element" &&
        (l.isHeader = Boolean(a.tagName === "thead")),
      r.sourcePos && (l["data-sourcepos"] = b6(d)),
      !m && r.rawSourcePos && (l.sourcePosition = t.position),
      !m &&
        r.includeElementIndex &&
        ((l.index = x0(a, t)), (l.siblingCount = x0(a))),
      m || (l.node = t),
      c.length > 0 ? S.createElement(p, l, c) : S.createElement(p, l)
    );
  }
  function h6(e) {
    let t = -1;
    for (; ++t < e.children.length; ) {
      let n = e.children[t];
      if (n.type === "element" && n.tagName === "input") return n;
    }
    return null;
  }
  function x0(e, t) {
    let n = -1,
      a = 0;
    for (; ++n < e.children.length && e.children[n] !== t; )
      e.children[n].type === "element" && a++;
    return a;
  }
  function f6(e, t, n, a) {
    let r = b0(a.schema, t),
      o = n;
    o == null ||
      o !== o ||
      (Array.isArray(o) && (o = r.commaSeparated ? o2(o) : r2(o)),
      r.property === "style" && typeof o == "string" && (o = g6(o)),
      r.space && r.property
        ? (e[w0.call(R1, r.property) ? R1[r.property] : r.property] = o)
        : r.attribute && (e[r.attribute] = o));
  }
  function g6(e) {
    let t = {};
    try {
      (0, f2.default)(e, n);
    } catch {}
    return t;
    function n(a, r) {
      let o = a.slice(0, 4) === "-ms-" ? `ms-${a.slice(4)}` : a;
      t[o.replace(/-([a-z])/g, v6)] = r;
    }
  }
  function v6(e, t) {
    return t.toUpperCase();
  }
  function b6(e) {
    return [
      e.start.line,
      ":",
      e.start.column,
      "-",
      e.end.line,
      ":",
      e.end.column,
    ]
      .map(String)
      .join("");
  }
  var g2 = {}.hasOwnProperty,
    _6 = "https://github.com/remarkjs/react-markdown/blob/main/changelog.md",
    B1 = {
      plugins: { to: "plugins", id: "change-plugins-to-remarkplugins" },
      renderers: { to: "components", id: "change-renderers-to-components" },
      astPlugins: { id: "remove-buggy-html-in-markdown-parser" },
      allowDangerousHtml: { id: "remove-buggy-html-in-markdown-parser" },
      escapeHtml: { id: "remove-buggy-html-in-markdown-parser" },
      source: { to: "children", id: "change-source-to-children" },
      allowNode: {
        to: "allowElement",
        id: "replace-allownode-allowedtypes-and-disallowedtypes",
      },
      allowedTypes: {
        to: "allowedElements",
        id: "replace-allownode-allowedtypes-and-disallowedtypes",
      },
      disallowedTypes: {
        to: "disallowedElements",
        id: "replace-allownode-allowedtypes-and-disallowedtypes",
      },
      includeNodeIndex: {
        to: "includeElementIndex",
        id: "change-includenodeindex-to-includeelementindex",
      },
    };
  function L5(e) {
    for (let o in B1)
      if (g2.call(B1, o) && g2.call(e, o)) {
        let i = B1[o];
        console.warn(
          `[react-markdown] Warning: please ${
            i.to ? `use \`${i.to}\` instead of` : "remove"
          } \`${o}\` (see <${_6}#${i.id}> for more info)`
        ),
          delete B1[o];
      }
    let t = $n()
        .use(ii)
        .use(e.remarkPlugins || [])
        .use(u0, { ...e.remarkRehypeOptions, allowDangerousHtml: !0 })
        .use(e.rehypePlugins || [])
        .use(_0, e),
      n = new Pt();
    typeof e.children == "string"
      ? (n.value = e.children)
      : e.children !== void 0 &&
        e.children !== null &&
        console.warn(
          `[react-markdown] Warning: please pass a string as \`children\` (not: \`${e.children}\`)`
        );
    let a = t.runSync(t.parse(n), n);
    if (a.type !== "root") throw new TypeError("Expected a `root` node");
    let r = S.createElement(
      S.Fragment,
      {},
      A0({ options: e, schema: Zi, listDepth: 0 }, a)
    );
    return (
      e.className &&
        (r = S.createElement("div", { className: e.className }, r)),
      r
    );
  }
  L5.defaultProps = { transformLinkUri: oo };
  L5.propTypes = {
    children: Q.default.string,
    className: Q.default.string,
    allowElement: Q.default.func,
    allowedElements: Q.default.arrayOf(Q.default.string),
    disallowedElements: Q.default.arrayOf(Q.default.string),
    unwrapDisallowed: Q.default.bool,
    remarkPlugins: Q.default.arrayOf(
      Q.default.oneOfType([
        Q.default.object,
        Q.default.func,
        Q.default.arrayOf(
          Q.default.oneOfType([
            Q.default.bool,
            Q.default.string,
            Q.default.object,
            Q.default.func,
            Q.default.arrayOf(Q.default.any),
          ])
        ),
      ])
    ),
    rehypePlugins: Q.default.arrayOf(
      Q.default.oneOfType([
        Q.default.object,
        Q.default.func,
        Q.default.arrayOf(
          Q.default.oneOfType([
            Q.default.bool,
            Q.default.string,
            Q.default.object,
            Q.default.func,
            Q.default.arrayOf(Q.default.any),
          ])
        ),
      ])
    ),
    sourcePos: Q.default.bool,
    rawSourcePos: Q.default.bool,
    skipHtml: Q.default.bool,
    includeElementIndex: Q.default.bool,
    transformLinkUri: Q.default.oneOfType([Q.default.func, Q.default.bool]),
    linkTarget: Q.default.oneOfType([Q.default.func, Q.default.string]),
    transformImageUri: Q.default.func,
    components: Q.default.object,
  };
  function E6(e) {
    let t = e.regex,
      n = e.COMMENT("//", "$", { contains: [{ begin: /\\\n/ }] }),
      a = "decltype\\(auto\\)",
      r = "[a-zA-Z_]\\w*::",
      o = "<[^<>]+>",
      i =
        "(?!struct)(" +
        a +
        "|" +
        t.optional(r) +
        "[a-zA-Z_]\\w*" +
        t.optional(o) +
        ")",
      l = { className: "type", begin: "\\b[a-z\\d_]*_t\\b" },
      s = "\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)",
      u = {
        className: "string",
        variants: [
          {
            begin: '(u8?|U|L)?"',
            end: '"',
            illegal: "\\n",
            contains: [e.BACKSLASH_ESCAPE],
          },
          { begin: "(u8?|U|L)?'(" + s + "|.)", end: "'", illegal: "." },
          e.END_SAME_AS_BEGIN({
            begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
            end: /\)([^()\\ ]{0,16})"/,
          }),
        ],
      },
      c = {
        className: "number",
        variants: [
          { begin: "\\b(0b[01']+)" },
          {
            begin:
              "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)((ll|LL|l|L)(u|U)?|(u|U)(ll|LL|l|L)?|f|F|b|B)",
          },
          {
            begin:
              "(-?)(\\b0[xX][a-fA-F0-9']+|(\\b[\\d']+(\\.[\\d']*)?|\\.[\\d']+)([eE][-+]?[\\d']+)?)",
          },
        ],
        relevance: 0,
      },
      d = {
        className: "meta",
        begin: /#\s*[a-z]+\b/,
        end: /$/,
        keywords: {
          keyword:
            "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include",
        },
        contains: [
          { begin: /\\\n/, relevance: 0 },
          e.inherit(u, { className: "string" }),
          { className: "string", begin: /<.*?>/ },
          n,
          e.C_BLOCK_COMMENT_MODE,
        ],
      },
      p = {
        className: "title",
        begin: t.optional(r) + e.IDENT_RE,
        relevance: 0,
      },
      m = t.optional(r) + e.IDENT_RE + "\\s*\\(",
      f = [
        "alignas",
        "alignof",
        "and",
        "and_eq",
        "asm",
        "atomic_cancel",
        "atomic_commit",
        "atomic_noexcept",
        "auto",
        "bitand",
        "bitor",
        "break",
        "case",
        "catch",
        "class",
        "co_await",
        "co_return",
        "co_yield",
        "compl",
        "concept",
        "const_cast|10",
        "consteval",
        "constexpr",
        "constinit",
        "continue",
        "decltype",
        "default",
        "delete",
        "do",
        "dynamic_cast|10",
        "else",
        "enum",
        "explicit",
        "export",
        "extern",
        "false",
        "final",
        "for",
        "friend",
        "goto",
        "if",
        "import",
        "inline",
        "module",
        "mutable",
        "namespace",
        "new",
        "noexcept",
        "not",
        "not_eq",
        "nullptr",
        "operator",
        "or",
        "or_eq",
        "override",
        "private",
        "protected",
        "public",
        "reflexpr",
        "register",
        "reinterpret_cast|10",
        "requires",
        "return",
        "sizeof",
        "static_assert",
        "static_cast|10",
        "struct",
        "switch",
        "synchronized",
        "template",
        "this",
        "thread_local",
        "throw",
        "transaction_safe",
        "transaction_safe_dynamic",
        "true",
        "try",
        "typedef",
        "typeid",
        "typename",
        "union",
        "using",
        "virtual",
        "volatile",
        "while",
        "xor",
        "xor_eq",
      ],
      v = [
        "bool",
        "char",
        "char16_t",
        "char32_t",
        "char8_t",
        "double",
        "float",
        "int",
        "long",
        "short",
        "void",
        "wchar_t",
        "unsigned",
        "signed",
        "const",
        "static",
      ],
      g = [
        "any",
        "auto_ptr",
        "barrier",
        "binary_semaphore",
        "bitset",
        "complex",
        "condition_variable",
        "condition_variable_any",
        "counting_semaphore",
        "deque",
        "false_type",
        "future",
        "imaginary",
        "initializer_list",
        "istringstream",
        "jthread",
        "latch",
        "lock_guard",
        "multimap",
        "multiset",
        "mutex",
        "optional",
        "ostringstream",
        "packaged_task",
        "pair",
        "promise",
        "priority_queue",
        "queue",
        "recursive_mutex",
        "recursive_timed_mutex",
        "scoped_lock",
        "set",
        "shared_future",
        "shared_lock",
        "shared_mutex",
        "shared_timed_mutex",
        "shared_ptr",
        "stack",
        "string_view",
        "stringstream",
        "timed_mutex",
        "thread",
        "true_type",
        "tuple",
        "unique_lock",
        "unique_ptr",
        "unordered_map",
        "unordered_multimap",
        "unordered_multiset",
        "unordered_set",
        "variant",
        "vector",
        "weak_ptr",
        "wstring",
        "wstring_view",
      ],
      _ = [
        "abort",
        "abs",
        "acos",
        "apply",
        "as_const",
        "asin",
        "atan",
        "atan2",
        "calloc",
        "ceil",
        "cerr",
        "cin",
        "clog",
        "cos",
        "cosh",
        "cout",
        "declval",
        "endl",
        "exchange",
        "exit",
        "exp",
        "fabs",
        "floor",
        "fmod",
        "forward",
        "fprintf",
        "fputs",
        "free",
        "frexp",
        "fscanf",
        "future",
        "invoke",
        "isalnum",
        "isalpha",
        "iscntrl",
        "isdigit",
        "isgraph",
        "islower",
        "isprint",
        "ispunct",
        "isspace",
        "isupper",
        "isxdigit",
        "labs",
        "launder",
        "ldexp",
        "log",
        "log10",
        "make_pair",
        "make_shared",
        "make_shared_for_overwrite",
        "make_tuple",
        "make_unique",
        "malloc",
        "memchr",
        "memcmp",
        "memcpy",
        "memset",
        "modf",
        "move",
        "pow",
        "printf",
        "putchar",
        "puts",
        "realloc",
        "scanf",
        "sin",
        "sinh",
        "snprintf",
        "sprintf",
        "sqrt",
        "sscanf",
        "std",
        "stderr",
        "stdin",
        "stdout",
        "strcat",
        "strchr",
        "strcmp",
        "strcpy",
        "strcspn",
        "strlen",
        "strncat",
        "strncmp",
        "strncpy",
        "strpbrk",
        "strrchr",
        "strspn",
        "strstr",
        "swap",
        "tan",
        "tanh",
        "terminate",
        "to_underlying",
        "tolower",
        "toupper",
        "vfprintf",
        "visit",
        "vprintf",
        "vsprintf",
      ],
      w = {
        type: v,
        keyword: f,
        literal: ["NULL", "false", "nullopt", "nullptr", "true"],
        built_in: ["_Pragma"],
        _type_hints: g,
      },
      M = {
        className: "function.dispatch",
        relevance: 0,
        keywords: { _hint: _ },
        begin: t.concat(
          /\b/,
          /(?!decltype)/,
          /(?!if)/,
          /(?!for)/,
          /(?!switch)/,
          /(?!while)/,
          e.IDENT_RE,
          t.lookahead(/(<[^<>]+>|)\s*\(/)
        ),
      },
      E = [M, d, l, n, e.C_BLOCK_COMMENT_MODE, c, u],
      z = {
        variants: [
          { begin: /=/, end: /;/ },
          { begin: /\(/, end: /\)/ },
          { beginKeywords: "new throw return else", end: /;/ },
        ],
        keywords: w,
        contains: E.concat([
          {
            begin: /\(/,
            end: /\)/,
            keywords: w,
            contains: E.concat(["self"]),
            relevance: 0,
          },
        ]),
        relevance: 0,
      },
      k = {
        className: "function",
        begin: "(" + i + "[\\*&\\s]+)+" + m,
        returnBegin: !0,
        end: /[{;=]/,
        excludeEnd: !0,
        keywords: w,
        illegal: /[^\w\s\*&:<>.]/,
        contains: [
          { begin: a, keywords: w, relevance: 0 },
          { begin: m, returnBegin: !0, contains: [p], relevance: 0 },
          { begin: /::/, relevance: 0 },
          { begin: /:/, endsWithParent: !0, contains: [u, c] },
          { relevance: 0, match: /,/ },
          {
            className: "params",
            begin: /\(/,
            end: /\)/,
            keywords: w,
            relevance: 0,
            contains: [
              n,
              e.C_BLOCK_COMMENT_MODE,
              u,
              c,
              l,
              {
                begin: /\(/,
                end: /\)/,
                keywords: w,
                relevance: 0,
                contains: ["self", n, e.C_BLOCK_COMMENT_MODE, u, c, l],
              },
            ],
          },
          l,
          n,
          e.C_BLOCK_COMMENT_MODE,
          d,
        ],
      };
    return {
      name: "C++",
      aliases: ["cc", "c++", "h++", "hpp", "hh", "hxx", "cxx"],
      keywords: w,
      illegal: "</",
      classNameAliases: { "function.dispatch": "built_in" },
      contains: [].concat(z, k, M, E, [
        d,
        {
          begin:
            "\\b(deque|list|queue|priority_queue|pair|stack|vector|map|set|bitset|multiset|multimap|unordered_map|unordered_set|unordered_multiset|unordered_multimap|array|tuple|optional|variant|function)\\s*<(?!<)",
          end: ">",
          keywords: w,
          contains: ["self", l],
        },
        { begin: e.IDENT_RE + "::", keywords: w },
        {
          match: [
            /\b(?:enum(?:\s+(?:class|struct))?|class|struct|union)/,
            /\s+/,
            /\w+/,
          ],
          className: { 1: "keyword", 3: "title.class" },
        },
      ]),
    };
  }
  function v2(e) {
    let t = {
        type: ["boolean", "byte", "word", "String"],
        built_in: [
          "KeyboardController",
          "MouseController",
          "SoftwareSerial",
          "EthernetServer",
          "EthernetClient",
          "LiquidCrystal",
          "RobotControl",
          "GSMVoiceCall",
          "EthernetUDP",
          "EsploraTFT",
          "HttpClient",
          "RobotMotor",
          "WiFiClient",
          "GSMScanner",
          "FileSystem",
          "Scheduler",
          "GSMServer",
          "YunClient",
          "YunServer",
          "IPAddress",
          "GSMClient",
          "GSMModem",
          "Keyboard",
          "Ethernet",
          "Console",
          "GSMBand",
          "Esplora",
          "Stepper",
          "Process",
          "WiFiUDP",
          "GSM_SMS",
          "Mailbox",
          "USBHost",
          "Firmata",
          "PImage",
          "Client",
          "Server",
          "GSMPIN",
          "FileIO",
          "Bridge",
          "Serial",
          "EEPROM",
          "Stream",
          "Mouse",
          "Audio",
          "Servo",
          "File",
          "Task",
          "GPRS",
          "WiFi",
          "Wire",
          "TFT",
          "GSM",
          "SPI",
          "SD",
        ],
        _hints: [
          "setup",
          "loop",
          "runShellCommandAsynchronously",
          "analogWriteResolution",
          "retrieveCallingNumber",
          "printFirmwareVersion",
          "analogReadResolution",
          "sendDigitalPortPair",
          "noListenOnLocalhost",
          "readJoystickButton",
          "setFirmwareVersion",
          "readJoystickSwitch",
          "scrollDisplayRight",
          "getVoiceCallStatus",
          "scrollDisplayLeft",
          "writeMicroseconds",
          "delayMicroseconds",
          "beginTransmission",
          "getSignalStrength",
          "runAsynchronously",
          "getAsynchronously",
          "listenOnLocalhost",
          "getCurrentCarrier",
          "readAccelerometer",
          "messageAvailable",
          "sendDigitalPorts",
          "lineFollowConfig",
          "countryNameWrite",
          "runShellCommand",
          "readStringUntil",
          "rewindDirectory",
          "readTemperature",
          "setClockDivider",
          "readLightSensor",
          "endTransmission",
          "analogReference",
          "detachInterrupt",
          "countryNameRead",
          "attachInterrupt",
          "encryptionType",
          "readBytesUntil",
          "robotNameWrite",
          "readMicrophone",
          "robotNameRead",
          "cityNameWrite",
          "userNameWrite",
          "readJoystickY",
          "readJoystickX",
          "mouseReleased",
          "openNextFile",
          "scanNetworks",
          "noInterrupts",
          "digitalWrite",
          "beginSpeaker",
          "mousePressed",
          "isActionDone",
          "mouseDragged",
          "displayLogos",
          "noAutoscroll",
          "addParameter",
          "remoteNumber",
          "getModifiers",
          "keyboardRead",
          "userNameRead",
          "waitContinue",
          "processInput",
          "parseCommand",
          "printVersion",
          "readNetworks",
          "writeMessage",
          "blinkVersion",
          "cityNameRead",
          "readMessage",
          "setDataMode",
          "parsePacket",
          "isListening",
          "setBitOrder",
          "beginPacket",
          "isDirectory",
          "motorsWrite",
          "drawCompass",
          "digitalRead",
          "clearScreen",
          "serialEvent",
          "rightToLeft",
          "setTextSize",
          "leftToRight",
          "requestFrom",
          "keyReleased",
          "compassRead",
          "analogWrite",
          "interrupts",
          "WiFiServer",
          "disconnect",
          "playMelody",
          "parseFloat",
          "autoscroll",
          "getPINUsed",
          "setPINUsed",
          "setTimeout",
          "sendAnalog",
          "readSlider",
          "analogRead",
          "beginWrite",
          "createChar",
          "motorsStop",
          "keyPressed",
          "tempoWrite",
          "readButton",
          "subnetMask",
          "debugPrint",
          "macAddress",
          "writeGreen",
          "randomSeed",
          "attachGPRS",
          "readString",
          "sendString",
          "remotePort",
          "releaseAll",
          "mouseMoved",
          "background",
          "getXChange",
          "getYChange",
          "answerCall",
          "getResult",
          "voiceCall",
          "endPacket",
          "constrain",
          "getSocket",
          "writeJSON",
          "getButton",
          "available",
          "connected",
          "findUntil",
          "readBytes",
          "exitValue",
          "readGreen",
          "writeBlue",
          "startLoop",
          "IPAddress",
          "isPressed",
          "sendSysex",
          "pauseMode",
          "gatewayIP",
          "setCursor",
          "getOemKey",
          "tuneWrite",
          "noDisplay",
          "loadImage",
          "switchPIN",
          "onRequest",
          "onReceive",
          "changePIN",
          "playFile",
          "noBuffer",
          "parseInt",
          "overflow",
          "checkPIN",
          "knobRead",
          "beginTFT",
          "bitClear",
          "updateIR",
          "bitWrite",
          "position",
          "writeRGB",
          "highByte",
          "writeRed",
          "setSpeed",
          "readBlue",
          "noStroke",
          "remoteIP",
          "transfer",
          "shutdown",
          "hangCall",
          "beginSMS",
          "endWrite",
          "attached",
          "maintain",
          "noCursor",
          "checkReg",
          "checkPUK",
          "shiftOut",
          "isValid",
          "shiftIn",
          "pulseIn",
          "connect",
          "println",
          "localIP",
          "pinMode",
          "getIMEI",
          "display",
          "noBlink",
          "process",
          "getBand",
          "running",
          "beginSD",
          "drawBMP",
          "lowByte",
          "setBand",
          "release",
          "bitRead",
          "prepare",
          "pointTo",
          "readRed",
          "setMode",
          "noFill",
          "remove",
          "listen",
          "stroke",
          "detach",
          "attach",
          "noTone",
          "exists",
          "buffer",
          "height",
          "bitSet",
          "circle",
          "config",
          "cursor",
          "random",
          "IRread",
          "setDNS",
          "endSMS",
          "getKey",
          "micros",
          "millis",
          "begin",
          "print",
          "write",
          "ready",
          "flush",
          "width",
          "isPIN",
          "blink",
          "clear",
          "press",
          "mkdir",
          "rmdir",
          "close",
          "point",
          "yield",
          "image",
          "BSSID",
          "click",
          "delay",
          "read",
          "text",
          "move",
          "peek",
          "beep",
          "rect",
          "line",
          "open",
          "seek",
          "fill",
          "size",
          "turn",
          "stop",
          "home",
          "find",
          "step",
          "tone",
          "sqrt",
          "RSSI",
          "SSID",
          "end",
          "bit",
          "tan",
          "cos",
          "sin",
          "pow",
          "map",
          "abs",
          "max",
          "min",
          "get",
          "run",
          "put",
        ],
        literal: [
          "DIGITAL_MESSAGE",
          "FIRMATA_STRING",
          "ANALOG_MESSAGE",
          "REPORT_DIGITAL",
          "REPORT_ANALOG",
          "INPUT_PULLUP",
          "SET_PIN_MODE",
          "INTERNAL2V56",
          "SYSTEM_RESET",
          "LED_BUILTIN",
          "INTERNAL1V1",
          "SYSEX_START",
          "INTERNAL",
          "EXTERNAL",
          "DEFAULT",
          "OUTPUT",
          "INPUT",
          "HIGH",
          "LOW",
        ],
      },
      n = E6(e),
      a = n.keywords;
    return (
      (a.type = [...a.type, ...t.type]),
      (a.literal = [...a.literal, ...t.literal]),
      (a.built_in = [...a.built_in, ...t.built_in]),
      (a._hints = t._hints),
      (n.name = "Arduino"),
      (n.aliases = ["ino"]),
      (n.supersetOf = "cpp"),
      n
    );
  }
  function b2(e) {
    let t = e.regex,
      n = {},
      a = {
        begin: /\$\{/,
        end: /\}/,
        contains: ["self", { begin: /:-/, contains: [n] }],
      };
    Object.assign(n, {
      className: "variable",
      variants: [
        { begin: t.concat(/\$[\w\d#@][\w\d_]*/, "(?![\\w\\d])(?![$])") },
        a,
      ],
    });
    let r = {
        className: "subst",
        begin: /\$\(/,
        end: /\)/,
        contains: [e.BACKSLASH_ESCAPE],
      },
      o = {
        begin: /<<-?\s*(?=\w+)/,
        starts: {
          contains: [
            e.END_SAME_AS_BEGIN({
              begin: /(\w+)/,
              end: /(\w+)/,
              className: "string",
            }),
          ],
        },
      },
      i = {
        className: "string",
        begin: /"/,
        end: /"/,
        contains: [e.BACKSLASH_ESCAPE, n, r],
      };
    r.contains.push(i);
    let l = { className: "", begin: /\\"/ },
      s = { className: "string", begin: /'/, end: /'/ },
      u = {
        begin: /\$?\(\(/,
        end: /\)\)/,
        contains: [
          { begin: /\d+#[0-9a-f]+/, className: "number" },
          e.NUMBER_MODE,
          n,
        ],
      },
      c = ["fish", "bash", "zsh", "sh", "csh", "ksh", "tcsh", "dash", "scsh"],
      d = e.SHEBANG({ binary: `(${c.join("|")})`, relevance: 10 }),
      p = {
        className: "function",
        begin: /\w[\w\d_]*\s*\(\s*\)\s*\{/,
        returnBegin: !0,
        contains: [e.inherit(e.TITLE_MODE, { begin: /\w[\w\d_]*/ })],
        relevance: 0,
      },
      m = [
        "if",
        "then",
        "else",
        "elif",
        "fi",
        "for",
        "while",
        "in",
        "do",
        "done",
        "case",
        "esac",
        "function",
      ],
      f = ["true", "false"],
      v = { match: /(\/[a-z._-]+)+/ },
      g = [
        "break",
        "cd",
        "continue",
        "eval",
        "exec",
        "exit",
        "export",
        "getopts",
        "hash",
        "pwd",
        "readonly",
        "return",
        "shift",
        "test",
        "times",
        "trap",
        "umask",
        "unset",
      ],
      _ = [
        "alias",
        "bind",
        "builtin",
        "caller",
        "command",
        "declare",
        "echo",
        "enable",
        "help",
        "let",
        "local",
        "logout",
        "mapfile",
        "printf",
        "read",
        "readarray",
        "source",
        "type",
        "typeset",
        "ulimit",
        "unalias",
      ],
      C = [
        "autoload",
        "bg",
        "bindkey",
        "bye",
        "cap",
        "chdir",
        "clone",
        "comparguments",
        "compcall",
        "compctl",
        "compdescribe",
        "compfiles",
        "compgroups",
        "compquote",
        "comptags",
        "comptry",
        "compvalues",
        "dirs",
        "disable",
        "disown",
        "echotc",
        "echoti",
        "emulate",
        "fc",
        "fg",
        "float",
        "functions",
        "getcap",
        "getln",
        "history",
        "integer",
        "jobs",
        "kill",
        "limit",
        "log",
        "noglob",
        "popd",
        "print",
        "pushd",
        "pushln",
        "rehash",
        "sched",
        "setcap",
        "setopt",
        "stat",
        "suspend",
        "ttyctl",
        "unfunction",
        "unhash",
        "unlimit",
        "unsetopt",
        "vared",
        "wait",
        "whence",
        "where",
        "which",
        "zcompile",
        "zformat",
        "zftp",
        "zle",
        "zmodload",
        "zparseopts",
        "zprof",
        "zpty",
        "zregexparse",
        "zsocket",
        "zstyle",
        "ztcp",
      ],
      y = [
        "chcon",
        "chgrp",
        "chown",
        "chmod",
        "cp",
        "dd",
        "df",
        "dir",
        "dircolors",
        "ln",
        "ls",
        "mkdir",
        "mkfifo",
        "mknod",
        "mktemp",
        "mv",
        "realpath",
        "rm",
        "rmdir",
        "shred",
        "sync",
        "touch",
        "truncate",
        "vdir",
        "b2sum",
        "base32",
        "base64",
        "cat",
        "cksum",
        "comm",
        "csplit",
        "cut",
        "expand",
        "fmt",
        "fold",
        "head",
        "join",
        "md5sum",
        "nl",
        "numfmt",
        "od",
        "paste",
        "ptx",
        "pr",
        "sha1sum",
        "sha224sum",
        "sha256sum",
        "sha384sum",
        "sha512sum",
        "shuf",
        "sort",
        "split",
        "sum",
        "tac",
        "tail",
        "tr",
        "tsort",
        "unexpand",
        "uniq",
        "wc",
        "arch",
        "basename",
        "chroot",
        "date",
        "dirname",
        "du",
        "echo",
        "env",
        "expr",
        "factor",
        "groups",
        "hostid",
        "id",
        "link",
        "logname",
        "nice",
        "nohup",
        "nproc",
        "pathchk",
        "pinky",
        "printenv",
        "printf",
        "pwd",
        "readlink",
        "runcon",
        "seq",
        "sleep",
        "stat",
        "stdbuf",
        "stty",
        "tee",
        "test",
        "timeout",
        "tty",
        "uname",
        "unlink",
        "uptime",
        "users",
        "who",
        "whoami",
        "yes",
      ];
    return {
      name: "Bash",
      aliases: ["sh"],
      keywords: {
        $pattern: /\b[a-z][a-z0-9._-]+\b/,
        keyword: m,
        literal: f,
        built_in: [...g, ..._, "set", "shopt", ...C, ...y],
      },
      contains: [d, e.SHEBANG(), p, u, e.HASH_COMMENT_MODE, o, v, i, l, s, n],
    };
  }
  function _2(e) {
    let t = e.regex,
      n = e.COMMENT("//", "$", { contains: [{ begin: /\\\n/ }] }),
      a = "decltype\\(auto\\)",
      r = "[a-zA-Z_]\\w*::",
      o = "<[^<>]+>",
      i = "(" + a + "|" + t.optional(r) + "[a-zA-Z_]\\w*" + t.optional(o) + ")",
      l = {
        className: "type",
        variants: [
          { begin: "\\b[a-z\\d_]*_t\\b" },
          { match: /\batomic_[a-z]{3,6}\b/ },
        ],
      },
      s = "\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)",
      u = {
        className: "string",
        variants: [
          {
            begin: '(u8?|U|L)?"',
            end: '"',
            illegal: "\\n",
            contains: [e.BACKSLASH_ESCAPE],
          },
          { begin: "(u8?|U|L)?'(" + s + "|.)", end: "'", illegal: "." },
          e.END_SAME_AS_BEGIN({
            begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
            end: /\)([^()\\ ]{0,16})"/,
          }),
        ],
      },
      c = {
        className: "number",
        variants: [
          { begin: "\\b(0b[01']+)" },
          {
            begin:
              "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)((ll|LL|l|L)(u|U)?|(u|U)(ll|LL|l|L)?|f|F|b|B)",
          },
          {
            begin:
              "(-?)(\\b0[xX][a-fA-F0-9']+|(\\b[\\d']+(\\.[\\d']*)?|\\.[\\d']+)([eE][-+]?[\\d']+)?)",
          },
        ],
        relevance: 0,
      },
      d = {
        className: "meta",
        begin: /#\s*[a-z]+\b/,
        end: /$/,
        keywords: {
          keyword:
            "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include",
        },
        contains: [
          { begin: /\\\n/, relevance: 0 },
          e.inherit(u, { className: "string" }),
          { className: "string", begin: /<.*?>/ },
          n,
          e.C_BLOCK_COMMENT_MODE,
        ],
      },
      p = {
        className: "title",
        begin: t.optional(r) + e.IDENT_RE,
        relevance: 0,
      },
      m = t.optional(r) + e.IDENT_RE + "\\s*\\(",
      g = {
        keyword: [
          "asm",
          "auto",
          "break",
          "case",
          "continue",
          "default",
          "do",
          "else",
          "enum",
          "extern",
          "for",
          "fortran",
          "goto",
          "if",
          "inline",
          "register",
          "restrict",
          "return",
          "sizeof",
          "struct",
          "switch",
          "typedef",
          "union",
          "volatile",
          "while",
          "_Alignas",
          "_Alignof",
          "_Atomic",
          "_Generic",
          "_Noreturn",
          "_Static_assert",
          "_Thread_local",
          "alignas",
          "alignof",
          "noreturn",
          "static_assert",
          "thread_local",
          "_Pragma",
        ],
        type: [
          "float",
          "double",
          "signed",
          "unsigned",
          "int",
          "short",
          "long",
          "char",
          "void",
          "_Bool",
          "_Complex",
          "_Imaginary",
          "_Decimal32",
          "_Decimal64",
          "_Decimal128",
          "const",
          "static",
          "complex",
          "bool",
          "imaginary",
        ],
        literal: "true false NULL",
        built_in:
          "std string wstring cin cout cerr clog stdin stdout stderr stringstream istringstream ostringstream auto_ptr deque list queue stack vector map set pair bitset multiset multimap unordered_set unordered_map unordered_multiset unordered_multimap priority_queue make_pair array shared_ptr abort terminate abs acos asin atan2 atan calloc ceil cosh cos exit exp fabs floor fmod fprintf fputs free frexp fscanf future isalnum isalpha iscntrl isdigit isgraph islower isprint ispunct isspace isupper isxdigit tolower toupper labs ldexp log10 log malloc realloc memchr memcmp memcpy memset modf pow printf putchar puts scanf sinh sin snprintf sprintf sqrt sscanf strcat strchr strcmp strcpy strcspn strlen strncat strncmp strncpy strpbrk strrchr strspn strstr tanh tan vfprintf vprintf vsprintf endl initializer_list unique_ptr",
      },
      _ = [d, l, n, e.C_BLOCK_COMMENT_MODE, c, u],
      C = {
        variants: [
          { begin: /=/, end: /;/ },
          { begin: /\(/, end: /\)/ },
          { beginKeywords: "new throw return else", end: /;/ },
        ],
        keywords: g,
        contains: _.concat([
          {
            begin: /\(/,
            end: /\)/,
            keywords: g,
            contains: _.concat(["self"]),
            relevance: 0,
          },
        ]),
        relevance: 0,
      },
      y = {
        begin: "(" + i + "[\\*&\\s]+)+" + m,
        returnBegin: !0,
        end: /[{;=]/,
        excludeEnd: !0,
        keywords: g,
        illegal: /[^\w\s\*&:<>.]/,
        contains: [
          { begin: a, keywords: g, relevance: 0 },
          {
            begin: m,
            returnBegin: !0,
            contains: [e.inherit(p, { className: "title.function" })],
            relevance: 0,
          },
          { relevance: 0, match: /,/ },
          {
            className: "params",
            begin: /\(/,
            end: /\)/,
            keywords: g,
            relevance: 0,
            contains: [
              n,
              e.C_BLOCK_COMMENT_MODE,
              u,
              c,
              l,
              {
                begin: /\(/,
                end: /\)/,
                keywords: g,
                relevance: 0,
                contains: ["self", n, e.C_BLOCK_COMMENT_MODE, u, c, l],
              },
            ],
          },
          l,
          n,
          e.C_BLOCK_COMMENT_MODE,
          d,
        ],
      };
    return {
      name: "C",
      aliases: ["h"],
      keywords: g,
      disableAutodetect: !0,
      illegal: "</",
      contains: [].concat(C, y, _, [
        d,
        { begin: e.IDENT_RE + "::", keywords: g },
        {
          className: "class",
          beginKeywords: "enum class struct union",
          end: /[{;:<>=]/,
          contains: [{ beginKeywords: "final class struct" }, e.TITLE_MODE],
        },
      ]),
      exports: { preprocessor: d, strings: u, keywords: g },
    };
  }
  function E2(e) {
    let t = e.regex,
      n = e.COMMENT("//", "$", { contains: [{ begin: /\\\n/ }] }),
      a = "decltype\\(auto\\)",
      r = "[a-zA-Z_]\\w*::",
      o = "<[^<>]+>",
      i =
        "(?!struct)(" +
        a +
        "|" +
        t.optional(r) +
        "[a-zA-Z_]\\w*" +
        t.optional(o) +
        ")",
      l = { className: "type", begin: "\\b[a-z\\d_]*_t\\b" },
      s = "\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)",
      u = {
        className: "string",
        variants: [
          {
            begin: '(u8?|U|L)?"',
            end: '"',
            illegal: "\\n",
            contains: [e.BACKSLASH_ESCAPE],
          },
          { begin: "(u8?|U|L)?'(" + s + "|.)", end: "'", illegal: "." },
          e.END_SAME_AS_BEGIN({
            begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
            end: /\)([^()\\ ]{0,16})"/,
          }),
        ],
      },
      c = {
        className: "number",
        variants: [
          { begin: "\\b(0b[01']+)" },
          {
            begin:
              "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)((ll|LL|l|L)(u|U)?|(u|U)(ll|LL|l|L)?|f|F|b|B)",
          },
          {
            begin:
              "(-?)(\\b0[xX][a-fA-F0-9']+|(\\b[\\d']+(\\.[\\d']*)?|\\.[\\d']+)([eE][-+]?[\\d']+)?)",
          },
        ],
        relevance: 0,
      },
      d = {
        className: "meta",
        begin: /#\s*[a-z]+\b/,
        end: /$/,
        keywords: {
          keyword:
            "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include",
        },
        contains: [
          { begin: /\\\n/, relevance: 0 },
          e.inherit(u, { className: "string" }),
          { className: "string", begin: /<.*?>/ },
          n,
          e.C_BLOCK_COMMENT_MODE,
        ],
      },
      p = {
        className: "title",
        begin: t.optional(r) + e.IDENT_RE,
        relevance: 0,
      },
      m = t.optional(r) + e.IDENT_RE + "\\s*\\(",
      f = [
        "alignas",
        "alignof",
        "and",
        "and_eq",
        "asm",
        "atomic_cancel",
        "atomic_commit",
        "atomic_noexcept",
        "auto",
        "bitand",
        "bitor",
        "break",
        "case",
        "catch",
        "class",
        "co_await",
        "co_return",
        "co_yield",
        "compl",
        "concept",
        "const_cast|10",
        "consteval",
        "constexpr",
        "constinit",
        "continue",
        "decltype",
        "default",
        "delete",
        "do",
        "dynamic_cast|10",
        "else",
        "enum",
        "explicit",
        "export",
        "extern",
        "false",
        "final",
        "for",
        "friend",
        "goto",
        "if",
        "import",
        "inline",
        "module",
        "mutable",
        "namespace",
        "new",
        "noexcept",
        "not",
        "not_eq",
        "nullptr",
        "operator",
        "or",
        "or_eq",
        "override",
        "private",
        "protected",
        "public",
        "reflexpr",
        "register",
        "reinterpret_cast|10",
        "requires",
        "return",
        "sizeof",
        "static_assert",
        "static_cast|10",
        "struct",
        "switch",
        "synchronized",
        "template",
        "this",
        "thread_local",
        "throw",
        "transaction_safe",
        "transaction_safe_dynamic",
        "true",
        "try",
        "typedef",
        "typeid",
        "typename",
        "union",
        "using",
        "virtual",
        "volatile",
        "while",
        "xor",
        "xor_eq",
      ],
      v = [
        "bool",
        "char",
        "char16_t",
        "char32_t",
        "char8_t",
        "double",
        "float",
        "int",
        "long",
        "short",
        "void",
        "wchar_t",
        "unsigned",
        "signed",
        "const",
        "static",
      ],
      g = [
        "any",
        "auto_ptr",
        "barrier",
        "binary_semaphore",
        "bitset",
        "complex",
        "condition_variable",
        "condition_variable_any",
        "counting_semaphore",
        "deque",
        "false_type",
        "future",
        "imaginary",
        "initializer_list",
        "istringstream",
        "jthread",
        "latch",
        "lock_guard",
        "multimap",
        "multiset",
        "mutex",
        "optional",
        "ostringstream",
        "packaged_task",
        "pair",
        "promise",
        "priority_queue",
        "queue",
        "recursive_mutex",
        "recursive_timed_mutex",
        "scoped_lock",
        "set",
        "shared_future",
        "shared_lock",
        "shared_mutex",
        "shared_timed_mutex",
        "shared_ptr",
        "stack",
        "string_view",
        "stringstream",
        "timed_mutex",
        "thread",
        "true_type",
        "tuple",
        "unique_lock",
        "unique_ptr",
        "unordered_map",
        "unordered_multimap",
        "unordered_multiset",
        "unordered_set",
        "variant",
        "vector",
        "weak_ptr",
        "wstring",
        "wstring_view",
      ],
      _ = [
        "abort",
        "abs",
        "acos",
        "apply",
        "as_const",
        "asin",
        "atan",
        "atan2",
        "calloc",
        "ceil",
        "cerr",
        "cin",
        "clog",
        "cos",
        "cosh",
        "cout",
        "declval",
        "endl",
        "exchange",
        "exit",
        "exp",
        "fabs",
        "floor",
        "fmod",
        "forward",
        "fprintf",
        "fputs",
        "free",
        "frexp",
        "fscanf",
        "future",
        "invoke",
        "isalnum",
        "isalpha",
        "iscntrl",
        "isdigit",
        "isgraph",
        "islower",
        "isprint",
        "ispunct",
        "isspace",
        "isupper",
        "isxdigit",
        "labs",
        "launder",
        "ldexp",
        "log",
        "log10",
        "make_pair",
        "make_shared",
        "make_shared_for_overwrite",
        "make_tuple",
        "make_unique",
        "malloc",
        "memchr",
        "memcmp",
        "memcpy",
        "memset",
        "modf",
        "move",
        "pow",
        "printf",
        "putchar",
        "puts",
        "realloc",
        "scanf",
        "sin",
        "sinh",
        "snprintf",
        "sprintf",
        "sqrt",
        "sscanf",
        "std",
        "stderr",
        "stdin",
        "stdout",
        "strcat",
        "strchr",
        "strcmp",
        "strcpy",
        "strcspn",
        "strlen",
        "strncat",
        "strncmp",
        "strncpy",
        "strpbrk",
        "strrchr",
        "strspn",
        "strstr",
        "swap",
        "tan",
        "tanh",
        "terminate",
        "to_underlying",
        "tolower",
        "toupper",
        "vfprintf",
        "visit",
        "vprintf",
        "vsprintf",
      ],
      w = {
        type: v,
        keyword: f,
        literal: ["NULL", "false", "nullopt", "nullptr", "true"],
        built_in: ["_Pragma"],
        _type_hints: g,
      },
      M = {
        className: "function.dispatch",
        relevance: 0,
        keywords: { _hint: _ },
        begin: t.concat(
          /\b/,
          /(?!decltype)/,
          /(?!if)/,
          /(?!for)/,
          /(?!switch)/,
          /(?!while)/,
          e.IDENT_RE,
          t.lookahead(/(<[^<>]+>|)\s*\(/)
        ),
      },
      E = [M, d, l, n, e.C_BLOCK_COMMENT_MODE, c, u],
      z = {
        variants: [
          { begin: /=/, end: /;/ },
          { begin: /\(/, end: /\)/ },
          { beginKeywords: "new throw return else", end: /;/ },
        ],
        keywords: w,
        contains: E.concat([
          {
            begin: /\(/,
            end: /\)/,
            keywords: w,
            contains: E.concat(["self"]),
            relevance: 0,
          },
        ]),
        relevance: 0,
      },
      k = {
        className: "function",
        begin: "(" + i + "[\\*&\\s]+)+" + m,
        returnBegin: !0,
        end: /[{;=]/,
        excludeEnd: !0,
        keywords: w,
        illegal: /[^\w\s\*&:<>.]/,
        contains: [
          { begin: a, keywords: w, relevance: 0 },
          { begin: m, returnBegin: !0, contains: [p], relevance: 0 },
          { begin: /::/, relevance: 0 },
          { begin: /:/, endsWithParent: !0, contains: [u, c] },
          { relevance: 0, match: /,/ },
          {
            className: "params",
            begin: /\(/,
            end: /\)/,
            keywords: w,
            relevance: 0,
            contains: [
              n,
              e.C_BLOCK_COMMENT_MODE,
              u,
              c,
              l,
              {
                begin: /\(/,
                end: /\)/,
                keywords: w,
                relevance: 0,
                contains: ["self", n, e.C_BLOCK_COMMENT_MODE, u, c, l],
              },
            ],
          },
          l,
          n,
          e.C_BLOCK_COMMENT_MODE,
          d,
        ],
      };
    return {
      name: "C++",
      aliases: ["cc", "c++", "h++", "hpp", "hh", "hxx", "cxx"],
      keywords: w,
      illegal: "</",
      classNameAliases: { "function.dispatch": "built_in" },
      contains: [].concat(z, k, M, E, [
        d,
        {
          begin:
            "\\b(deque|list|queue|priority_queue|pair|stack|vector|map|set|bitset|multiset|multimap|unordered_map|unordered_set|unordered_multiset|unordered_multimap|array|tuple|optional|variant|function)\\s*<(?!<)",
          end: ">",
          keywords: w,
          contains: ["self", l],
        },
        { begin: e.IDENT_RE + "::", keywords: w },
        {
          match: [
            /\b(?:enum(?:\s+(?:class|struct))?|class|struct|union)/,
            /\s+/,
            /\w+/,
          ],
          className: { 1: "keyword", 3: "title.class" },
        },
      ]),
    };
  }
  function y2(e) {
    let t = [
        "bool",
        "byte",
        "char",
        "decimal",
        "delegate",
        "double",
        "dynamic",
        "enum",
        "float",
        "int",
        "long",
        "nint",
        "nuint",
        "object",
        "sbyte",
        "short",
        "string",
        "ulong",
        "uint",
        "ushort",
      ],
      n = [
        "public",
        "private",
        "protected",
        "static",
        "internal",
        "protected",
        "abstract",
        "async",
        "extern",
        "override",
        "unsafe",
        "virtual",
        "new",
        "sealed",
        "partial",
      ],
      a = ["default", "false", "null", "true"],
      r = [
        "abstract",
        "as",
        "base",
        "break",
        "case",
        "catch",
        "class",
        "const",
        "continue",
        "do",
        "else",
        "event",
        "explicit",
        "extern",
        "finally",
        "fixed",
        "for",
        "foreach",
        "goto",
        "if",
        "implicit",
        "in",
        "interface",
        "internal",
        "is",
        "lock",
        "namespace",
        "new",
        "operator",
        "out",
        "override",
        "params",
        "private",
        "protected",
        "public",
        "readonly",
        "record",
        "ref",
        "return",
        "scoped",
        "sealed",
        "sizeof",
        "stackalloc",
        "static",
        "struct",
        "switch",
        "this",
        "throw",
        "try",
        "typeof",
        "unchecked",
        "unsafe",
        "using",
        "virtual",
        "void",
        "volatile",
        "while",
      ],
      o = [
        "add",
        "alias",
        "and",
        "ascending",
        "async",
        "await",
        "by",
        "descending",
        "equals",
        "from",
        "get",
        "global",
        "group",
        "init",
        "into",
        "join",
        "let",
        "nameof",
        "not",
        "notnull",
        "on",
        "or",
        "orderby",
        "partial",
        "remove",
        "select",
        "set",
        "unmanaged",
        "value|0",
        "var",
        "when",
        "where",
        "with",
        "yield",
      ],
      i = { keyword: r.concat(o), built_in: t, literal: a },
      l = e.inherit(e.TITLE_MODE, { begin: "[a-zA-Z](\\.?\\w)*" }),
      s = {
        className: "number",
        variants: [
          { begin: "\\b(0b[01']+)" },
          {
            begin:
              "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)(u|U|l|L|ul|UL|f|F|b|B)",
          },
          {
            begin:
              "(-?)(\\b0[xX][a-fA-F0-9']+|(\\b[\\d']+(\\.[\\d']*)?|\\.[\\d']+)([eE][-+]?[\\d']+)?)",
          },
        ],
        relevance: 0,
      },
      u = {
        className: "string",
        begin: '@"',
        end: '"',
        contains: [{ begin: '""' }],
      },
      c = e.inherit(u, { illegal: /\n/ }),
      d = { className: "subst", begin: /\{/, end: /\}/, keywords: i },
      p = e.inherit(d, { illegal: /\n/ }),
      m = {
        className: "string",
        begin: /\$"/,
        end: '"',
        illegal: /\n/,
        contains: [{ begin: /\{\{/ }, { begin: /\}\}/ }, e.BACKSLASH_ESCAPE, p],
      },
      f = {
        className: "string",
        begin: /\$@"/,
        end: '"',
        contains: [{ begin: /\{\{/ }, { begin: /\}\}/ }, { begin: '""' }, d],
      },
      v = e.inherit(f, {
        illegal: /\n/,
        contains: [{ begin: /\{\{/ }, { begin: /\}\}/ }, { begin: '""' }, p],
      });
    (d.contains = [
      f,
      m,
      u,
      e.APOS_STRING_MODE,
      e.QUOTE_STRING_MODE,
      s,
      e.C_BLOCK_COMMENT_MODE,
    ]),
      (p.contains = [
        v,
        m,
        c,
        e.APOS_STRING_MODE,
        e.QUOTE_STRING_MODE,
        s,
        e.inherit(e.C_BLOCK_COMMENT_MODE, { illegal: /\n/ }),
      ]);
    let g = { variants: [f, m, u, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE] },
      _ = { begin: "<", end: ">", contains: [{ beginKeywords: "in out" }, l] },
      C =
        e.IDENT_RE +
        "(<" +
        e.IDENT_RE +
        "(\\s*,\\s*" +
        e.IDENT_RE +
        ")*>)?(\\[\\])?",
      y = { begin: "@" + e.IDENT_RE, relevance: 0 };
    return {
      name: "C#",
      aliases: ["cs", "c#"],
      keywords: i,
      illegal: /::/,
      contains: [
        e.COMMENT("///", "$", {
          returnBegin: !0,
          contains: [
            {
              className: "doctag",
              variants: [
                { begin: "///", relevance: 0 },
                { begin: "<!--|-->" },
                { begin: "</?", end: ">" },
              ],
            },
          ],
        }),
        e.C_LINE_COMMENT_MODE,
        e.C_BLOCK_COMMENT_MODE,
        {
          className: "meta",
          begin: "#",
          end: "$",
          keywords: {
            keyword:
              "if else elif endif define undef warning error line region endregion pragma checksum",
          },
        },
        g,
        s,
        {
          beginKeywords: "class interface",
          relevance: 0,
          end: /[{;=]/,
          illegal: /[^\s:,]/,
          contains: [
            { beginKeywords: "where class" },
            l,
            _,
            e.C_LINE_COMMENT_MODE,
            e.C_BLOCK_COMMENT_MODE,
          ],
        },
        {
          beginKeywords: "namespace",
          relevance: 0,
          end: /[{;=]/,
          illegal: /[^\s:]/,
          contains: [l, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE],
        },
        {
          beginKeywords: "record",
          relevance: 0,
          end: /[{;=]/,
          illegal: /[^\s:]/,
          contains: [l, _, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE],
        },
        {
          className: "meta",
          begin: "^\\s*\\[(?=[\\w])",
          excludeBegin: !0,
          end: "\\]",
          excludeEnd: !0,
          contains: [{ className: "string", begin: /"/, end: /"/ }],
        },
        { beginKeywords: "new return throw await else", relevance: 0 },
        {
          className: "function",
          begin: "(" + C + "\\s+)+" + e.IDENT_RE + "\\s*(<[^=]+>\\s*)?\\(",
          returnBegin: !0,
          end: /\s*[{;=]/,
          excludeEnd: !0,
          keywords: i,
          contains: [
            { beginKeywords: n.join(" "), relevance: 0 },
            {
              begin: e.IDENT_RE + "\\s*(<[^=]+>\\s*)?\\(",
              returnBegin: !0,
              contains: [e.TITLE_MODE, _],
              relevance: 0,
            },
            { match: /\(\)/ },
            {
              className: "params",
              begin: /\(/,
              end: /\)/,
              excludeBegin: !0,
              excludeEnd: !0,
              keywords: i,
              relevance: 0,
              contains: [g, s, e.C_BLOCK_COMMENT_MODE],
            },
            e.C_LINE_COMMENT_MODE,
            e.C_BLOCK_COMMENT_MODE,
          ],
        },
        y,
      ],
    };
  }
  var y6 = (e) => ({
      IMPORTANT: { scope: "meta", begin: "!important" },
      BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
      HEXCOLOR: {
        scope: "number",
        begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/,
      },
      FUNCTION_DISPATCH: { className: "built_in", begin: /[\w-]+(?=\()/ },
      ATTRIBUTE_SELECTOR_MODE: {
        scope: "selector-attr",
        begin: /\[/,
        end: /\]/,
        illegal: "$",
        contains: [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE],
      },
      CSS_NUMBER_MODE: {
        scope: "number",
        begin:
          e.NUMBER_RE +
          "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
        relevance: 0,
      },
      CSS_VARIABLE: { className: "attr", begin: /--[A-Za-z][A-Za-z0-9_-]*/ },
    }),
    x6 = [
      "a",
      "abbr",
      "address",
      "article",
      "aside",
      "audio",
      "b",
      "blockquote",
      "body",
      "button",
      "canvas",
      "caption",
      "cite",
      "code",
      "dd",
      "del",
      "details",
      "dfn",
      "div",
      "dl",
      "dt",
      "em",
      "fieldset",
      "figcaption",
      "figure",
      "footer",
      "form",
      "h1",
      "h2",
      "h3",
      "h4",
      "h5",
      "h6",
      "header",
      "hgroup",
      "html",
      "i",
      "iframe",
      "img",
      "input",
      "ins",
      "kbd",
      "label",
      "legend",
      "li",
      "main",
      "mark",
      "menu",
      "nav",
      "object",
      "ol",
      "p",
      "q",
      "quote",
      "samp",
      "section",
      "span",
      "strong",
      "summary",
      "sup",
      "table",
      "tbody",
      "td",
      "textarea",
      "tfoot",
      "th",
      "thead",
      "time",
      "tr",
      "ul",
      "var",
      "video",
    ],
    w6 = [
      "any-hover",
      "any-pointer",
      "aspect-ratio",
      "color",
      "color-gamut",
      "color-index",
      "device-aspect-ratio",
      "device-height",
      "device-width",
      "display-mode",
      "forced-colors",
      "grid",
      "height",
      "hover",
      "inverted-colors",
      "monochrome",
      "orientation",
      "overflow-block",
      "overflow-inline",
      "pointer",
      "prefers-color-scheme",
      "prefers-contrast",
      "prefers-reduced-motion",
      "prefers-reduced-transparency",
      "resolution",
      "scan",
      "scripting",
      "update",
      "width",
      "min-width",
      "max-width",
      "min-height",
      "max-height",
    ],
    A6 = [
      "active",
      "any-link",
      "blank",
      "checked",
      "current",
      "default",
      "defined",
      "dir",
      "disabled",
      "drop",
      "empty",
      "enabled",
      "first",
      "first-child",
      "first-of-type",
      "fullscreen",
      "future",
      "focus",
      "focus-visible",
      "focus-within",
      "has",
      "host",
      "host-context",
      "hover",
      "indeterminate",
      "in-range",
      "invalid",
      "is",
      "lang",
      "last-child",
      "last-of-type",
      "left",
      "link",
      "local-link",
      "not",
      "nth-child",
      "nth-col",
      "nth-last-child",
      "nth-last-col",
      "nth-last-of-type",
      "nth-of-type",
      "only-child",
      "only-of-type",
      "optional",
      "out-of-range",
      "past",
      "placeholder-shown",
      "read-only",
      "read-write",
      "required",
      "right",
      "root",
      "scope",
      "target",
      "target-within",
      "user-invalid",
      "valid",
      "visited",
      "where",
    ],
    M6 = [
      "after",
      "backdrop",
      "before",
      "cue",
      "cue-region",
      "first-letter",
      "first-line",
      "grammar-error",
      "marker",
      "part",
      "placeholder",
      "selection",
      "slotted",
      "spelling-error",
    ],
    z6 = [
      "align-content",
      "align-items",
      "align-self",
      "all",
      "animation",
      "animation-delay",
      "animation-direction",
      "animation-duration",
      "animation-fill-mode",
      "animation-iteration-count",
      "animation-name",
      "animation-play-state",
      "animation-timing-function",
      "backface-visibility",
      "background",
      "background-attachment",
      "background-blend-mode",
      "background-clip",
      "background-color",
      "background-image",
      "background-origin",
      "background-position",
      "background-repeat",
      "background-size",
      "block-size",
      "border",
      "border-block",
      "border-block-color",
      "border-block-end",
      "border-block-end-color",
      "border-block-end-style",
      "border-block-end-width",
      "border-block-start",
      "border-block-start-color",
      "border-block-start-style",
      "border-block-start-width",
      "border-block-style",
      "border-block-width",
      "border-bottom",
      "border-bottom-color",
      "border-bottom-left-radius",
      "border-bottom-right-radius",
      "border-bottom-style",
      "border-bottom-width",
      "border-collapse",
      "border-color",
      "border-image",
      "border-image-outset",
      "border-image-repeat",
      "border-image-slice",
      "border-image-source",
      "border-image-width",
      "border-inline",
      "border-inline-color",
      "border-inline-end",
      "border-inline-end-color",
      "border-inline-end-style",
      "border-inline-end-width",
      "border-inline-start",
      "border-inline-start-color",
      "border-inline-start-style",
      "border-inline-start-width",
      "border-inline-style",
      "border-inline-width",
      "border-left",
      "border-left-color",
      "border-left-style",
      "border-left-width",
      "border-radius",
      "border-right",
      "border-right-color",
      "border-right-style",
      "border-right-width",
      "border-spacing",
      "border-style",
      "border-top",
      "border-top-color",
      "border-top-left-radius",
      "border-top-right-radius",
      "border-top-style",
      "border-top-width",
      "border-width",
      "bottom",
      "box-decoration-break",
      "box-shadow",
      "box-sizing",
      "break-after",
      "break-before",
      "break-inside",
      "caption-side",
      "caret-color",
      "clear",
      "clip",
      "clip-path",
      "clip-rule",
      "color",
      "column-count",
      "column-fill",
      "column-gap",
      "column-rule",
      "column-rule-color",
      "column-rule-style",
      "column-rule-width",
      "column-span",
      "column-width",
      "columns",
      "contain",
      "content",
      "content-visibility",
      "counter-increment",
      "counter-reset",
      "cue",
      "cue-after",
      "cue-before",
      "cursor",
      "direction",
      "display",
      "empty-cells",
      "filter",
      "flex",
      "flex-basis",
      "flex-direction",
      "flex-flow",
      "flex-grow",
      "flex-shrink",
      "flex-wrap",
      "float",
      "flow",
      "font",
      "font-display",
      "font-family",
      "font-feature-settings",
      "font-kerning",
      "font-language-override",
      "font-size",
      "font-size-adjust",
      "font-smoothing",
      "font-stretch",
      "font-style",
      "font-synthesis",
      "font-variant",
      "font-variant-caps",
      "font-variant-east-asian",
      "font-variant-ligatures",
      "font-variant-numeric",
      "font-variant-position",
      "font-variation-settings",
      "font-weight",
      "gap",
      "glyph-orientation-vertical",
      "grid",
      "grid-area",
      "grid-auto-columns",
      "grid-auto-flow",
      "grid-auto-rows",
      "grid-column",
      "grid-column-end",
      "grid-column-start",
      "grid-gap",
      "grid-row",
      "grid-row-end",
      "grid-row-start",
      "grid-template",
      "grid-template-areas",
      "grid-template-columns",
      "grid-template-rows",
      "hanging-punctuation",
      "height",
      "hyphens",
      "icon",
      "image-orientation",
      "image-rendering",
      "image-resolution",
      "ime-mode",
      "inline-size",
      "isolation",
      "justify-content",
      "left",
      "letter-spacing",
      "line-break",
      "line-height",
      "list-style",
      "list-style-image",
      "list-style-position",
      "list-style-type",
      "margin",
      "margin-block",
      "margin-block-end",
      "margin-block-start",
      "margin-bottom",
      "margin-inline",
      "margin-inline-end",
      "margin-inline-start",
      "margin-left",
      "margin-right",
      "margin-top",
      "marks",
      "mask",
      "mask-border",
      "mask-border-mode",
      "mask-border-outset",
      "mask-border-repeat",
      "mask-border-slice",
      "mask-border-source",
      "mask-border-width",
      "mask-clip",
      "mask-composite",
      "mask-image",
      "mask-mode",
      "mask-origin",
      "mask-position",
      "mask-repeat",
      "mask-size",
      "mask-type",
      "max-block-size",
      "max-height",
      "max-inline-size",
      "max-width",
      "min-block-size",
      "min-height",
      "min-inline-size",
      "min-width",
      "mix-blend-mode",
      "nav-down",
      "nav-index",
      "nav-left",
      "nav-right",
      "nav-up",
      "none",
      "normal",
      "object-fit",
      "object-position",
      "opacity",
      "order",
      "orphans",
      "outline",
      "outline-color",
      "outline-offset",
      "outline-style",
      "outline-width",
      "overflow",
      "overflow-wrap",
      "overflow-x",
      "overflow-y",
      "padding",
      "padding-block",
      "padding-block-end",
      "padding-block-start",
      "padding-bottom",
      "padding-inline",
      "padding-inline-end",
      "padding-inline-start",
      "padding-left",
      "padding-right",
      "padding-top",
      "page-break-after",
      "page-break-before",
      "page-break-inside",
      "pause",
      "pause-after",
      "pause-before",
      "perspective",
      "perspective-origin",
      "pointer-events",
      "position",
      "quotes",
      "resize",
      "rest",
      "rest-after",
      "rest-before",
      "right",
      "row-gap",
      "scroll-margin",
      "scroll-margin-block",
      "scroll-margin-block-end",
      "scroll-margin-block-start",
      "scroll-margin-bottom",
      "scroll-margin-inline",
      "scroll-margin-inline-end",
      "scroll-margin-inline-start",
      "scroll-margin-left",
      "scroll-margin-right",
      "scroll-margin-top",
      "scroll-padding",
      "scroll-padding-block",
      "scroll-padding-block-end",
      "scroll-padding-block-start",
      "scroll-padding-bottom",
      "scroll-padding-inline",
      "scroll-padding-inline-end",
      "scroll-padding-inline-start",
      "scroll-padding-left",
      "scroll-padding-right",
      "scroll-padding-top",
      "scroll-snap-align",
      "scroll-snap-stop",
      "scroll-snap-type",
      "scrollbar-color",
      "scrollbar-gutter",
      "scrollbar-width",
      "shape-image-threshold",
      "shape-margin",
      "shape-outside",
      "speak",
      "speak-as",
      "src",
      "tab-size",
      "table-layout",
      "text-align",
      "text-align-all",
      "text-align-last",
      "text-combine-upright",
      "text-decoration",
      "text-decoration-color",
      "text-decoration-line",
      "text-decoration-style",
      "text-emphasis",
      "text-emphasis-color",
      "text-emphasis-position",
      "text-emphasis-style",
      "text-indent",
      "text-justify",
      "text-orientation",
      "text-overflow",
      "text-rendering",
      "text-shadow",
      "text-transform",
      "text-underline-position",
      "top",
      "transform",
      "transform-box",
      "transform-origin",
      "transform-style",
      "transition",
      "transition-delay",
      "transition-duration",
      "transition-property",
      "transition-timing-function",
      "unicode-bidi",
      "vertical-align",
      "visibility",
      "voice-balance",
      "voice-duration",
      "voice-family",
      "voice-pitch",
      "voice-range",
      "voice-rate",
      "voice-stress",
      "voice-volume",
      "white-space",
      "widows",
      "width",
      "will-change",
      "word-break",
      "word-spacing",
      "word-wrap",
      "writing-mode",
      "z-index",
    ].reverse();
  function x2(e) {
    let t = e.regex,
      n = y6(e),
      a = { begin: /-(webkit|moz|ms|o)-(?=[a-z])/ },
      r = "and or not only",
      o = /@-?\w[\w]*(-\w+)*/,
      i = "[a-zA-Z-][a-zA-Z0-9_-]*",
      l = [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE];
    return {
      name: "CSS",
      case_insensitive: !0,
      illegal: /[=|'\$]/,
      keywords: { keyframePosition: "from to" },
      classNameAliases: { keyframePosition: "selector-tag" },
      contains: [
        n.BLOCK_COMMENT,
        a,
        n.CSS_NUMBER_MODE,
        { className: "selector-id", begin: /#[A-Za-z0-9_-]+/, relevance: 0 },
        { className: "selector-class", begin: "\\." + i, relevance: 0 },
        n.ATTRIBUTE_SELECTOR_MODE,
        {
          className: "selector-pseudo",
          variants: [
            { begin: ":(" + A6.join("|") + ")" },
            { begin: ":(:)?(" + M6.join("|") + ")" },
          ],
        },
        n.CSS_VARIABLE,
        { className: "attribute", begin: "\\b(" + z6.join("|") + ")\\b" },
        {
          begin: /:/,
          end: /[;}{]/,
          contains: [
            n.BLOCK_COMMENT,
            n.HEXCOLOR,
            n.IMPORTANT,
            n.CSS_NUMBER_MODE,
            ...l,
            {
              begin: /(url|data-uri)\(/,
              end: /\)/,
              relevance: 0,
              keywords: { built_in: "url data-uri" },
              contains: [
                ...l,
                {
                  className: "string",
                  begin: /[^)]/,
                  endsWithParent: !0,
                  excludeEnd: !0,
                },
              ],
            },
            n.FUNCTION_DISPATCH,
          ],
        },
        {
          begin: t.lookahead(/@/),
          end: "[{;]",
          relevance: 0,
          illegal: /:/,
          contains: [
            { className: "keyword", begin: o },
            {
              begin: /\s/,
              endsWithParent: !0,
              excludeEnd: !0,
              relevance: 0,
              keywords: {
                $pattern: /[a-z-]+/,
                keyword: r,
                attribute: w6.join(" "),
              },
              contains: [
                { begin: /[a-z-]+(?=:)/, className: "attribute" },
                ...l,
                n.CSS_NUMBER_MODE,
              ],
            },
          ],
        },
        { className: "selector-tag", begin: "\\b(" + x6.join("|") + ")\\b" },
      ],
    };
  }
  function w2(e) {
    let t = e.regex;
    return {
      name: "Diff",
      aliases: ["patch"],
      contains: [
        {
          className: "meta",
          relevance: 10,
          match: t.either(
            /^@@ +-\d+,\d+ +\+\d+,\d+ +@@/,
            /^\*\*\* +\d+,\d+ +\*\*\*\*$/,
            /^--- +\d+,\d+ +----$/
          ),
        },
        {
          className: "comment",
          variants: [
            {
              begin: t.either(
                /Index: /,
                /^index/,
                /={3,}/,
                /^-{3}/,
                /^\*{3} /,
                /^\+{3}/,
                /^diff --git/
              ),
              end: /$/,
            },
            { match: /^\*{15}$/ },
          ],
        },
        { className: "addition", begin: /^\+/, end: /$/ },
        { className: "deletion", begin: /^-/, end: /$/ },
        { className: "addition", begin: /^!/, end: /$/ },
      ],
    };
  }
  function A2(e) {
    let o = {
      keyword: [
        "break",
        "case",
        "chan",
        "const",
        "continue",
        "default",
        "defer",
        "else",
        "fallthrough",
        "for",
        "func",
        "go",
        "goto",
        "if",
        "import",
        "interface",
        "map",
        "package",
        "range",
        "return",
        "select",
        "struct",
        "switch",
        "type",
        "var",
      ],
      type: [
        "bool",
        "byte",
        "complex64",
        "complex128",
        "error",
        "float32",
        "float64",
        "int8",
        "int16",
        "int32",
        "int64",
        "string",
        "uint8",
        "uint16",
        "uint32",
        "uint64",
        "int",
        "uint",
        "uintptr",
        "rune",
      ],
      literal: ["true", "false", "iota", "nil"],
      built_in: [
        "append",
        "cap",
        "close",
        "complex",
        "copy",
        "imag",
        "len",
        "make",
        "new",
        "panic",
        "print",
        "println",
        "real",
        "recover",
        "delete",
      ],
    };
    return {
      name: "Go",
      aliases: ["golang"],
      keywords: o,
      illegal: "</",
      contains: [
        e.C_LINE_COMMENT_MODE,
        e.C_BLOCK_COMMENT_MODE,
        {
          className: "string",
          variants: [
            e.QUOTE_STRING_MODE,
            e.APOS_STRING_MODE,
            { begin: "`", end: "`" },
          ],
        },
        {
          className: "number",
          variants: [
            { begin: e.C_NUMBER_RE + "[i]", relevance: 1 },
            e.C_NUMBER_MODE,
          ],
        },
        { begin: /:=/ },
        {
          className: "function",
          beginKeywords: "func",
          end: "\\s*(\\{|$)",
          excludeEnd: !0,
          contains: [
            e.TITLE_MODE,
            {
              className: "params",
              begin: /\(/,
              end: /\)/,
              endsParent: !0,
              keywords: o,
              illegal: /["']/,
            },
          ],
        },
      ],
    };
  }
  function M2(e) {
    let t = e.regex,
      n = /[_A-Za-z][_0-9A-Za-z]*/;
    return {
      name: "GraphQL",
      aliases: ["gql"],
      case_insensitive: !0,
      disableAutodetect: !1,
      keywords: {
        keyword: [
          "query",
          "mutation",
          "subscription",
          "type",
          "input",
          "schema",
          "directive",
          "interface",
          "union",
          "scalar",
          "fragment",
          "enum",
          "on",
        ],
        literal: ["true", "false", "null"],
      },
      contains: [
        e.HASH_COMMENT_MODE,
        e.QUOTE_STRING_MODE,
        e.NUMBER_MODE,
        { scope: "punctuation", match: /[.]{3}/, relevance: 0 },
        {
          scope: "punctuation",
          begin: /[\!\(\)\:\=\[\]\{\|\}]{1}/,
          relevance: 0,
        },
        {
          scope: "variable",
          begin: /\$/,
          end: /\W/,
          excludeEnd: !0,
          relevance: 0,
        },
        { scope: "meta", match: /@\w+/, excludeEnd: !0 },
        {
          scope: "symbol",
          begin: t.concat(n, t.lookahead(/\s*:/)),
          relevance: 0,
        },
      ],
      illegal: [/[;<']/, /BEGIN/],
    };
  }
  function z2(e) {
    let t = e.regex,
      n = {
        className: "number",
        relevance: 0,
        variants: [{ begin: /([+-]+)?[\d]+_[\d_]+/ }, { begin: e.NUMBER_RE }],
      },
      a = e.COMMENT();
    a.variants = [
      { begin: /;/, end: /$/ },
      { begin: /#/, end: /$/ },
    ];
    let r = {
        className: "variable",
        variants: [{ begin: /\$[\w\d"][\w\d_]*/ }, { begin: /\$\{(.*?)\}/ }],
      },
      o = { className: "literal", begin: /\bon|off|true|false|yes|no\b/ },
      i = {
        className: "string",
        contains: [e.BACKSLASH_ESCAPE],
        variants: [
          { begin: "'''", end: "'''", relevance: 10 },
          { begin: '"""', end: '"""', relevance: 10 },
          { begin: '"', end: '"' },
          { begin: "'", end: "'" },
        ],
      },
      l = {
        begin: /\[/,
        end: /\]/,
        contains: [a, o, r, i, n, "self"],
        relevance: 0,
      },
      s = /[A-Za-z0-9_-]+/,
      u = /"(\\"|[^"])*"/,
      c = /'[^']*'/,
      d = t.either(s, u, c),
      p = t.concat(d, "(\\s*\\.\\s*", d, ")*", t.lookahead(/\s*=\s*[^#\s]/));
    return {
      name: "TOML, also INI",
      aliases: ["toml"],
      case_insensitive: !0,
      illegal: /\S/,
      contains: [
        a,
        { className: "section", begin: /\[+/, end: /\]+/ },
        {
          begin: p,
          className: "attr",
          starts: { end: /$/, contains: [a, l, o, r, i, n] },
        },
      ],
    };
  }
  var l5 = "[0-9](_*[0-9])*",
    U1 = `\\.(${l5})`,
    G1 = "[0-9a-fA-F](_*[0-9a-fA-F])*",
    S2 = {
      className: "number",
      variants: [
        {
          begin: `(\\b(${l5})((${U1})|\\.)?|(${U1}))[eE][+-]?(${l5})[fFdD]?\\b`,
        },
        { begin: `\\b(${l5})((${U1})[fFdD]?\\b|\\.([fFdD]\\b)?)` },
        { begin: `(${U1})[fFdD]?\\b` },
        { begin: `\\b(${l5})[fFdD]\\b` },
        {
          begin: `\\b0[xX]((${G1})\\.?|(${G1})?\\.(${G1}))[pP][+-]?(${l5})[fFdD]?\\b`,
        },
        { begin: "\\b(0|[1-9](_*[0-9])*)[lL]?\\b" },
        { begin: `\\b0[xX](${G1})[lL]?\\b` },
        { begin: "\\b0(_*[0-7])*[lL]?\\b" },
        { begin: "\\b0[bB][01](_*[01])*[lL]?\\b" },
      ],
      relevance: 0,
    };
  function C2(e, t, n) {
    return n === -1 ? "" : e.replace(t, (a) => C2(e, t, n - 1));
  }
  function k2(e) {
    let t = e.regex,
      n = "[\xC0-\u02B8a-zA-Z_$][\xC0-\u02B8a-zA-Z_$0-9]*",
      a = n + C2("(?:<" + n + "~~~(?:\\s*,\\s*" + n + "~~~)*>)?", /~~~/g, 2),
      s = {
        keyword: [
          "synchronized",
          "abstract",
          "private",
          "var",
          "static",
          "if",
          "const ",
          "for",
          "while",
          "strictfp",
          "finally",
          "protected",
          "import",
          "native",
          "final",
          "void",
          "enum",
          "else",
          "break",
          "transient",
          "catch",
          "instanceof",
          "volatile",
          "case",
          "assert",
          "package",
          "default",
          "public",
          "try",
          "switch",
          "continue",
          "throws",
          "protected",
          "public",
          "private",
          "module",
          "requires",
          "exports",
          "do",
          "sealed",
          "yield",
          "permits",
        ],
        literal: ["false", "true", "null"],
        type: [
          "char",
          "boolean",
          "long",
          "float",
          "int",
          "byte",
          "short",
          "double",
        ],
        built_in: ["super", "this"],
      },
      u = {
        className: "meta",
        begin: "@" + n,
        contains: [{ begin: /\(/, end: /\)/, contains: ["self"] }],
      },
      c = {
        className: "params",
        begin: /\(/,
        end: /\)/,
        keywords: s,
        relevance: 0,
        contains: [e.C_BLOCK_COMMENT_MODE],
        endsParent: !0,
      };
    return {
      name: "Java",
      aliases: ["jsp"],
      keywords: s,
      illegal: /<\/|#/,
      contains: [
        e.COMMENT("/\\*\\*", "\\*/", {
          relevance: 0,
          contains: [
            { begin: /\w+@/, relevance: 0 },
            { className: "doctag", begin: "@[A-Za-z]+" },
          ],
        }),
        { begin: /import java\.[a-z]+\./, keywords: "import", relevance: 2 },
        e.C_LINE_COMMENT_MODE,
        e.C_BLOCK_COMMENT_MODE,
        {
          begin: /"""/,
          end: /"""/,
          className: "string",
          contains: [e.BACKSLASH_ESCAPE],
        },
        e.APOS_STRING_MODE,
        e.QUOTE_STRING_MODE,
        {
          match: [
            /\b(?:class|interface|enum|extends|implements|new)/,
            /\s+/,
            n,
          ],
          className: { 1: "keyword", 3: "title.class" },
        },
        { match: /non-sealed/, scope: "keyword" },
        {
          begin: [t.concat(/(?!else)/, n), /\s+/, n, /\s+/, /=(?!=)/],
          className: { 1: "type", 3: "variable", 5: "operator" },
        },
        {
          begin: [/record/, /\s+/, n],
          className: { 1: "keyword", 3: "title.class" },
          contains: [c, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE],
        },
        { beginKeywords: "new throw return else", relevance: 0 },
        {
          begin: ["(?:" + a + "\\s+)", e.UNDERSCORE_IDENT_RE, /\s*(?=\()/],
          className: { 2: "title.function" },
          keywords: s,
          contains: [
            {
              className: "params",
              begin: /\(/,
              end: /\)/,
              keywords: s,
              relevance: 0,
              contains: [
                u,
                e.APOS_STRING_MODE,
                e.QUOTE_STRING_MODE,
                S2,
                e.C_BLOCK_COMMENT_MODE,
              ],
            },
            e.C_LINE_COMMENT_MODE,
            e.C_BLOCK_COMMENT_MODE,
          ],
        },
        S2,
        u,
      ],
    };
  }
  var R2 = "[A-Za-z$_][0-9A-Za-z$_]*",
    S6 = [
      "as",
      "in",
      "of",
      "if",
      "for",
      "while",
      "finally",
      "var",
      "new",
      "function",
      "do",
      "return",
      "void",
      "else",
      "break",
      "catch",
      "instanceof",
      "with",
      "throw",
      "case",
      "default",
      "try",
      "switch",
      "continue",
      "typeof",
      "delete",
      "let",
      "yield",
      "const",
      "class",
      "debugger",
      "async",
      "await",
      "static",
      "import",
      "from",
      "export",
      "extends",
    ],
    C6 = ["true", "false", "null", "undefined", "NaN", "Infinity"],
    I2 = [
      "Object",
      "Function",
      "Boolean",
      "Symbol",
      "Math",
      "Date",
      "Number",
      "BigInt",
      "String",
      "RegExp",
      "Array",
      "Float32Array",
      "Float64Array",
      "Int8Array",
      "Uint8Array",
      "Uint8ClampedArray",
      "Int16Array",
      "Int32Array",
      "Uint16Array",
      "Uint32Array",
      "BigInt64Array",
      "BigUint64Array",
      "Set",
      "Map",
      "WeakSet",
      "WeakMap",
      "ArrayBuffer",
      "SharedArrayBuffer",
      "Atomics",
      "DataView",
      "JSON",
      "Promise",
      "Generator",
      "GeneratorFunction",
      "AsyncFunction",
      "Reflect",
      "Proxy",
      "Intl",
      "WebAssembly",
    ],
    T2 = [
      "Error",
      "EvalError",
      "InternalError",
      "RangeError",
      "ReferenceError",
      "SyntaxError",
      "TypeError",
      "URIError",
    ],
    N2 = [
      "setInterval",
      "setTimeout",
      "clearInterval",
      "clearTimeout",
      "require",
      "exports",
      "eval",
      "isFinite",
      "isNaN",
      "parseFloat",
      "parseInt",
      "decodeURI",
      "decodeURIComponent",
      "encodeURI",
      "encodeURIComponent",
      "escape",
      "unescape",
    ],
    k6 = [
      "arguments",
      "this",
      "super",
      "console",
      "window",
      "document",
      "localStorage",
      "module",
      "global",
    ],
    R6 = [].concat(N2, I2, T2);
  function L2(e) {
    let t = e.regex,
      n = (T, { after: P }) => {
        let B = "</" + T[0].slice(1);
        return T.input.indexOf(B, P) !== -1;
      },
      a = R2,
      r = { begin: "<>", end: "</>" },
      o = /<[A-Za-z0-9\\._:-]+\s*\/>/,
      i = {
        begin: /<[A-Za-z0-9\\._:-]+/,
        end: /\/[A-Za-z0-9\\._:-]+>|\/>/,
        isTrulyOpeningTag: (T, P) => {
          let B = T[0].length + T.index,
            $ = T.input[B];
          if ($ === "<" || $ === ",") {
            P.ignoreMatch();
            return;
          }
          $ === ">" && (n(T, { after: B }) || P.ignoreMatch());
          let b,
            h = T.input.substring(B);
          if ((b = h.match(/^\s*=/))) {
            P.ignoreMatch();
            return;
          }
          if ((b = h.match(/^\s+extends\s+/)) && b.index === 0) {
            P.ignoreMatch();
            return;
          }
        },
      },
      l = {
        $pattern: R2,
        keyword: S6,
        literal: C6,
        built_in: R6,
        "variable.language": k6,
      },
      s = "[0-9](_?[0-9])*",
      u = `\\.(${s})`,
      c = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*",
      d = {
        className: "number",
        variants: [
          { begin: `(\\b(${c})((${u})|\\.)?|(${u}))[eE][+-]?(${s})\\b` },
          { begin: `\\b(${c})\\b((${u})\\b|\\.)?|(${u})\\b` },
          { begin: "\\b(0|[1-9](_?[0-9])*)n\\b" },
          { begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b" },
          { begin: "\\b0[bB][0-1](_?[0-1])*n?\\b" },
          { begin: "\\b0[oO][0-7](_?[0-7])*n?\\b" },
          { begin: "\\b0[0-7]+n?\\b" },
        ],
        relevance: 0,
      },
      p = {
        className: "subst",
        begin: "\\$\\{",
        end: "\\}",
        keywords: l,
        contains: [],
      },
      m = {
        begin: "html`",
        end: "",
        starts: {
          end: "`",
          returnEnd: !1,
          contains: [e.BACKSLASH_ESCAPE, p],
          subLanguage: "xml",
        },
      },
      f = {
        begin: "css`",
        end: "",
        starts: {
          end: "`",
          returnEnd: !1,
          contains: [e.BACKSLASH_ESCAPE, p],
          subLanguage: "css",
        },
      },
      v = {
        className: "string",
        begin: "`",
        end: "`",
        contains: [e.BACKSLASH_ESCAPE, p],
      },
      _ = {
        className: "comment",
        variants: [
          e.COMMENT(/\/\*\*(?!\/)/, "\\*/", {
            relevance: 0,
            contains: [
              {
                begin: "(?=@[A-Za-z]+)",
                relevance: 0,
                contains: [
                  { className: "doctag", begin: "@[A-Za-z]+" },
                  {
                    className: "type",
                    begin: "\\{",
                    end: "\\}",
                    excludeEnd: !0,
                    excludeBegin: !0,
                    relevance: 0,
                  },
                  {
                    className: "variable",
                    begin: a + "(?=\\s*(-)|$)",
                    endsParent: !0,
                    relevance: 0,
                  },
                  { begin: /(?=[^\n])\s/, relevance: 0 },
                ],
              },
            ],
          }),
          e.C_BLOCK_COMMENT_MODE,
          e.C_LINE_COMMENT_MODE,
        ],
      },
      C = [
        e.APOS_STRING_MODE,
        e.QUOTE_STRING_MODE,
        m,
        f,
        v,
        { match: /\$\d+/ },
        d,
      ];
    p.contains = C.concat({
      begin: /\{/,
      end: /\}/,
      keywords: l,
      contains: ["self"].concat(C),
    });
    let y = [].concat(_, p.contains),
      w = y.concat([
        { begin: /\(/, end: /\)/, keywords: l, contains: ["self"].concat(y) },
      ]),
      M = {
        className: "params",
        begin: /\(/,
        end: /\)/,
        excludeBegin: !0,
        excludeEnd: !0,
        keywords: l,
        contains: w,
      },
      E = {
        variants: [
          {
            match: [
              /class/,
              /\s+/,
              a,
              /\s+/,
              /extends/,
              /\s+/,
              t.concat(a, "(", t.concat(/\./, a), ")*"),
            ],
            scope: {
              1: "keyword",
              3: "title.class",
              5: "keyword",
              7: "title.class.inherited",
            },
          },
          {
            match: [/class/, /\s+/, a],
            scope: { 1: "keyword", 3: "title.class" },
          },
        ],
      },
      z = {
        relevance: 0,
        match: t.either(
          /\bJSON/,
          /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/,
          /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/,
          /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/
        ),
        className: "title.class",
        keywords: { _: [...I2, ...T2] },
      },
      k = {
        label: "use_strict",
        className: "meta",
        relevance: 10,
        begin: /^\s*['"]use (strict|asm)['"]/,
      },
      O = {
        variants: [
          { match: [/function/, /\s+/, a, /(?=\s*\()/] },
          { match: [/function/, /\s*(?=\()/] },
        ],
        className: { 1: "keyword", 3: "title.function" },
        label: "func.def",
        contains: [M],
        illegal: /%/,
      },
      K = {
        relevance: 0,
        match: /\b[A-Z][A-Z_0-9]+\b/,
        className: "variable.constant",
      };
    function H(T) {
      return t.concat("(?!", T.join("|"), ")");
    }
    let V = {
        match: t.concat(
          /\b/,
          H([...N2, "super", "import"]),
          a,
          t.lookahead(/\(/)
        ),
        className: "title.function",
        relevance: 0,
      },
      I = {
        begin: t.concat(/\./, t.lookahead(t.concat(a, /(?![0-9A-Za-z$_(])/))),
        end: a,
        excludeBegin: !0,
        keywords: "prototype",
        className: "property",
        relevance: 0,
      },
      D = {
        match: [/get|set/, /\s+/, a, /(?=\()/],
        className: { 1: "keyword", 3: "title.function" },
        contains: [{ begin: /\(\)/ }, M],
      },
      J =
        "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" +
        e.UNDERSCORE_IDENT_RE +
        ")\\s*=>",
      R = {
        match: [
          /const|var|let/,
          /\s+/,
          a,
          /\s*/,
          /=\s*/,
          /(async\s*)?/,
          t.lookahead(J),
        ],
        keywords: "async",
        className: { 1: "keyword", 3: "title.function" },
        contains: [M],
      };
    return {
      name: "Javascript",
      aliases: ["js", "jsx", "mjs", "cjs"],
      keywords: l,
      exports: { PARAMS_CONTAINS: w, CLASS_REFERENCE: z },
      illegal: /#(?![$_A-z])/,
      contains: [
        e.SHEBANG({ label: "shebang", binary: "node", relevance: 5 }),
        k,
        e.APOS_STRING_MODE,
        e.QUOTE_STRING_MODE,
        m,
        f,
        v,
        _,
        { match: /\$\d+/ },
        d,
        z,
        { className: "attr", begin: a + t.lookahead(":"), relevance: 0 },
        R,
        {
          begin: "(" + e.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
          keywords: "return throw case",
          relevance: 0,
          contains: [
            _,
            e.REGEXP_MODE,
            {
              className: "function",
              begin: J,
              returnBegin: !0,
              end: "\\s*=>",
              contains: [
                {
                  className: "params",
                  variants: [
                    { begin: e.UNDERSCORE_IDENT_RE, relevance: 0 },
                    { className: null, begin: /\(\s*\)/, skip: !0 },
                    {
                      begin: /\(/,
                      end: /\)/,
                      excludeBegin: !0,
                      excludeEnd: !0,
                      keywords: l,
                      contains: w,
                    },
                  ],
                },
              ],
            },
            { begin: /,/, relevance: 0 },
            { match: /\s+/, relevance: 0 },
            {
              variants: [
                { begin: r.begin, end: r.end },
                { match: o },
                { begin: i.begin, "on:begin": i.isTrulyOpeningTag, end: i.end },
              ],
              subLanguage: "xml",
              contains: [
                { begin: i.begin, end: i.end, skip: !0, contains: ["self"] },
              ],
            },
          ],
        },
        O,
        { beginKeywords: "while if switch catch for" },
        {
          begin:
            "\\b(?!function)" +
            e.UNDERSCORE_IDENT_RE +
            "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
          returnBegin: !0,
          label: "func.def",
          contains: [
            M,
            e.inherit(e.TITLE_MODE, { begin: a, className: "title.function" }),
          ],
        },
        { match: /\.\.\./, relevance: 0 },
        I,
        { match: "\\$" + a, relevance: 0 },
        {
          match: [/\bconstructor(?=\s*\()/],
          className: { 1: "title.function" },
          contains: [M],
        },
        V,
        K,
        E,
        D,
        { match: /\$[(.]/ },
      ],
    };
  }
  function O2(e) {
    let t = {
        className: "attr",
        begin: /"(\\.|[^\\"\r\n])*"(?=\s*:)/,
        relevance: 1.01,
      },
      n = { match: /[{}[\],:]/, className: "punctuation", relevance: 0 },
      a = ["true", "false", "null"],
      r = { scope: "literal", beginKeywords: a.join(" ") };
    return {
      name: "JSON",
      keywords: { literal: a },
      contains: [
        t,
        n,
        e.QUOTE_STRING_MODE,
        r,
        e.C_NUMBER_MODE,
        e.C_LINE_COMMENT_MODE,
        e.C_BLOCK_COMMENT_MODE,
      ],
      illegal: "\\S",
    };
  }
  var c5 = "[0-9](_*[0-9])*",
    $1 = `\\.(${c5})`,
    q1 = "[0-9a-fA-F](_*[0-9a-fA-F])*",
    I6 = {
      className: "number",
      variants: [
        {
          begin: `(\\b(${c5})((${$1})|\\.)?|(${$1}))[eE][+-]?(${c5})[fFdD]?\\b`,
        },
        { begin: `\\b(${c5})((${$1})[fFdD]?\\b|\\.([fFdD]\\b)?)` },
        { begin: `(${$1})[fFdD]?\\b` },
        { begin: `\\b(${c5})[fFdD]\\b` },
        {
          begin: `\\b0[xX]((${q1})\\.?|(${q1})?\\.(${q1}))[pP][+-]?(${c5})[fFdD]?\\b`,
        },
        { begin: "\\b(0|[1-9](_*[0-9])*)[lL]?\\b" },
        { begin: `\\b0[xX](${q1})[lL]?\\b` },
        { begin: "\\b0(_*[0-7])*[lL]?\\b" },
        { begin: "\\b0[bB][01](_*[01])*[lL]?\\b" },
      ],
      relevance: 0,
    };
  function H2(e) {
    let t = {
        keyword:
          "abstract as val var vararg get set class object open private protected public noinline crossinline dynamic final enum if else do while for when throw try catch finally import package is in fun override companion reified inline lateinit init interface annotation data sealed internal infix operator out by constructor super tailrec where const inner suspend typealias external expect actual",
        built_in:
          "Byte Short Char Int Long Boolean Float Double Void Unit Nothing",
        literal: "true false null",
      },
      n = {
        className: "keyword",
        begin: /\b(break|continue|return|this)\b/,
        starts: { contains: [{ className: "symbol", begin: /@\w+/ }] },
      },
      a = { className: "symbol", begin: e.UNDERSCORE_IDENT_RE + "@" },
      r = {
        className: "subst",
        begin: /\$\{/,
        end: /\}/,
        contains: [e.C_NUMBER_MODE],
      },
      o = { className: "variable", begin: "\\$" + e.UNDERSCORE_IDENT_RE },
      i = {
        className: "string",
        variants: [
          { begin: '"""', end: '"""(?=[^"])', contains: [o, r] },
          {
            begin: "'",
            end: "'",
            illegal: /\n/,
            contains: [e.BACKSLASH_ESCAPE],
          },
          {
            begin: '"',
            end: '"',
            illegal: /\n/,
            contains: [e.BACKSLASH_ESCAPE, o, r],
          },
        ],
      };
    r.contains.push(i);
    let l = {
        className: "meta",
        begin:
          "@(?:file|property|field|get|set|receiver|param|setparam|delegate)\\s*:(?:\\s*" +
          e.UNDERSCORE_IDENT_RE +
          ")?",
      },
      s = {
        className: "meta",
        begin: "@" + e.UNDERSCORE_IDENT_RE,
        contains: [
          {
            begin: /\(/,
            end: /\)/,
            contains: [e.inherit(i, { className: "string" }), "self"],
          },
        ],
      },
      u = I6,
      c = e.COMMENT("/\\*", "\\*/", { contains: [e.C_BLOCK_COMMENT_MODE] }),
      d = {
        variants: [
          { className: "type", begin: e.UNDERSCORE_IDENT_RE },
          { begin: /\(/, end: /\)/, contains: [] },
        ],
      },
      p = d;
    return (
      (p.variants[1].contains = [d]),
      (d.variants[1].contains = [p]),
      {
        name: "Kotlin",
        aliases: ["kt", "kts"],
        keywords: t,
        contains: [
          e.COMMENT("/\\*\\*", "\\*/", {
            relevance: 0,
            contains: [{ className: "doctag", begin: "@[A-Za-z]+" }],
          }),
          e.C_LINE_COMMENT_MODE,
          c,
          n,
          a,
          l,
          s,
          {
            className: "function",
            beginKeywords: "fun",
            end: "[(]|$",
            returnBegin: !0,
            excludeEnd: !0,
            keywords: t,
            relevance: 5,
            contains: [
              {
                begin: e.UNDERSCORE_IDENT_RE + "\\s*\\(",
                returnBegin: !0,
                relevance: 0,
                contains: [e.UNDERSCORE_TITLE_MODE],
              },
              {
                className: "type",
                begin: /</,
                end: />/,
                keywords: "reified",
                relevance: 0,
              },
              {
                className: "params",
                begin: /\(/,
                end: /\)/,
                endsParent: !0,
                keywords: t,
                relevance: 0,
                contains: [
                  {
                    begin: /:/,
                    end: /[=,\/]/,
                    endsWithParent: !0,
                    contains: [d, e.C_LINE_COMMENT_MODE, c],
                    relevance: 0,
                  },
                  e.C_LINE_COMMENT_MODE,
                  c,
                  l,
                  s,
                  i,
                  e.C_NUMBER_MODE,
                ],
              },
              c,
            ],
          },
          {
            begin: [/class|interface|trait/, /\s+/, e.UNDERSCORE_IDENT_RE],
            beginScope: { 3: "title.class" },
            keywords: "class interface trait",
            end: /[:\{(]|$/,
            excludeEnd: !0,
            illegal: "extends implements",
            contains: [
              {
                beginKeywords: "public protected internal private constructor",
              },
              e.UNDERSCORE_TITLE_MODE,
              {
                className: "type",
                begin: /</,
                end: />/,
                excludeBegin: !0,
                excludeEnd: !0,
                relevance: 0,
              },
              {
                className: "type",
                begin: /[,:]\s*/,
                end: /[<\(,){\s]|$/,
                excludeBegin: !0,
                returnEnd: !0,
              },
              l,
              s,
            ],
          },
          i,
          {
            className: "meta",
            begin: "^#!/usr/bin/env",
            end: "$",
            illegal: `
`,
          },
          u,
        ],
      }
    );
  }
  var T6 = (e) => ({
      IMPORTANT: { scope: "meta", begin: "!important" },
      BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
      HEXCOLOR: {
        scope: "number",
        begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/,
      },
      FUNCTION_DISPATCH: { className: "built_in", begin: /[\w-]+(?=\()/ },
      ATTRIBUTE_SELECTOR_MODE: {
        scope: "selector-attr",
        begin: /\[/,
        end: /\]/,
        illegal: "$",
        contains: [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE],
      },
      CSS_NUMBER_MODE: {
        scope: "number",
        begin:
          e.NUMBER_RE +
          "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
        relevance: 0,
      },
      CSS_VARIABLE: { className: "attr", begin: /--[A-Za-z][A-Za-z0-9_-]*/ },
    }),
    N6 = [
      "a",
      "abbr",
      "address",
      "article",
      "aside",
      "audio",
      "b",
      "blockquote",
      "body",
      "button",
      "canvas",
      "caption",
      "cite",
      "code",
      "dd",
      "del",
      "details",
      "dfn",
      "div",
      "dl",
      "dt",
      "em",
      "fieldset",
      "figcaption",
      "figure",
      "footer",
      "form",
      "h1",
      "h2",
      "h3",
      "h4",
      "h5",
      "h6",
      "header",
      "hgroup",
      "html",
      "i",
      "iframe",
      "img",
      "input",
      "ins",
      "kbd",
      "label",
      "legend",
      "li",
      "main",
      "mark",
      "menu",
      "nav",
      "object",
      "ol",
      "p",
      "q",
      "quote",
      "samp",
      "section",
      "span",
      "strong",
      "summary",
      "sup",
      "table",
      "tbody",
      "td",
      "textarea",
      "tfoot",
      "th",
      "thead",
      "time",
      "tr",
      "ul",
      "var",
      "video",
    ],
    L6 = [
      "any-hover",
      "any-pointer",
      "aspect-ratio",
      "color",
      "color-gamut",
      "color-index",
      "device-aspect-ratio",
      "device-height",
      "device-width",
      "display-mode",
      "forced-colors",
      "grid",
      "height",
      "hover",
      "inverted-colors",
      "monochrome",
      "orientation",
      "overflow-block",
      "overflow-inline",
      "pointer",
      "prefers-color-scheme",
      "prefers-contrast",
      "prefers-reduced-motion",
      "prefers-reduced-transparency",
      "resolution",
      "scan",
      "scripting",
      "update",
      "width",
      "min-width",
      "max-width",
      "min-height",
      "max-height",
    ],
    D2 = [
      "active",
      "any-link",
      "blank",
      "checked",
      "current",
      "default",
      "defined",
      "dir",
      "disabled",
      "drop",
      "empty",
      "enabled",
      "first",
      "first-child",
      "first-of-type",
      "fullscreen",
      "future",
      "focus",
      "focus-visible",
      "focus-within",
      "has",
      "host",
      "host-context",
      "hover",
      "indeterminate",
      "in-range",
      "invalid",
      "is",
      "lang",
      "last-child",
      "last-of-type",
      "left",
      "link",
      "local-link",
      "not",
      "nth-child",
      "nth-col",
      "nth-last-child",
      "nth-last-col",
      "nth-last-of-type",
      "nth-of-type",
      "only-child",
      "only-of-type",
      "optional",
      "out-of-range",
      "past",
      "placeholder-shown",
      "read-only",
      "read-write",
      "required",
      "right",
      "root",
      "scope",
      "target",
      "target-within",
      "user-invalid",
      "valid",
      "visited",
      "where",
    ],
    P2 = [
      "after",
      "backdrop",
      "before",
      "cue",
      "cue-region",
      "first-letter",
      "first-line",
      "grammar-error",
      "marker",
      "part",
      "placeholder",
      "selection",
      "slotted",
      "spelling-error",
    ],
    O6 = [
      "align-content",
      "align-items",
      "align-self",
      "all",
      "animation",
      "animation-delay",
      "animation-direction",
      "animation-duration",
      "animation-fill-mode",
      "animation-iteration-count",
      "animation-name",
      "animation-play-state",
      "animation-timing-function",
      "backface-visibility",
      "background",
      "background-attachment",
      "background-blend-mode",
      "background-clip",
      "background-color",
      "background-image",
      "background-origin",
      "background-position",
      "background-repeat",
      "background-size",
      "block-size",
      "border",
      "border-block",
      "border-block-color",
      "border-block-end",
      "border-block-end-color",
      "border-block-end-style",
      "border-block-end-width",
      "border-block-start",
      "border-block-start-color",
      "border-block-start-style",
      "border-block-start-width",
      "border-block-style",
      "border-block-width",
      "border-bottom",
      "border-bottom-color",
      "border-bottom-left-radius",
      "border-bottom-right-radius",
      "border-bottom-style",
      "border-bottom-width",
      "border-collapse",
      "border-color",
      "border-image",
      "border-image-outset",
      "border-image-repeat",
      "border-image-slice",
      "border-image-source",
      "border-image-width",
      "border-inline",
      "border-inline-color",
      "border-inline-end",
      "border-inline-end-color",
      "border-inline-end-style",
      "border-inline-end-width",
      "border-inline-start",
      "border-inline-start-color",
      "border-inline-start-style",
      "border-inline-start-width",
      "border-inline-style",
      "border-inline-width",
      "border-left",
      "border-left-color",
      "border-left-style",
      "border-left-width",
      "border-radius",
      "border-right",
      "border-right-color",
      "border-right-style",
      "border-right-width",
      "border-spacing",
      "border-style",
      "border-top",
      "border-top-color",
      "border-top-left-radius",
      "border-top-right-radius",
      "border-top-style",
      "border-top-width",
      "border-width",
      "bottom",
      "box-decoration-break",
      "box-shadow",
      "box-sizing",
      "break-after",
      "break-before",
      "break-inside",
      "caption-side",
      "caret-color",
      "clear",
      "clip",
      "clip-path",
      "clip-rule",
      "color",
      "column-count",
      "column-fill",
      "column-gap",
      "column-rule",
      "column-rule-color",
      "column-rule-style",
      "column-rule-width",
      "column-span",
      "column-width",
      "columns",
      "contain",
      "content",
      "content-visibility",
      "counter-increment",
      "counter-reset",
      "cue",
      "cue-after",
      "cue-before",
      "cursor",
      "direction",
      "display",
      "empty-cells",
      "filter",
      "flex",
      "flex-basis",
      "flex-direction",
      "flex-flow",
      "flex-grow",
      "flex-shrink",
      "flex-wrap",
      "float",
      "flow",
      "font",
      "font-display",
      "font-family",
      "font-feature-settings",
      "font-kerning",
      "font-language-override",
      "font-size",
      "font-size-adjust",
      "font-smoothing",
      "font-stretch",
      "font-style",
      "font-synthesis",
      "font-variant",
      "font-variant-caps",
      "font-variant-east-asian",
      "font-variant-ligatures",
      "font-variant-numeric",
      "font-variant-position",
      "font-variation-settings",
      "font-weight",
      "gap",
      "glyph-orientation-vertical",
      "grid",
      "grid-area",
      "grid-auto-columns",
      "grid-auto-flow",
      "grid-auto-rows",
      "grid-column",
      "grid-column-end",
      "grid-column-start",
      "grid-gap",
      "grid-row",
      "grid-row-end",
      "grid-row-start",
      "grid-template",
      "grid-template-areas",
      "grid-template-columns",
      "grid-template-rows",
      "hanging-punctuation",
      "height",
      "hyphens",
      "icon",
      "image-orientation",
      "image-rendering",
      "image-resolution",
      "ime-mode",
      "inline-size",
      "isolation",
      "justify-content",
      "left",
      "letter-spacing",
      "line-break",
      "line-height",
      "list-style",
      "list-style-image",
      "list-style-position",
      "list-style-type",
      "margin",
      "margin-block",
      "margin-block-end",
      "margin-block-start",
      "margin-bottom",
      "margin-inline",
      "margin-inline-end",
      "margin-inline-start",
      "margin-left",
      "margin-right",
      "margin-top",
      "marks",
      "mask",
      "mask-border",
      "mask-border-mode",
      "mask-border-outset",
      "mask-border-repeat",
      "mask-border-slice",
      "mask-border-source",
      "mask-border-width",
      "mask-clip",
      "mask-composite",
      "mask-image",
      "mask-mode",
      "mask-origin",
      "mask-position",
      "mask-repeat",
      "mask-size",
      "mask-type",
      "max-block-size",
      "max-height",
      "max-inline-size",
      "max-width",
      "min-block-size",
      "min-height",
      "min-inline-size",
      "min-width",
      "mix-blend-mode",
      "nav-down",
      "nav-index",
      "nav-left",
      "nav-right",
      "nav-up",
      "none",
      "normal",
      "object-fit",
      "object-position",
      "opacity",
      "order",
      "orphans",
      "outline",
      "outline-color",
      "outline-offset",
      "outline-style",
      "outline-width",
      "overflow",
      "overflow-wrap",
      "overflow-x",
      "overflow-y",
      "padding",
      "padding-block",
      "padding-block-end",
      "padding-block-start",
      "padding-bottom",
      "padding-inline",
      "padding-inline-end",
      "padding-inline-start",
      "padding-left",
      "padding-right",
      "padding-top",
      "page-break-after",
      "page-break-before",
      "page-break-inside",
      "pause",
      "pause-after",
      "pause-before",
      "perspective",
      "perspective-origin",
      "pointer-events",
      "position",
      "quotes",
      "resize",
      "rest",
      "rest-after",
      "rest-before",
      "right",
      "row-gap",
      "scroll-margin",
      "scroll-margin-block",
      "scroll-margin-block-end",
      "scroll-margin-block-start",
      "scroll-margin-bottom",
      "scroll-margin-inline",
      "scroll-margin-inline-end",
      "scroll-margin-inline-start",
      "scroll-margin-left",
      "scroll-margin-right",
      "scroll-margin-top",
      "scroll-padding",
      "scroll-padding-block",
      "scroll-padding-block-end",
      "scroll-padding-block-start",
      "scroll-padding-bottom",
      "scroll-padding-inline",
      "scroll-padding-inline-end",
      "scroll-padding-inline-start",
      "scroll-padding-left",
      "scroll-padding-right",
      "scroll-padding-top",
      "scroll-snap-align",
      "scroll-snap-stop",
      "scroll-snap-type",
      "scrollbar-color",
      "scrollbar-gutter",
      "scrollbar-width",
      "shape-image-threshold",
      "shape-margin",
      "shape-outside",
      "speak",
      "speak-as",
      "src",
      "tab-size",
      "table-layout",
      "text-align",
      "text-align-all",
      "text-align-last",
      "text-combine-upright",
      "text-decoration",
      "text-decoration-color",
      "text-decoration-line",
      "text-decoration-style",
      "text-emphasis",
      "text-emphasis-color",
      "text-emphasis-position",
      "text-emphasis-style",
      "text-indent",
      "text-justify",
      "text-orientation",
      "text-overflow",
      "text-rendering",
      "text-shadow",
      "text-transform",
      "text-underline-position",
      "top",
      "transform",
      "transform-box",
      "transform-origin",
      "transform-style",
      "transition",
      "transition-delay",
      "transition-duration",
      "transition-property",
      "transition-timing-function",
      "unicode-bidi",
      "vertical-align",
      "visibility",
      "voice-balance",
      "voice-duration",
      "voice-family",
      "voice-pitch",
      "voice-range",
      "voice-rate",
      "voice-stress",
      "voice-volume",
      "white-space",
      "widows",
      "width",
      "will-change",
      "word-break",
      "word-spacing",
      "word-wrap",
      "writing-mode",
      "z-index",
    ].reverse(),
    H6 = D2.concat(P2);
  function F2(e) {
    let t = T6(e),
      n = H6,
      a = "and or not only",
      r = "[\\w-]+",
      o = "(" + r + "|@\\{" + r + "\\})",
      i = [],
      l = [],
      s = function (y) {
        return { className: "string", begin: "~?" + y + ".*?" + y };
      },
      u = function (y, w, M) {
        return { className: y, begin: w, relevance: M };
      },
      c = { $pattern: /[a-z-]+/, keyword: a, attribute: L6.join(" ") },
      d = { begin: "\\(", end: "\\)", contains: l, keywords: c, relevance: 0 };
    l.push(
      e.C_LINE_COMMENT_MODE,
      e.C_BLOCK_COMMENT_MODE,
      s("'"),
      s('"'),
      t.CSS_NUMBER_MODE,
      {
        begin: "(url|data-uri)\\(",
        starts: { className: "string", end: "[\\)\\n]", excludeEnd: !0 },
      },
      t.HEXCOLOR,
      d,
      u("variable", "@@?" + r, 10),
      u("variable", "@\\{" + r + "\\}"),
      u("built_in", "~?`[^`]*?`"),
      {
        className: "attribute",
        begin: r + "\\s*:",
        end: ":",
        returnBegin: !0,
        excludeEnd: !0,
      },
      t.IMPORTANT,
      { beginKeywords: "and not" },
      t.FUNCTION_DISPATCH
    );
    let p = l.concat({ begin: /\{/, end: /\}/, contains: i }),
      m = {
        beginKeywords: "when",
        endsWithParent: !0,
        contains: [{ beginKeywords: "and not" }].concat(l),
      },
      f = {
        begin: o + "\\s*:",
        returnBegin: !0,
        end: /[;}]/,
        relevance: 0,
        contains: [
          { begin: /-(webkit|moz|ms|o)-/ },
          t.CSS_VARIABLE,
          {
            className: "attribute",
            begin: "\\b(" + O6.join("|") + ")\\b",
            end: /(?=:)/,
            starts: {
              endsWithParent: !0,
              illegal: "[<=$]",
              relevance: 0,
              contains: l,
            },
          },
        ],
      },
      v = {
        className: "keyword",
        begin:
          "@(import|media|charset|font-face|(-[a-z]+-)?keyframes|supports|document|namespace|page|viewport|host)\\b",
        starts: {
          end: "[;{}]",
          keywords: c,
          returnEnd: !0,
          contains: l,
          relevance: 0,
        },
      },
      g = {
        className: "variable",
        variants: [
          { begin: "@" + r + "\\s*:", relevance: 15 },
          { begin: "@" + r },
        ],
        starts: { end: "[;}]", returnEnd: !0, contains: p },
      },
      _ = {
        variants: [
          { begin: "[\\.#:&\\[>]", end: "[;{}]" },
          { begin: o, end: /\{/ },
        ],
        returnBegin: !0,
        returnEnd: !0,
        illegal: `[<='$"]`,
        relevance: 0,
        contains: [
          e.C_LINE_COMMENT_MODE,
          e.C_BLOCK_COMMENT_MODE,
          m,
          u("keyword", "all\\b"),
          u("variable", "@\\{" + r + "\\}"),
          { begin: "\\b(" + N6.join("|") + ")\\b", className: "selector-tag" },
          t.CSS_NUMBER_MODE,
          u("selector-tag", o, 0),
          u("selector-id", "#" + o),
          u("selector-class", "\\." + o, 0),
          u("selector-tag", "&", 0),
          t.ATTRIBUTE_SELECTOR_MODE,
          { className: "selector-pseudo", begin: ":(" + D2.join("|") + ")" },
          {
            className: "selector-pseudo",
            begin: ":(:)?(" + P2.join("|") + ")",
          },
          { begin: /\(/, end: /\)/, relevance: 0, contains: p },
          { begin: "!important" },
          t.FUNCTION_DISPATCH,
        ],
      },
      C = {
        begin: r + `:(:)?(${n.join("|")})`,
        returnBegin: !0,
        contains: [_],
      };
    return (
      i.push(
        e.C_LINE_COMMENT_MODE,
        e.C_BLOCK_COMMENT_MODE,
        v,
        g,
        C,
        f,
        _,
        m,
        t.FUNCTION_DISPATCH
      ),
      { name: "Less", case_insensitive: !0, illegal: `[=>'/<($"]`, contains: i }
    );
  }
  function V2(e) {
    let t = "\\[=*\\[",
      n = "\\]=*\\]",
      a = { begin: t, end: n, contains: ["self"] },
      r = [
        e.COMMENT("--(?!" + t + ")", "$"),
        e.COMMENT("--" + t, n, { contains: [a], relevance: 10 }),
      ];
    return {
      name: "Lua",
      keywords: {
        $pattern: e.UNDERSCORE_IDENT_RE,
        literal: "true false nil",
        keyword:
          "and break do else elseif end for goto if in local not or repeat return then until while",
        built_in:
          "_G _ENV _VERSION __index __newindex __mode __call __metatable __tostring __len __gc __add __sub __mul __div __mod __pow __concat __unm __eq __lt __le assert collectgarbage dofile error getfenv getmetatable ipairs load loadfile loadstring module next pairs pcall print rawequal rawget rawset require select setfenv setmetatable tonumber tostring type unpack xpcall arg self coroutine resume yield status wrap create running debug getupvalue debug sethook getmetatable gethook setmetatable setlocal traceback setfenv getinfo setupvalue getlocal getregistry getfenv io lines write close flush open output type read stderr stdin input stdout popen tmpfile math log max acos huge ldexp pi cos tanh pow deg tan cosh sinh random randomseed frexp ceil floor rad abs sqrt modf asin min mod fmod log10 atan2 exp sin atan os exit setlocale date getenv difftime remove time clock tmpname rename execute package preload loadlib loaded loaders cpath config path seeall string sub upper len gfind rep find match char dump gmatch reverse byte format gsub lower table setn insert getn foreachi maxn foreach concat sort remove",
      },
      contains: r.concat([
        {
          className: "function",
          beginKeywords: "function",
          end: "\\)",
          contains: [
            e.inherit(e.TITLE_MODE, {
              begin: "([_a-zA-Z]\\w*\\.)*([_a-zA-Z]\\w*:)?[_a-zA-Z]\\w*",
            }),
            {
              className: "params",
              begin: "\\(",
              endsWithParent: !0,
              contains: r,
            },
          ].concat(r),
        },
        e.C_NUMBER_MODE,
        e.APOS_STRING_MODE,
        e.QUOTE_STRING_MODE,
        { className: "string", begin: t, end: n, contains: [a], relevance: 5 },
      ]),
    };
  }
  function B2(e) {
    let t = {
        className: "variable",
        variants: [
          {
            begin: "\\$\\(" + e.UNDERSCORE_IDENT_RE + "\\)",
            contains: [e.BACKSLASH_ESCAPE],
          },
          { begin: /\$[@%<?\^\+\*]/ },
        ],
      },
      n = {
        className: "string",
        begin: /"/,
        end: /"/,
        contains: [e.BACKSLASH_ESCAPE, t],
      },
      a = {
        className: "variable",
        begin: /\$\([\w-]+\s/,
        end: /\)/,
        keywords: {
          built_in:
            "subst patsubst strip findstring filter filter-out sort word wordlist firstword lastword dir notdir suffix basename addsuffix addprefix join wildcard realpath abspath error warning shell origin flavor foreach if or and call eval file value",
        },
        contains: [t],
      },
      r = { begin: "^" + e.UNDERSCORE_IDENT_RE + "\\s*(?=[:+?]?=)" },
      o = {
        className: "meta",
        begin: /^\.PHONY:/,
        end: /$/,
        keywords: { $pattern: /[\.\w]+/, keyword: ".PHONY" },
      },
      i = { className: "section", begin: /^[^\s]+:/, end: /$/, contains: [t] };
    return {
      name: "Makefile",
      aliases: ["mk", "mak", "make"],
      keywords: {
        $pattern: /[\w-]+/,
        keyword:
          "define endef undefine ifdef ifndef ifeq ifneq else endif include -include sinclude override export unexport private vpath",
      },
      contains: [e.HASH_COMMENT_MODE, t, n, a, r, o, i],
    };
  }
  function U2(e) {
    let t = e.regex,
      n = {
        begin: /<\/?[A-Za-z_]/,
        end: ">",
        subLanguage: "xml",
        relevance: 0,
      },
      a = { begin: "^[-\\*]{3,}", end: "$" },
      r = {
        className: "code",
        variants: [
          { begin: "(`{3,})[^`](.|\\n)*?\\1`*[ ]*" },
          { begin: "(~{3,})[^~](.|\\n)*?\\1~*[ ]*" },
          { begin: "```", end: "```+[ ]*$" },
          { begin: "~~~", end: "~~~+[ ]*$" },
          { begin: "`.+?`" },
          {
            begin: "(?=^( {4}|\\t))",
            contains: [{ begin: "^( {4}|\\t)", end: "(\\n)$" }],
            relevance: 0,
          },
        ],
      },
      o = {
        className: "bullet",
        begin: "^[ 	]*([*+-]|(\\d+\\.))(?=\\s+)",
        end: "\\s+",
        excludeEnd: !0,
      },
      i = {
        begin: /^\[[^\n]+\]:/,
        returnBegin: !0,
        contains: [
          {
            className: "symbol",
            begin: /\[/,
            end: /\]/,
            excludeBegin: !0,
            excludeEnd: !0,
          },
          { className: "link", begin: /:\s*/, end: /$/, excludeBegin: !0 },
        ],
      },
      l = /[A-Za-z][A-Za-z0-9+.-]*/,
      s = {
        variants: [
          { begin: /\[.+?\]\[.*?\]/, relevance: 0 },
          {
            begin:
              /\[.+?\]\(((data|javascript|mailto):|(?:http|ftp)s?:\/\/).*?\)/,
            relevance: 2,
          },
          { begin: t.concat(/\[.+?\]\(/, l, /:\/\/.*?\)/), relevance: 2 },
          { begin: /\[.+?\]\([./?&#].*?\)/, relevance: 1 },
          { begin: /\[.*?\]\(.*?\)/, relevance: 0 },
        ],
        returnBegin: !0,
        contains: [
          { match: /\[(?=\])/ },
          {
            className: "string",
            relevance: 0,
            begin: "\\[",
            end: "\\]",
            excludeBegin: !0,
            returnEnd: !0,
          },
          {
            className: "link",
            relevance: 0,
            begin: "\\]\\(",
            end: "\\)",
            excludeBegin: !0,
            excludeEnd: !0,
          },
          {
            className: "symbol",
            relevance: 0,
            begin: "\\]\\[",
            end: "\\]",
            excludeBegin: !0,
            excludeEnd: !0,
          },
        ],
      },
      u = {
        className: "strong",
        contains: [],
        variants: [
          { begin: /_{2}(?!\s)/, end: /_{2}/ },
          { begin: /\*{2}(?!\s)/, end: /\*{2}/ },
        ],
      },
      c = {
        className: "emphasis",
        contains: [],
        variants: [
          { begin: /\*(?![*\s])/, end: /\*/ },
          { begin: /_(?![_\s])/, end: /_/, relevance: 0 },
        ],
      },
      d = e.inherit(u, { contains: [] }),
      p = e.inherit(c, { contains: [] });
    u.contains.push(p), c.contains.push(d);
    let m = [n, s];
    return (
      [u, c, d, p].forEach((g) => {
        g.contains = g.contains.concat(m);
      }),
      (m = m.concat(u, c)),
      {
        name: "Markdown",
        aliases: ["md", "mkdown", "mkd"],
        contains: [
          {
            className: "section",
            variants: [
              { begin: "^#{1,6}", end: "$", contains: m },
              {
                begin: "(?=^.+?\\n[=-]{2,}$)",
                contains: [
                  { begin: "^[=-]*$" },
                  { begin: "^", end: "\\n", contains: m },
                ],
              },
            ],
          },
          n,
          o,
          u,
          c,
          { className: "quote", begin: "^>\\s+", contains: m, end: "$" },
          r,
          a,
          s,
          i,
        ],
      }
    );
  }
  function G2(e) {
    let t = {
        className: "built_in",
        begin:
          "\\b(AV|CA|CF|CG|CI|CL|CM|CN|CT|MK|MP|MTK|MTL|NS|SCN|SK|UI|WK|XC)\\w+",
      },
      n = /[a-zA-Z@][a-zA-Z0-9_]*/,
      l = {
        "variable.language": ["this", "super"],
        $pattern: n,
        keyword: [
          "while",
          "export",
          "sizeof",
          "typedef",
          "const",
          "struct",
          "for",
          "union",
          "volatile",
          "static",
          "mutable",
          "if",
          "do",
          "return",
          "goto",
          "enum",
          "else",
          "break",
          "extern",
          "asm",
          "case",
          "default",
          "register",
          "explicit",
          "typename",
          "switch",
          "continue",
          "inline",
          "readonly",
          "assign",
          "readwrite",
          "self",
          "@synchronized",
          "id",
          "typeof",
          "nonatomic",
          "IBOutlet",
          "IBAction",
          "strong",
          "weak",
          "copy",
          "in",
          "out",
          "inout",
          "bycopy",
          "byref",
          "oneway",
          "__strong",
          "__weak",
          "__block",
          "__autoreleasing",
          "@private",
          "@protected",
          "@public",
          "@try",
          "@property",
          "@end",
          "@throw",
          "@catch",
          "@finally",
          "@autoreleasepool",
          "@synthesize",
          "@dynamic",
          "@selector",
          "@optional",
          "@required",
          "@encode",
          "@package",
          "@import",
          "@defs",
          "@compatibility_alias",
          "__bridge",
          "__bridge_transfer",
          "__bridge_retained",
          "__bridge_retain",
          "__covariant",
          "__contravariant",
          "__kindof",
          "_Nonnull",
          "_Nullable",
          "_Null_unspecified",
          "__FUNCTION__",
          "__PRETTY_FUNCTION__",
          "__attribute__",
          "getter",
          "setter",
          "retain",
          "unsafe_unretained",
          "nonnull",
          "nullable",
          "null_unspecified",
          "null_resettable",
          "class",
          "instancetype",
          "NS_DESIGNATED_INITIALIZER",
          "NS_UNAVAILABLE",
          "NS_REQUIRES_SUPER",
          "NS_RETURNS_INNER_POINTER",
          "NS_INLINE",
          "NS_AVAILABLE",
          "NS_DEPRECATED",
          "NS_ENUM",
          "NS_OPTIONS",
          "NS_SWIFT_UNAVAILABLE",
          "NS_ASSUME_NONNULL_BEGIN",
          "NS_ASSUME_NONNULL_END",
          "NS_REFINED_FOR_SWIFT",
          "NS_SWIFT_NAME",
          "NS_SWIFT_NOTHROW",
          "NS_DURING",
          "NS_HANDLER",
          "NS_ENDHANDLER",
          "NS_VALUERETURN",
          "NS_VOIDRETURN",
        ],
        literal: ["false", "true", "FALSE", "TRUE", "nil", "YES", "NO", "NULL"],
        built_in: [
          "dispatch_once_t",
          "dispatch_queue_t",
          "dispatch_sync",
          "dispatch_async",
          "dispatch_once",
        ],
        type: [
          "int",
          "float",
          "char",
          "unsigned",
          "signed",
          "short",
          "long",
          "double",
          "wchar_t",
          "unichar",
          "void",
          "bool",
          "BOOL",
          "id|0",
          "_Bool",
        ],
      },
      s = {
        $pattern: n,
        keyword: ["@interface", "@class", "@protocol", "@implementation"],
      };
    return {
      name: "Objective-C",
      aliases: ["mm", "objc", "obj-c", "obj-c++", "objective-c++"],
      keywords: l,
      illegal: "</",
      contains: [
        t,
        e.C_LINE_COMMENT_MODE,
        e.C_BLOCK_COMMENT_MODE,
        e.C_NUMBER_MODE,
        e.QUOTE_STRING_MODE,
        e.APOS_STRING_MODE,
        {
          className: "string",
          variants: [
            {
              begin: '@"',
              end: '"',
              illegal: "\\n",
              contains: [e.BACKSLASH_ESCAPE],
            },
          ],
        },
        {
          className: "meta",
          begin: /#\s*[a-z]+\b/,
          end: /$/,
          keywords: {
            keyword:
              "if else elif endif define undef warning error line pragma ifdef ifndef include",
          },
          contains: [
            { begin: /\\\n/, relevance: 0 },
            e.inherit(e.QUOTE_STRING_MODE, { className: "string" }),
            { className: "string", begin: /<.*?>/, end: /$/, illegal: "\\n" },
            e.C_LINE_COMMENT_MODE,
            e.C_BLOCK_COMMENT_MODE,
          ],
        },
        {
          className: "class",
          begin: "(" + s.keyword.join("|") + ")\\b",
          end: /(\{|$)/,
          excludeEnd: !0,
          keywords: s,
          contains: [e.UNDERSCORE_TITLE_MODE],
        },
        { begin: "\\." + e.UNDERSCORE_IDENT_RE, relevance: 0 },
      ],
    };
  }
  function $2(e) {
    let t = e.regex,
      n = [
        "abs",
        "accept",
        "alarm",
        "and",
        "atan2",
        "bind",
        "binmode",
        "bless",
        "break",
        "caller",
        "chdir",
        "chmod",
        "chomp",
        "chop",
        "chown",
        "chr",
        "chroot",
        "close",
        "closedir",
        "connect",
        "continue",
        "cos",
        "crypt",
        "dbmclose",
        "dbmopen",
        "defined",
        "delete",
        "die",
        "do",
        "dump",
        "each",
        "else",
        "elsif",
        "endgrent",
        "endhostent",
        "endnetent",
        "endprotoent",
        "endpwent",
        "endservent",
        "eof",
        "eval",
        "exec",
        "exists",
        "exit",
        "exp",
        "fcntl",
        "fileno",
        "flock",
        "for",
        "foreach",
        "fork",
        "format",
        "formline",
        "getc",
        "getgrent",
        "getgrgid",
        "getgrnam",
        "gethostbyaddr",
        "gethostbyname",
        "gethostent",
        "getlogin",
        "getnetbyaddr",
        "getnetbyname",
        "getnetent",
        "getpeername",
        "getpgrp",
        "getpriority",
        "getprotobyname",
        "getprotobynumber",
        "getprotoent",
        "getpwent",
        "getpwnam",
        "getpwuid",
        "getservbyname",
        "getservbyport",
        "getservent",
        "getsockname",
        "getsockopt",
        "given",
        "glob",
        "gmtime",
        "goto",
        "grep",
        "gt",
        "hex",
        "if",
        "index",
        "int",
        "ioctl",
        "join",
        "keys",
        "kill",
        "last",
        "lc",
        "lcfirst",
        "length",
        "link",
        "listen",
        "local",
        "localtime",
        "log",
        "lstat",
        "lt",
        "ma",
        "map",
        "mkdir",
        "msgctl",
        "msgget",
        "msgrcv",
        "msgsnd",
        "my",
        "ne",
        "next",
        "no",
        "not",
        "oct",
        "open",
        "opendir",
        "or",
        "ord",
        "our",
        "pack",
        "package",
        "pipe",
        "pop",
        "pos",
        "print",
        "printf",
        "prototype",
        "push",
        "q|0",
        "qq",
        "quotemeta",
        "qw",
        "qx",
        "rand",
        "read",
        "readdir",
        "readline",
        "readlink",
        "readpipe",
        "recv",
        "redo",
        "ref",
        "rename",
        "require",
        "reset",
        "return",
        "reverse",
        "rewinddir",
        "rindex",
        "rmdir",
        "say",
        "scalar",
        "seek",
        "seekdir",
        "select",
        "semctl",
        "semget",
        "semop",
        "send",
        "setgrent",
        "sethostent",
        "setnetent",
        "setpgrp",
        "setpriority",
        "setprotoent",
        "setpwent",
        "setservent",
        "setsockopt",
        "shift",
        "shmctl",
        "shmget",
        "shmread",
        "shmwrite",
        "shutdown",
        "sin",
        "sleep",
        "socket",
        "socketpair",
        "sort",
        "splice",
        "split",
        "sprintf",
        "sqrt",
        "srand",
        "stat",
        "state",
        "study",
        "sub",
        "substr",
        "symlink",
        "syscall",
        "sysopen",
        "sysread",
        "sysseek",
        "system",
        "syswrite",
        "tell",
        "telldir",
        "tie",
        "tied",
        "time",
        "times",
        "tr",
        "truncate",
        "uc",
        "ucfirst",
        "umask",
        "undef",
        "unless",
        "unlink",
        "unpack",
        "unshift",
        "untie",
        "until",
        "use",
        "utime",
        "values",
        "vec",
        "wait",
        "waitpid",
        "wantarray",
        "warn",
        "when",
        "while",
        "write",
        "x|0",
        "xor",
        "y|0",
      ],
      a = /[dualxmsipngr]{0,12}/,
      r = { $pattern: /[\w.]+/, keyword: n.join(" ") },
      o = { className: "subst", begin: "[$@]\\{", end: "\\}", keywords: r },
      i = { begin: /->\{/, end: /\}/ },
      l = {
        variants: [
          { begin: /\$\d/ },
          {
            begin: t.concat(
              /[$%@](\^\w\b|#\w+(::\w+)*|\{\w+\}|\w+(::\w*)*)/,
              "(?![A-Za-z])(?![@$%])"
            ),
          },
          { begin: /[$%@][^\s\w{]/, relevance: 0 },
        ],
      },
      s = [e.BACKSLASH_ESCAPE, o, l],
      u = [/!/, /\//, /\|/, /\?/, /'/, /"/, /#/],
      c = (m, f, v = "\\1") => {
        let g = v === "\\1" ? v : t.concat(v, f);
        return t.concat(
          t.concat("(?:", m, ")"),
          f,
          /(?:\\.|[^\\\/])*?/,
          g,
          /(?:\\.|[^\\\/])*?/,
          v,
          a
        );
      },
      d = (m, f, v) =>
        t.concat(t.concat("(?:", m, ")"), f, /(?:\\.|[^\\\/])*?/, v, a),
      p = [
        l,
        e.HASH_COMMENT_MODE,
        e.COMMENT(/^=\w/, /=cut/, { endsWithParent: !0 }),
        i,
        {
          className: "string",
          contains: s,
          variants: [
            { begin: "q[qwxr]?\\s*\\(", end: "\\)", relevance: 5 },
            { begin: "q[qwxr]?\\s*\\[", end: "\\]", relevance: 5 },
            { begin: "q[qwxr]?\\s*\\{", end: "\\}", relevance: 5 },
            { begin: "q[qwxr]?\\s*\\|", end: "\\|", relevance: 5 },
            { begin: "q[qwxr]?\\s*<", end: ">", relevance: 5 },
            { begin: "qw\\s+q", end: "q", relevance: 5 },
            { begin: "'", end: "'", contains: [e.BACKSLASH_ESCAPE] },
            { begin: '"', end: '"' },
            { begin: "`", end: "`", contains: [e.BACKSLASH_ESCAPE] },
            { begin: /\{\w+\}/, relevance: 0 },
            { begin: "-?\\w+\\s*=>", relevance: 0 },
          ],
        },
        {
          className: "number",
          begin:
            "(\\b0[0-7_]+)|(\\b0x[0-9a-fA-F_]+)|(\\b[1-9][0-9_]*(\\.[0-9_]+)?)|[0_]\\b",
          relevance: 0,
        },
        {
          begin:
            "(\\/\\/|" +
            e.RE_STARTERS_RE +
            "|\\b(split|return|print|reverse|grep)\\b)\\s*",
          keywords: "split return print reverse grep",
          relevance: 0,
          contains: [
            e.HASH_COMMENT_MODE,
            {
              className: "regexp",
              variants: [
                { begin: c("s|tr|y", t.either(...u, { capture: !0 })) },
                { begin: c("s|tr|y", "\\(", "\\)") },
                { begin: c("s|tr|y", "\\[", "\\]") },
                { begin: c("s|tr|y", "\\{", "\\}") },
              ],
              relevance: 2,
            },
            {
              className: "regexp",
              variants: [
                { begin: /(m|qr)\/\//, relevance: 0 },
                { begin: d("(?:m|qr)?", /\//, /\//) },
                { begin: d("m|qr", t.either(...u, { capture: !0 }), /\1/) },
                { begin: d("m|qr", /\(/, /\)/) },
                { begin: d("m|qr", /\[/, /\]/) },
                { begin: d("m|qr", /\{/, /\}/) },
              ],
            },
          ],
        },
        {
          className: "function",
          beginKeywords: "sub",
          end: "(\\s*\\(.*?\\))?[;{]",
          excludeEnd: !0,
          relevance: 5,
          contains: [e.TITLE_MODE],
        },
        { begin: "-\\w\\b", relevance: 0 },
        {
          begin: "^__DATA__$",
          end: "^__END__$",
          subLanguage: "mojolicious",
          contains: [{ begin: "^@@.*", end: "$", className: "comment" }],
        },
      ];
    return (
      (o.contains = p),
      (i.contains = p),
      { name: "Perl", aliases: ["pl", "pm"], keywords: r, contains: p }
    );
  }
  function q2(e) {
    let t = e.regex,
      n = /(?![A-Za-z0-9])(?![$])/,
      a = t.concat(/[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*/, n),
      r = t.concat(
        /(\\?[A-Z][a-z0-9_\x7f-\xff]+|\\?[A-Z]+(?=[A-Z][a-z0-9_\x7f-\xff])){1,}/,
        n
      ),
      o = { scope: "variable", match: "\\$+" + a },
      i = {
        scope: "meta",
        variants: [
          { begin: /<\?php/, relevance: 10 },
          { begin: /<\?=/ },
          { begin: /<\?/, relevance: 0.1 },
          { begin: /\?>/ },
        ],
      },
      l = {
        scope: "subst",
        variants: [{ begin: /\$\w+/ }, { begin: /\{\$/, end: /\}/ }],
      },
      s = e.inherit(e.APOS_STRING_MODE, { illegal: null }),
      u = e.inherit(e.QUOTE_STRING_MODE, {
        illegal: null,
        contains: e.QUOTE_STRING_MODE.contains.concat(l),
      }),
      c = e.END_SAME_AS_BEGIN({
        begin: /<<<[ \t]*(\w+)\n/,
        end: /[ \t]*(\w+)\b/,
        contains: e.QUOTE_STRING_MODE.contains.concat(l),
      }),
      d = `[ 	
]`,
      p = { scope: "string", variants: [u, s, c] },
      m = {
        scope: "number",
        variants: [
          { begin: "\\b0[bB][01]+(?:_[01]+)*\\b" },
          { begin: "\\b0[oO][0-7]+(?:_[0-7]+)*\\b" },
          { begin: "\\b0[xX][\\da-fA-F]+(?:_[\\da-fA-F]+)*\\b" },
          {
            begin:
              "(?:\\b\\d+(?:_\\d+)*(\\.(?:\\d+(?:_\\d+)*))?|\\B\\.\\d+)(?:[eE][+-]?\\d+)?",
          },
        ],
        relevance: 0,
      },
      f = ["false", "null", "true"],
      v = [
        "__CLASS__",
        "__DIR__",
        "__FILE__",
        "__FUNCTION__",
        "__COMPILER_HALT_OFFSET__",
        "__LINE__",
        "__METHOD__",
        "__NAMESPACE__",
        "__TRAIT__",
        "die",
        "echo",
        "exit",
        "include",
        "include_once",
        "print",
        "require",
        "require_once",
        "array",
        "abstract",
        "and",
        "as",
        "binary",
        "bool",
        "boolean",
        "break",
        "callable",
        "case",
        "catch",
        "class",
        "clone",
        "const",
        "continue",
        "declare",
        "default",
        "do",
        "double",
        "else",
        "elseif",
        "empty",
        "enddeclare",
        "endfor",
        "endforeach",
        "endif",
        "endswitch",
        "endwhile",
        "enum",
        "eval",
        "extends",
        "final",
        "finally",
        "float",
        "for",
        "foreach",
        "from",
        "global",
        "goto",
        "if",
        "implements",
        "instanceof",
        "insteadof",
        "int",
        "integer",
        "interface",
        "isset",
        "iterable",
        "list",
        "match|0",
        "mixed",
        "new",
        "never",
        "object",
        "or",
        "private",
        "protected",
        "public",
        "readonly",
        "real",
        "return",
        "string",
        "switch",
        "throw",
        "trait",
        "try",
        "unset",
        "use",
        "var",
        "void",
        "while",
        "xor",
        "yield",
      ],
      g = [
        "Error|0",
        "AppendIterator",
        "ArgumentCountError",
        "ArithmeticError",
        "ArrayIterator",
        "ArrayObject",
        "AssertionError",
        "BadFunctionCallException",
        "BadMethodCallException",
        "CachingIterator",
        "CallbackFilterIterator",
        "CompileError",
        "Countable",
        "DirectoryIterator",
        "DivisionByZeroError",
        "DomainException",
        "EmptyIterator",
        "ErrorException",
        "Exception",
        "FilesystemIterator",
        "FilterIterator",
        "GlobIterator",
        "InfiniteIterator",
        "InvalidArgumentException",
        "IteratorIterator",
        "LengthException",
        "LimitIterator",
        "LogicException",
        "MultipleIterator",
        "NoRewindIterator",
        "OutOfBoundsException",
        "OutOfRangeException",
        "OuterIterator",
        "OverflowException",
        "ParentIterator",
        "ParseError",
        "RangeException",
        "RecursiveArrayIterator",
        "RecursiveCachingIterator",
        "RecursiveCallbackFilterIterator",
        "RecursiveDirectoryIterator",
        "RecursiveFilterIterator",
        "RecursiveIterator",
        "RecursiveIteratorIterator",
        "RecursiveRegexIterator",
        "RecursiveTreeIterator",
        "RegexIterator",
        "RuntimeException",
        "SeekableIterator",
        "SplDoublyLinkedList",
        "SplFileInfo",
        "SplFileObject",
        "SplFixedArray",
        "SplHeap",
        "SplMaxHeap",
        "SplMinHeap",
        "SplObjectStorage",
        "SplObserver",
        "SplPriorityQueue",
        "SplQueue",
        "SplStack",
        "SplSubject",
        "SplTempFileObject",
        "TypeError",
        "UnderflowException",
        "UnexpectedValueException",
        "UnhandledMatchError",
        "ArrayAccess",
        "BackedEnum",
        "Closure",
        "Fiber",
        "Generator",
        "Iterator",
        "IteratorAggregate",
        "Serializable",
        "Stringable",
        "Throwable",
        "Traversable",
        "UnitEnum",
        "WeakReference",
        "WeakMap",
        "Directory",
        "__PHP_Incomplete_Class",
        "parent",
        "php_user_filter",
        "self",
        "static",
        "stdClass",
      ],
      C = {
        keyword: v,
        literal: ((V) => {
          let I = [];
          return (
            V.forEach((D) => {
              I.push(D),
                D.toLowerCase() === D
                  ? I.push(D.toUpperCase())
                  : I.push(D.toLowerCase());
            }),
            I
          );
        })(f),
        built_in: g,
      },
      y = (V) => V.map((I) => I.replace(/\|\d+$/, "")),
      w = {
        variants: [
          {
            match: [
              /new/,
              t.concat(d, "+"),
              t.concat("(?!", y(g).join("\\b|"), "\\b)"),
              r,
            ],
            scope: { 1: "keyword", 4: "title.class" },
          },
        ],
      },
      M = t.concat(a, "\\b(?!\\()"),
      E = {
        variants: [
          {
            match: [t.concat(/::/, t.lookahead(/(?!class\b)/)), M],
            scope: { 2: "variable.constant" },
          },
          { match: [/::/, /class/], scope: { 2: "variable.language" } },
          {
            match: [r, t.concat(/::/, t.lookahead(/(?!class\b)/)), M],
            scope: { 1: "title.class", 3: "variable.constant" },
          },
          {
            match: [r, t.concat("::", t.lookahead(/(?!class\b)/))],
            scope: { 1: "title.class" },
          },
          {
            match: [r, /::/, /class/],
            scope: { 1: "title.class", 3: "variable.language" },
          },
        ],
      },
      z = {
        scope: "attr",
        match: t.concat(a, t.lookahead(":"), t.lookahead(/(?!::)/)),
      },
      k = {
        relevance: 0,
        begin: /\(/,
        end: /\)/,
        keywords: C,
        contains: [z, o, E, e.C_BLOCK_COMMENT_MODE, p, m, w],
      },
      O = {
        relevance: 0,
        match: [
          /\b/,
          t.concat(
            "(?!fn\\b|function\\b|",
            y(v).join("\\b|"),
            "|",
            y(g).join("\\b|"),
            "\\b)"
          ),
          a,
          t.concat(d, "*"),
          t.lookahead(/(?=\()/),
        ],
        scope: { 3: "title.function.invoke" },
        contains: [k],
      };
    k.contains.push(O);
    let K = [z, E, e.C_BLOCK_COMMENT_MODE, p, m, w],
      H = {
        begin: t.concat(/#\[\s*/, r),
        beginScope: "meta",
        end: /]/,
        endScope: "meta",
        keywords: { literal: f, keyword: ["new", "array"] },
        contains: [
          {
            begin: /\[/,
            end: /]/,
            keywords: { literal: f, keyword: ["new", "array"] },
            contains: ["self", ...K],
          },
          ...K,
          { scope: "meta", match: r },
        ],
      };
    return {
      case_insensitive: !1,
      keywords: C,
      contains: [
        H,
        e.HASH_COMMENT_MODE,
        e.COMMENT("//", "$"),
        e.COMMENT("/\\*", "\\*/", {
          contains: [{ scope: "doctag", match: "@[A-Za-z]+" }],
        }),
        {
          match: /__halt_compiler\(\);/,
          keywords: "__halt_compiler",
          starts: {
            scope: "comment",
            end: e.MATCH_NOTHING_RE,
            contains: [{ match: /\?>/, scope: "meta", endsParent: !0 }],
          },
        },
        i,
        { scope: "variable.language", match: /\$this\b/ },
        o,
        O,
        E,
        {
          match: [/const/, /\s/, a],
          scope: { 1: "keyword", 3: "variable.constant" },
        },
        w,
        {
          scope: "function",
          relevance: 0,
          beginKeywords: "fn function",
          end: /[;{]/,
          excludeEnd: !0,
          illegal: "[$%\\[]",
          contains: [
            { beginKeywords: "use" },
            e.UNDERSCORE_TITLE_MODE,
            { begin: "=>", endsParent: !0 },
            {
              scope: "params",
              begin: "\\(",
              end: "\\)",
              excludeBegin: !0,
              excludeEnd: !0,
              keywords: C,
              contains: ["self", o, E, e.C_BLOCK_COMMENT_MODE, p, m],
            },
          ],
        },
        {
          scope: "class",
          variants: [
            { beginKeywords: "enum", illegal: /[($"]/ },
            { beginKeywords: "class interface trait", illegal: /[:($"]/ },
          ],
          relevance: 0,
          end: /\{/,
          excludeEnd: !0,
          contains: [
            { beginKeywords: "extends implements" },
            e.UNDERSCORE_TITLE_MODE,
          ],
        },
        {
          beginKeywords: "namespace",
          relevance: 0,
          end: ";",
          illegal: /[.']/,
          contains: [
            e.inherit(e.UNDERSCORE_TITLE_MODE, { scope: "title.class" }),
          ],
        },
        {
          beginKeywords: "use",
          relevance: 0,
          end: ";",
          contains: [
            { match: /\b(as|const|function)\b/, scope: "keyword" },
            e.UNDERSCORE_TITLE_MODE,
          ],
        },
        p,
        m,
      ],
    };
  }
  function W2(e) {
    return {
      name: "PHP template",
      subLanguage: "xml",
      contains: [
        {
          begin: /<\?(php|=)?/,
          end: /\?>/,
          subLanguage: "php",
          contains: [
            { begin: "/\\*", end: "\\*/", skip: !0 },
            { begin: 'b"', end: '"', skip: !0 },
            { begin: "b'", end: "'", skip: !0 },
            e.inherit(e.APOS_STRING_MODE, {
              illegal: null,
              className: null,
              contains: null,
              skip: !0,
            }),
            e.inherit(e.QUOTE_STRING_MODE, {
              illegal: null,
              className: null,
              contains: null,
              skip: !0,
            }),
          ],
        },
      ],
    };
  }
  function K2(e) {
    return {
      name: "Plain text",
      aliases: ["text", "txt"],
      disableAutodetect: !0,
    };
  }
  function j2(e) {
    let t = e.regex,
      n = /[\p{XID_Start}_]\p{XID_Continue}*/u,
      a = [
        "and",
        "as",
        "assert",
        "async",
        "await",
        "break",
        "case",
        "class",
        "continue",
        "def",
        "del",
        "elif",
        "else",
        "except",
        "finally",
        "for",
        "from",
        "global",
        "if",
        "import",
        "in",
        "is",
        "lambda",
        "match",
        "nonlocal|10",
        "not",
        "or",
        "pass",
        "raise",
        "return",
        "try",
        "while",
        "with",
        "yield",
      ],
      l = {
        $pattern: /[A-Za-z]\w+|__\w+__/,
        keyword: a,
        built_in: [
          "__import__",
          "abs",
          "all",
          "any",
          "ascii",
          "bin",
          "bool",
          "breakpoint",
          "bytearray",
          "bytes",
          "callable",
          "chr",
          "classmethod",
          "compile",
          "complex",
          "delattr",
          "dict",
          "dir",
          "divmod",
          "enumerate",
          "eval",
          "exec",
          "filter",
          "float",
          "format",
          "frozenset",
          "getattr",
          "globals",
          "hasattr",
          "hash",
          "help",
          "hex",
          "id",
          "input",
          "int",
          "isinstance",
          "issubclass",
          "iter",
          "len",
          "list",
          "locals",
          "map",
          "max",
          "memoryview",
          "min",
          "next",
          "object",
          "oct",
          "open",
          "ord",
          "pow",
          "print",
          "property",
          "range",
          "repr",
          "reversed",
          "round",
          "set",
          "setattr",
          "slice",
          "sorted",
          "staticmethod",
          "str",
          "sum",
          "super",
          "tuple",
          "type",
          "vars",
          "zip",
        ],
        literal: [
          "__debug__",
          "Ellipsis",
          "False",
          "None",
          "NotImplemented",
          "True",
        ],
        type: [
          "Any",
          "Callable",
          "Coroutine",
          "Dict",
          "List",
          "Literal",
          "Generic",
          "Optional",
          "Sequence",
          "Set",
          "Tuple",
          "Type",
          "Union",
        ],
      },
      s = { className: "meta", begin: /^(>>>|\.\.\.) / },
      u = {
        className: "subst",
        begin: /\{/,
        end: /\}/,
        keywords: l,
        illegal: /#/,
      },
      c = { begin: /\{\{/, relevance: 0 },
      d = {
        className: "string",
        contains: [e.BACKSLASH_ESCAPE],
        variants: [
          {
            begin: /([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?'''/,
            end: /'''/,
            contains: [e.BACKSLASH_ESCAPE, s],
            relevance: 10,
          },
          {
            begin: /([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?"""/,
            end: /"""/,
            contains: [e.BACKSLASH_ESCAPE, s],
            relevance: 10,
          },
          {
            begin: /([fF][rR]|[rR][fF]|[fF])'''/,
            end: /'''/,
            contains: [e.BACKSLASH_ESCAPE, s, c, u],
          },
          {
            begin: /([fF][rR]|[rR][fF]|[fF])"""/,
            end: /"""/,
            contains: [e.BACKSLASH_ESCAPE, s, c, u],
          },
          { begin: /([uU]|[rR])'/, end: /'/, relevance: 10 },
          { begin: /([uU]|[rR])"/, end: /"/, relevance: 10 },
          { begin: /([bB]|[bB][rR]|[rR][bB])'/, end: /'/ },
          { begin: /([bB]|[bB][rR]|[rR][bB])"/, end: /"/ },
          {
            begin: /([fF][rR]|[rR][fF]|[fF])'/,
            end: /'/,
            contains: [e.BACKSLASH_ESCAPE, c, u],
          },
          {
            begin: /([fF][rR]|[rR][fF]|[fF])"/,
            end: /"/,
            contains: [e.BACKSLASH_ESCAPE, c, u],
          },
          e.APOS_STRING_MODE,
          e.QUOTE_STRING_MODE,
        ],
      },
      p = "[0-9](_?[0-9])*",
      m = `(\\b(${p}))?\\.(${p})|\\b(${p})\\.`,
      f = `\\b|${a.join("|")}`,
      v = {
        className: "number",
        relevance: 0,
        variants: [
          { begin: `(\\b(${p})|(${m}))[eE][+-]?(${p})[jJ]?(?=${f})` },
          { begin: `(${m})[jJ]?` },
          { begin: `\\b([1-9](_?[0-9])*|0+(_?0)*)[lLjJ]?(?=${f})` },
          { begin: `\\b0[bB](_?[01])+[lL]?(?=${f})` },
          { begin: `\\b0[oO](_?[0-7])+[lL]?(?=${f})` },
          { begin: `\\b0[xX](_?[0-9a-fA-F])+[lL]?(?=${f})` },
          { begin: `\\b(${p})[jJ](?=${f})` },
        ],
      },
      g = {
        className: "comment",
        begin: t.lookahead(/# type:/),
        end: /$/,
        keywords: l,
        contains: [
          { begin: /# type:/ },
          { begin: /#/, end: /\b\B/, endsWithParent: !0 },
        ],
      },
      _ = {
        className: "params",
        variants: [
          { className: "", begin: /\(\s*\)/, skip: !0 },
          {
            begin: /\(/,
            end: /\)/,
            excludeBegin: !0,
            excludeEnd: !0,
            keywords: l,
            contains: ["self", s, v, d, e.HASH_COMMENT_MODE],
          },
        ],
      };
    return (
      (u.contains = [d, v, s]),
      {
        name: "Python",
        aliases: ["py", "gyp", "ipython"],
        unicodeRegex: !0,
        keywords: l,
        illegal: /(<\/|->|\?)|=>/,
        contains: [
          s,
          v,
          { begin: /\bself\b/ },
          { beginKeywords: "if", relevance: 0 },
          d,
          g,
          e.HASH_COMMENT_MODE,
          {
            match: [/\bdef/, /\s+/, n],
            scope: { 1: "keyword", 3: "title.function" },
            contains: [_],
          },
          {
            variants: [
              { match: [/\bclass/, /\s+/, n, /\s*/, /\(\s*/, n, /\s*\)/] },
              { match: [/\bclass/, /\s+/, n] },
            ],
            scope: {
              1: "keyword",
              3: "title.class",
              6: "title.class.inherited",
            },
          },
          {
            className: "meta",
            begin: /^[\t ]*@/,
            end: /(?=#)|$/,
            contains: [v, _, d],
          },
        ],
      }
    );
  }
  function Y2(e) {
    return {
      aliases: ["pycon"],
      contains: [
        {
          className: "meta.prompt",
          starts: { end: / |$/, starts: { end: "$", subLanguage: "python" } },
          variants: [{ begin: /^>>>(?=[ ]|$)/ }, { begin: /^\.\.\.(?=[ ]|$)/ }],
        },
      ],
    };
  }
  function Q2(e) {
    let t = e.regex,
      n = /(?:(?:[a-zA-Z]|\.[._a-zA-Z])[._a-zA-Z0-9]*)|\.(?!\d)/,
      a = t.either(
        /0[xX][0-9a-fA-F]+\.[0-9a-fA-F]*[pP][+-]?\d+i?/,
        /0[xX][0-9a-fA-F]+(?:[pP][+-]?\d+)?[Li]?/,
        /(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?[Li]?/
      ),
      r = /[=!<>:]=|\|\||&&|:::?|<-|<<-|->>|->|\|>|[-+*\/?!$&|:<=>@^~]|\*\*/,
      o = t.either(/[()]/, /[{}]/, /\[\[/, /[[\]]/, /\\/, /,/);
    return {
      name: "R",
      keywords: {
        $pattern: n,
        keyword: "function if in break next repeat else for while",
        literal:
          "NULL NA TRUE FALSE Inf NaN NA_integer_|10 NA_real_|10 NA_character_|10 NA_complex_|10",
        built_in:
          "LETTERS letters month.abb month.name pi T F abs acos acosh all any anyNA Arg as.call as.character as.complex as.double as.environment as.integer as.logical as.null.default as.numeric as.raw asin asinh atan atanh attr attributes baseenv browser c call ceiling class Conj cos cosh cospi cummax cummin cumprod cumsum digamma dim dimnames emptyenv exp expression floor forceAndCall gamma gc.time globalenv Im interactive invisible is.array is.atomic is.call is.character is.complex is.double is.environment is.expression is.finite is.function is.infinite is.integer is.language is.list is.logical is.matrix is.na is.name is.nan is.null is.numeric is.object is.pairlist is.raw is.recursive is.single is.symbol lazyLoadDBfetch length lgamma list log max min missing Mod names nargs nzchar oldClass on.exit pos.to.env proc.time prod quote range Re rep retracemem return round seq_along seq_len seq.int sign signif sin sinh sinpi sqrt standardGeneric substitute sum switch tan tanh tanpi tracemem trigamma trunc unclass untracemem UseMethod xtfrm",
      },
      contains: [
        e.COMMENT(/#'/, /$/, {
          contains: [
            {
              scope: "doctag",
              match: /@examples/,
              starts: {
                end: t.lookahead(
                  t.either(/\n^#'\s*(?=@[a-zA-Z]+)/, /\n^(?!#')/)
                ),
                endsParent: !0,
              },
            },
            {
              scope: "doctag",
              begin: "@param",
              end: /$/,
              contains: [
                {
                  scope: "variable",
                  variants: [{ match: n }, { match: /`(?:\\.|[^`\\])+`/ }],
                  endsParent: !0,
                },
              ],
            },
            { scope: "doctag", match: /@[a-zA-Z]+/ },
            { scope: "keyword", match: /\\[a-zA-Z]+/ },
          ],
        }),
        e.HASH_COMMENT_MODE,
        {
          scope: "string",
          contains: [e.BACKSLASH_ESCAPE],
          variants: [
            e.END_SAME_AS_BEGIN({ begin: /[rR]"(-*)\(/, end: /\)(-*)"/ }),
            e.END_SAME_AS_BEGIN({ begin: /[rR]"(-*)\{/, end: /\}(-*)"/ }),
            e.END_SAME_AS_BEGIN({ begin: /[rR]"(-*)\[/, end: /\](-*)"/ }),
            e.END_SAME_AS_BEGIN({ begin: /[rR]'(-*)\(/, end: /\)(-*)'/ }),
            e.END_SAME_AS_BEGIN({ begin: /[rR]'(-*)\{/, end: /\}(-*)'/ }),
            e.END_SAME_AS_BEGIN({ begin: /[rR]'(-*)\[/, end: /\](-*)'/ }),
            { begin: '"', end: '"', relevance: 0 },
            { begin: "'", end: "'", relevance: 0 },
          ],
        },
        {
          relevance: 0,
          variants: [
            { scope: { 1: "operator", 2: "number" }, match: [r, a] },
            { scope: { 1: "operator", 2: "number" }, match: [/%[^%]*%/, a] },
            { scope: { 1: "punctuation", 2: "number" }, match: [o, a] },
            { scope: { 2: "number" }, match: [/[^a-zA-Z0-9._]|^/, a] },
          ],
        },
        { scope: { 3: "operator" }, match: [n, /\s+/, /<-/, /\s+/] },
        {
          scope: "operator",
          relevance: 0,
          variants: [{ match: r }, { match: /%[^%]*%/ }],
        },
        { scope: "punctuation", relevance: 0, match: o },
        { begin: "`", end: "`", contains: [{ begin: /\\./ }] },
      ],
    };
  }
  function Z2(e) {
    let t = e.regex,
      n =
        "([a-zA-Z_]\\w*[!?=]?|[-+~]@|<<|>>|=~|===?|<=>|[<>]=?|\\*\\*|[-/+%^&*~`|]|\\[\\]=?)",
      a = t.either(/\b([A-Z]+[a-z0-9]+)+/, /\b([A-Z]+[a-z0-9]+)+[A-Z]+/),
      r = t.concat(a, /(::\w+)*/),
      i = {
        "variable.constant": ["__FILE__", "__LINE__", "__ENCODING__"],
        "variable.language": ["self", "super"],
        keyword: [
          "alias",
          "and",
          "begin",
          "BEGIN",
          "break",
          "case",
          "class",
          "defined",
          "do",
          "else",
          "elsif",
          "end",
          "END",
          "ensure",
          "for",
          "if",
          "in",
          "module",
          "next",
          "not",
          "or",
          "redo",
          "require",
          "rescue",
          "retry",
          "return",
          "then",
          "undef",
          "unless",
          "until",
          "when",
          "while",
          "yield",
          ...[
            "include",
            "extend",
            "prepend",
            "public",
            "private",
            "protected",
            "raise",
            "throw",
          ],
        ],
        built_in: [
          "proc",
          "lambda",
          "attr_accessor",
          "attr_reader",
          "attr_writer",
          "define_method",
          "private_constant",
          "module_function",
        ],
        literal: ["true", "false", "nil"],
      },
      l = { className: "doctag", begin: "@[A-Za-z]+" },
      s = { begin: "#<", end: ">" },
      u = [
        e.COMMENT("#", "$", { contains: [l] }),
        e.COMMENT("^=begin", "^=end", { contains: [l], relevance: 10 }),
        e.COMMENT("^__END__", e.MATCH_NOTHING_RE),
      ],
      c = { className: "subst", begin: /#\{/, end: /\}/, keywords: i },
      d = {
        className: "string",
        contains: [e.BACKSLASH_ESCAPE, c],
        variants: [
          { begin: /'/, end: /'/ },
          { begin: /"/, end: /"/ },
          { begin: /`/, end: /`/ },
          { begin: /%[qQwWx]?\(/, end: /\)/ },
          { begin: /%[qQwWx]?\[/, end: /\]/ },
          { begin: /%[qQwWx]?\{/, end: /\}/ },
          { begin: /%[qQwWx]?</, end: />/ },
          { begin: /%[qQwWx]?\//, end: /\// },
          { begin: /%[qQwWx]?%/, end: /%/ },
          { begin: /%[qQwWx]?-/, end: /-/ },
          { begin: /%[qQwWx]?\|/, end: /\|/ },
          { begin: /\B\?(\\\d{1,3})/ },
          { begin: /\B\?(\\x[A-Fa-f0-9]{1,2})/ },
          { begin: /\B\?(\\u\{?[A-Fa-f0-9]{1,6}\}?)/ },
          { begin: /\B\?(\\M-\\C-|\\M-\\c|\\c\\M-|\\M-|\\C-\\M-)[\x20-\x7e]/ },
          { begin: /\B\?\\(c|C-)[\x20-\x7e]/ },
          { begin: /\B\?\\?\S/ },
          {
            begin: t.concat(
              /<<[-~]?'?/,
              t.lookahead(/(\w+)(?=\W)[^\n]*\n(?:[^\n]*\n)*?\s*\1\b/)
            ),
            contains: [
              e.END_SAME_AS_BEGIN({
                begin: /(\w+)/,
                end: /(\w+)/,
                contains: [e.BACKSLASH_ESCAPE, c],
              }),
            ],
          },
        ],
      },
      p = "[1-9](_?[0-9])*|0",
      m = "[0-9](_?[0-9])*",
      f = {
        className: "number",
        relevance: 0,
        variants: [
          { begin: `\\b(${p})(\\.(${m}))?([eE][+-]?(${m})|r)?i?\\b` },
          { begin: "\\b0[dD][0-9](_?[0-9])*r?i?\\b" },
          { begin: "\\b0[bB][0-1](_?[0-1])*r?i?\\b" },
          { begin: "\\b0[oO][0-7](_?[0-7])*r?i?\\b" },
          { begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*r?i?\\b" },
          { begin: "\\b0(_?[0-7])+r?i?\\b" },
        ],
      },
      v = {
        variants: [
          { match: /\(\)/ },
          {
            className: "params",
            begin: /\(/,
            end: /(?=\))/,
            excludeBegin: !0,
            endsParent: !0,
            keywords: i,
          },
        ],
      },
      E = [
        d,
        {
          variants: [
            { match: [/class\s+/, r, /\s+<\s+/, r] },
            { match: [/\b(class|module)\s+/, r] },
          ],
          scope: { 2: "title.class", 4: "title.class.inherited" },
          keywords: i,
        },
        {
          match: [/(include|extend)\s+/, r],
          scope: { 2: "title.class" },
          keywords: i,
        },
        { relevance: 0, match: [r, /\.new[. (]/], scope: { 1: "title.class" } },
        {
          relevance: 0,
          match: /\b[A-Z][A-Z_0-9]+\b/,
          className: "variable.constant",
        },
        { relevance: 0, match: a, scope: "title.class" },
        {
          match: [/def/, /\s+/, n],
          scope: { 1: "keyword", 3: "title.function" },
          contains: [v],
        },
        { begin: e.IDENT_RE + "::" },
        {
          className: "symbol",
          begin: e.UNDERSCORE_IDENT_RE + "(!|\\?)?:",
          relevance: 0,
        },
        {
          className: "symbol",
          begin: ":(?!\\s)",
          contains: [d, { begin: n }],
          relevance: 0,
        },
        f,
        {
          className: "variable",
          begin: "(\\$\\W)|((\\$|@@?)(\\w+))(?=[^@$?])(?![A-Za-z])(?![@$?'])",
        },
        {
          className: "params",
          begin: /\|/,
          end: /\|/,
          excludeBegin: !0,
          excludeEnd: !0,
          relevance: 0,
          keywords: i,
        },
        {
          begin: "(" + e.RE_STARTERS_RE + "|unless)\\s*",
          keywords: "unless",
          contains: [
            {
              className: "regexp",
              contains: [e.BACKSLASH_ESCAPE, c],
              illegal: /\n/,
              variants: [
                { begin: "/", end: "/[a-z]*" },
                { begin: /%r\{/, end: /\}[a-z]*/ },
                { begin: "%r\\(", end: "\\)[a-z]*" },
                { begin: "%r!", end: "![a-z]*" },
                { begin: "%r\\[", end: "\\][a-z]*" },
              ],
            },
          ].concat(s, u),
          relevance: 0,
        },
      ].concat(s, u);
    (c.contains = E), (v.contains = E);
    let z = "[>?]>",
      k = "[\\w#]+\\(\\w+\\):\\d+:\\d+[>*]",
      O = "(\\w+-)?\\d+\\.\\d+\\.\\d+(p\\d+)?[^\\d][^>]+>",
      K = [
        { begin: /^\s*=>/, starts: { end: "$", contains: E } },
        {
          className: "meta.prompt",
          begin: "^(" + z + "|" + k + "|" + O + ")(?=[ ])",
          starts: { end: "$", keywords: i, contains: E },
        },
      ];
    return (
      u.unshift(s),
      {
        name: "Ruby",
        aliases: ["rb", "gemspec", "podspec", "thor", "irb"],
        keywords: i,
        illegal: /\/\*/,
        contains: [e.SHEBANG({ binary: "ruby" })].concat(K).concat(u).concat(E),
      }
    );
  }
  function X2(e) {
    let t = e.regex,
      n = {
        className: "title.function.invoke",
        relevance: 0,
        begin: t.concat(/\b/, /(?!let\b)/, e.IDENT_RE, t.lookahead(/\s*\(/)),
      },
      a = "([ui](8|16|32|64|128|size)|f(32|64))?",
      r = [
        "abstract",
        "as",
        "async",
        "await",
        "become",
        "box",
        "break",
        "const",
        "continue",
        "crate",
        "do",
        "dyn",
        "else",
        "enum",
        "extern",
        "false",
        "final",
        "fn",
        "for",
        "if",
        "impl",
        "in",
        "let",
        "loop",
        "macro",
        "match",
        "mod",
        "move",
        "mut",
        "override",
        "priv",
        "pub",
        "ref",
        "return",
        "self",
        "Self",
        "static",
        "struct",
        "super",
        "trait",
        "true",
        "try",
        "type",
        "typeof",
        "unsafe",
        "unsized",
        "use",
        "virtual",
        "where",
        "while",
        "yield",
      ],
      o = ["true", "false", "Some", "None", "Ok", "Err"],
      i = [
        "drop ",
        "Copy",
        "Send",
        "Sized",
        "Sync",
        "Drop",
        "Fn",
        "FnMut",
        "FnOnce",
        "ToOwned",
        "Clone",
        "Debug",
        "PartialEq",
        "PartialOrd",
        "Eq",
        "Ord",
        "AsRef",
        "AsMut",
        "Into",
        "From",
        "Default",
        "Iterator",
        "Extend",
        "IntoIterator",
        "DoubleEndedIterator",
        "ExactSizeIterator",
        "SliceConcatExt",
        "ToString",
        "assert!",
        "assert_eq!",
        "bitflags!",
        "bytes!",
        "cfg!",
        "col!",
        "concat!",
        "concat_idents!",
        "debug_assert!",
        "debug_assert_eq!",
        "env!",
        "panic!",
        "file!",
        "format!",
        "format_args!",
        "include_bytes!",
        "include_str!",
        "line!",
        "local_data_key!",
        "module_path!",
        "option_env!",
        "print!",
        "println!",
        "select!",
        "stringify!",
        "try!",
        "unimplemented!",
        "unreachable!",
        "vec!",
        "write!",
        "writeln!",
        "macro_rules!",
        "assert_ne!",
        "debug_assert_ne!",
      ],
      l = [
        "i8",
        "i16",
        "i32",
        "i64",
        "i128",
        "isize",
        "u8",
        "u16",
        "u32",
        "u64",
        "u128",
        "usize",
        "f32",
        "f64",
        "str",
        "char",
        "bool",
        "Box",
        "Option",
        "Result",
        "String",
        "Vec",
      ];
    return {
      name: "Rust",
      aliases: ["rs"],
      keywords: {
        $pattern: e.IDENT_RE + "!?",
        type: l,
        keyword: r,
        literal: o,
        built_in: i,
      },
      illegal: "</",
      contains: [
        e.C_LINE_COMMENT_MODE,
        e.COMMENT("/\\*", "\\*/", { contains: ["self"] }),
        e.inherit(e.QUOTE_STRING_MODE, { begin: /b?"/, illegal: null }),
        {
          className: "string",
          variants: [
            { begin: /b?r(#*)"(.|\n)*?"\1(?!#)/ },
            { begin: /b?'\\?(x\w{2}|u\w{4}|U\w{8}|.)'/ },
          ],
        },
        { className: "symbol", begin: /'[a-zA-Z_][a-zA-Z0-9_]*/ },
        {
          className: "number",
          variants: [
            { begin: "\\b0b([01_]+)" + a },
            { begin: "\\b0o([0-7_]+)" + a },
            { begin: "\\b0x([A-Fa-f0-9_]+)" + a },
            { begin: "\\b(\\d[\\d_]*(\\.[0-9_]+)?([eE][+-]?[0-9_]+)?)" + a },
          ],
          relevance: 0,
        },
        {
          begin: [/fn/, /\s+/, e.UNDERSCORE_IDENT_RE],
          className: { 1: "keyword", 3: "title.function" },
        },
        {
          className: "meta",
          begin: "#!?\\[",
          end: "\\]",
          contains: [{ className: "string", begin: /"/, end: /"/ }],
        },
        {
          begin: [/let/, /\s+/, /(?:mut\s+)?/, e.UNDERSCORE_IDENT_RE],
          className: { 1: "keyword", 3: "keyword", 4: "variable" },
        },
        {
          begin: [/for/, /\s+/, e.UNDERSCORE_IDENT_RE, /\s+/, /in/],
          className: { 1: "keyword", 3: "variable", 5: "keyword" },
        },
        {
          begin: [/type/, /\s+/, e.UNDERSCORE_IDENT_RE],
          className: { 1: "keyword", 3: "title.class" },
        },
        {
          begin: [
            /(?:trait|enum|struct|union|impl|for)/,
            /\s+/,
            e.UNDERSCORE_IDENT_RE,
          ],
          className: { 1: "keyword", 3: "title.class" },
        },
        {
          begin: e.IDENT_RE + "::",
          keywords: { keyword: "Self", built_in: i, type: l },
        },
        { className: "punctuation", begin: "->" },
        n,
      ],
    };
  }
  var D6 = (e) => ({
      IMPORTANT: { scope: "meta", begin: "!important" },
      BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
      HEXCOLOR: {
        scope: "number",
        begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/,
      },
      FUNCTION_DISPATCH: { className: "built_in", begin: /[\w-]+(?=\()/ },
      ATTRIBUTE_SELECTOR_MODE: {
        scope: "selector-attr",
        begin: /\[/,
        end: /\]/,
        illegal: "$",
        contains: [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE],
      },
      CSS_NUMBER_MODE: {
        scope: "number",
        begin:
          e.NUMBER_RE +
          "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
        relevance: 0,
      },
      CSS_VARIABLE: { className: "attr", begin: /--[A-Za-z][A-Za-z0-9_-]*/ },
    }),
    P6 = [
      "a",
      "abbr",
      "address",
      "article",
      "aside",
      "audio",
      "b",
      "blockquote",
      "body",
      "button",
      "canvas",
      "caption",
      "cite",
      "code",
      "dd",
      "del",
      "details",
      "dfn",
      "div",
      "dl",
      "dt",
      "em",
      "fieldset",
      "figcaption",
      "figure",
      "footer",
      "form",
      "h1",
      "h2",
      "h3",
      "h4",
      "h5",
      "h6",
      "header",
      "hgroup",
      "html",
      "i",
      "iframe",
      "img",
      "input",
      "ins",
      "kbd",
      "label",
      "legend",
      "li",
      "main",
      "mark",
      "menu",
      "nav",
      "object",
      "ol",
      "p",
      "q",
      "quote",
      "samp",
      "section",
      "span",
      "strong",
      "summary",
      "sup",
      "table",
      "tbody",
      "td",
      "textarea",
      "tfoot",
      "th",
      "thead",
      "time",
      "tr",
      "ul",
      "var",
      "video",
    ],
    F6 = [
      "any-hover",
      "any-pointer",
      "aspect-ratio",
      "color",
      "color-gamut",
      "color-index",
      "device-aspect-ratio",
      "device-height",
      "device-width",
      "display-mode",
      "forced-colors",
      "grid",
      "height",
      "hover",
      "inverted-colors",
      "monochrome",
      "orientation",
      "overflow-block",
      "overflow-inline",
      "pointer",
      "prefers-color-scheme",
      "prefers-contrast",
      "prefers-reduced-motion",
      "prefers-reduced-transparency",
      "resolution",
      "scan",
      "scripting",
      "update",
      "width",
      "min-width",
      "max-width",
      "min-height",
      "max-height",
    ],
    V6 = [
      "active",
      "any-link",
      "blank",
      "checked",
      "current",
      "default",
      "defined",
      "dir",
      "disabled",
      "drop",
      "empty",
      "enabled",
      "first",
      "first-child",
      "first-of-type",
      "fullscreen",
      "future",
      "focus",
      "focus-visible",
      "focus-within",
      "has",
      "host",
      "host-context",
      "hover",
      "indeterminate",
      "in-range",
      "invalid",
      "is",
      "lang",
      "last-child",
      "last-of-type",
      "left",
      "link",
      "local-link",
      "not",
      "nth-child",
      "nth-col",
      "nth-last-child",
      "nth-last-col",
      "nth-last-of-type",
      "nth-of-type",
      "only-child",
      "only-of-type",
      "optional",
      "out-of-range",
      "past",
      "placeholder-shown",
      "read-only",
      "read-write",
      "required",
      "right",
      "root",
      "scope",
      "target",
      "target-within",
      "user-invalid",
      "valid",
      "visited",
      "where",
    ],
    B6 = [
      "after",
      "backdrop",
      "before",
      "cue",
      "cue-region",
      "first-letter",
      "first-line",
      "grammar-error",
      "marker",
      "part",
      "placeholder",
      "selection",
      "slotted",
      "spelling-error",
    ],
    U6 = [
      "align-content",
      "align-items",
      "align-self",
      "all",
      "animation",
      "animation-delay",
      "animation-direction",
      "animation-duration",
      "animation-fill-mode",
      "animation-iteration-count",
      "animation-name",
      "animation-play-state",
      "animation-timing-function",
      "backface-visibility",
      "background",
      "background-attachment",
      "background-blend-mode",
      "background-clip",
      "background-color",
      "background-image",
      "background-origin",
      "background-position",
      "background-repeat",
      "background-size",
      "block-size",
      "border",
      "border-block",
      "border-block-color",
      "border-block-end",
      "border-block-end-color",
      "border-block-end-style",
      "border-block-end-width",
      "border-block-start",
      "border-block-start-color",
      "border-block-start-style",
      "border-block-start-width",
      "border-block-style",
      "border-block-width",
      "border-bottom",
      "border-bottom-color",
      "border-bottom-left-radius",
      "border-bottom-right-radius",
      "border-bottom-style",
      "border-bottom-width",
      "border-collapse",
      "border-color",
      "border-image",
      "border-image-outset",
      "border-image-repeat",
      "border-image-slice",
      "border-image-source",
      "border-image-width",
      "border-inline",
      "border-inline-color",
      "border-inline-end",
      "border-inline-end-color",
      "border-inline-end-style",
      "border-inline-end-width",
      "border-inline-start",
      "border-inline-start-color",
      "border-inline-start-style",
      "border-inline-start-width",
      "border-inline-style",
      "border-inline-width",
      "border-left",
      "border-left-color",
      "border-left-style",
      "border-left-width",
      "border-radius",
      "border-right",
      "border-right-color",
      "border-right-style",
      "border-right-width",
      "border-spacing",
      "border-style",
      "border-top",
      "border-top-color",
      "border-top-left-radius",
      "border-top-right-radius",
      "border-top-style",
      "border-top-width",
      "border-width",
      "bottom",
      "box-decoration-break",
      "box-shadow",
      "box-sizing",
      "break-after",
      "break-before",
      "break-inside",
      "caption-side",
      "caret-color",
      "clear",
      "clip",
      "clip-path",
      "clip-rule",
      "color",
      "column-count",
      "column-fill",
      "column-gap",
      "column-rule",
      "column-rule-color",
      "column-rule-style",
      "column-rule-width",
      "column-span",
      "column-width",
      "columns",
      "contain",
      "content",
      "content-visibility",
      "counter-increment",
      "counter-reset",
      "cue",
      "cue-after",
      "cue-before",
      "cursor",
      "direction",
      "display",
      "empty-cells",
      "filter",
      "flex",
      "flex-basis",
      "flex-direction",
      "flex-flow",
      "flex-grow",
      "flex-shrink",
      "flex-wrap",
      "float",
      "flow",
      "font",
      "font-display",
      "font-family",
      "font-feature-settings",
      "font-kerning",
      "font-language-override",
      "font-size",
      "font-size-adjust",
      "font-smoothing",
      "font-stretch",
      "font-style",
      "font-synthesis",
      "font-variant",
      "font-variant-caps",
      "font-variant-east-asian",
      "font-variant-ligatures",
      "font-variant-numeric",
      "font-variant-position",
      "font-variation-settings",
      "font-weight",
      "gap",
      "glyph-orientation-vertical",
      "grid",
      "grid-area",
      "grid-auto-columns",
      "grid-auto-flow",
      "grid-auto-rows",
      "grid-column",
      "grid-column-end",
      "grid-column-start",
      "grid-gap",
      "grid-row",
      "grid-row-end",
      "grid-row-start",
      "grid-template",
      "grid-template-areas",
      "grid-template-columns",
      "grid-template-rows",
      "hanging-punctuation",
      "height",
      "hyphens",
      "icon",
      "image-orientation",
      "image-rendering",
      "image-resolution",
      "ime-mode",
      "inline-size",
      "isolation",
      "justify-content",
      "left",
      "letter-spacing",
      "line-break",
      "line-height",
      "list-style",
      "list-style-image",
      "list-style-position",
      "list-style-type",
      "margin",
      "margin-block",
      "margin-block-end",
      "margin-block-start",
      "margin-bottom",
      "margin-inline",
      "margin-inline-end",
      "margin-inline-start",
      "margin-left",
      "margin-right",
      "margin-top",
      "marks",
      "mask",
      "mask-border",
      "mask-border-mode",
      "mask-border-outset",
      "mask-border-repeat",
      "mask-border-slice",
      "mask-border-source",
      "mask-border-width",
      "mask-clip",
      "mask-composite",
      "mask-image",
      "mask-mode",
      "mask-origin",
      "mask-position",
      "mask-repeat",
      "mask-size",
      "mask-type",
      "max-block-size",
      "max-height",
      "max-inline-size",
      "max-width",
      "min-block-size",
      "min-height",
      "min-inline-size",
      "min-width",
      "mix-blend-mode",
      "nav-down",
      "nav-index",
      "nav-left",
      "nav-right",
      "nav-up",
      "none",
      "normal",
      "object-fit",
      "object-position",
      "opacity",
      "order",
      "orphans",
      "outline",
      "outline-color",
      "outline-offset",
      "outline-style",
      "outline-width",
      "overflow",
      "overflow-wrap",
      "overflow-x",
      "overflow-y",
      "padding",
      "padding-block",
      "padding-block-end",
      "padding-block-start",
      "padding-bottom",
      "padding-inline",
      "padding-inline-end",
      "padding-inline-start",
      "padding-left",
      "padding-right",
      "padding-top",
      "page-break-after",
      "page-break-before",
      "page-break-inside",
      "pause",
      "pause-after",
      "pause-before",
      "perspective",
      "perspective-origin",
      "pointer-events",
      "position",
      "quotes",
      "resize",
      "rest",
      "rest-after",
      "rest-before",
      "right",
      "row-gap",
      "scroll-margin",
      "scroll-margin-block",
      "scroll-margin-block-end",
      "scroll-margin-block-start",
      "scroll-margin-bottom",
      "scroll-margin-inline",
      "scroll-margin-inline-end",
      "scroll-margin-inline-start",
      "scroll-margin-left",
      "scroll-margin-right",
      "scroll-margin-top",
      "scroll-padding",
      "scroll-padding-block",
      "scroll-padding-block-end",
      "scroll-padding-block-start",
      "scroll-padding-bottom",
      "scroll-padding-inline",
      "scroll-padding-inline-end",
      "scroll-padding-inline-start",
      "scroll-padding-left",
      "scroll-padding-right",
      "scroll-padding-top",
      "scroll-snap-align",
      "scroll-snap-stop",
      "scroll-snap-type",
      "scrollbar-color",
      "scrollbar-gutter",
      "scrollbar-width",
      "shape-image-threshold",
      "shape-margin",
      "shape-outside",
      "speak",
      "speak-as",
      "src",
      "tab-size",
      "table-layout",
      "text-align",
      "text-align-all",
      "text-align-last",
      "text-combine-upright",
      "text-decoration",
      "text-decoration-color",
      "text-decoration-line",
      "text-decoration-style",
      "text-emphasis",
      "text-emphasis-color",
      "text-emphasis-position",
      "text-emphasis-style",
      "text-indent",
      "text-justify",
      "text-orientation",
      "text-overflow",
      "text-rendering",
      "text-shadow",
      "text-transform",
      "text-underline-position",
      "top",
      "transform",
      "transform-box",
      "transform-origin",
      "transform-style",
      "transition",
      "transition-delay",
      "transition-duration",
      "transition-property",
      "transition-timing-function",
      "unicode-bidi",
      "vertical-align",
      "visibility",
      "voice-balance",
      "voice-duration",
      "voice-family",
      "voice-pitch",
      "voice-range",
      "voice-rate",
      "voice-stress",
      "voice-volume",
      "white-space",
      "widows",
      "width",
      "will-change",
      "word-break",
      "word-spacing",
      "word-wrap",
      "writing-mode",
      "z-index",
    ].reverse();
  function J2(e) {
    let t = D6(e),
      n = B6,
      a = V6,
      r = "@[a-z-]+",
      o = "and or not only",
      l = {
        className: "variable",
        begin: "(\\$" + "[a-zA-Z-][a-zA-Z0-9_-]*" + ")\\b",
        relevance: 0,
      };
    return {
      name: "SCSS",
      case_insensitive: !0,
      illegal: "[=/|']",
      contains: [
        e.C_LINE_COMMENT_MODE,
        e.C_BLOCK_COMMENT_MODE,
        t.CSS_NUMBER_MODE,
        { className: "selector-id", begin: "#[A-Za-z0-9_-]+", relevance: 0 },
        {
          className: "selector-class",
          begin: "\\.[A-Za-z0-9_-]+",
          relevance: 0,
        },
        t.ATTRIBUTE_SELECTOR_MODE,
        {
          className: "selector-tag",
          begin: "\\b(" + P6.join("|") + ")\\b",
          relevance: 0,
        },
        { className: "selector-pseudo", begin: ":(" + a.join("|") + ")" },
        { className: "selector-pseudo", begin: ":(:)?(" + n.join("|") + ")" },
        l,
        { begin: /\(/, end: /\)/, contains: [t.CSS_NUMBER_MODE] },
        t.CSS_VARIABLE,
        { className: "attribute", begin: "\\b(" + U6.join("|") + ")\\b" },
        {
          begin:
            "\\b(whitespace|wait|w-resize|visible|vertical-text|vertical-ideographic|uppercase|upper-roman|upper-alpha|underline|transparent|top|thin|thick|text|text-top|text-bottom|tb-rl|table-header-group|table-footer-group|sw-resize|super|strict|static|square|solid|small-caps|separate|se-resize|scroll|s-resize|rtl|row-resize|ridge|right|repeat|repeat-y|repeat-x|relative|progress|pointer|overline|outside|outset|oblique|nowrap|not-allowed|normal|none|nw-resize|no-repeat|no-drop|newspaper|ne-resize|n-resize|move|middle|medium|ltr|lr-tb|lowercase|lower-roman|lower-alpha|loose|list-item|line|line-through|line-edge|lighter|left|keep-all|justify|italic|inter-word|inter-ideograph|inside|inset|inline|inline-block|inherit|inactive|ideograph-space|ideograph-parenthesis|ideograph-numeric|ideograph-alpha|horizontal|hidden|help|hand|groove|fixed|ellipsis|e-resize|double|dotted|distribute|distribute-space|distribute-letter|distribute-all-lines|disc|disabled|default|decimal|dashed|crosshair|collapse|col-resize|circle|char|center|capitalize|break-word|break-all|bottom|both|bolder|bold|block|bidi-override|below|baseline|auto|always|all-scroll|absolute|table|table-cell)\\b",
        },
        {
          begin: /:/,
          end: /[;}{]/,
          relevance: 0,
          contains: [
            t.BLOCK_COMMENT,
            l,
            t.HEXCOLOR,
            t.CSS_NUMBER_MODE,
            e.QUOTE_STRING_MODE,
            e.APOS_STRING_MODE,
            t.IMPORTANT,
            t.FUNCTION_DISPATCH,
          ],
        },
        {
          begin: "@(page|font-face)",
          keywords: { $pattern: r, keyword: "@page @font-face" },
        },
        {
          begin: "@",
          end: "[{;]",
          returnBegin: !0,
          keywords: {
            $pattern: /[a-z-]+/,
            keyword: o,
            attribute: F6.join(" "),
          },
          contains: [
            { begin: r, className: "keyword" },
            { begin: /[a-z-]+(?=:)/, className: "attribute" },
            l,
            e.QUOTE_STRING_MODE,
            e.APOS_STRING_MODE,
            t.HEXCOLOR,
            t.CSS_NUMBER_MODE,
          ],
        },
        t.FUNCTION_DISPATCH,
      ],
    };
  }
  function el(e) {
    return {
      name: "Shell Session",
      aliases: ["console", "shellsession"],
      contains: [
        {
          className: "meta.prompt",
          begin: /^\s{0,3}[/~\w\d[\]()@-]*[>%$#][ ]?/,
          starts: { end: /[^\\](?=\s*$)/, subLanguage: "bash" },
        },
      ],
    };
  }
  function tl(e) {
    let t = e.regex,
      n = e.COMMENT("--", "$"),
      a = {
        className: "string",
        variants: [{ begin: /'/, end: /'/, contains: [{ begin: /''/ }] }],
      },
      r = { begin: /"/, end: /"/, contains: [{ begin: /""/ }] },
      o = ["true", "false", "unknown"],
      i = [
        "double precision",
        "large object",
        "with timezone",
        "without timezone",
      ],
      l = [
        "bigint",
        "binary",
        "blob",
        "boolean",
        "char",
        "character",
        "clob",
        "date",
        "dec",
        "decfloat",
        "decimal",
        "float",
        "int",
        "integer",
        "interval",
        "nchar",
        "nclob",
        "national",
        "numeric",
        "real",
        "row",
        "smallint",
        "time",
        "timestamp",
        "varchar",
        "varying",
        "varbinary",
      ],
      s = ["add", "asc", "collation", "desc", "final", "first", "last", "view"],
      u = [
        "abs",
        "acos",
        "all",
        "allocate",
        "alter",
        "and",
        "any",
        "are",
        "array",
        "array_agg",
        "array_max_cardinality",
        "as",
        "asensitive",
        "asin",
        "asymmetric",
        "at",
        "atan",
        "atomic",
        "authorization",
        "avg",
        "begin",
        "begin_frame",
        "begin_partition",
        "between",
        "bigint",
        "binary",
        "blob",
        "boolean",
        "both",
        "by",
        "call",
        "called",
        "cardinality",
        "cascaded",
        "case",
        "cast",
        "ceil",
        "ceiling",
        "char",
        "char_length",
        "character",
        "character_length",
        "check",
        "classifier",
        "clob",
        "close",
        "coalesce",
        "collate",
        "collect",
        "column",
        "commit",
        "condition",
        "connect",
        "constraint",
        "contains",
        "convert",
        "copy",
        "corr",
        "corresponding",
        "cos",
        "cosh",
        "count",
        "covar_pop",
        "covar_samp",
        "create",
        "cross",
        "cube",
        "cume_dist",
        "current",
        "current_catalog",
        "current_date",
        "current_default_transform_group",
        "current_path",
        "current_role",
        "current_row",
        "current_schema",
        "current_time",
        "current_timestamp",
        "current_path",
        "current_role",
        "current_transform_group_for_type",
        "current_user",
        "cursor",
        "cycle",
        "date",
        "day",
        "deallocate",
        "dec",
        "decimal",
        "decfloat",
        "declare",
        "default",
        "define",
        "delete",
        "dense_rank",
        "deref",
        "describe",
        "deterministic",
        "disconnect",
        "distinct",
        "double",
        "drop",
        "dynamic",
        "each",
        "element",
        "else",
        "empty",
        "end",
        "end_frame",
        "end_partition",
        "end-exec",
        "equals",
        "escape",
        "every",
        "except",
        "exec",
        "execute",
        "exists",
        "exp",
        "external",
        "extract",
        "false",
        "fetch",
        "filter",
        "first_value",
        "float",
        "floor",
        "for",
        "foreign",
        "frame_row",
        "free",
        "from",
        "full",
        "function",
        "fusion",
        "get",
        "global",
        "grant",
        "group",
        "grouping",
        "groups",
        "having",
        "hold",
        "hour",
        "identity",
        "in",
        "indicator",
        "initial",
        "inner",
        "inout",
        "insensitive",
        "insert",
        "int",
        "integer",
        "intersect",
        "intersection",
        "interval",
        "into",
        "is",
        "join",
        "json_array",
        "json_arrayagg",
        "json_exists",
        "json_object",
        "json_objectagg",
        "json_query",
        "json_table",
        "json_table_primitive",
        "json_value",
        "lag",
        "language",
        "large",
        "last_value",
        "lateral",
        "lead",
        "leading",
        "left",
        "like",
        "like_regex",
        "listagg",
        "ln",
        "local",
        "localtime",
        "localtimestamp",
        "log",
        "log10",
        "lower",
        "match",
        "match_number",
        "match_recognize",
        "matches",
        "max",
        "member",
        "merge",
        "method",
        "min",
        "minute",
        "mod",
        "modifies",
        "module",
        "month",
        "multiset",
        "national",
        "natural",
        "nchar",
        "nclob",
        "new",
        "no",
        "none",
        "normalize",
        "not",
        "nth_value",
        "ntile",
        "null",
        "nullif",
        "numeric",
        "octet_length",
        "occurrences_regex",
        "of",
        "offset",
        "old",
        "omit",
        "on",
        "one",
        "only",
        "open",
        "or",
        "order",
        "out",
        "outer",
        "over",
        "overlaps",
        "overlay",
        "parameter",
        "partition",
        "pattern",
        "per",
        "percent",
        "percent_rank",
        "percentile_cont",
        "percentile_disc",
        "period",
        "portion",
        "position",
        "position_regex",
        "power",
        "precedes",
        "precision",
        "prepare",
        "primary",
        "procedure",
        "ptf",
        "range",
        "rank",
        "reads",
        "real",
        "recursive",
        "ref",
        "references",
        "referencing",
        "regr_avgx",
        "regr_avgy",
        "regr_count",
        "regr_intercept",
        "regr_r2",
        "regr_slope",
        "regr_sxx",
        "regr_sxy",
        "regr_syy",
        "release",
        "result",
        "return",
        "returns",
        "revoke",
        "right",
        "rollback",
        "rollup",
        "row",
        "row_number",
        "rows",
        "running",
        "savepoint",
        "scope",
        "scroll",
        "search",
        "second",
        "seek",
        "select",
        "sensitive",
        "session_user",
        "set",
        "show",
        "similar",
        "sin",
        "sinh",
        "skip",
        "smallint",
        "some",
        "specific",
        "specifictype",
        "sql",
        "sqlexception",
        "sqlstate",
        "sqlwarning",
        "sqrt",
        "start",
        "static",
        "stddev_pop",
        "stddev_samp",
        "submultiset",
        "subset",
        "substring",
        "substring_regex",
        "succeeds",
        "sum",
        "symmetric",
        "system",
        "system_time",
        "system_user",
        "table",
        "tablesample",
        "tan",
        "tanh",
        "then",
        "time",
        "timestamp",
        "timezone_hour",
        "timezone_minute",
        "to",
        "trailing",
        "translate",
        "translate_regex",
        "translation",
        "treat",
        "trigger",
        "trim",
        "trim_array",
        "true",
        "truncate",
        "uescape",
        "union",
        "unique",
        "unknown",
        "unnest",
        "update",
        "upper",
        "user",
        "using",
        "value",
        "values",
        "value_of",
        "var_pop",
        "var_samp",
        "varbinary",
        "varchar",
        "varying",
        "versioning",
        "when",
        "whenever",
        "where",
        "width_bucket",
        "window",
        "with",
        "within",
        "without",
        "year",
      ],
      c = [
        "abs",
        "acos",
        "array_agg",
        "asin",
        "atan",
        "avg",
        "cast",
        "ceil",
        "ceiling",
        "coalesce",
        "corr",
        "cos",
        "cosh",
        "count",
        "covar_pop",
        "covar_samp",
        "cume_dist",
        "dense_rank",
        "deref",
        "element",
        "exp",
        "extract",
        "first_value",
        "floor",
        "json_array",
        "json_arrayagg",
        "json_exists",
        "json_object",
        "json_objectagg",
        "json_query",
        "json_table",
        "json_table_primitive",
        "json_value",
        "lag",
        "last_value",
        "lead",
        "listagg",
        "ln",
        "log",
        "log10",
        "lower",
        "max",
        "min",
        "mod",
        "nth_value",
        "ntile",
        "nullif",
        "percent_rank",
        "percentile_cont",
        "percentile_disc",
        "position",
        "position_regex",
        "power",
        "rank",
        "regr_avgx",
        "regr_avgy",
        "regr_count",
        "regr_intercept",
        "regr_r2",
        "regr_slope",
        "regr_sxx",
        "regr_sxy",
        "regr_syy",
        "row_number",
        "sin",
        "sinh",
        "sqrt",
        "stddev_pop",
        "stddev_samp",
        "substring",
        "substring_regex",
        "sum",
        "tan",
        "tanh",
        "translate",
        "translate_regex",
        "treat",
        "trim",
        "trim_array",
        "unnest",
        "upper",
        "value_of",
        "var_pop",
        "var_samp",
        "width_bucket",
      ],
      d = [
        "current_catalog",
        "current_date",
        "current_default_transform_group",
        "current_path",
        "current_role",
        "current_schema",
        "current_transform_group_for_type",
        "current_user",
        "session_user",
        "system_time",
        "system_user",
        "current_time",
        "localtime",
        "current_timestamp",
        "localtimestamp",
      ],
      p = [
        "create table",
        "insert into",
        "primary key",
        "foreign key",
        "not null",
        "alter table",
        "add constraint",
        "grouping sets",
        "on overflow",
        "character set",
        "respect nulls",
        "ignore nulls",
        "nulls first",
        "nulls last",
        "depth first",
        "breadth first",
      ],
      m = c,
      f = [...u, ...s].filter((y) => !c.includes(y)),
      v = { className: "variable", begin: /@[a-z0-9]+/ },
      g = {
        className: "operator",
        begin: /[-+*/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?/,
        relevance: 0,
      },
      _ = {
        begin: t.concat(/\b/, t.either(...m), /\s*\(/),
        relevance: 0,
        keywords: { built_in: m },
      };
    function C(y, { exceptions: w, when: M } = {}) {
      let E = M;
      return (
        (w = w || []),
        y.map((z) =>
          z.match(/\|\d+$/) || w.includes(z) ? z : E(z) ? `${z}|0` : z
        )
      );
    }
    return {
      name: "SQL",
      case_insensitive: !0,
      illegal: /[{}]|<\//,
      keywords: {
        $pattern: /\b[\w\.]+/,
        keyword: C(f, { when: (y) => y.length < 3 }),
        literal: o,
        type: l,
        built_in: d,
      },
      contains: [
        {
          begin: t.either(...p),
          relevance: 0,
          keywords: {
            $pattern: /[\w\.]+/,
            keyword: f.concat(p),
            literal: o,
            type: l,
          },
        },
        { className: "type", begin: t.either(...i) },
        _,
        v,
        a,
        r,
        e.C_NUMBER_MODE,
        e.C_BLOCK_COMMENT_MODE,
        n,
        g,
      ],
    };
  }
  function ol(e) {
    return e ? (typeof e == "string" ? e : e.source) : null;
  }
  function W1(e) {
    return Ee("(?=", e, ")");
  }
  function Ee(...e) {
    return e.map((n) => ol(n)).join("");
  }
  function G6(e) {
    let t = e[e.length - 1];
    return typeof t == "object" && t.constructor === Object
      ? (e.splice(e.length - 1, 1), t)
      : {};
  }
  function Ze(...e) {
    return (
      "(" + (G6(e).capture ? "" : "?:") + e.map((a) => ol(a)).join("|") + ")"
    );
  }
  var C0 = (e) => Ee(/\b/, e, /\w$/.test(e) ? /\b/ : /\B/),
    $6 = ["Protocol", "Type"].map(C0),
    nl = ["init", "self"].map(C0),
    q6 = ["Any", "Self"],
    M0 = [
      "actor",
      "any",
      "associatedtype",
      "async",
      "await",
      /as\?/,
      /as!/,
      "as",
      "break",
      "case",
      "catch",
      "class",
      "continue",
      "convenience",
      "default",
      "defer",
      "deinit",
      "didSet",
      "distributed",
      "do",
      "dynamic",
      "else",
      "enum",
      "extension",
      "fallthrough",
      /fileprivate\(set\)/,
      "fileprivate",
      "final",
      "for",
      "func",
      "get",
      "guard",
      "if",
      "import",
      "indirect",
      "infix",
      /init\?/,
      /init!/,
      "inout",
      /internal\(set\)/,
      "internal",
      "in",
      "is",
      "isolated",
      "nonisolated",
      "lazy",
      "let",
      "mutating",
      "nonmutating",
      /open\(set\)/,
      "open",
      "operator",
      "optional",
      "override",
      "postfix",
      "precedencegroup",
      "prefix",
      /private\(set\)/,
      "private",
      "protocol",
      /public\(set\)/,
      "public",
      "repeat",
      "required",
      "rethrows",
      "return",
      "set",
      "some",
      "static",
      "struct",
      "subscript",
      "super",
      "switch",
      "throws",
      "throw",
      /try\?/,
      /try!/,
      "try",
      "typealias",
      /unowned\(safe\)/,
      /unowned\(unsafe\)/,
      "unowned",
      "var",
      "weak",
      "where",
      "while",
      "willSet",
    ],
    al = ["false", "nil", "true"],
    W6 = [
      "assignment",
      "associativity",
      "higherThan",
      "left",
      "lowerThan",
      "none",
      "right",
    ],
    K6 = [
      "#colorLiteral",
      "#column",
      "#dsohandle",
      "#else",
      "#elseif",
      "#endif",
      "#error",
      "#file",
      "#fileID",
      "#fileLiteral",
      "#filePath",
      "#function",
      "#if",
      "#imageLiteral",
      "#keyPath",
      "#line",
      "#selector",
      "#sourceLocation",
      "#warn_unqualified_access",
      "#warning",
    ],
    rl = [
      "abs",
      "all",
      "any",
      "assert",
      "assertionFailure",
      "debugPrint",
      "dump",
      "fatalError",
      "getVaList",
      "isKnownUniquelyReferenced",
      "max",
      "min",
      "numericCast",
      "pointwiseMax",
      "pointwiseMin",
      "precondition",
      "preconditionFailure",
      "print",
      "readLine",
      "repeatElement",
      "sequence",
      "stride",
      "swap",
      "swift_unboxFromSwiftValueWithType",
      "transcode",
      "type",
      "unsafeBitCast",
      "unsafeDowncast",
      "withExtendedLifetime",
      "withUnsafeMutablePointer",
      "withUnsafePointer",
      "withVaList",
      "withoutActuallyEscaping",
      "zip",
    ],
    il = Ze(
      /[/=\-+!*%<>&|^~?]/,
      /[\u00A1-\u00A7]/,
      /[\u00A9\u00AB]/,
      /[\u00AC\u00AE]/,
      /[\u00B0\u00B1]/,
      /[\u00B6\u00BB\u00BF\u00D7\u00F7]/,
      /[\u2016-\u2017]/,
      /[\u2020-\u2027]/,
      /[\u2030-\u203E]/,
      /[\u2041-\u2053]/,
      /[\u2055-\u205E]/,
      /[\u2190-\u23FF]/,
      /[\u2500-\u2775]/,
      /[\u2794-\u2BFF]/,
      /[\u2E00-\u2E7F]/,
      /[\u3001-\u3003]/,
      /[\u3008-\u3020]/,
      /[\u3030]/
    ),
    ll = Ze(
      il,
      /[\u0300-\u036F]/,
      /[\u1DC0-\u1DFF]/,
      /[\u20D0-\u20FF]/,
      /[\uFE00-\uFE0F]/,
      /[\uFE20-\uFE2F]/
    ),
    z0 = Ee(il, ll, "*"),
    cl = Ze(
      /[a-zA-Z_]/,
      /[\u00A8\u00AA\u00AD\u00AF\u00B2-\u00B5\u00B7-\u00BA]/,
      /[\u00BC-\u00BE\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF]/,
      /[\u0100-\u02FF\u0370-\u167F\u1681-\u180D\u180F-\u1DBF]/,
      /[\u1E00-\u1FFF]/,
      /[\u200B-\u200D\u202A-\u202E\u203F-\u2040\u2054\u2060-\u206F]/,
      /[\u2070-\u20CF\u2100-\u218F\u2460-\u24FF\u2776-\u2793]/,
      /[\u2C00-\u2DFF\u2E80-\u2FFF]/,
      /[\u3004-\u3007\u3021-\u302F\u3031-\u303F\u3040-\uD7FF]/,
      /[\uF900-\uFD3D\uFD40-\uFDCF\uFDF0-\uFE1F\uFE30-\uFE44]/,
      /[\uFE47-\uFEFE\uFF00-\uFFFD]/
    ),
    K1 = Ze(cl, /\d/, /[\u0300-\u036F\u1DC0-\u1DFF\u20D0-\u20FF\uFE20-\uFE2F]/),
    At = Ee(cl, K1, "*"),
    S0 = Ee(/[A-Z]/, K1, "*"),
    j6 = [
      "autoclosure",
      Ee(/convention\(/, Ze("swift", "block", "c"), /\)/),
      "discardableResult",
      "dynamicCallable",
      "dynamicMemberLookup",
      "escaping",
      "frozen",
      "GKInspectable",
      "IBAction",
      "IBDesignable",
      "IBInspectable",
      "IBOutlet",
      "IBSegueAction",
      "inlinable",
      "main",
      "nonobjc",
      "NSApplicationMain",
      "NSCopying",
      "NSManaged",
      Ee(/objc\(/, At, /\)/),
      "objc",
      "objcMembers",
      "propertyWrapper",
      "requires_stored_property_inits",
      "resultBuilder",
      "testable",
      "UIApplicationMain",
      "unknown",
      "usableFromInline",
    ],
    Y6 = [
      "iOS",
      "iOSApplicationExtension",
      "macOS",
      "macOSApplicationExtension",
      "macCatalyst",
      "macCatalystApplicationExtension",
      "watchOS",
      "watchOSApplicationExtension",
      "tvOS",
      "tvOSApplicationExtension",
      "swift",
    ];
  function sl(e) {
    let t = { match: /\s+/, relevance: 0 },
      n = e.COMMENT("/\\*", "\\*/", { contains: ["self"] }),
      a = [e.C_LINE_COMMENT_MODE, n],
      r = { match: [/\./, Ze(...$6, ...nl)], className: { 2: "keyword" } },
      o = { match: Ee(/\./, Ze(...M0)), relevance: 0 },
      i = M0.filter((ae) => typeof ae == "string").concat(["_|0"]),
      l = M0.filter((ae) => typeof ae != "string")
        .concat(q6)
        .map(C0),
      s = { variants: [{ className: "keyword", match: Ze(...l, ...nl) }] },
      u = { $pattern: Ze(/\b\w+/, /#\w+/), keyword: i.concat(K6), literal: al },
      c = [r, o, s],
      d = { match: Ee(/\./, Ze(...rl)), relevance: 0 },
      p = { className: "built_in", match: Ee(/\b/, Ze(...rl), /(?=\()/) },
      m = [d, p],
      f = { match: /->/, relevance: 0 },
      v = {
        className: "operator",
        relevance: 0,
        variants: [{ match: z0 }, { match: `\\.(\\.|${ll})+` }],
      },
      g = [f, v],
      _ = "([0-9]_*)+",
      C = "([0-9a-fA-F]_*)+",
      y = {
        className: "number",
        relevance: 0,
        variants: [
          { match: `\\b(${_})(\\.(${_}))?([eE][+-]?(${_}))?\\b` },
          { match: `\\b0x(${C})(\\.(${C}))?([pP][+-]?(${_}))?\\b` },
          { match: /\b0o([0-7]_*)+\b/ },
          { match: /\b0b([01]_*)+\b/ },
        ],
      },
      w = (ae = "") => ({
        className: "subst",
        variants: [
          { match: Ee(/\\/, ae, /[0\\tnr"']/) },
          { match: Ee(/\\/, ae, /u\{[0-9a-fA-F]{1,8}\}/) },
        ],
      }),
      M = (ae = "") => ({
        className: "subst",
        match: Ee(/\\/, ae, /[\t ]*(?:[\r\n]|\r\n)/),
      }),
      E = (ae = "") => ({
        className: "subst",
        label: "interpol",
        begin: Ee(/\\/, ae, /\(/),
        end: /\)/,
      }),
      z = (ae = "") => ({
        begin: Ee(ae, /"""/),
        end: Ee(/"""/, ae),
        contains: [w(ae), M(ae), E(ae)],
      }),
      k = (ae = "") => ({
        begin: Ee(ae, /"/),
        end: Ee(/"/, ae),
        contains: [w(ae), E(ae)],
      }),
      O = {
        className: "string",
        variants: [
          z(),
          z("#"),
          z("##"),
          z("###"),
          k(),
          k("#"),
          k("##"),
          k("###"),
        ],
      },
      K = { match: Ee(/`/, At, /`/) },
      H = { className: "variable", match: /\$\d+/ },
      V = { className: "variable", match: `\\$${K1}+` },
      I = [K, H, V],
      D = {
        match: /(@|#(un)?)available/,
        className: "keyword",
        starts: {
          contains: [
            { begin: /\(/, end: /\)/, keywords: Y6, contains: [...g, y, O] },
          ],
        },
      },
      J = { className: "keyword", match: Ee(/@/, Ze(...j6)) },
      R = { className: "meta", match: Ee(/@/, At) },
      T = [D, J, R],
      P = {
        match: W1(/\b[A-Z]/),
        relevance: 0,
        contains: [
          {
            className: "type",
            match: Ee(
              /(AV|CA|CF|CG|CI|CL|CM|CN|CT|MK|MP|MTK|MTL|NS|SCN|SK|UI|WK|XC)/,
              K1,
              "+"
            ),
          },
          { className: "type", match: S0, relevance: 0 },
          { match: /[?!]+/, relevance: 0 },
          { match: /\.\.\./, relevance: 0 },
          { match: Ee(/\s+&\s+/, W1(S0)), relevance: 0 },
        ],
      },
      B = {
        begin: /</,
        end: />/,
        keywords: u,
        contains: [...a, ...c, ...T, f, P],
      };
    P.contains.push(B);
    let $ = { match: Ee(At, /\s*:/), keywords: "_|0", relevance: 0 },
      b = {
        begin: /\(/,
        end: /\)/,
        relevance: 0,
        keywords: u,
        contains: ["self", $, ...a, ...c, ...m, ...g, y, O, ...I, ...T, P],
      },
      h = { begin: /</, end: />/, contains: [...a, P] },
      Le = {
        begin: Ze(W1(Ee(At, /\s*:/)), W1(Ee(At, /\s+/, At, /\s*:/))),
        end: /:/,
        relevance: 0,
        contains: [
          { className: "keyword", match: /\b_\b/ },
          { className: "params", match: At },
        ],
      },
      le = {
        begin: /\(/,
        end: /\)/,
        keywords: u,
        contains: [Le, ...a, ...c, ...g, y, O, ...T, P, b],
        endsParent: !0,
        illegal: /["']/,
      },
      me = {
        match: [/func/, /\s+/, Ze(K.match, At, z0)],
        className: { 1: "keyword", 3: "title.function" },
        contains: [h, le, t],
        illegal: [/\[/, /%/],
      },
      Ge = {
        match: [/\b(?:subscript|init[?!]?)/, /\s*(?=[<(])/],
        className: { 1: "keyword" },
        contains: [h, le, t],
        illegal: /\[|%/,
      },
      Me = {
        match: [/operator/, /\s+/, z0],
        className: { 1: "keyword", 3: "title" },
      },
      be = {
        begin: [/precedencegroup/, /\s+/, S0],
        className: { 1: "keyword", 3: "title" },
        contains: [P],
        keywords: [...W6, ...al],
        end: /}/,
      };
    for (let ae of O.variants) {
      let ze = ae.contains.find((Te) => Te.label === "interpol");
      ze.keywords = u;
      let Ce = [...c, ...m, ...g, y, O, ...I];
      ze.contains = [
        ...Ce,
        { begin: /\(/, end: /\)/, contains: ["self", ...Ce] },
      ];
    }
    return {
      name: "Swift",
      keywords: u,
      contains: [
        ...a,
        me,
        Ge,
        {
          beginKeywords: "struct protocol class extension enum actor",
          end: "\\{",
          excludeEnd: !0,
          keywords: u,
          contains: [
            e.inherit(e.TITLE_MODE, {
              className: "title.class",
              begin: /[A-Za-z$_][\u00C0-\u02B80-9A-Za-z$_]*/,
            }),
            ...c,
          ],
        },
        Me,
        be,
        { beginKeywords: "import", end: /$/, contains: [...a], relevance: 0 },
        ...c,
        ...m,
        ...g,
        y,
        O,
        ...I,
        ...T,
        P,
        b,
      ],
    };
  }
  var j1 = "[A-Za-z$_][0-9A-Za-z$_]*",
    ul = [
      "as",
      "in",
      "of",
      "if",
      "for",
      "while",
      "finally",
      "var",
      "new",
      "function",
      "do",
      "return",
      "void",
      "else",
      "break",
      "catch",
      "instanceof",
      "with",
      "throw",
      "case",
      "default",
      "try",
      "switch",
      "continue",
      "typeof",
      "delete",
      "let",
      "yield",
      "const",
      "class",
      "debugger",
      "async",
      "await",
      "static",
      "import",
      "from",
      "export",
      "extends",
    ],
    dl = ["true", "false", "null", "undefined", "NaN", "Infinity"],
    pl = [
      "Object",
      "Function",
      "Boolean",
      "Symbol",
      "Math",
      "Date",
      "Number",
      "BigInt",
      "String",
      "RegExp",
      "Array",
      "Float32Array",
      "Float64Array",
      "Int8Array",
      "Uint8Array",
      "Uint8ClampedArray",
      "Int16Array",
      "Int32Array",
      "Uint16Array",
      "Uint32Array",
      "BigInt64Array",
      "BigUint64Array",
      "Set",
      "Map",
      "WeakSet",
      "WeakMap",
      "ArrayBuffer",
      "SharedArrayBuffer",
      "Atomics",
      "DataView",
      "JSON",
      "Promise",
      "Generator",
      "GeneratorFunction",
      "AsyncFunction",
      "Reflect",
      "Proxy",
      "Intl",
      "WebAssembly",
    ],
    ml = [
      "Error",
      "EvalError",
      "InternalError",
      "RangeError",
      "ReferenceError",
      "SyntaxError",
      "TypeError",
      "URIError",
    ],
    hl = [
      "setInterval",
      "setTimeout",
      "clearInterval",
      "clearTimeout",
      "require",
      "exports",
      "eval",
      "isFinite",
      "isNaN",
      "parseFloat",
      "parseInt",
      "decodeURI",
      "decodeURIComponent",
      "encodeURI",
      "encodeURIComponent",
      "escape",
      "unescape",
    ],
    fl = [
      "arguments",
      "this",
      "super",
      "console",
      "window",
      "document",
      "localStorage",
      "module",
      "global",
    ],
    gl = [].concat(hl, pl, ml);
  function Q6(e) {
    let t = e.regex,
      n = (T, { after: P }) => {
        let B = "</" + T[0].slice(1);
        return T.input.indexOf(B, P) !== -1;
      },
      a = j1,
      r = { begin: "<>", end: "</>" },
      o = /<[A-Za-z0-9\\._:-]+\s*\/>/,
      i = {
        begin: /<[A-Za-z0-9\\._:-]+/,
        end: /\/[A-Za-z0-9\\._:-]+>|\/>/,
        isTrulyOpeningTag: (T, P) => {
          let B = T[0].length + T.index,
            $ = T.input[B];
          if ($ === "<" || $ === ",") {
            P.ignoreMatch();
            return;
          }
          $ === ">" && (n(T, { after: B }) || P.ignoreMatch());
          let b,
            h = T.input.substring(B);
          if ((b = h.match(/^\s*=/))) {
            P.ignoreMatch();
            return;
          }
          if ((b = h.match(/^\s+extends\s+/)) && b.index === 0) {
            P.ignoreMatch();
            return;
          }
        },
      },
      l = {
        $pattern: j1,
        keyword: ul,
        literal: dl,
        built_in: gl,
        "variable.language": fl,
      },
      s = "[0-9](_?[0-9])*",
      u = `\\.(${s})`,
      c = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*",
      d = {
        className: "number",
        variants: [
          { begin: `(\\b(${c})((${u})|\\.)?|(${u}))[eE][+-]?(${s})\\b` },
          { begin: `\\b(${c})\\b((${u})\\b|\\.)?|(${u})\\b` },
          { begin: "\\b(0|[1-9](_?[0-9])*)n\\b" },
          { begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b" },
          { begin: "\\b0[bB][0-1](_?[0-1])*n?\\b" },
          { begin: "\\b0[oO][0-7](_?[0-7])*n?\\b" },
          { begin: "\\b0[0-7]+n?\\b" },
        ],
        relevance: 0,
      },
      p = {
        className: "subst",
        begin: "\\$\\{",
        end: "\\}",
        keywords: l,
        contains: [],
      },
      m = {
        begin: "html`",
        end: "",
        starts: {
          end: "`",
          returnEnd: !1,
          contains: [e.BACKSLASH_ESCAPE, p],
          subLanguage: "xml",
        },
      },
      f = {
        begin: "css`",
        end: "",
        starts: {
          end: "`",
          returnEnd: !1,
          contains: [e.BACKSLASH_ESCAPE, p],
          subLanguage: "css",
        },
      },
      v = {
        className: "string",
        begin: "`",
        end: "`",
        contains: [e.BACKSLASH_ESCAPE, p],
      },
      _ = {
        className: "comment",
        variants: [
          e.COMMENT(/\/\*\*(?!\/)/, "\\*/", {
            relevance: 0,
            contains: [
              {
                begin: "(?=@[A-Za-z]+)",
                relevance: 0,
                contains: [
                  { className: "doctag", begin: "@[A-Za-z]+" },
                  {
                    className: "type",
                    begin: "\\{",
                    end: "\\}",
                    excludeEnd: !0,
                    excludeBegin: !0,
                    relevance: 0,
                  },
                  {
                    className: "variable",
                    begin: a + "(?=\\s*(-)|$)",
                    endsParent: !0,
                    relevance: 0,
                  },
                  { begin: /(?=[^\n])\s/, relevance: 0 },
                ],
              },
            ],
          }),
          e.C_BLOCK_COMMENT_MODE,
          e.C_LINE_COMMENT_MODE,
        ],
      },
      C = [
        e.APOS_STRING_MODE,
        e.QUOTE_STRING_MODE,
        m,
        f,
        v,
        { match: /\$\d+/ },
        d,
      ];
    p.contains = C.concat({
      begin: /\{/,
      end: /\}/,
      keywords: l,
      contains: ["self"].concat(C),
    });
    let y = [].concat(_, p.contains),
      w = y.concat([
        { begin: /\(/, end: /\)/, keywords: l, contains: ["self"].concat(y) },
      ]),
      M = {
        className: "params",
        begin: /\(/,
        end: /\)/,
        excludeBegin: !0,
        excludeEnd: !0,
        keywords: l,
        contains: w,
      },
      E = {
        variants: [
          {
            match: [
              /class/,
              /\s+/,
              a,
              /\s+/,
              /extends/,
              /\s+/,
              t.concat(a, "(", t.concat(/\./, a), ")*"),
            ],
            scope: {
              1: "keyword",
              3: "title.class",
              5: "keyword",
              7: "title.class.inherited",
            },
          },
          {
            match: [/class/, /\s+/, a],
            scope: { 1: "keyword", 3: "title.class" },
          },
        ],
      },
      z = {
        relevance: 0,
        match: t.either(
          /\bJSON/,
          /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/,
          /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/,
          /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/
        ),
        className: "title.class",
        keywords: { _: [...pl, ...ml] },
      },
      k = {
        label: "use_strict",
        className: "meta",
        relevance: 10,
        begin: /^\s*['"]use (strict|asm)['"]/,
      },
      O = {
        variants: [
          { match: [/function/, /\s+/, a, /(?=\s*\()/] },
          { match: [/function/, /\s*(?=\()/] },
        ],
        className: { 1: "keyword", 3: "title.function" },
        label: "func.def",
        contains: [M],
        illegal: /%/,
      },
      K = {
        relevance: 0,
        match: /\b[A-Z][A-Z_0-9]+\b/,
        className: "variable.constant",
      };
    function H(T) {
      return t.concat("(?!", T.join("|"), ")");
    }
    let V = {
        match: t.concat(
          /\b/,
          H([...hl, "super", "import"]),
          a,
          t.lookahead(/\(/)
        ),
        className: "title.function",
        relevance: 0,
      },
      I = {
        begin: t.concat(/\./, t.lookahead(t.concat(a, /(?![0-9A-Za-z$_(])/))),
        end: a,
        excludeBegin: !0,
        keywords: "prototype",
        className: "property",
        relevance: 0,
      },
      D = {
        match: [/get|set/, /\s+/, a, /(?=\()/],
        className: { 1: "keyword", 3: "title.function" },
        contains: [{ begin: /\(\)/ }, M],
      },
      J =
        "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" +
        e.UNDERSCORE_IDENT_RE +
        ")\\s*=>",
      R = {
        match: [
          /const|var|let/,
          /\s+/,
          a,
          /\s*/,
          /=\s*/,
          /(async\s*)?/,
          t.lookahead(J),
        ],
        keywords: "async",
        className: { 1: "keyword", 3: "title.function" },
        contains: [M],
      };
    return {
      name: "Javascript",
      aliases: ["js", "jsx", "mjs", "cjs"],
      keywords: l,
      exports: { PARAMS_CONTAINS: w, CLASS_REFERENCE: z },
      illegal: /#(?![$_A-z])/,
      contains: [
        e.SHEBANG({ label: "shebang", binary: "node", relevance: 5 }),
        k,
        e.APOS_STRING_MODE,
        e.QUOTE_STRING_MODE,
        m,
        f,
        v,
        _,
        { match: /\$\d+/ },
        d,
        z,
        { className: "attr", begin: a + t.lookahead(":"), relevance: 0 },
        R,
        {
          begin: "(" + e.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
          keywords: "return throw case",
          relevance: 0,
          contains: [
            _,
            e.REGEXP_MODE,
            {
              className: "function",
              begin: J,
              returnBegin: !0,
              end: "\\s*=>",
              contains: [
                {
                  className: "params",
                  variants: [
                    { begin: e.UNDERSCORE_IDENT_RE, relevance: 0 },
                    { className: null, begin: /\(\s*\)/, skip: !0 },
                    {
                      begin: /\(/,
                      end: /\)/,
                      excludeBegin: !0,
                      excludeEnd: !0,
                      keywords: l,
                      contains: w,
                    },
                  ],
                },
              ],
            },
            { begin: /,/, relevance: 0 },
            { match: /\s+/, relevance: 0 },
            {
              variants: [
                { begin: r.begin, end: r.end },
                { match: o },
                { begin: i.begin, "on:begin": i.isTrulyOpeningTag, end: i.end },
              ],
              subLanguage: "xml",
              contains: [
                { begin: i.begin, end: i.end, skip: !0, contains: ["self"] },
              ],
            },
          ],
        },
        O,
        { beginKeywords: "while if switch catch for" },
        {
          begin:
            "\\b(?!function)" +
            e.UNDERSCORE_IDENT_RE +
            "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
          returnBegin: !0,
          label: "func.def",
          contains: [
            M,
            e.inherit(e.TITLE_MODE, { begin: a, className: "title.function" }),
          ],
        },
        { match: /\.\.\./, relevance: 0 },
        I,
        { match: "\\$" + a, relevance: 0 },
        {
          match: [/\bconstructor(?=\s*\()/],
          className: { 1: "title.function" },
          contains: [M],
        },
        V,
        K,
        E,
        D,
        { match: /\$[(.]/ },
      ],
    };
  }
  function vl(e) {
    let t = Q6(e),
      n = j1,
      a = [
        "any",
        "void",
        "number",
        "boolean",
        "string",
        "object",
        "never",
        "symbol",
        "bigint",
        "unknown",
      ],
      r = {
        beginKeywords: "namespace",
        end: /\{/,
        excludeEnd: !0,
        contains: [t.exports.CLASS_REFERENCE],
      },
      o = {
        beginKeywords: "interface",
        end: /\{/,
        excludeEnd: !0,
        keywords: { keyword: "interface extends", built_in: a },
        contains: [t.exports.CLASS_REFERENCE],
      },
      i = { className: "meta", relevance: 10, begin: /^\s*['"]use strict['"]/ },
      l = [
        "type",
        "namespace",
        "interface",
        "public",
        "private",
        "protected",
        "implements",
        "declare",
        "abstract",
        "readonly",
        "enum",
        "override",
      ],
      s = {
        $pattern: j1,
        keyword: ul.concat(l),
        literal: dl,
        built_in: gl.concat(a),
        "variable.language": fl,
      },
      u = { className: "meta", begin: "@" + n },
      c = (p, m, f) => {
        let v = p.contains.findIndex((g) => g.label === m);
        if (v === -1) throw new Error("can not find mode to replace");
        p.contains.splice(v, 1, f);
      };
    Object.assign(t.keywords, s),
      t.exports.PARAMS_CONTAINS.push(u),
      (t.contains = t.contains.concat([u, r, o])),
      c(t, "shebang", e.SHEBANG()),
      c(t, "use_strict", i);
    let d = t.contains.find((p) => p.label === "func.def");
    return (
      (d.relevance = 0),
      Object.assign(t, { name: "TypeScript", aliases: ["ts", "tsx"] }),
      t
    );
  }
  function bl(e) {
    let t = e.regex,
      n = { className: "string", begin: /"(""|[^/n])"C\b/ },
      a = {
        className: "string",
        begin: /"/,
        end: /"/,
        illegal: /\n/,
        contains: [{ begin: /""/ }],
      },
      r = /\d{1,2}\/\d{1,2}\/\d{4}/,
      o = /\d{4}-\d{1,2}-\d{1,2}/,
      i = /(\d|1[012])(:\d+){0,2} *(AM|PM)/,
      l = /\d{1,2}(:\d{1,2}){1,2}/,
      s = {
        className: "literal",
        variants: [
          { begin: t.concat(/# */, t.either(o, r), / *#/) },
          { begin: t.concat(/# */, l, / *#/) },
          { begin: t.concat(/# */, i, / *#/) },
          {
            begin: t.concat(/# */, t.either(o, r), / +/, t.either(i, l), / *#/),
          },
        ],
      },
      u = {
        className: "number",
        relevance: 0,
        variants: [
          {
            begin:
              /\b\d[\d_]*((\.[\d_]+(E[+-]?[\d_]+)?)|(E[+-]?[\d_]+))[RFD@!#]?/,
          },
          { begin: /\b\d[\d_]*((U?[SIL])|[%&])?/ },
          { begin: /&H[\dA-F_]+((U?[SIL])|[%&])?/ },
          { begin: /&O[0-7_]+((U?[SIL])|[%&])?/ },
          { begin: /&B[01_]+((U?[SIL])|[%&])?/ },
        ],
      },
      c = { className: "label", begin: /^\w+:/ },
      d = e.COMMENT(/'''/, /$/, {
        contains: [{ className: "doctag", begin: /<\/?/, end: />/ }],
      }),
      p = e.COMMENT(null, /$/, {
        variants: [{ begin: /'/ }, { begin: /([\t ]|^)REM(?=\s)/ }],
      });
    return {
      name: "Visual Basic .NET",
      aliases: ["vb"],
      case_insensitive: !0,
      classNameAliases: { label: "symbol" },
      keywords: {
        keyword:
          "addhandler alias aggregate ansi as async assembly auto binary by byref byval call case catch class compare const continue custom declare default delegate dim distinct do each equals else elseif end enum erase error event exit explicit finally for friend from function get global goto group handles if implements imports in inherits interface into iterator join key let lib loop me mid module mustinherit mustoverride mybase myclass namespace narrowing new next notinheritable notoverridable of off on operator option optional order overloads overridable overrides paramarray partial preserve private property protected public raiseevent readonly redim removehandler resume return select set shadows shared skip static step stop structure strict sub synclock take text then throw to try unicode until using when where while widening with withevents writeonly yield",
        built_in:
          "addressof and andalso await directcast gettype getxmlnamespace is isfalse isnot istrue like mod nameof new not or orelse trycast typeof xor cbool cbyte cchar cdate cdbl cdec cint clng cobj csbyte cshort csng cstr cuint culng cushort",
        type: "boolean byte char date decimal double integer long object sbyte short single string uinteger ulong ushort",
        literal: "true false nothing",
      },
      illegal: "//|\\{|\\}|endif|gosub|variant|wend|^\\$ ",
      contains: [
        n,
        a,
        s,
        u,
        c,
        d,
        p,
        {
          className: "meta",
          begin:
            /[\t ]*#(const|disable|else|elseif|enable|end|externalsource|if|region)\b/,
          end: /$/,
          keywords: {
            keyword:
              "const disable else elseif enable end externalsource if region then",
          },
          contains: [p],
        },
      ],
    };
  }
  function _l(e) {
    e.regex;
    let t = e.COMMENT(/\(;/, /;\)/);
    t.contains.push("self");
    let n = e.COMMENT(/;;/, /$/),
      a = [
        "anyfunc",
        "block",
        "br",
        "br_if",
        "br_table",
        "call",
        "call_indirect",
        "data",
        "drop",
        "elem",
        "else",
        "end",
        "export",
        "func",
        "global.get",
        "global.set",
        "local.get",
        "local.set",
        "local.tee",
        "get_global",
        "get_local",
        "global",
        "if",
        "import",
        "local",
        "loop",
        "memory",
        "memory.grow",
        "memory.size",
        "module",
        "mut",
        "nop",
        "offset",
        "param",
        "result",
        "return",
        "select",
        "set_global",
        "set_local",
        "start",
        "table",
        "tee_local",
        "then",
        "type",
        "unreachable",
      ],
      r = {
        begin: [/(?:func|call|call_indirect)/, /\s+/, /\$[^\s)]+/],
        className: { 1: "keyword", 3: "title.function" },
      },
      o = { className: "variable", begin: /\$[\w_]+/ },
      i = { match: /(\((?!;)|\))+/, className: "punctuation", relevance: 0 },
      l = {
        className: "number",
        relevance: 0,
        match:
          /[+-]?\b(?:\d(?:_?\d)*(?:\.\d(?:_?\d)*)?(?:[eE][+-]?\d(?:_?\d)*)?|0x[\da-fA-F](?:_?[\da-fA-F])*(?:\.[\da-fA-F](?:_?[\da-fA-D])*)?(?:[pP][+-]?\d(?:_?\d)*)?)\b|\binf\b|\bnan(?::0x[\da-fA-F](?:_?[\da-fA-D])*)?\b/,
      },
      s = { match: /(i32|i64|f32|f64)(?!\.)/, className: "type" },
      u = {
        className: "keyword",
        match:
          /\b(f32|f64|i32|i64)(?:\.(?:abs|add|and|ceil|clz|const|convert_[su]\/i(?:32|64)|copysign|ctz|demote\/f64|div(?:_[su])?|eqz?|extend_[su]\/i32|floor|ge(?:_[su])?|gt(?:_[su])?|le(?:_[su])?|load(?:(?:8|16|32)_[su])?|lt(?:_[su])?|max|min|mul|nearest|neg?|or|popcnt|promote\/f32|reinterpret\/[fi](?:32|64)|rem_[su]|rot[lr]|shl|shr_[su]|store(?:8|16|32)?|sqrt|sub|trunc(?:_[su]\/f(?:32|64))?|wrap\/i64|xor))\b/,
      };
    return {
      name: "WebAssembly",
      keywords: { $pattern: /[\w.]+/, keyword: a },
      contains: [
        n,
        t,
        {
          match: [/(?:offset|align)/, /\s*/, /=/],
          className: { 1: "keyword", 3: "operator" },
        },
        o,
        i,
        r,
        e.QUOTE_STRING_MODE,
        s,
        u,
        l,
      ],
    };
  }
  function El(e) {
    let t = e.regex,
      n = t.concat(
        /[\p{L}_]/u,
        t.optional(/[\p{L}0-9_.-]*:/u),
        /[\p{L}0-9_.-]*/u
      ),
      a = /[\p{L}0-9._:-]+/u,
      r = { className: "symbol", begin: /&[a-z]+;|&#[0-9]+;|&#x[a-f0-9]+;/ },
      o = {
        begin: /\s/,
        contains: [
          { className: "keyword", begin: /#?[a-z_][a-z1-9_-]+/, illegal: /\n/ },
        ],
      },
      i = e.inherit(o, { begin: /\(/, end: /\)/ }),
      l = e.inherit(e.APOS_STRING_MODE, { className: "string" }),
      s = e.inherit(e.QUOTE_STRING_MODE, { className: "string" }),
      u = {
        endsWithParent: !0,
        illegal: /</,
        relevance: 0,
        contains: [
          { className: "attr", begin: a, relevance: 0 },
          {
            begin: /=\s*/,
            relevance: 0,
            contains: [
              {
                className: "string",
                endsParent: !0,
                variants: [
                  { begin: /"/, end: /"/, contains: [r] },
                  { begin: /'/, end: /'/, contains: [r] },
                  { begin: /[^\s"'=<>`]+/ },
                ],
              },
            ],
          },
        ],
      };
    return {
      name: "HTML, XML",
      aliases: [
        "html",
        "xhtml",
        "rss",
        "atom",
        "xjb",
        "xsd",
        "xsl",
        "plist",
        "wsf",
        "svg",
      ],
      case_insensitive: !0,
      unicodeRegex: !0,
      contains: [
        {
          className: "meta",
          begin: /<![a-z]/,
          end: />/,
          relevance: 10,
          contains: [
            o,
            s,
            l,
            i,
            {
              begin: /\[/,
              end: /\]/,
              contains: [
                {
                  className: "meta",
                  begin: /<![a-z]/,
                  end: />/,
                  contains: [o, i, s, l],
                },
              ],
            },
          ],
        },
        e.COMMENT(/<!--/, /-->/, { relevance: 10 }),
        { begin: /<!\[CDATA\[/, end: /\]\]>/, relevance: 10 },
        r,
        {
          className: "meta",
          end: /\?>/,
          variants: [
            { begin: /<\?xml/, relevance: 10, contains: [s] },
            { begin: /<\?[a-z][a-z0-9]+/ },
          ],
        },
        {
          className: "tag",
          begin: /<style(?=\s|>)/,
          end: />/,
          keywords: { name: "style" },
          contains: [u],
          starts: {
            end: /<\/style>/,
            returnEnd: !0,
            subLanguage: ["css", "xml"],
          },
        },
        {
          className: "tag",
          begin: /<script(?=\s|>)/,
          end: />/,
          keywords: { name: "script" },
          contains: [u],
          starts: {
            end: /<\/script>/,
            returnEnd: !0,
            subLanguage: ["javascript", "handlebars", "xml"],
          },
        },
        { className: "tag", begin: /<>|<\/>/ },
        {
          className: "tag",
          begin: t.concat(
            /</,
            t.lookahead(t.concat(n, t.either(/\/>/, />/, /\s/)))
          ),
          end: /\/?>/,
          contains: [{ className: "name", begin: n, relevance: 0, starts: u }],
        },
        {
          className: "tag",
          begin: t.concat(/<\//, t.lookahead(t.concat(n, />/))),
          contains: [
            { className: "name", begin: n, relevance: 0 },
            { begin: />/, relevance: 0, endsParent: !0 },
          ],
        },
      ],
    };
  }
  function yl(e) {
    let t = "true false yes no null",
      n = "[\\w#;/?:@&=+$,.~*'()[\\]]+",
      a = {
        className: "attr",
        variants: [
          { begin: "\\w[\\w :\\/.-]*:(?=[ 	]|$)" },
          { begin: '"\\w[\\w :\\/.-]*":(?=[ 	]|$)' },
          { begin: "'\\w[\\w :\\/.-]*':(?=[ 	]|$)" },
        ],
      },
      r = {
        className: "template-variable",
        variants: [
          { begin: /\{\{/, end: /\}\}/ },
          { begin: /%\{/, end: /\}/ },
        ],
      },
      o = {
        className: "string",
        relevance: 0,
        variants: [
          { begin: /'/, end: /'/ },
          { begin: /"/, end: /"/ },
          { begin: /\S+/ },
        ],
        contains: [e.BACKSLASH_ESCAPE, r],
      },
      i = e.inherit(o, {
        variants: [
          { begin: /'/, end: /'/ },
          { begin: /"/, end: /"/ },
          { begin: /[^\s,{}[\]]+/ },
        ],
      }),
      l = "[0-9]{4}(-[0-9][0-9]){0,2}",
      s = "([Tt \\t][0-9][0-9]?(:[0-9][0-9]){2})?",
      u = "(\\.[0-9]*)?",
      c = "([ \\t])*(Z|[-+][0-9][0-9]?(:[0-9][0-9])?)?",
      d = { className: "number", begin: "\\b" + l + s + u + c + "\\b" },
      p = {
        end: ",",
        endsWithParent: !0,
        excludeEnd: !0,
        keywords: t,
        relevance: 0,
      },
      m = {
        begin: /\{/,
        end: /\}/,
        contains: [p],
        illegal: "\\n",
        relevance: 0,
      },
      f = {
        begin: "\\[",
        end: "\\]",
        contains: [p],
        illegal: "\\n",
        relevance: 0,
      },
      v = [
        a,
        { className: "meta", begin: "^---\\s*$", relevance: 10 },
        {
          className: "string",
          begin:
            "[\\|>]([1-9]?[+-])?[ ]*\\n( +)[^ ][^\\n]*\\n(\\2[^\\n]+\\n?)*",
        },
        {
          begin: "<%[%=-]?",
          end: "[%-]?%>",
          subLanguage: "ruby",
          excludeBegin: !0,
          excludeEnd: !0,
          relevance: 0,
        },
        { className: "type", begin: "!\\w+!" + n },
        { className: "type", begin: "!<" + n + ">" },
        { className: "type", begin: "!" + n },
        { className: "type", begin: "!!" + n },
        { className: "meta", begin: "&" + e.UNDERSCORE_IDENT_RE + "$" },
        { className: "meta", begin: "\\*" + e.UNDERSCORE_IDENT_RE + "$" },
        { className: "bullet", begin: "-(?=[ ]|$)", relevance: 0 },
        e.HASH_COMMENT_MODE,
        { beginKeywords: t, keywords: { literal: t } },
        d,
        { className: "number", begin: e.C_NUMBER_RE + "\\b", relevance: 0 },
        m,
        f,
        o,
      ],
      g = [...v];
    return (
      g.pop(),
      g.push(i),
      (p.contains = g),
      { name: "YAML", case_insensitive: !0, aliases: ["yml"], contains: v }
    );
  }
  var Vl = pt(Fl(), 1);
  var lt = Vl.default;
  var Ul = pt(Bl(), 1),
    F5 = Object.assign(Kt(Error), {
      eval: Kt(EvalError),
      range: Kt(RangeError),
      reference: Kt(ReferenceError),
      syntax: Kt(SyntaxError),
      type: Kt(TypeError),
      uri: Kt(URIError),
    });
  function Kt(e) {
    return (t.displayName = e.displayName || e.name), t;
    function t(n, ...a) {
      let r = n && (0, Ul.default)(n, ...a);
      return new e(r);
    }
  }
  var Bd = {}.hasOwnProperty,
    Gl = "hljs-";
  function $l(e, t, n = {}) {
    let a = n.prefix;
    if (typeof e != "string")
      throw F5("Expected `string` for name, got `%s`", e);
    if (!lt.getLanguage(e))
      throw F5("Unknown language: `%s` is not registered", e);
    if (typeof t != "string")
      throw F5("Expected `string` for value, got `%s`", t);
    a == null && (a = Gl), lt.configure({ __emitter: F0, classPrefix: a });
    let r = lt.highlight(t, { language: e, ignoreIllegals: !0 });
    if ((lt.configure({}), r.errorRaised)) throw r.errorRaised;
    return (
      (r._emitter.root.data.language = r.language),
      (r._emitter.root.data.relevance = r.relevance),
      r._emitter.root
    );
  }
  function Ud(e, t = {}) {
    let n = t.subset || lt.listLanguages(),
      a = t.prefix,
      r = -1,
      o = {
        type: "root",
        data: { language: null, relevance: 0 },
        children: [],
      };
    if ((a == null && (a = Gl), typeof e != "string"))
      throw F5("Expected `string` for value, got `%s`", e);
    for (; ++r < n.length; ) {
      let i = n[r];
      if (!lt.getLanguage(i)) continue;
      let l = $l(i, e, t);
      l.data.relevance > o.data.relevance && (o = l);
    }
    return o;
  }
  function Gd(e, t) {
    lt.registerLanguage(e, t);
  }
  var $d = function (e, t) {
    if (typeof e == "string") lt.registerAliases(t, { languageName: e });
    else {
      let n;
      for (n in e)
        Bd.call(e, n) && lt.registerAliases(e[n], { languageName: n });
    }
  };
  function qd(e) {
    return Boolean(lt.getLanguage(e));
  }
  function Wd() {
    return lt.listLanguages();
  }
  var F0 = class {
      constructor(t) {
        (this.options = t),
          (this.root = {
            type: "root",
            data: { language: null, relevance: 0 },
            children: [],
          }),
          (this.stack = [this.root]);
      }
      addText(t) {
        if (t === "") return;
        let n = this.stack[this.stack.length - 1],
          a = n.children[n.children.length - 1];
        a && a.type === "text"
          ? (a.value += t)
          : n.children.push({ type: "text", value: t });
      }
      addKeyword(t, n) {
        this.openNode(n), this.addText(t), this.closeNode();
      }
      addSublanguage(t, n) {
        let a = this.stack[this.stack.length - 1],
          r = t.root.children;
        n
          ? a.children.push({
              type: "element",
              tagName: "span",
              properties: { className: [n] },
              children: r,
            })
          : a.children.push(...r);
      }
      openNode(t) {
        let n = t
            .split(".")
            .map((o, i) =>
              i ? o + "_".repeat(i) : this.options.classPrefix + o
            ),
          a = this.stack[this.stack.length - 1],
          r = {
            type: "element",
            tagName: "span",
            properties: { className: n },
            children: [],
          };
        a.children.push(r), this.stack.push(r);
      }
      closeNode() {
        this.stack.pop();
      }
      closeAllNodes() {}
      finalize() {}
      toHTML() {
        return "";
      }
    },
    Z = {
      highlight: $l,
      highlightAuto: Ud,
      registerLanguage: Gd,
      registered: qd,
      listLanguages: Wd,
      registerAlias: $d,
    };
  Z.registerLanguage("arduino", v2);
  Z.registerLanguage("bash", b2);
  Z.registerLanguage("c", _2);
  Z.registerLanguage("cpp", E2);
  Z.registerLanguage("csharp", y2);
  Z.registerLanguage("css", x2);
  Z.registerLanguage("diff", w2);
  Z.registerLanguage("go", A2);
  Z.registerLanguage("graphql", M2);
  Z.registerLanguage("ini", z2);
  Z.registerLanguage("java", k2);
  Z.registerLanguage("javascript", L2);
  Z.registerLanguage("json", O2);
  Z.registerLanguage("kotlin", H2);
  Z.registerLanguage("less", F2);
  Z.registerLanguage("lua", V2);
  Z.registerLanguage("makefile", B2);
  Z.registerLanguage("markdown", U2);
  Z.registerLanguage("objectivec", G2);
  Z.registerLanguage("perl", $2);
  Z.registerLanguage("php", q2);
  Z.registerLanguage("php-template", W2);
  Z.registerLanguage("plaintext", K2);
  Z.registerLanguage("python", j2);
  Z.registerLanguage("python-repl", Y2);
  Z.registerLanguage("r", Q2);
  Z.registerLanguage("ruby", Z2);
  Z.registerLanguage("rust", X2);
  Z.registerLanguage("scss", J2);
  Z.registerLanguage("shell", el);
  Z.registerLanguage("sql", tl);
  Z.registerLanguage("swift", sl);
  Z.registerLanguage("typescript", vl);
  Z.registerLanguage("vbnet", bl);
  Z.registerLanguage("wasm", _l);
  Z.registerLanguage("xml", El);
  Z.registerLanguage("yaml", yl);
  var Ot = function (e) {
    if (e == null) return V0;
    if (typeof e == "string") return jd(e);
    if (typeof e == "object") return Kd(e);
    if (typeof e == "function") return ql(e);
    throw new Error("Expected function, string, or array as test");
  };
  function Kd(e) {
    let t = [],
      n = -1;
    for (; ++n < e.length; ) t[n] = Ot(e[n]);
    return ql(a);
    function a(...r) {
      let o = -1;
      for (; ++o < t.length; ) if (t[o].call(this, ...r)) return !0;
      return !1;
    }
  }
  function jd(e) {
    return t;
    function t(n) {
      return V0(n) && n.tagName === e;
    }
  }
  function ql(e) {
    return t;
    function t(n, ...a) {
      return V0(n) && Boolean(e.call(this, n, ...a));
    }
  }
  function V0(e) {
    return Boolean(
      e &&
        typeof e == "object" &&
        e.type === "element" &&
        typeof e.tagName == "string"
    );
  }
  var B0 = function (e, t, n) {
    var a = I5(n);
    if (!e || !e.type || !e.children) throw new Error("Expected parent node");
    if (typeof t == "number") {
      if (t < 0 || t === Number.POSITIVE_INFINITY)
        throw new Error("Expected positive finite number as index");
    } else if (((t = e.children.indexOf(t)), t < 0))
      throw new Error("Expected child node or index");
    for (; ++t < e.children.length; )
      if (a(e.children[t], t, e)) return e.children[t];
    return null;
  };
  var Wl = /\n/g,
    Kl = /[\t ]+/g,
    U0 = Ot("br"),
    Yd = Ot("p"),
    jl = Ot(["th", "td"]),
    Yl = Ot("tr"),
    Qd = Ot([
      "datalist",
      "head",
      "noembed",
      "noframes",
      "noscript",
      "rp",
      "script",
      "style",
      "template",
      "title",
      ep,
      tp,
    ]),
    Ql = Ot([
      "address",
      "article",
      "aside",
      "blockquote",
      "body",
      "caption",
      "center",
      "dd",
      "dialog",
      "dir",
      "dl",
      "dt",
      "div",
      "figure",
      "figcaption",
      "footer",
      "form,",
      "h1",
      "h2",
      "h3",
      "h4",
      "h5",
      "h6",
      "header",
      "hgroup",
      "hr",
      "html",
      "legend",
      "listing",
      "main",
      "menu",
      "nav",
      "ol",
      "p",
      "plaintext",
      "pre",
      "section",
      "ul",
      "xmp",
    ]);
  function G0(e, t = {}) {
    let n = e.children || [],
      a = Ql(e),
      r = Jl(e, {
        whitespace: t.whitespace || "normal",
        breakBefore: !1,
        breakAfter: !1,
      }),
      o = -1,
      i,
      l,
      s;
    if (e.type === "text" || e.type === "comment")
      return Xl(e, { whitespace: r, breakBefore: !0, breakAfter: !0 });
    for (i = []; ++o < n.length; )
      i = i.concat(
        Zl(n[o], e, {
          whitespace: r,
          breakBefore: o ? null : a,
          breakAfter: o < n.length - 1 ? U0(n[o + 1]) : a,
        })
      );
    o = -1;
    let u = [];
    for (; ++o < i.length; )
      (l = i[o]),
        typeof l == "number"
          ? s !== void 0 && l > s && (s = l)
          : l &&
            (s &&
              u.push(
                `
`.repeat(s)
              ),
            (s = 0),
            u.push(l));
    return u.join("");
  }
  function Zl(e, t, n) {
    return e.type === "element"
      ? Zd(e, t, n)
      : e.type === "text"
      ? [n.whitespace === "normal" ? Xl(e, n) : Xd(e)]
      : [];
  }
  function Zd(e, t, n) {
    let a = Jl(e, n),
      r = e.children || [],
      o = -1,
      i = [],
      l,
      s;
    if (Qd(e)) return i;
    for (
      U0(e) || (Yl(e) && B0(t, e, Yl))
        ? (s = `
`)
        : Yd(e)
        ? ((l = 2), (s = 2))
        : Ql(e) && ((l = 1), (s = 1));
      ++o < r.length;

    )
      i = i.concat(
        Zl(r[o], e, {
          whitespace: a,
          breakBefore: o ? void 0 : l,
          breakAfter: o < r.length - 1 ? U0(r[o + 1]) : s,
        })
      );
    return (
      jl(e) && B0(t, e, jl) && i.push("	"), l && i.unshift(l), s && i.push(s), i
    );
  }
  function Xl(e, t) {
    let n = String(e.value),
      a = [],
      r = [],
      o = 0,
      i = -1,
      l,
      s,
      u;
    for (; o < n.length; )
      (Wl.lastIndex = o),
        (l = Wl.exec(n)),
        (s = l ? l.index : n.length),
        a.push(
          Jd(
            n
              .slice(o, s)
              .replace(/[\u061C\u200E\u200F\u202A-\u202E\u2066-\u2069]/g, ""),
            t.breakBefore,
            t.breakAfter
          )
        ),
        (o = s + 1);
    for (; ++i < a.length; )
      a[i].charCodeAt(a[i].length - 1) === 8203 ||
      (i < a.length - 1 && a[i + 1].charCodeAt(0) === 8203)
        ? (r.push(a[i]), (u = ""))
        : a[i] && (u && r.push(u), r.push(a[i]), (u = " "));
    return r.join("");
  }
  function Xd(e) {
    return String(e.value);
  }
  function Jd(e, t, n) {
    let a = [],
      r = 0,
      o,
      i;
    for (; r < e.length; )
      (Kl.lastIndex = r),
        (o = Kl.exec(e)),
        (i = o ? o.index : e.length),
        !r && !i && o && !t && a.push(""),
        r !== i && a.push(e.slice(r, i)),
        (r = o ? i + o[0].length : i);
    return r !== i && !n && a.push(""), a.join(" ");
  }
  function Jl(e, t) {
    let n;
    if (e.type === "element")
      switch (((n = e.properties || {}), e.tagName)) {
        case "listing":
        case "plaintext":
        case "xmp":
          return "pre";
        case "nobr":
          return "nowrap";
        case "pre":
          return n.wrap ? "pre-wrap" : "pre";
        case "td":
        case "th":
          return n.noWrap ? "nowrap" : t.whitespace;
        case "textarea":
          return "pre-wrap";
        default:
      }
    return t.whitespace;
  }
  function ep(e) {
    return Boolean((e.properties || {}).hidden);
  }
  function tp(e) {
    return e.tagName === "dialog" && !(e.properties || {}).open;
  }
  var np = {}.hasOwnProperty;
  function J1(e = {}) {
    let {
        aliases: t,
        languages: n,
        prefix: a,
        plainText: r,
        ignoreMissing: o,
        subset: i,
        detect: l,
      } = e,
      s = "hljs";
    if ((t && Z.registerAlias(t), n)) {
      let u;
      for (u in n) np.call(n, u) && Z.registerLanguage(u, n[u]);
    }
    if (a) {
      let u = a.indexOf("-");
      s = u > -1 ? a.slice(0, u) : a;
    }
    return (u, c) => {
      Tt(u, "element", (d, p, m) => {
        let f = m;
        if (
          !f ||
          !("tagName" in f) ||
          f.tagName !== "pre" ||
          d.tagName !== "code" ||
          !d.properties
        )
          return;
        let v = ap(d);
        if (v === !1 || (!v && !l) || (v && r && r.includes(v))) return;
        Array.isArray(d.properties.className) || (d.properties.className = []),
          d.properties.className.includes(s) ||
            d.properties.className.unshift(s);
        let g;
        try {
          g = v
            ? Z.highlight(v, G0(f), { prefix: a })
            : Z.highlightAuto(G0(f), { prefix: a, subset: i });
        } catch (_) {
          let C = _;
          (!o || !/Unknown language/.test(C.message)) &&
            c.fail(C, d, "rehype-highlight:missing-language");
          return;
        }
        !v &&
          g.data.language &&
          d.properties.className.push("language-" + g.data.language),
          Array.isArray(g.children) &&
            g.children.length > 0 &&
            (d.children = g.children);
      });
    };
  }
  function ap(e) {
    let t = e.properties && e.properties.className,
      n = -1;
    if (!!Array.isArray(t))
      for (; ++n < t.length; ) {
        let a = String(t[n]);
        if (a === "no-highlight" || a === "nohighlight") return !1;
        if (a.slice(0, 5) === "lang-") return a.slice(5);
        if (a.slice(0, 9) === "language-") return a.slice(9);
      }
  }
  var _a = pt(n1());
  var $0 = pt(n1());
  function en(e) {
    for (let t of e) {
      let n = document.querySelector(t);
      if (n) return n;
    }
  }
  function t7(e) {
    return (
      e.endsWith("?") ||
      e.endsWith("\uFF1F") ||
      e.endsWith("\u061F") ||
      e.endsWith("\u2E2E")
    );
  }
  function n7() {
    var e;
    return (e = navigator.brave) == null ? void 0 : e.isBrave();
  }
  async function a7() {
    let { triggerModeTipShowTimes: e = 0 } = await $0.default.storage.local.get(
      "triggerModeTipShowTimes"
    );
    if (e >= 3) return !1;
    let { triggerMode: t } = await yt(),
      n = t === "always";
    return (
      n &&
        (await $0.default.storage.local.set({
          triggerModeTipShowCount: e + 1,
        })),
      n
    );
  }
  var r7 =
    " data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA8oAAAPKCAYAAABMb6M0AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAGvXSURBVHgB7P1djJ13fh94/v6nqPil1dZptmeTDTAtqgPkYt5IZW4WmwAsdotq9xgIyczNziIxS3NjZ5EFqZm8AB4gJIPZAezMRuTu7MS+WRbtxTg3Y1ILJO0m22IRsI2ZC4+KtifAGHaLkgE7jrulI0vdrW6xzn/O/5BFkRSrWHXOc855/s/5fACqSiTd7i6qjp7v+b2lAAAeyFf7/fixeG78N1txaPyxt3Lv4zD3I0X/3qf3f20kpVx+rh+f/MShJ/+Hx5N/fq9S3Pn0f2YejP46ePSn0vj39fLo53v3f238ebr3+XDr3n/OcPRzz4x+/Hm8n04NBgEAjKUAgI56EHpL4N0OuzkfGgXE/nAUeEcBt/zcKPym/ihIPhp2l9Ng9GQwGH2N7pS/KYH7QdguH9PwzvhjCdjfi7eFawC6SlAGoDrjAPwj8XysjAJwWumX8FsqvPcru4fuB99DweyVKvfDwbr8fRpVtEvVWqAGoFKCMgCtk3+9//woZB15LAQfGrc0q/xWKm+O/jJ4UphOPzG4HQDQIoIyAHP3oCJ8YOVImfsdRhx5KAgfCpbP/cr0gyAdw81xm/d34raKNADzJigDMDMPKsO5d+h+GD4y+lfPoVARZn8GpSL9SIjeijsq0QDMiqAMwFQeqQ5v5SO5N64MH1EZZj7GLd13UqRNARqApgjKAOzZpyrEvVgViGknARqAyQnKADxR/rX+4YeqxKVlevRDyzRVG7dwp+H98JxjU3gG4EkEZQAehOLhMK+aI2b55A3hGYCHCcoAS2bcPp1XVu9XileFYniS++G5N9zQtg2wfARlgA4bL9r6TByO6B3JaRyKRz+EYpjAvbbtSBuRR+HZ2SqAThOUATrkCdXiIwHMyPhk1WYvDa9FLzbTlwdvBwCdICgDVGwcjLd6J22ghhbI+c7oyWozDfM1s84AdROUASrySDBOcTK0UUN7Cc4A1RKUAVpMMIYOeTg4H4gNrdoA7SUoA7TIePnWZ1dOjGeMV0bBWCs1dNcoOOdIG+MZ5w/jluVgAO0hKAMsWL7ePzpMsZrGG6nHW6mBpXT/JNUoOKeXB7cCgIURlAHm7N7Jpt5p55qAXQzuBWdt2gCLICgDzMFDVeOTTjYB+5c3R9XmDdVmgPkQlAFmYHvWeDjMq5ZwAY0y2wwwc4IyQEMeaqk+adYYmJ9xi/a6Fm2A5gjKAFMo55uGw1iziAtoh7yZclqP4XDD3WaAyQnKAPv0YN449dacbwJaK+c7o9B8LfJwXWgG2B9BGWAPhGOgakIzwL4IygA7EI6BThKaAZ5KUAZ4SH6jf3i4FSeFY2ApbIfmA8OLFoEBfEJQBpZe2VY9fDbOWMgFLLdyqzlftD0bQFAGlpRTTgC7cXIKWG6CMrBUytxxTun86OXvyOhv+wHArnKO9V4aXkvHB68HwJIQlIHOK+E4cu9k7sVaCMcAk8n5To600RsOL1oCBnSdoAx0ktZqgFkyzwx0m6AMdMr91uqz98Ox6jHAjI1bs2O4nl4e3AqAjhCUgep9srW6NwrIwjHAQpTW7JTXe71YV2UGaicoA9V6aDHXagDQIvlairxuARhQK0EZqIrqMUBFVJmBSgnKQBVUjwHqZpYZqImgDLTWQ5ur1+7fPQagdqMqc8r5vI3ZQJsJykDr5Df6h+Pj3pq7xwCdNhhVma/1VobnBWagbQRloDW0VwMsq7yRIl+0/AtoC0EZWKgH7dWRz0ZKhwKA5bXdlv3deD2dGgwCYEEEZWAhbK8GYEdlW3akDW3ZwKIIysBc3W+vHoXjdDIA4CnG27IFZmDOBGVgLswfAzAdc8zA/AjKwEzlr/dP515aE5ABaMT9Oeb0lcGVAJgRQRlonPljAGZOYAZmSFAGGiMgAzB3ZfFXyuu9XqybYwaaIigDUxOQAVg4m7KBBgnKwMQEZADayKZsYFqCMrBv+Wv9Q7HSO5dTrAUAtJTADExKUAb2TEAGoEYCM7BfgjLwVAIyAF0gMAN7JSgDOxKQAegigRl4GkEZ+BRLugBYBgIzsBNBGXhAQAZgGQnMwOMEZUBABoByhznl9V4v1gVmQFCGJSYgA8BjRoE55Xw+fWVwJYClJSjDkspf75/OKZ2PlA4FAPAogRmWmqAMSyZf7x8dB+RIqwEA7E5ghqUkKMOSEJABYBp5I/XymvllWA6CMnScW8gA0BwbsmE5CMrQURZ1AcDs5BietyEbuktQhg7K1w+eGVWQz4eADACzY34ZOktQhg4ZzyFHuhgpHQkAYD5KYE75bDo+eD2AThCUoQPKHHI+kC5b1AUAi2N+GbpDUIaKmUMGgPYZzy9/GJfSqcEggCoJylCp/PX+6dzrXQwBGQDax/wyVE1Qhsq4hwwAFSmBeSWvaseGugjKUIn7bdbn7rdZAwAVMb8MdRGUoQLOPQFAB2jHhmoIytBi+Y3+4byVLmqzBoAO0Y4NrScoQwtpswaA7svDuNj77vCC7djQPoIytEz+tf6J3BtVkVM6FABAt2nHhlYSlKEl8tf6h/KBdFmbNQAsH8u+oF16ASzceFnXgd6bQjIALKeUYi0Pe5v5ev9MAAunogwLZFkXAPApln3BwgnKsACWdQEAT5NjeH7l+OBCAHMnKMOc5ev9oznSumVdAMBTlepy5LX08uBWAHMjKMOcqCIDAJMan5I6MLyoHRvmQ1CGOVBFBgCm5pQUzI2gDDOkigwANM0pKZg9QRlmRBUZAJgZ1WWYKUEZGqaKDADMi+oyzIagDA1SRQYA5s5mbGicoAwNUEUGABZtvBn7u8ML6dRgEMBUBGWYkioyANAapbq8kle1YsN0egFMbOtG/7WcehtCMgDQCqNnkjzs3Rk9o5wLYGIqyjCB/LX+obySro7+ZXQkAADaSHUZJqaiDPuUrx88kw/03hSSAYBWu1dd3szX+2cC2BcVZdijsrArPzuqIkdaDQCAijgjBfsjKMMeWNgFAFSvtGKnfDYdH7wewK60XsNTWNgFAHRCacWO3jWLvuDpVJRhBxZ2AQCdZdEX7EpFGZ7Awi4AoNMs+oJdqSjDQ8rCruGzcS5F72wAACyB8aKv7wxfTacGgwDGBGW4L7/RP5zvpmtmkQGApaMVGx6h9Rrifqv1loVdAMCSuteKfUcrNtyjosxSG7daf7b3WsqxFgAAaMWGEJRZYlqtAQB2oBWbJaf1mqWk1RoAYBe2YrPkVJRZKrZaAwDsTx7GxZWvvPtqwBIRlFka+Wv9Q3klXXUbGQBgn7Ris2S0XrMU8vX+0Xyg96aQDAAwgdKKvZU28o3+iYAlICjTeVs3Dp7Lqbcx+rQfAABMpoTl6F3butE/F9BxWq/prDKPnJ9NV0f/mK8GAAANytdSL5/Vik1XCcp00v155Ju2WgMAzIi5ZTpM6zWdc/fr/dP355EPBQAAs7F9Qmr07BXQMYIynVLmkXu93nqYRwYAmId+Hj17mVuma7Re0wn355Evj/6RPhkAACxAvpY+zK+kU4NBQOUEZapnHhkAoCXMLdMRWq+p2kP3kQ8FAACLtX1vefSMFlAxQZlq5esHz7iPDADQMiUsj57RzC1TM0GZKo1eeF/LKS4GAACtlKJ3XlimVmaUqcr9pV1XR//orgYAABXIG6mX18wtUxNBmWpY2gUAUClLvqiM1muqkN/oH7a0CwCgUttLvn6tfzigAoIyrXf36/3Teau3GZZ2AQDUq4Tlld5mvt4/E9BygjKttnXj4Ller7ceAAB0Qk69i5Z80XZmlGmtrW8cvJxyrAUAAJ2Th3Fx5SvvvhrQQoIyrWOzNQDAssibqZdPWvJF2wjKtIrN1gAAS8ZGbFrIjDKtMd5sLSQDACyX7Y3Yv95/PqAlBGVaIV/vH81bvQ0hGQBgCZWwPBxvxD4a0AKCMgs3Pv+URiHZ+ScAgGXWL8+EzkfRBoIyC+X8EwAAD3M+ijawzIuFKSF59A/g+QAAgMfkGJ5fOT64ELAAgjIL4UYyAABP49YyiyIoM1f3byRfHv2jdzIAAOCp8rX0YX4lnRoMAuZEUGZuxiH5M+PzT0cCAAD2LG+mXj7p1jLzIigzF/lr/UNuJAMAMLGc76SVvCosMw+CMjMnJAMA0AhhmTkRlJkpIRkAgEYJy8yBO8rMTH6jf1hIBgCgUaNny7yVNvKv9Q8HzIiKMjMxDslbvY3Rp/0AAIDmDdLWcDX9xOB2QMMEZRonJAMAMCfCMjOh9ZpG3f16/7SQDADAnPTzSm+zPIMGNEhFmcaUF6her7ceAAAwZ8PhcO3AVwZXAhogKNMIIRkAgEUTlmmKoMzUhGQAANpCWKYJZpSZSr5+8IyQDABAW5Rn03y9fyZgCoIyE9u6cfBcTnExAACgRXLqXdy60T8XMCGt10ykhOTRPzznAwAAWirH8PzK8cGFgH0SlNk3IRkAgFoIy0xCUGZfhGQAAGojLLNfgjJ7VhZ3mUkGAKBGKQ/PppcHlwL2QFBmT5yAAgCgdk5HsVeCMk8lJAMA0BXCMnshKLMrIRkAgK4RlnkaQZkdCckAAHSVsMxuBGWeKL/RP5y3epsBAADdNEhbw9X0E4PbAY/pBTzmfkjeCAAA6K5+Xult5F/rHw54jIoyj8hf6x/KB3pvjj7tBwAAdJ/KMp+ioswD45C8km6GkAwAwPLo5166ln+9/3zAfSrKjD0IySkdCgAAWDY530kreTV9efB2sPQEZYRkAAAohGXuE5SXXL7a7+fPpDeFZAAAiHth+Tv5xXRqMAiWlhnlJXY/JKskAwDAttGzcX423SzPysHSEpSX2OgF4PLoheBIAAAAD0lHxs/KLC1BeUlt3ei/NnoBOBkAAMATpJNb1w8Ky0tKUF5CWzcOnkvROxsAAMCOUoq1UYHpXLB0LPNaMvdCcpwPAABgT3IMz68cH1wIloagvETy9YNncoqLAQAA7MtwOFw78JXBlWApCMpLIl/vH82ptxEAAMBEUh6uppcHt4LOE5SXQP5a/1A+0Htz9KkV9wAAMLlB2hqF5Z8Y3A46zTKvjhuH5JV0M4RkAACYVj/30rX86/3ng05TUe6wByE5pUMBAAA0I+c76Tv5xXRqMAg6SUW5w0Yh+aqQDAAADRs9Y+dnR8/adJag3FFbN/qvjb6BjwQAADADaXXr+sHLQScJyh1071Zy72wAAAAzk1KsjQpU54LOMaPcMW4lAwDAfLmx3D2CcofkN/qH81ZvMwAAgLlKW8MjzkZ1h9brjhhvuL6brgUAADB3eaW34WxUdwjKHeAMFAAALFw/b6WNfLXfD6onKHdAPpAuC8kAALBgzkZ1hqBcubLhuqymDwAAoAXS6tbXD74WVE1Qrti9M1BxPgAAgNZIvTibr/fPBNWy9bpSo2+8ozn1NgIAAGillIer6eXBraA6gnKFLO8CAIAqDFJveCR9efB2UBWt15UpW/SEZAAAqIJN2JUSlCuTn7XhGgAAqnFvE/bloCqCckXub7g+GQAAQEXSya0b/XNBNcwoVyJ/vX8693rrAQAAVGk4HK4d+MrgStB6gnIFxsu7DvTeHH1qtgEAAOpluVcltF633IMN10IyAADUznKvSgjKLZcPpNcs7wIAgI64t9zratBqgnKLWd4FAABdlFYt92o3M8otlX+tfyKv9K4FAADQSSkPV9PLg1tB6wjKLfRgLlnLNQAAdJnlXi2l9bqFhGQAAFgK/TxM1yz3ap8DQats3ei/Nir0HwrgU97+02EMPsxx599s3fs4+vvyc8Wd8a/d+/Vtd+7/GtQi5xxQk/zRO5/8zffuf373/Xuf3/3z+5//0b2PH/zuvZ8DHpOODH80lXnlV4PW0HrdIvn6wTM5xcWAJTb4To7bf7A1DsOb39waB+HNP7g7DsDl16DLBGWWQR4H5vvB+aNRiP7g94RoiPG88tn08uBS0AqCckuM55IP9N4M95JZItsheON37j74XBWYZSYos8zydnh+7zc/Cc8lSMPyGKSt4Wr6icHtYOEE5RYoMwn5M+lNc8l03e0/3IqN2x8/+CgUw6MEZXhULi3cH94Pz9sBGros5zvpO/nFdGowCBZKUG6BfP3g5ZxiLaBjSpX42m/+IG6NKsYbmx9rnYanEJRhd+Oq83u/EfFv/9W94KziTAeN/lWwvvLyu68ECyUoL5i5ZLrm1u27ce23fhCvjwKyijHsj6AM+zOuOP/Zvxz9+Nq94AwdYV558QTlBbo/l/xWQOW2w/GVr39f1RimICjD5MahuVSb/+RfCM10gXnlBROUF8RcMrUTjqF5gjI0Q2imE8wrL5SgvCDmkqlRCcSX/seP4tKvfiQcwwwIytC8cWj+k1+J+ONfMdNMdfIwLq585V33lRdAUF4Ac8nUplSPL/zy98abqoHZEZRhtnKpMpfAXCrNUAnzyoshKM+Ze8nUQvUY5k9QhvkYV5n/6Bfubc9WZab9Bqk3PJK+PHg7mBtBec6G1z/3lrlk2szsMSyOoAzzl//4f4j45s8LzLRc3uwdf+/FYG4E5TnaunHw3OgLfj6ghbRXw+IJyrA448Bs+RctZl55vgTlOcm/1j+RV3rXAlpGQIb2EJRh8cZzzKXCLDDTQikPV9PLg1vBzAnKczCeS15JN7Vc0yYCMrSPoAztMQ7Mv/9fRXzwewGt4WTU3AjKc+AUFG2y+Yd347/45wIytJGgDO1jhpn2yRu94+8dC2ZKUJ4xp6Boi7KY68KV78Wlqx8F0E6CMrSXwEybOBk1e4LyDDkFRRs48wT1EJSh5e6+H/mdX7gXmGGxnIyaMUF5hpyCYtHKHPLaP/0w3v7TYQDtJyhDHcZ3mL/5c/e2ZMPCOBk1S4LyjDgFxSLdGQXj//yffsccMlRGUIa6aMdm0ZyMmh1BeQbut1y/FbAApcX6wi99T5s1VEhQhgqVduxSXX7nFwMWwcmo2RCUG5av9vv5M+lNLdfMmyoy1E9QhnqN27F/+2+qLjN/TkbNRC9o1PDZOCckM2+livzXfvp9IRkAFiT9yBci/Y3NiC/+w4C5GmWP4Y/2zgWNUlFuUL7eP5pTbyNgTlSRoVtUlKEb8nu/EfG//j3VZeZKC3azBOWGjOeSV9JN1WTm5cr178er//13zSJDhwjK0B02YzN3WrAbpfW6KSs9LdfMRQnGJSC/MqokC8kA0E7jVux///8T8Vf/64gDzwXMnBbsRqkoNyB/vX8693rrATNWWq2P/Zd/7i4ydJSKMnSTRV/MkxbsZqgoT2nccp3S+YAZK63WZWGXkAwAdRlXl/9Po9zyhZ8OmLUcab1c4gmmIihPS8s1c6DVGgAqd+C5SH/1v7EVm9nTgt0IrddT0HLNrJVg/LfOfWirNSwJrdewHPIHvxtx++9oxWamtGBPR1CekC3XzJp5ZFg+gjIsD3PLzJwt2FPRej2h4YE4IyQzK7du3zWPDAAd9mBu+XN/PWAmtGBPRUV5Avl6/2hOvY2AGbj0qx/Fq//8uwEsHxVlWE7593824p1fDJgFLdiTUVGeQNkkFzADF37pu0IyACwZS76YJVuwJyMo79PWjYO2XDMTJSRf+OWPAgBYPumL/0hYZja0YE9E6/U+jBd4Hei9FdCwV37+w7hy4wcBLDet10D+4/8h4l//3wOalraGR9JPDG4He6KivA/jLdfQMCEZANiW/vL/NeLf+38HNG2UZS4GeyYo71G+ftCWaxpVbiR/6e9/ICQDAI8Yh+X/+PWIA88FNCet5uv9M8GeaL3eg/st12+OPjUETyNKSC43km//4VYAbNN6DTwsf/C7Eb99IuLu+wENGaTe8Ej68uDtYFcqynuxMh5+F5JpTGm3FpIBgN2kz/6HEYd/KaBB/Tx0wWcvBOWnyF/vn84p1gIaUkLy67/1cQAAPE363N8ws0zD0mq+0T8R7Err9S7KvbH8mfSm2WSaYnEXsBut18BObMOmUTnfSd/JL6ZTg0HwRCrKuxg+G24m05hyJ1lIBgAmMV7w5c4yTXFb+alUlHfgZjJNKiH5wi9/FAC7UVEGniZ/8+civvnzAU1wW3lnKso7cDOZplz61Y+EZACgEemL/yjiCz8d0AS3lXcmKD9BWeCl5Zom3Lp9N179598NAICmpL/630R87q8HTM9t5Z1ovX7MuOW6VJMFZaZ050+H8dd++v3xzWSAvdB6DezZ3fcj/09HIz76o4ApDdKHwxcs9nqUivLjys1kIZkplZB87L/8cyEZAJiNA89F/Mf//3sfYTp9i70+TUX5IRZ40ZQXf+b9uP2HWwGwHyrKwH7l934j4redxGV6KQ9X08uDW8GYivJDLPCiCWXDtZAMAMxD+tzfiPir/3XAtHJK54MHBOX7LPCiCTZcAwDzlr7wdyP+j/+XgOmk1XEmYkzr9Ui+2u/nz6Q3BWWmYXkXMC2t18DELPeiGRZ73aeiPDJ8tndGSGYaJRxb3gUALIzlXjSjH8+Gc1EhKI8XeI3K6ucDpnDhyvfi7VFFGQBgUdKPfCHii/8gYBo5emfzr/efjyWnorxiFTrTWb/+/bh01VwyALB45pVpQD8P03osuaWeUc43+idG75hcC5jQ9r1k1WSgCWaUgUaYV6YBy34uaqkryjmniwFT+M//6XeEZACgXcqc8r//3wVMI6flzkpLG5Sdg2Ja5V7yxu2PAwCgbcb3lb/w0wGTS0fy9f7SLvZaytbrssArr6SbgjKTKi3XX/zbS781H2iY1mugUVqwmd7Snotayory8EBPNZmplLlkAIBW04LN9Jb2XNTSBWXnoJjWpV/9yFwyAFAFLdhMa1nPRS1fRdk5KKZQWq4v/NL3AgCgFumL/yjih//dgAn1h1u987Fkliooj2eTU6wFTKiE5MF3zBACABXRgs2U0ihD5ev9o7FElisoH1i5HDCh9evfjyujHwAAtRm3YH/urwdMKqd0PpbI0gTl8TmoyKsBE9JyDQBU7d/77+5Vl2EiaXWZqsrLE5SX7B0QmlVuJlvgBQDULP3IFyz2YirLlKmWIiiPq8nOQTGhssDr0q9quQYA6pe+8DOqykxhVFUed+p233IEZdVkpmCBFwDQGSUkf/EfBEyqZKt8td+Pjut8UFZNZhqlmmyBFwDQJekLfzfis/9BwERKtno2zkTHdToo3zsHpZrM5CzwAgA66a/+PwImlaN3tutV5U4H5eGBnmoyE9v8w7uqyQBAJzkXxZT6Xa8qdzYol2pyynktYEL/xX//3QAA6Kwv/sOASXW9qtzdivJK75xqMpO6dfvj2PiduwEA0FWqykyp01XlTgble7PJsRYwIbPJAMBSUFVmCl2uKnezolyqyTAh1WQAYFmoKjOlzlaVOxeUVZOZ1vr1HwQAwNJQVWYK46ryr/efj47pXkVZNZkpuJsMACwbVWWm1B9u9c5Hx3QqKKsmMy2zyQDAUvp3/pOASaVRButaVblbFWXVZKagmgwALKv0l/+ziAPPBUyqa1XlzgRl1WSmde03zSYDAEuqhOQv/HTApLpWVe5ORVk1mSld+tWPAgBgWaUv/EzANLpUVe5EUFZNZlrr178fb//pMAAAllapKlvqxRS6VFXuRkVZNZkp/dLXzSYDADgVxbS6UlVOUblxNflA762ACZUlXl/824MAWLSccwAsWt74YsTd9wMmlT4cfi6dGlT9gF1/RVk1mSld+brZZACAByz1YlrPxpmoXNUVZdVkmvDCqJpsPhloAxVloBVG1eRxVRkmNxhVlV+ouapcd0VZNZkp3br9sZAMAPAwS72YXr/2qnK1QXlcTY68GjCF9etuJwMAfMq/858ETCNH72y+2u9HpaoNysMDvdOR0qGAKWyMKsoAADwq/eX/LGBKVVeVqw3KKee1gClouwYA2IH2axpQc1W5yqCcv95XTWZq2q4BAHah/ZrpVVtVrjMop3Q+YErargEAdqb9miaUqnJUqLqgrJpME7RdAwA8hfZrmtEfZ7jK1BeUVZNpwLXfVE0GAHgq7dc0IPfSWlSmqqCcb/RPqCbThGu/ZT4ZAOBpkqBMI9Jqvt4/GhWpKyjHSpX97bTLnT8darsGANiLH/lCxA//uwHTqq0zuJqgnL/WPzT662rAlCzxAgDYh/+DqjJNqKuqXE9FeaV3LqABr5tPBgDYu8/9jYAmjKrK1XQIp6hAqSbnA723Ahpw8OR7MfhODoC2ydlrE9BCd9+PvPHFgCakD4efS6cGg2i5OirKqsk0ZPMPt4RkAID9KGeiPvsfBDTi2TgTFWh9UM43+/1sNpmG3DKfDACwf+4p05AcvbP5ar8fLdf+ivIPwkkoGrNx+24AALBPz/6HAQ3px2d6p6Pl2l9RrmyNOO22+YeCMgDAfiUVZRqUI7d+qVerg3K+0VdNpjHuJwMATMg9ZZo0ynhtPxXV7qAcK9WsD6f9bv+BajIAwMR+TPs1zWl753Brg3I5CRWWeNGgsvEaAIAJ9bVf06S0mn+tfzhaqr0VZSehaJiN1wAAUyjt19Ckld5atFQrg3KpJucUJwMapKIMADC59KxbyjQrR6y19VRUOyvKvSiD3a2/rUU9Bh/mGHwnBwAAEyoV5QPPBTSotaei2llRdhKKht12FgoAYHqfVVWmWTnyWrRQ64JyfuPHjzoJRdO0XQMANMCJKJqW0pE2nopqX0X57nAtoGF3/o37yQAAU/usE1E0r40dxa0KyveXeK0FNEzrNQBAA2y+ZibSatuWerWronygnYPc1K8s8wIAYDo2XzMzz8aZaJF2VZRzOwe5qd/mN80oAwBM7Rlbr5mNHL2z0SKtCcr5Rv+EJV7MgmoyAEBDynkoC72YjX6blnq1qKKc1gJmwHwyAECDVJWZkTYt9WpFUB4v8Yp0MmAGVJQBABpkoRcz056lXu2oKFvixQzd+VOnoQAAGrPyYwEz05KlXu2oKFvixQypKAMANEhFmRlqy1KvhQfl/MaPH7XEi1kSlAEAGvTDgjIz1YqlXouvKN8drgXMkNZrAACoR05p4VXlhQbl8RKvFGsBM/T+h4IyAEBTktZrZm7xS70WW1HuRWvuZAEAAHvwjGVezFw/PrPYhc+LrSj3Fl9Sp/ve0noNANCcFXeUmb2c8kLPBy8sKOfr/SOjkvqRAAAAgEek1UUu9VpgRbnXivtYAAAAtFDqLayqvLiKcuTVgDl4W+s1AEBzLPNiTnIsbvHzQoJyvtE/4XYyAAAAu1jYTeXFVJRzb6GD2QAAALRfTul8LMDcg7LbyQAAAOxNOrKIm8rzryi7nQwAAMDeLOSm8vwryr2VtQAAAIA9WMRN5bkG5dJ2HbZdAwAAsGdpdd7t1/OtKGu7BgAAYL+ejTMxR/OtKPfS2QAAAIB9yKOqcszR3ILyvbbrdCQAAABgX9Jq/rX+4ZiT+VWUD/TmWioHAACgQ1Zibku95ldRzvPfVAYAAEA35NxbizmZS1DO1/tHIqVDAQAAAJNIcWiULeeyIHo+FeU0/wPRAAAAdEyK1ZiD+VSUtV0DAAAwpXm1X888KGu7BgAAoBFzar+efUVZ2zUAAABNmUP79ewrytquAQAAaMg82q9nGpS1XQMAANCoObRfz7airO0aAACAps24/Xq2FWVt1wAAADRs1u3XMwvK2q4BAACYidJ+/ev952NGZlhR7s18ZTcAAABLahhrMSOzqyinvBYAAAAwAznSaszITIJy/lr/0KgWfiQAAABgJtJqvtrvxwzMpqLcC23XAAAAzNZnZnNpaTYV5d7KWgAAAMAM5TSbS0uNB+V8s5S+82oAAADATM2m/br5ivJdbdcAAADMyWdXTkTDmg/KuTeT0jcAAAA8bjhsvqO5+dZrbdcAAADMSUrReLG20aCc3/jxo6P/locCAAAA5qOfr/cbHQFutqK8NdR2DQAAwHylWI0GNVtR1nYNAADAnOVodldWY0E5f61/aBTjjwQAAADM15Emz0Q1V1HuOQsFAADAgnymdzoa0mBQTuaTAQAAWIzU3Chwc63XkVYDAAAAFqDJTNpIUB6fhYporB8cAAAA9qmxM1HNVJSdhQIAAGDRGjoT1UxF2bZrAAAAFqyp9uupg3K+WVZwu58MAADAoqXVJs5ETV9RvussFAAAAC3x2ZUTMaXpg3LumU8GAACgHXKeejR4+tZrbdcAAAC0RM4xdTF3qqCcv9Y/FCkdCgAAAGiDFIfyr/efjylMV1HumU8GAACgZbamGxGeMign88kAAAC0yjBiqjnl6Vqvc7ifDAAAQKukFIupKOfr/SPmkwEAAGih/jRzypNXlHMcDgAAAGijKeaUJw/K5pMBAABoqWnmlCdvvTafDAAAQEtNM6c8UVA2nwwAAEDLTTynPFlF2XwyAAAAbTfhnPJkQdl8MgAAAC036ZzyZK3X5pMBAABouRSxGhPYd1DOX+sfMp8MAABA66U4NMmc8v4rygfMJwMAAFCJvLIa+7T/oJx75pMBAACoQ877Hh3ef+t1yuaTAQAAqEKeYE55X0E53+z3I5KgDAAAQC2O5Ksly+7d/irK+YD5ZAAAAOrymf3t2tpfUN4argYAAABETXr76ozeX+t1pNUAAACAmqS8up/fvs9lXhZ5AQAAUJf9Fn33HJTz9X4JyfsagAYAAIAW6Odf7z+/19+894pyij3/hwIAAECr5JXVvf7WfbRe91YDAAAAapT3Pkq899Zr95MBAACoVI5Y3evv3UdFeX9bwgAAAKBFDu31N+4pKN9f5AUAAAC16ud/ubdsu7eKco7DAQAAADX7oZU9ZdsDe/lNkXqrAdBh/X4/nnvuuThy5Mj48+0fhw4devDr5cduBoPB+Edx586dB3+//fnbb7/94NcBnmT7NWP7dWP74/vvvz/+9fL3T7P9uvX8888/eB3b/rj9awDLajgcjxRfedrv21NQzikdGo8+A1SuPCwePnx4HIi3f2w/RM5DeeDd3Nwcf9zY2Bh/Xh58S4gGlsf2a0H5cfv27QevBfN4M237DcHyWri6ujp+DSw/B7AMUoo9veClvfym4Y2DUjLV6h1/N1he2w+C5SFw+4GwjbYfmkt4Lj9u3boVLJ+c/eu2q0oIvnbt2jgUl+/xvVSG56kE5/I6efTo0fFrZfkBu8nf+HxApQajfPC5p/2mpwblssgrp96bAZUSlJdLedg7ceLE+CHv5MmTc6sUz0J5mC4P1uVjebim+wTl7th+86t8D7/++uutC8Z7UV5HT58+3eo3GVkcQZmapR8MX0w/Odjc9ffEU+Sv90/nXm89oFKCcveVMFwe5kow7moVZLsatb6+LjR3mKBcv/LG1pUrV8bfr13aSVCqzduvs0IzhaBMzVJKa+mlb+86p/z0oHzj4Gujf22fDaiUoNxdpUXw/PnzD+btlkUJzeV/d3kgN9vcLYJynbYrx5cuXVqKhX3blea1tbVgeQnK1GwUgi+m4++++pTfs7vhjc/fHH0rrAZUSlDulhKIz5w5E2fPnl2qcLyTUmEuP8w0d4OgXJfyZtWFCxfGH5dRqSxvB2ZV5uUjKFO3vNE7/t6x3X7HHoLywfdGHzyNUi1BuRsE5N2VitbFixfHLZ/US1CuQ3lzqlSPy/cd95TAXDpdBOblIShTuacu9No1KFvkRRcIynUTkPdnuy1bYK6ToNxuJSCX7y8jDzsTmJeHoEztUm94KH15sOMLem/3/+t4PgAWoITic+fOxVtvvTV+6BKS96Y8nJaH+fJ1Kw+swPRKa/WxY8filVdeEZKforxJ9+KLL45ftwFabbiy6z3l3YNy9FyfB+aunHd68803BeQpbAfmq1evxvPPe88TJlE6NMqW5xKSl3UOeRJloVmZ3X7hhRfGr0MArZTzod1++SlBOQvKwNyUcHfz5s3x9lhte80oD/nlYb9U573pAHtXZv5LZbTcQGYy5bWnVOHLsq8a70gD3TaMmLyinEfPrQEwB2UOuVSRu3oHedFKdb58fctJLWBnJdCVCvKrr766FKee5qG0Y5evqeoy0CYpYnW3X39KRTmpKAMztV1FLtUbFc/ZKl/r0j762muvBfBp21VkbdbNU10GWifFoXx154fPHbde23hNV9h63V6lulkqDNqs5688qJbqvcVE7WLr9WKUynHZrG9b/Hxsv0Hqtb9utl7TBekHwxfTTw6eeOtv54qyjdfADJVW61K18aC0GOXrXm7A2ozNsitvGh05ckRInqPyNS+LvkoFH2Chfmjl8E6/tEvrtY3XwGyU1l8PSItXWt1LRb8s+oJlVN6sK63WOisWo8yBl0o+wMLknZdX7xKUbbwGmlWCWWm382DULmXRl7lllk15s64smLKwa7EuXbo0HgPx5wAsxs4nonYMyjZeA03aDsm2WrdTefOibMW2UI1lUN4cKtVM2uHWrVvjyr4lX8C85ZwmqSjbeA00Y3txS5kDpL3Kn0/5cxKW6bISki9cuBC0y/ZZLmEZmKu0c3H4iUG5bLwOgAaU0HX16lUhuRLCMl0mJLebsAwsQv71/hOXWD+5omzjNdAQleT6bIdl6BIhuQ7CMjB3w5UnPqju0Hpt4zUwvcuXLwvJlSp/buXPD7pASK6LsAzMVX7yQq+dKspP/M0Ae1VODq2trQX1Kn9+TkdROyG5TiUknzx50jZsYOaGo/rAk37+yTPKOR0KgAmdPn16/HBK/cqfY/nzhBqVO+FCcr1u3749DssAs5RS7Kf12g1lYDJlw3W5T0p3lD/P55+3uoK6lIqkE1D1K6ejyvk6gBk69KSf/FRQzjfHq06tOwUmYmNy95Q/z42NDX+uVKOE5HKzXdtuN1y6dMkbsMAs9fPVTz/kfLqinA8cDoAJlHnWUlGme8qfq3llavHKK6/E22+/HXRH6Q7Y3NwMgJn4C5+uKn86KG/dVTIA9q0EKXPJ3VbaH48ePRrQZuV1qHRA0D2nTp3SJQDMxg+tfKpY/IQZZaehgP1zd3c5lOVIWrBpqxKQLe/qrtJS75oCMBPDvIfWa6ehgH3Scr08yp/zmTNnAtpGiFoOr7/+unlloHFPOhH16WVeTkMB+1CCk42ky6X8eduCTduUlmtzycuhdA2UN0YAmtJL+dCnfu7xn0hP+E0AOynVZK24y6X8eZtHp03KSMCVK1eC5VDmlHUPAE16UrE4Pf4TwxsHc0CH9I6/G8xGqSa/9dZb0VVlw2r5USoX25WqJ1UxSnAsFdby9dj+ceRI99c9lP+dKnjNytm/gvdr+xSUfxaXz2uvvaajaYHyNz4f0CWjzPBINn7kb/L1/pGcem8GdIigPDuXL1/u1Lv6ZRFQ+XHr1q1xQJ5mu2oJzyUsnz59evwQ38UZ7lLFK2d4aI6gvH8lKJU7u11XXlPK1vnycfsNuYdtv4m3/ebe7du3o+vK16K8WauraTEEZbom9YaH0pcHD951fTQov/HjR/PWcCOgQwTl2ehKNbmE4bIYpiyImeWNzhKayxKskydPduqhTlW5WYLy/pRA+MILL0QXldeJEydOjN9om/TNtu03/65du9bZ4FxeVy33WgxBma5JkU6m499+/ZO/f0i+/vm1nPLlgA4RlGej9mrydkAulah53uUsD7ulyly+dl2oMpdZZed4miMo78+LL7440ze4FqFUjcvrQ9NvqpU3FbZvTHftza1ynrC8mcB8Ccp0TUppLb307QcLLx4NyjcOnhv9K/p8QIcIys2rvZpcAnIJd/MMyI/bDsy1L8UqX8NS0Vvk17JLBOW961rrfwnI5fVg1oGvBObytSs/uhKYy9euvAHAfAnKdM0oGJ9Px9998O5/77FfPRQAT1EeSmpUHhBLC/Srr7668GBX/ruUsF5CZs1nTkrFqwR+mLeubF4v30NXr14dB715VEXLm3TbleWufO+WvRKCMjCtYX40Cz8SlN1QBvaixgfUUj0pbZptm9PbnrGs+aG/tIjCPHWlGlpmkEt3ziK+h0pgLl/HMkbThbvoFgsC03r8lvJjd5SH1gYCuyoV2dpma0sILQ9RbW4PLtXlWs+clCqYrbPMUxeqyeW0UVmytejvnTIPXaqxhw8fjpptt5QDTOrxovFjQTl1//AnMJWyYbQmNS2bKovFyhsRNc77ar9mXmqvJpdgXJZPtemNsfLmZ1mKVtvr++MsFgSmkuKRdy4fBOV8UzkAeLqaNotuL+2qSWkNr7GVWfs181JzNbkE0jZvaC6vmefOnYtaqSoDU+rnq59k4k8qyh9b5AXsrqa261IdKUu7alQW09TWhl3+2dB+zazVXE3eDsnle6XNyhsRNYfl0pkDMLG/8Ekm/iQoHzjwXADsopZt16WqUHuFszzslepOLUpIrn3GkfartZq8vdm6ljcay9e51jbs8iapDdjAxP7CyoPthp8E5bv5hQDYRS3hszzkdWEjbmkbr+l0VNsrZdStLL6q9fu6VGhr+/4ob9TVegqwK6fDgAV4aE75k6Cccv23AYCZqmE+uVQSrly5El1QlnqVjbS1qGl+nfrU2lJbQnKtG+3LmxM1no5yVxmYWP7kRNRDQdmMMrCzWioLNQXLvSgPfLUsp1FRZlZKZ0WNwaeMI9Rc3Swt47UuxyohH2C/hvkJM8qP340CeFgNIaj2szE7qWVzd5m/tNCLWagxbJbvhy6EtdIpUuNyr9JZVOOpPWCxeik/ofUaYBc1tNV2peX6caWaVssDdy3LiqhLjdXkEi678v1Q3qiorQW7hGSnooD9ypEObX/+ICin9Ek/NsDj2v7AV2tr5l7VsgHb5muaVuMSrzKq0rUxkBpDp/ZrYN/yE5Z55WxGGdhZ21uvazqlNIkyq1zDBmwVZZpWY0DrYiWzdBWdOHEiamKpF7Bv6bEZ5XzTUBmwsxrmk5ehclDD/0ZBmSaV9tnXX389anL69OnOfh+UNyRr20MgKAP7la/ee6G7V1H+WDUZ2Nlzzz0XbVYqrV1c4vW4GoKyZV40qbY3wEpA7vIN3/K/78yZM1GTWs+KAQv0YzF+8L0XlA8caPdTMLBQba8oL0vF4Pbt29F2gjJNqi0od7mavK3chK7p+7x0JagqA/vyg3ihfLgXlLfuerIBdtT2h6JleQgqD3xtn1MWlGlKjW3XXVvg9STle7y2WWVLvYB9eWZlvOb/XlDOvUMBsIO2V0hqqLQ2pe1vCgjKNKW2N8CWoZq8rbY3BGp7wwVoh3tBOYUnG2BHbX/429zcjGVRqmywDGqrAnZ5NvlxZQN2OYFVi9KJU8PVAKAl8r2zydvnoQRloErL9vDjYY9lUVNFuYTGZdv4XtsbA9qvgX14aOu1ijKwizY/AC5bcHz//fcDuq6E5Jo22S/DbPLjypLHmkYtBGVgr4b5oaCcczoUAAAtUNM4RXkjcRmDcgnJZS67FmWXhdEVYC966dHWa4AqaUVuF38eNKGm5Us1zeo27eTJk1GLEpKXaZ8FMLkc6ZOKcrqfmgGeZNlm74DFqmk+eRmrydvKUi/t10Dn3G+9PjD+PJtRBna2vr4ebbUsN5RrobWRadX0PV3eRCxhcZmV9utLly5FDVSUgT1JDwXlsPUa2MUrr7wStMPzzz8fbab1mmnVtu162ZX261qC8q1bt8Zv5rn3DjzFvdbrfNOrBUAt2v6AJygzrRJmalHTjO6s1NZ+raoM7EW+2u/34iPVZIBalJMsbSYoM62agsyyt11vq6myLigDe/Jj8VwvVgRlgFq0vXJT0+1b2qeEmFrm3Es41MJ7T01vGNhrAexVLw4ceC4AaL3yUN72irJqDdOoqSOh7d+L81RTC3q5pwzwVD+IF9xRBqjE4cOHo81UaphWTf8Mabv+RNn+XUt1vbwZYzs/sBe9uJtfCABar+1VG9VkplVTtU9QftSJEyeiFt7UA57qmZXnVZQBKtH2B3NBmWnV8s9Qabs2n/yomlrRLR0E9mIUlLMZZYCWK62NbX8QVaVhGqUdtpaW2LbfM1+EmoKyOWXgqYa534tk6zVA2507dy7arFRobLxmGs5C1a2moKz7BXiqUUbWeg1QgbY/mKsmM62awouN159WWtFrqbRrvQb2ogRlFWWAFjt9+vS49Tpa7MqVKwHTcBqqfrV8XUqLv7AM7GaY45DWa4CWO3/+fLRZeeBUUWZatQSXUjm1yOvJanoDwYko4Gm0XgO0WA3VZCGZJtQy4972e+aL1PbXqoeZUwaeppdzOhQAtFLbq8mFtmuaUFNFmSdzIgroil7KlnkBtFXZdN32Co22a5pQ02ko88k7q6mibEs/8BSCMkAblQfOGqrJNfx3pP1svO6Gmua333rrrQDYjaAM0EJtv5u8TTWZJtS0WEnr9e5qqSqrKANPMwrKQ6/4AC1y5syZWFtbi7ZbX1/3sEkjapoXram9eBFquaVs6zWwm7LHq5dSEpQBWqKWlutC2zVNqSm0CMq7q+XrU9NcPLAYWq8BWuTmzZtVtHaqJtMkG6+7o6avkaAM7EZQBmiJ1157rZpqjGoyTaolsKgmP11NXyMnooDdCMoALVDmks+ePRs1UE2mae+//37U4Lnnngt2p6IMdIWgDLBghw8fjosXL0YtVJNpWi2B5YUXXgh2V1NFWVAGdtPLOQ4FAAtRHiqvXbsWtVBNZhbee++9qIGK8tOpKAOdkOKQijLAgpSQXJZ31VKBKfN8qsnMQi1vvljm9XSCMtAVgjLAApSHyatXr1bVplhCsmoyy0xQfjpBGegKQRlgAcqG6yNHjkQtNjc348qVKwFNq2nzsKC8N7V8nWpZIgcshqAMMGclJK+trUVNTp48GbDsBOW9McsNdIGgDDBH586dq+YM1DYt18xSTe2vgnK31LJEDlgMQRlgTkpIrm0ZVmmLvXDhQsCsmBNlUfyzB+xGUAaYgxpDcnmIXF1dDYD9cG8a6AJBGWDGzpw5U+VZJS3X8Cit1wDLQ1AGmKHTp0/HxYsXozbr6+tx6dKlAD4hKHeLrdfAbgRlgBkpIbkEztqUueRXX301ALrMjDKwG0EZYAZqDclFmUv2AMm81HRHGYDlISgDNKzmkFxOV5lLBgCWnaAM0KCaQ3KZpTaXDAAgKAM0puaQvLm5aS4ZAOA+QRmgATWH5DIjevLkyQAA4J5eSnEnAJhYzSG5LO0qy7vMJQMA3JfjjooywBTOnDlTbUgu1tbWhGQWym1iFuX5558PgJ0IygATOnfu3HgBVq3Onz8fr7/+esAiCcoAtJGgDDCBEpJL0KxV+e9+4cKFAADg0wRlgH167bXXqg7JpVVcSIb9K4vvAFgOBwKAPbt8+fJ4rrdW5QzUK6+8EgCzUpYEAlQtxeBAzulORD4UAOyozFHevHkzjhw5ErUq1bBjx44FtMmhQ4eCbnnvvfeiBi+88EIAPEmKPNB6DfAU5UG+CyG5nIFS6YHJab0GWB5arwF2sR2Sa656bYdkZ6CAeXj//fejBs8991wA7KSXYqi8APAEQjLMXk3fXzoy9qaWr5PTZMBuepGSV32Axxw+fLj6kFweVoVkaI6g/HQ1fY0EZWAnw5zumFEGeEwJyRsbG0IyzMnzzz8fNRCUn05QBrpCUAZ4yOnTp8chueYHqO2QfPv27QCaU8vs7SLVtPDMxnVgJ70Ug17kuBMAjEPy+vq6kAxzVsuZnrfeeisAWArOQwEU586dG4fkmgnJ1KqW1mujDE+nogx0RakoG7gBlloJyefPn4+aCclAG5hRBjohjyvKycANsLSEZFi8Wip7NVVLF6WWr1EJyYIysKNe0noNLK/Lly8LydACNbXACsu7q+Xro+0aeJpeHEg2UwBLpVQRrl69Gmtra1EzIZmuqKmy50TU7mrZDP7cc88FwI4+3npbRRlYKuWB/ObNm3Hy5MmomZBMl9RU3dvc3Ax2Vstm8Fo2rQOL04vv37XCEVgK5WH8zTffjCNHjkTNhGS6Rut1d9SyGbyWTevAggydhwKWRHkQL5Xk2ufShGS6qKbFSk5E7aymarsZZWBXPxzv9UZ/MWwDdFpXQnKpZJVquJBMF9Xy/an1emc1zW8LysCu/jze76VjtlIA3XX48OFxu3UXQnKpJKtm0VXle7UGWq93VtObCLWP4ACzlU4NHrReC8tA5xw9ejQ2Njaqv5UpJLMMavk+LVVTYfnJyuttDdxQBp5inI3HQTklQRnoltOnTwvJUJGaKnzar5+sltNQtXQvAAuSHwrKOWdBGeiMM2fOxPr6etSuPIwLySyLmoKyivKT1fIGgmoysJuU8p3y8X7rdU9QBjrh3LlzcfHixahdeeA8duyYkMzSqGmPgIV6n1Zes2pZ5mU+GdiL+63X91IzQM1KSD5//nzUrlTDS0iuaYMsTKtU+Wq5bVvLLO481VRlL506ADsZ5nSnfLxXUc5mlIG6vfbaa50Jya+88oqQzFKqpdJXQqHv0UfV9OaB01DAbnrpoRnlsPUaqNjly5fj7NmzUbsS9EtIhmVVU4BRVX5ULe3opXNBUAae4qGgnJMhOKA65YGn3EheW1uL2pWQfOHChYBlVlNLrKD8iVJdr+XrYeM18FT50YoyQFVKReDmzZudWMpSquFCMjgRVauavhbmk4GnSg/PKB9IbwVAJboUkks1/NKlSwHc+96u5XTPrVu3zCnfd+3ataiFjdfAU93dGh+FvxeUv39X6zVQhe2Q3IUZsxKSr1y5EsAnjh49GrXQfn1PedOgFirKwFMNH269/mHLvID2K7NlQjJ0mznlupQN4LW0Xpdqci0dC8AC/SDulA/37igf0zsEtFsJyeWhVEiGbqupNdb3cV1vFljkBexFOjV4dJlXSveSM0DbnD59evww1oVKgJAMuysV5Vq+12va9jwrNb2eabsGnip/kokfBOWcs6oy0DolJK+vr1cfkssDtZAMe1NT5a+mRVZNK23XNb1RICgDT5NSvrP9+ScV5VBRBtrl3Llz45BcuxKSywOakAx7c/LkyajFMn9f1xSSS0t/F0Z3gPn55I5ySirKQGuUkHz+/Pmo3XZIvn37dgB7U1Plb5nbr2t6k6CmberA4gzzvRvKxSdBOasoA+0gJMNyq207cRder/artrbrmroUgMXppSfMKEdObikDC3f58mUhGRjvJ6hFuSM8WLIDIjW9Tpc3XcwnA3uSnlRRTlvvBcCClAeZq1evjhde1U5IhunVVgG8ePFiLItSTX799dejFtqugT37eOtB8fjh1msVZWAhSki+efNmJ1rjhGRoRm3t15cuXVqaqnJpua7pf6u2a2DPhvHgxe2ToPyMGWVg/soW0jfffHP8UFy7UmUp/zuEZJheCck1VQJLcFyWqnJt4zGCMrBnP3jCjHI6Nn5r0OZrYG5KSC6V5C6c7CghuVSS335bcw40pbZRjGWoKpeTfTW9zp04caKqzgRgsdKpwRMqyuUXkqAMzIeQDDxN+b6qKeR0vapcXutUk4EO23z4bx4Jyvmhu1EAs3L48OFxu7WQDOymhORSEaxJl6vK5U2Aml7ryj8/gjKwVynyIy/ej1WU850AmKEyc1gWwXShFU5Ihtmrrf26hOQu3lUur3flTYCaaLsG9mP4WNH4kaAc2UIvYHbKXVQhGdiP2tqvixIoy2tdl9R4h7gL5waB+emlR7PwY0E5eeIDZuLMmTPjJTBdICTDfJXXj9q88sornWnBLhXy2l7vymhPjeEeWKC0W0U5bb0XAA07d+5cZxbcCMkwf2fPno3a1Lj46knK/44LFy5Ebcq/dwD25eOtRx7uHg3Kd8PxT6BR5WGlK/N6QjIsRm03lbfV3oJdKuK1VmVVk4F9G8Yuy7y+OrgTAA157bXXhGSgEbW+lpw6dWr8+lGjMuNb42te2YfRhasKwHylnxzsfB5q/BuShV7A9C5fvlxlu+STCMmweOV7sMaqcqnKHjt2rLp55fLGxOuvvx416uLWcWDGnrDU+lNB2S1lYBqlRbLcSO7KtlEhGdqj1teV7deRWsJyCZo1ziUX5c0U1WRgv550Jrm3l98EsBfl4eTmzZtx5MiR6ILNzc148cUXhWRoiRKUn3/++ajR7du3qwjLNYfkQjUZmMTwCcXi3qd/V2wGwD51MSTX2C4JXVdzENoOy22dWa49JJd//1jiBUyil/bQej2qKb8fAPuwHZK70u4mJEN71VxVLkpYLq8vbQrL5bWufF1rDslFjfe2gbZInyoWPyEob6koA3t2+PDhToXk8vAqJEO71d5eW15nXnjhhVbcly9vDJZK7JUrV6Jm5d9BXdmNASzA3a1PFYvT4z+Rb/b7+W7vvYCO6B1/N5iNEpLLjdCywKsrykPjyZMng+m9//773nDYp5xzsDclGHVhf0BZPrW+vj73NxvL92YJ6uXWcxe+T8sbttqu5yt/4/MBXZE+HH4unXr0xTA96TcObxwsQbk7T74sNUF5NsqdyvKQ1aWQTLNqn3dcBEF578qbdKX7oyvKa2r5nplHYL527dr4fF9XFhWWr115s4H5EpTpkMEoL3zu8Z/sPfn32nwN7Gz7oURIBhal1rvKOymtz6Udu7QPz2J+ebuCXDb5nzp1qlPb/G26BqaRIj9x9PiJQTmlZE4ZeKJz58555x5ohS4GpO3AXAJtCbZlHGRSJRyX1+tXXnll/J/56quvTvWf10bljVt3k4FpPOk0VHHgyb87Np/clA0ssxKSvXMPtEWpKpdNx2XOtmtKoN0OtaV7pyzcKnshSigsPx7v6CmhuPwo1ehSLS6t6W09Q9WU8nXw7yRgWk86DVU8OSin4Z0du7KBpeWBBGib8rpUqrBdXhxX/reV4Ft+8Iny5q1qMjC9tPfW67gbtwMAoOVKZfXy5cvBcinz6c5BAY34wdYTlzY8eUb5q4M7AQBQgXLS7cSJE8HysCsDaEr6ycE+Ksrl/2CHXm0AgLaxiX95vPbaa1qugabsuOFw50HknG2+BgCqUELy1atXg24rLdflBjRAE9IuZ5F32diV7gQAQCW2t2DTTaWKrOUaaFaapKKcLPQCAKpSbg+XM0p0j5ZroHmTBOXY0noNAFTn2rVr5pU7ppyCKkvbABq1w8brYueg/IxlXgBAfUrV0bxyd5SN5uVeNkDTdtp4Xey89frYYGDzNQBQozKvXFp1qZu5ZGCGdu2g7sXuNgIAoEJlO3Jp2aVOJSTfvHlTGz0wE7ttvC52D8rDMKcMAFSrtOyePn06qEsJxyUkW94FzE6aoqKchncCAKBipXW3zLlSByEZmI9pgvLdcCIKAKheCcvORtWhzJYfOXIkAGZql43Xxa5BOX11cGf0YRAAABUrVcqNjQ1hueUuX74ca2trATBjg902XhdPW+YVTytJAwDUoITlzc1NM8sttN1uLSQD85AiPzXjPjUo7+U/BACgFqUN+8yZM0E7bG+3Lie9AOYjTR+UIydzygBAp1y8eNHpqBbYDslmkoG5Sk0E5dhSUQYAOqecjiqLo9zpXYyjR4/Gm2++abs1MH/f33pqMfjprdcvj4ecLfQCADrn7Nmz47D2/PPPB/NTWt/LcjVvUgCL8LRFXsUeKspFvhMAAB1UKpoltFnyNXslGJfN1qX1HWARUuSNvfy+PQXllGy+BgC6q4TlsuRLK/bsbLda22wNLNIwpTt7+X17qygPQ1AGADpvuxW7hDqaUd54KG9AlKq9eWRg0XqRNvb2+/ZkeCsAAJbAdit2aRE2uzyd7SpyeQMCoBX2sMir2FvrtYVeAMCSKS3CZpcnsz2LrIoMtM1eFnkVe6woFxZ6AQDLZXt2+a233hKY96AE5HKfuny9zCIDbbPXRV7FnoNy2mMvNwBA12wH5ps3b5pffoKHA3K5T20hGtBOe19SvfeKck576uUGAOiq1dXVcTtxCcwqzAIyUJu9F3/3HpS3tjYCAIBxYH64JXvZln6VqnrZZC0gA1X5wdbbe/2tB/b6G9NXB3eGNw6WhV5eCQEA4pOW7KJ8LD9u3ermsZAShsubAidPnhy/UQBQmcFeF3kVKfYh3/jc1RzpZEBFesffDYAa5JyD+t25c2fcnt2F0FzC8YkTJ8aLuY4cOaJyzAP5G58PqElZ5JWOv3ds779/H/L1g2dyiosBFRGUgVoIyt0zGAzGofnatWuxubkZt2+3f+VLaasuoVjlmN0IytRmFHzPp+PvXtjH79+7/MaPH81bw42AigjKQC0E5e4r1eYSmEt43g7OJUwvSpmtLqG4/CihWNWYvRKUqU26OzyWvjrY2PPvj33IN/v9fLf3XkBFBGWgFoLycipBuYTm8qME6fKj/Fz5+Pbbe947s6MShkv43Q7B28G4zFcLxUxKUKY26cPh59Kpvb8zua+gXAxvfO7N0f/ZkYBKCMpALQRlnqSE5u3g/LCH/74E3u3Qu/35wz8HTROUqczmKBO8uJ//gz1vvd6WIm2M/jUuKAMAzMF24C0VYAD2L6fY87brbXu/o/zJ/5f2b6EAAACAkV5O12Kf9h+Ut7Y2AgAAAGrQ25p9RTl9dXAnpbgTAAAA0Gaj7Jq+PNj3ZsT9V5Tv2QgAAABosZTzvqvJxWRBeRgT/T8DAACAuUm9fc8nF5MF5a3h6wEAAABt9v2tiZZRTxSUy5zy6MOejzUDAADAXJX55J8czLH1uvz/TDFRCRsAAABmbdL55GLioGxOGQAAgNaacD65mDwom1MGAACgrSacTy4mb702pwwAAEAbTTGfXExeUQ5zygAAALTPNPPJxVRB2ZwyAAAArTPFfHIxXVA2pwwAAEDbpK2NmMJ0rddfHdxJKe4EAAAAtEGZT/7y4O2YwnQV5SKbUwYAAKAdcsRGTKmBoJwmXrkNAAAATerlNHUxd/qg/MyWijIAAADt8OHWrZjS1EE5HRsMRn/dCAAAAFigFHkjnSoZdTrTV5Tj3n+ZAAAAgIVKjZwwbiQox0pvIwAAAGCR7jZzwriZivKXvlV6wKcubwMAAMCEBumrg41oQDMV5dB+DQAAwOI0mUkbC8qRLfQCAABgQVKvsYtMzQXlZ4ZXAgAAABYhbW1EQ5prvR6ficqNbBgDAACAfdhMXx68HQ1prqIcpSc8NVbqBgAAgL1IERvRoEaDsjNRAAAAzF1DZ6G2NVtRdiYKAACAeUpxp6mzUNuarSiPpBTarwEAAJiL3HDbddF4UI5huhUAAAAwB73c/K6s5oPyM1sqygAAAMzHh1uNF2ubb70en4lKGwEAAAAzlCJvpFODxvdkNV9RHkk5qyoDAAAwW6m3HjMwk6AczwyvBAAAAMxS2tqIGZhNRVn7NQAAALO1mb48eDtmYDYV5bjXKx4AAAAwAynHeszIzIJy3NV+DQAAwIx8PJzZaeLZVZS/OriTUtwJAAAAaNIoa6afHGzGjMyuolzMsBQOAADAcko5ZnppabZBeaW3EQAAANCkH8x21HemQTl96Vu3tF8DAADQmBm3XRezrSgX2q8BAABoyKzbrovZB2Xt1wAAADTlB7O/sDTzoKz9GgAAgEbMoe26mH1FudB+DQAAwJTm0XZdzCcoa78GAABgWnNouy7mEpS1XwMAADCVObVdF/OpKBfarwEAAJjQvNquizkG5eHrAQAAAJPoDS/GnMwtKKeXS4k8bQQAAADsz2b68uDtmJP5VZSjtJTnjQAAAIB9SCnNrZpczDUox4HhpQAAAID9SFsbMUfzrSgfGwy0XwMAALBXpTN5nm3XxXwrylE2leW5bSoDAACgcqm3HnM296Acz4wPRA8CAAAAnmbObdfF/CvK99qv53IkGgAAgHrlFOvzbrsu5l9RHkkr6XwAAADALno5LWR0dzFB+UvfuhXarwEAANhJijvp+LdfjwVYSFAuUsR6AAAAwBPkiI1YkIUF5Vjp2X7NXDz/Fxf3jzkAQOd8752Aeeh9f3gpFmRxFeVx+7WbygAAAHzKZvrJwcKWQC+01OamMgAAAI9LKV2MBVpsT6qbyszB5z6TAgCAhnz0RwEzt4DbyQ9bbEX52GCQUt4ImKH+s4IyAADUYlG3kx+2+C1HvZWFltTpvuf/0koAANCMfPf9gFnqfTzuPF7sf4dYMDeVAQCgIrZeM0vldvJXBxuxYK24m5MiVJWZmUPOQwEANEdFmRlKebgeLdCOBHFgcfex6D53lAEAGiQoM0u9WI8WaEdF+dhg4KYys/I5y7wAAJpj6zUzkiJfW/QSr22tKbWllXQ+YAYs8wIAaNDHKsrMSm89WqI9QdlSL2ak744yAEBzPvi9gMaVJV7Hv/16tESrhjct9WIWDv2lnrAMANAUM8rMQFuWeG1r15YjS72YkefMKQMATO/D3w2YiZYs8drWroqypV7MyJG/ciAAAJjSx38e0LScYr0tS7y2te5ujqVezIJbygAA08sfqCjTvN7HwyvRMu0LyveWem0GNOjwX7H5GgBgah+9E9CossTrq4ONaJlWltlSbld/OvUrC70AAJiSjdc0LEU7O4rbmR6eGZfenYqiMWaUAQAaICjTrEGkrY1ooXZWlI8NBilUlWlO/9kUz5tTBgCYXDkL5TQUDcoprrVtide29iaH3L6BbuqmqgwAMAXVZBrWS8Pz0VKtDcrp5cGmU1E0yeZrAIDJ5fd+I6ApKfJGW6vJRauTg1NRNGn1sIoyAMDEPlRRpkm9i9Fi7Q7K5VRUijsBDTis9RoAYHJar2lKOQl1/NuvR4u1vhc1DaPV7zRQj3IiykIvAIAJlPvJ33NDmWa09STUw9qfGpyKokGrh58JAAD2J6sm05TSMfzBVquryUX7K8r3TkWpKtOII39lJQAA2CeLvGhIjthIpwatL4TW0Yd6YHgpoAFHVZQBAPbvvd8MaEKbT0I9rIqgPK4qp3wtYEqlotz/TAoAAPbo7vsWedGInGK9zSehHlbPZqPeivZrGqGqDACwd1k1mYbUUk0uqgnK41NRkTYCpuSeMgDAPvzZvwqYVoq8UUs1uajqVk5aaf8acdrvxP/5LwQAAHukokwjelV1CNcVlFWVaYB7ygAAe+R+Mk1IcScd/3brT0I9rLq0kFKsB0zppKoyAMBT5X+r7ZrppaivM7i+oPzSt6+MPrT+7hbtduKvW+gFAPBU5pOZVqkm38twVamy/zRF2IDNVFYPP+NMFADAbkrbtflkplRjNbmoc1DzwPBSqCozpdMv/1AAAPBkzkIxtUqryUWdFeVjg4GqMtPSfg0AsIs//pWAaaQ8XI9K1bv6V1WZKWm/BgDYgbZrpjWqJo/S5npUqtqgrKpME7RfAwB8mrZrppUjNtKXB29Hpeo+JquqzJS0XwMAPIG2a6bUS8PzUbGqg7KqMtPSfg0A8Bht10wpp1ivuZpc1F1RLu5VlWFiZ/6W9msAgG1ZNZkp1V5NLqoPyuOqcqp3SJzFO/O3fiQAALjvT/5FwKS6UE0u6q8oFx8PLwRMqP9siqP/0YEAAFh6peX6e+8ETKoL1eSiE0E5fXVwR1WZaZz7KVVlAID8J9qumVxXqslFNyrKhaoyU7DUCwBYemWJl/lkptCVanLRmaCsqsy0LPUCAJZZfucXAibVpWpy0Z2KcqGqzBTKUi9VZQBgaf3Z1wIm1aVqctGpoKyqzDTKUq/TL6sqAwDLZzybbIkXE+paNbnoVkW5uFdVHgRM4MRffyYAAJbON38+YFJdqyYXnQvK46pyxMWACZSlXk5FAQDLRDWZaXSxmlx0r6JcHBheClVlJuRUFACwVGy6ZgpdrCYXnQzK6dhgoKrMpFSVAYCl8d5v3vsBE+hqNbnoZkW5UFVmCqrKAMAyyN/8uYCJpLjT1Wpy0dmgrKrMNFSVAYDOU01mCikPO1tNLrpbUS5UlZmCqjIA0GX59382YCKjavIoSa5Hh3U6KKsqMw1VZQCgq8abrj/4vYBJpEjnu1xNLlJ0XL7Z7+et3puR41DAPm3+4d34az/z5wEwDznnAJiH/JsvOgnFZMps8kvvvhAd1+3W69iuKqfzARM48lcOxJlTPxQAAF3hbjLTWJZs1fmK8rbhjc/fHL0srAbs0+DDHF/824MYfEelB5gtFWVg5u6+H/l/XhWUmcySVJOLzleUt6UVVWUm0382xZm/paoMANQvv/MLQjITW6ZO3aWpKBeqykyqVJVf/Jn34+0/HQbArKgoAzP10TuRf+PFgEmkyBvp+HvHYkksTUW5UFVmUqWqfPkffCYAAGqVv/nzARPr5bVYIssVlL/0rVspdfveF7PjXBQAUKvxAq8//pWASeRRhur6OajHLVVQHvt4eGH010HABEpVuf+ZpZpYAABqd/f9CNVkptBLw/OxZJYuKKevDu6MYs7FgAkc+ksr8Y//zo8EAEAt8jd/zgIvJpZieH7ZqsnF8lWUiwPDS6GqzITO/qc/rAUbAKjDR6OA/M4vBkwkxZ1RYlyPJbSUQTkdGwxSivMBE9KCDQDUIP/2iYBJlXNQy1hNLpazojySXnp3VFXOmwET0IINALSdlmumMqomp5e+fSWW1NIG5SKtrJwNmJAWbACgtd77TQu8mErKw6XOSssdlL/0rVujv24ETEgLNgDQOh+9E/lf/72ASY3PQR0fvB5LbKmDcpHubr0SFnsxodKC/c/+7o8GAEBb5FJJ1nLNFJbxHNTjBGXnopjS2ld+KM6c+qEAAFi0/M4vRPzxrwRMalnPQT1u6YPymHNRTOncT/1oPP8XfTsBAAtUTkGZS2Ya5RzUh3EpEJSLe+eiksVeTKz/bIqb/+1nzSsDAItx9/17p6BGH2FS43NQpwYKiCEoP3Bv9bnFXkzOvDIAsChOQTG1JT8H9ThB+SFpJZ0PmIJ5ZQBg3sYh+Z1fDJhGSsPV4AFB+SHlXJTFXkzrtf/bZ9xXBgDm44PfNZfM1MbnoCzweoSg/LgDwwthsRdTunrhs5Z7AQCzVe4l/85PBUwlxR3noD7Nk/xj7i32ivMBU7DcCwCYqe3lXeaSmdJ4gZdq8qd4it/B8Mbnb0bk1YApbNz+OL709z8IgL3IOQfAXuTf/psR7/1mwFRKNfmld18IPkVFeQdpZcu5KKa2eviZ+Gc/YxM2ANCc/Ps/KyTTCAu8diYo7yB9aXDbYi+acPY//eH4x3/nhwMAYFo2XNOUknW0XO9MUN5NWeyV4k7AlM7/1I8KywDAVMYh2YZrmlAyzofjJcbsQFDexXixVx5qwaYRJSz/1PG/EAAA+5X/5FeEZBozXuB1auDSzy4s89oDi71o0trPfxi/dOMHAfA4y7yAJxmH5P/17wU0odxMXnnp3VeCXako70G6u1X+QfKOC41Y/4fPxtH/6EAAADxVWdolJNOUFAM3k/dGUN6D9NXBHbeVadLVC5+Nw19cCQCAHX3wu5Fv/52ApqRhuJm8R1qv90ELNk0afJjj1LkP4tbv3A2AQus18MCokjwOyXffD2iEm8n7oqK8D24r06T+sylu/j9/zIIvAOARZSY5//bfFJJplJvJ+yMo74PbysxCmVkWlgGAwuIuZiHFUMv1Pmm93qd8s9/PW703I8ehgAad/6Xvxj/55Y8CWF5ar2G5uZPMTGi5noiK8j6Nbyv3emsBDSt3lv/x3/nhAACWj5DMrKTccwpqAoLyBNKXvnVLCzazUMLyP/uZHw0AYHnk3/9ZIZmZKJklHf/WRrBvWq8npAWbWdq4/XH8rXMfxuA72jBhmWi9hiVz9/17m63LrWRoWoo7ZYGX2eTJqChPSAs2s7R6+Jn4X37hx+L5v+hbFAA66aN3Iv/Pq0IyM5MiWeA1BU/hU9CCzSwd+ksrcfO//Wwc/uJKAAAdUm4k/0+rEd97J2AWcor19NK3rwQTE5SndWB4obQ1BMxACctv/uJzlnwBQEfkd37BjWRmq2y5TsPzwVTMKDcgv/HjR/PWcCNghi7+jx/FP/nl75lbhg4zowwdVuaR/7efjfiTfxEwSymlNdXk6QnKDck3Dr42erw5GzBDd/7NVhz7+x/E2386DKB7BGXoqDKP/NsntFozc6XleuWld52DaoDW66ZowWYOxq3Yv/BcnDn1QwEAtN+41do8MvOg5bpRKsoN0oLNPK1//ftx4Ze/p7oMHaKiDB2i1Zo5S9E75mZycwTlhmnBZp5KK/Yr//Q7cet37gZQP0EZOqJstf7Xf08Vmbkpl3jS8XdfDRojKDcs3+z381bvzchxKGBOzv/Sd+Of/PJHAdRNUIbKlSryN38u4p1fDJibFHfSB8MX06nBIGiMoDwDWrBZBIu+oH6CMlRMFZkFSb3hofTlwdtBoyzzmoH0pW/dKu0PAXNUFn299f/rxz/7mR+N/me8BwYAc1GqyL//s/duIwvJzFmK4XkheTY8Tc/Q8Mbn3hx9iY8EzFmpLl/4pe/FlRs/CKAeKspQGVVkFqlsuX7p3ReCmVBRnqF0N58afTArwNyV6vLlf/hs/H///mfi+b/o2xwAGjW+i/w3VZFZnBSDlIarwcyoKM9Y/sbBM6MCgTZsFqos+/p//er3Y/Ad1SpoMxVlaLnSZv3OL9xb1jX6HBYl5TibXn73UjAzgvIcDG98/ubo8Wc1YIG0Y0P7CcrQXuOA/M2fF5BZuJxifeWld18JZkpQngMno2gTgRnaS1CGFipzyL//X0V88LsBC1dOQaXhqgVesycoz4mTUbTN5h/cjVf/+Xfj1u/cDaAdBGVokRKQy03k0UdoixTDk+n44PVg5gTlOco3Dr42egQ6G9AiG7c/HleYBWZYPEEZWkBApqXGp6CODy4EcyEoz5mTUbRVCcxXvv59LdmwQIIyLJCATJs5BTV3gvKc5a/1D+UDvVFYjn5AC5lhhsURlGHOyhbrP/6ViD/7VwIy7XXvFNQRc8nzJSgvgJNR1KAE5mu/9XFc+tWP4u0/HQYwe4IyzIkzT1TEKajFEJQXxLwyNVkvLdnXv2+OGWZMUIYZ015NZZyCWhxBeUGcjKJGpcq8fr2E5h+oMsMMCMowA6rH1Kqcgvpg+GI6NRgEcycoL1B+o394FJY3wrwyFdpe/rUxqjILzdAMQRkaYvaYDki94SFzyYsjKC+YeWW6QGiGZgjKMAXhmA4xl7x4gnILjMLy5dGz0VpAB5TQ/PpvfhzXfkt7NuyXoAz79NEfRf63/1I4plPMJbeDoNwC5pXpqjLTvHH7brw+Cs23Rh8H3xECYDeCMjxFmTEuC7lKKC4BeRSUoVPMJbeGoNwS5pVZBpt/eDdubd6Njd/5ePT5loozPEZQhseUIPzub0T+8PdGAfk3Ij74vYDOci+5VQTlFjGvzLIpFecSmG//4da4Zbt8VHVmmQnKLLUSij/43cjfe+deG/XocxVjlom55HYRlFvGfWWW3eDDPK483/6DrbgzqjiXz8vP3f7mVkDXCcp0XmmdvvvnnwTiUikuH0ul2OkmltgolF1Mx999NWgNQbllxvPKd9PN0R/NkQAesR2iy8e3/81wXH0un9/5063xx+LOQ+3cWrupjaBMdR6u+H78/r2wW4LvSP7onXu/Xn6+fD7+qEIMn5LiTu+ld18IWkVQbqH8tf6hfKD3ZphXBgCA7irLu9Jw1Vxy+/SC1klfHdxJK72TAQAAdFbKw7NCcjsJyi2VvvStW6Ny//kAAAA6J8XwfDo+eD1oJa3XLTe88fmbEXk1AACAbkj5Wu+l904FraWi3HLpwNapMrsQAABA/cZzydmVm5ZTUa6A5V4AANABKQYpDY+YS24/FeUKjJd7paF3nQAAoGIpkuVdlRCUK5FeGlyx3AsAAOo0Xt710revBFXQel2Z4Y3PXR39sTkdBQAAtbC8qzoqypVJB/IrlnsBAEAlyvKuD0bP8FRFUK5MOjYYpI+Hx0afDgIAAGiv8Ybr4Wo6NfDsXhlBuULj5V4rPe3XAADQYin3XrG8q06CcqXSl751K6WwCRsAAFpovLzr+Lc2gioJyhVLL717KUVcDAAAoDXuheTBhaBatl53wPDG529G5NUAAAAWKkXaSMe/fSyomopyB6QDW6dswgYAgAUrz+S9rbWgeoJyB9iEDQAAC7a94dryrk7Qet0h+Y3+4bzV2wwAAGCu0srwSPrS4HbQCSrKHVK+MUfvYq0FAAAwNynHWSG5WwTljkkvDa6kiPMBAADM3HjD9cvvXgo6Ret1R+VvHLycc6wFAAAwE+VUazr+7qtB5wjKHeZsFAAAzEre7B1/78Wgk7Red5izUQAAMANlw/WH2a3kDhOUO+zB2ShhGQAAmrF9BurUwGnWDtN6vQTun43aGH3aDwAAYDIpBqOQfMSt5O5TUV4C47NRK72TAQAATCzl3ikheTkIyksifelbt9xYBgCAyYxvJR//1kawFATlJeLGMgAA7J9bycvHjPISyjcOnssCMwAAPNU4JB8fXAiWiqC8pPI3Dl7OOdYCAAB4olFYupiOv/tqsHQE5SU2vPG5q6N/BCz5AgCAx6V8rffSe6eCpWRGeYmlA/mVUW15MwAAgIfkzfRBeVZmWakoL7l8s9/PW703I8ehAACAZZfiTvpg+GI6NRgES0tFecmlY4NB+nh4rLwgBAAALLMSktNwVUhGRZmx/LX+ofxM76bKMgAAS2k7JH958Haw9ARlHhCWAQBYSkIyjxGUeUR+o384b/U2Rp/2AwAAui7FYBSSjwjJPMyMMo9IXxrcTivD1dGn5jIAAOi2EpJ7Ksl8mooyT6SyDABA140KREdKoSjgMSrKPNG4spyGZwMAADooDYdrQjI7UVFmV/kb/dM599YDAAA6YhySvzK4ErADQZmnEpYBAOgKIZm9EJTZE2EZAIDaCcnslRll9iS9NLiSUphZBgCgSinHWSGZvRKU2bP00ruXUsT5AACAiqQYnk8vv3spYI+0XrNv+cbBc1lgBgCgAuOQfHxwIWAfBGUmIiwDANB2QjKTEpSZmLAMAEBbCclMQ1BmKvkbB8/kHBcDAABaYry4y0wyUxCUmZrTUQAAtIUTUDRBUKYRwjIAAIsmJNMUQZnGCMsAACyKkEyT3FGmMemlwZWUhmsBAADzkmIgJNM0FWUal9/oH85bvY3Rp/0AAIBZKSG5N1xNXxrcDmiQoMxMCMsAAMyUkMwMab1mJsoLVloZro5ewO4EAAA0afSMKSQzSyrKzFT+Wv9QfqZ3M3IcCgAAmFYJyWkUkr88eDtgRgRlZk5YBgCgEUIycyIoMxfCMgAAUxGSmSMzysxF+urgTvp4eGwUmTcDAAD2JW+mD4YvCsnMi6DM3IzD8oFcwvK1AACAvUj5WvowH0unBoOAOdF6zULkGwdfyxFnAwAAdpBSrKeX3n0lYM5UlFmIdPzdV0fv0pwPAAB4ghTD80Iyi6KizEKNKsvnssAMAMBDxiH5+OBCwIIIyixc/sbBMznHxQAAYOml4XAtfWVwJWCBBGVaIb/x40fz1rAs+eoHAADLJ8Ug5d6pdPxbGwELJijTGm4tAwAsqXIjuTc8mb40uB3QAoIyrSIsAwAsmRKS03DVjWTaxNZrWmV8a/njYbm1vBkAAHRairSRPhi+KCTTNirKtJZbywAA3eVGMm2mokxrubUMANBNbiTTdirKtJ7zUQAA3eH8EzUQlKlCfqN/OA971yz5AgCoVDn/1Buu2mxNDQRlqmEjNgBApWy2pjJmlKnGJxux00YAAFAFm62pkYoyVbIRGwCg/UZh42JZ0BpQGRVlqmQjNgBAu6UcZ4VkaqWiTNXyGz9+NA+H6+aWAQBaoiztyr1T6fi3NgIqJShTPUu+AABawtIuOkLrNdUbL/laGb44iszXAgCAxUj5mqVddIWKMp2Sbxw8l80uAwDMVYrh+XR8cCGgIwRlOid/4/Onc84XR5/2AwCA2SnzyFvDs+krgysBHSIo00nmlgEAZsw8Mh1mRplOGs8tfzw8Zm4ZAKB5KdKGeWS6TEWZzjO3DADQHPPILANBmaWQb/RP5NS7qBUbAGBC7iOzRARlloa5ZQCASeXN1MsntVqzLMwoszTK3HLvpXdfGL07dDEAANiT8uyUPszHhGSWiYoySyl/4+CZnMdzy05IAQA8SWm1Hsb59PK7lwKWjKDM0tKKDQCwg3L6qTc8mb40uB2whLRes7TGJ6RWhi+mFOsBAMBYeTYan34SklliKsoQD1qxzS4DAMtLqzU8ICjDfVqxAYClpdUaHqH1Gu7Tig0ALKPxVmut1vAIFWV4AluxAYDO02oNOxKUYQdasQGA7sqbqZdPuo0MTyYow1PkGwfP5RhXlwEAqjdutT7+7qsB7EhQhj3IN/oncupdVF0GAKpVFnbl3ivp+Lc2AtiVZV6wB+n44PX08fCYRV8AQI1SpI3xwi4hGfZERRn2yaIvAKAaFnbBRARlmIBFXwBA+1nYBZMSlGEKFn0BAG1kYRdMR1CGKakuAwCtYWEXNMIyL5hS+urgTloZvljeuQ0AgAUZV5Et7IJGqChDg/IbP340D4frqssAwNyoIkPjVJShQelL37rljBQAMC+qyDAbKsowI/kbnz+dI59XXQYAGqeKDDOlogwzkl769hXVZQCgaarIMHsqyjAHqssAwNRUkWFuVJRhDh5Ul23GBgAmoIoM86WiDHNmMzYAsGeqyLAQgjIsSL5x8FyOOB8AAE8w7kT7cHghnRoMApgrQRkWKH+tfyg/07upugwAbEuRNmJl62z60uB2AAshKEML5G8cPJPzuLrcDwBgOaUYpGGcTy+/eymAhRKUoSVKdTme6Z0bBea1AACWyriK3NtaS18evB3AwgnK0DJOSQHAErGsC1rJeShomfEpqZXhi05JAUC3OfkE7aWiDC1m2RcAdI9lXdB+gjJUQDs2AHSAZV1QDa3XUIFxO/bHw2MpxXoAANW532b9gpAMdVBRhspoxwaAeozbrCNdMIcMdRGUoVLasQGgxUqbdaSzpSssgOoIylCxfLPfj7u9MznifAAAi1cCco6L8eHwUjo1GARQJUEZOqC0Y8czvXM5x1oAAAsxbrPuba2lLw/eDqBqgjJ0SH7j8yfyMF/Ujg0A85Q3U6y8ag4ZukNQhg4yvwwAc+DcE3SWoAwdNW7HPtA7bX4ZABpmDhk6T1CGjjO/DADNySnWe2l43hwydJugDEviXoV55XKOvBoAwL64hwzLRVCGJWN+GQD2TkCG5SQow5ISmAFgFynujELy+fTSt68EsHQEZVhyAjMAPMSiLiAEZSAe2pCdYk1gBmApCcjAQwRl4AEbsgFYOgIy8ASCMvApAjMAnScgA7sQlIEdCcwAdJFbyMDTCMrAUwnMAHSBgAzslaAM7JnADECNBGRgvwRlYN8EZgBqICADkxKUgYkJzAC0jiVdQAMEZWBqDwJzxKo7zAAshIAMNEhQBhozDswHeqdzGlWYBWYA5kFABmZAUAZmIn/j86dz5PMCMwAzISADMyQoAzMlMAPQpBRpY/SX9fTSt68EwIwIysBcjALzyVFYPjMKzasBAPs0DsiRLqTj39oIgBkTlIG5sikbgP0YBeRro79eEpCBeRKUgYWwKRuAHZk/BhZMUAYWKl/t9+OzKyfMMQMwejK9M3o4vRgfDK8IyMAiCcpAa5hjBlhO5o+BthGUgdZ5qC27BOd+ANA999qr1yOvXEkv/9lmALSIoAy01r3AvHJUWzZAl+TNlNK69mqgzQRloAr5xo+vRhqeti0boE7aq4GaCMpAVcZV5gO90zmNArMqM0C72V4NVEpQBqp1b/nXqMoc6WQA0Bqqx0DtBGWgeqrMAC2gegx0iKAMdIpZZoA5GofjcfX4kuox0CWCMtBJ2xuzI+ezOeJIANCYcWt1ytdsrga6SlAGOi9f7x+JXu/MKDCvas0GmND23ePova56DHSdoAwslfECsMgntGYD7MG91upNi7mAZSMoA0vpk9bsWMuRVwOAB7RWA8tOUAaWnnlmgO2TTnnD1moAQRngEfdPTZ3JKU6aZwa6LqW4E2Xu+H9v795xmwrCAIzOJCmQAOGCnuwA7wBXSFSwRVZAqGmcHZgdmJrGSCAhJb7DzPiRa+JIedq+9jlNbiw7ShXl0z+PdPw1vv85CgBUQhngBvUQsFjvZxbNwN5YxnE4OrfvGGA9oQxwC6IZ6DJxDHA3QhngjkQz0AXiGOD+hDLAA8zvaJ6fnu0gMGC7lgdyXTaf44fJOABwL0IZ4JG4cgrYBlc5ATw+oQzwBNKXXi+8PB7kp4950jywRBt4NDFMYhPO8sN5+DM9E8cAj08oA2xA+vZ6EELzMT8OLNEG7ir/w1aubjqz3xhgM4QywIZdLdFuPqUYy7S5FwDaytQ4pWGIcWhJNcDmCWWALbuaNse+vc1wuJYHcZkaA2ydUAbYIfY2w+GYX990FlL8bq8xwG4RygA77L9l2n3hDB22OITrKIzCRfPV9U0Au0soA3TI7N7m47fCGTpAGAN0llAG6DDhDLujLqVuwlAYA3SfUAbYI/Ol2v2yxzlHc99VVPB05lc2Dese4+l0KIwB9odQBthj9XCwFyc5lpt3+U/+IMXUdx0V3EP7uqZ09D38vhw5fAtgfwllgAMzX659GlJ650oqWKNGcRgH02KAgyWUAWjtdc4TZ/HMIVlEcSrLqON5CNNRfD8ZBQAOmlAGYK1r8WzZNl1XozjmCE6jOikWxQDcQCgDcGutZdtv83cloE8dGMYuWjmBOsQf4SJHseXTANySUAbgwQQ021KDOKUSw+PFlDj8CWMHbQHwEEIZgCezEtDljueYA9oSbu6qvY/YhBiADRDKAGzc8tqqmHrtiM7fn6byzMGZTYbLVDiNaww38ZfpMADbIpQB2Dl1Eh1PSkSXeH6zDOmQepZ0d1CZCIcwWYbwLIp/5CCemAwDsIuEMgCdUyfSz0s8r4vpzGR6Y2aT4By8IZX4naxEcDMdmwgD0EVCGYC9tRLUZZl3qEFd9kf36td2WC9eO2TLyW8J3xy9s+lvidxJjd/6njwVvrwch7/5vQIYgD0llAGgpcb1sxzMxyWkT2bhXKbWxVF61Yrpq7BeBPfVT8mfvR7dD51y1+nt2l86tl5vJnWyu/zQ/DMleOu+3zCL3aIEbyF6AWDFPy5KBuLHxK4hAAAAAElFTkSuQmCC";
  function oe() {
    return (
      (oe = Object.assign
        ? Object.assign.bind()
        : function (e) {
            for (var t = 1; t < arguments.length; t++) {
              var n = arguments[t];
              for (var a in n)
                Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
            }
            return e;
          }),
      oe.apply(this, arguments)
    );
  }
  function q0(e) {
    if (Array.isArray(e)) return e;
  }
  function W0(e, t) {
    var n =
      e == null
        ? null
        : (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
    if (n != null) {
      var a,
        r,
        o,
        i,
        l = [],
        s = !0,
        u = !1;
      try {
        if (((o = (n = n.call(e)).next), t === 0)) {
          if (Object(n) !== n) return;
          s = !1;
        } else
          for (
            ;
            !(s = (a = o.call(n)).done) && (l.push(a.value), l.length !== t);
            s = !0
          );
      } catch (c) {
        (u = !0), (r = c);
      } finally {
        try {
          if (!s && n.return != null && ((i = n.return()), Object(i) !== i))
            return;
        } finally {
          if (u) throw r;
        }
      }
      return l;
    }
  }
  function tn(e, t) {
    (t == null || t > e.length) && (t = e.length);
    for (var n = 0, a = new Array(t); n < t; n++) a[n] = e[n];
    return a;
  }
  function K0(e, t) {
    if (!!e) {
      if (typeof e == "string") return tn(e, t);
      var n = Object.prototype.toString.call(e).slice(8, -1);
      if (
        (n === "Object" && e.constructor && (n = e.constructor.name),
        n === "Map" || n === "Set")
      )
        return Array.from(e);
      if (
        n === "Arguments" ||
        /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
      )
        return tn(e, t);
    }
  }
  function j0() {
    throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  function ue(e, t) {
    return q0(e) || W0(e, t) || K0(e, t) || j0();
  }
  function Y0(e, t) {
    if (e == null) return {};
    var n = {},
      a = Object.keys(e),
      r,
      o;
    for (o = 0; o < a.length; o++)
      (r = a[o]), !(t.indexOf(r) >= 0) && (n[r] = e[r]);
    return n;
  }
  function Re(e, t) {
    if (e == null) return {};
    var n = Y0(e, t),
      a,
      r;
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      for (r = 0; r < o.length; r++)
        (a = o[r]),
          !(t.indexOf(a) >= 0) &&
            (!Object.prototype.propertyIsEnumerable.call(e, a) ||
              (n[a] = e[a]));
    }
    return n;
  }
  var jt = {},
    o7 = {};
  function op(e) {
    for (var t = 5381, n = e.length; n; ) t = (t * 33) ^ e.charCodeAt(--n);
    return t >>> 0;
  }
  var ip = op,
    i7 = {};
  (function (e) {
    (e.__esModule = !0), (e.default = void 0);
    function t(l, s) {
      for (var u = 0; u < s.length; u++) {
        var c = s[u];
        (c.enumerable = c.enumerable || !1),
          (c.configurable = !0),
          "value" in c && (c.writable = !0),
          Object.defineProperty(l, c.key, c);
      }
    }
    function n(l, s, u) {
      return s && t(l.prototype, s), u && t(l, u), l;
    }
    var a = typeof process < "u" && process.env && !0,
      r = function (s) {
        return Object.prototype.toString.call(s) === "[object String]";
      },
      o = (function () {
        function l(u) {
          var c = u === void 0 ? {} : u,
            d = c.name,
            p = d === void 0 ? "stylesheet" : d,
            m = c.optimizeForSpeed,
            f = m === void 0 ? a : m,
            v = c.isBrowser,
            g = v === void 0 ? typeof window < "u" : v;
          i(r(p), "`name` must be a string"),
            (this._name = p),
            (this._deletedRulePlaceholder = "#" + p + "-deleted-rule____{}"),
            i(typeof f == "boolean", "`optimizeForSpeed` must be a boolean"),
            (this._optimizeForSpeed = f),
            (this._isBrowser = g),
            (this._serverSheet = void 0),
            (this._tags = []),
            (this._injected = !1),
            (this._rulesCount = 0);
          var _ =
            this._isBrowser &&
            document.querySelector('meta[property="csp-nonce"]');
          this._nonce = _ ? _.getAttribute("content") : null;
        }
        var s = l.prototype;
        return (
          (s.setOptimizeForSpeed = function (c) {
            i(typeof c == "boolean", "`setOptimizeForSpeed` accepts a boolean"),
              i(
                this._rulesCount === 0,
                "optimizeForSpeed cannot be when rules have already been inserted"
              ),
              this.flush(),
              (this._optimizeForSpeed = c),
              this.inject();
          }),
          (s.isOptimizeForSpeed = function () {
            return this._optimizeForSpeed;
          }),
          (s.inject = function () {
            var c = this;
            if (
              (i(!this._injected, "sheet already injected"),
              (this._injected = !0),
              this._isBrowser && this._optimizeForSpeed)
            ) {
              (this._tags[0] = this.makeStyleTag(this._name)),
                (this._optimizeForSpeed = "insertRule" in this.getSheet()),
                this._optimizeForSpeed ||
                  (a ||
                    console.warn(
                      "StyleSheet: optimizeForSpeed mode not supported falling back to standard mode."
                    ),
                  this.flush(),
                  (this._injected = !0));
              return;
            }
            this._serverSheet = {
              cssRules: [],
              insertRule: function (p, m) {
                return (
                  typeof m == "number"
                    ? (c._serverSheet.cssRules[m] = { cssText: p })
                    : c._serverSheet.cssRules.push({ cssText: p }),
                  m
                );
              },
              deleteRule: function (p) {
                c._serverSheet.cssRules[p] = null;
              },
            };
          }),
          (s.getSheetForTag = function (c) {
            if (c.sheet) return c.sheet;
            for (var d = 0; d < document.styleSheets.length; d++)
              if (document.styleSheets[d].ownerNode === c)
                return document.styleSheets[d];
          }),
          (s.getSheet = function () {
            return this.getSheetForTag(this._tags[this._tags.length - 1]);
          }),
          (s.insertRule = function (c, d) {
            if (
              (i(r(c), "`insertRule` accepts only strings"), !this._isBrowser)
            )
              return (
                typeof d != "number" && (d = this._serverSheet.cssRules.length),
                this._serverSheet.insertRule(c, d),
                this._rulesCount++
              );
            if (this._optimizeForSpeed) {
              var p = this.getSheet();
              typeof d != "number" && (d = p.cssRules.length);
              try {
                p.insertRule(c, d);
              } catch {
                return (
                  a ||
                    console.warn(
                      `StyleSheet: illegal rule: 

` +
                        c +
                        `

See https://stackoverflow.com/q/20007992 for more info`
                    ),
                  -1
                );
              }
            } else {
              var m = this._tags[d];
              this._tags.push(this.makeStyleTag(this._name, c, m));
            }
            return this._rulesCount++;
          }),
          (s.replaceRule = function (c, d) {
            if (this._optimizeForSpeed || !this._isBrowser) {
              var p = this._isBrowser ? this.getSheet() : this._serverSheet;
              if (
                (d.trim() || (d = this._deletedRulePlaceholder), !p.cssRules[c])
              )
                return c;
              p.deleteRule(c);
              try {
                p.insertRule(d, c);
              } catch {
                a ||
                  console.warn(
                    `StyleSheet: illegal rule: 

` +
                      d +
                      `

See https://stackoverflow.com/q/20007992 for more info`
                  ),
                  p.insertRule(this._deletedRulePlaceholder, c);
              }
            } else {
              var m = this._tags[c];
              i(m, "old rule at index `" + c + "` not found"),
                (m.textContent = d);
            }
            return c;
          }),
          (s.deleteRule = function (c) {
            if (!this._isBrowser) {
              this._serverSheet.deleteRule(c);
              return;
            }
            if (this._optimizeForSpeed) this.replaceRule(c, "");
            else {
              var d = this._tags[c];
              i(d, "rule at index `" + c + "` not found"),
                d.parentNode.removeChild(d),
                (this._tags[c] = null);
            }
          }),
          (s.flush = function () {
            (this._injected = !1),
              (this._rulesCount = 0),
              this._isBrowser
                ? (this._tags.forEach(function (c) {
                    return c && c.parentNode.removeChild(c);
                  }),
                  (this._tags = []))
                : (this._serverSheet.cssRules = []);
          }),
          (s.cssRules = function () {
            var c = this;
            return this._isBrowser
              ? this._tags.reduce(function (d, p) {
                  return (
                    p
                      ? (d = d.concat(
                          Array.prototype.map.call(
                            c.getSheetForTag(p).cssRules,
                            function (m) {
                              return m.cssText === c._deletedRulePlaceholder
                                ? null
                                : m;
                            }
                          )
                        ))
                      : d.push(null),
                    d
                  );
                }, [])
              : this._serverSheet.cssRules;
          }),
          (s.makeStyleTag = function (c, d, p) {
            d &&
              i(r(d), "makeStyleTag acceps only strings as second parameter");
            var m = document.createElement("style");
            this._nonce && m.setAttribute("nonce", this._nonce),
              (m.type = "text/css"),
              m.setAttribute("data-" + c, ""),
              d && m.appendChild(document.createTextNode(d));
            var f = document.head || document.getElementsByTagName("head")[0];
            return p ? f.insertBefore(m, p) : f.appendChild(m), m;
          }),
          n(l, [
            {
              key: "length",
              get: function () {
                return this._rulesCount;
              },
            },
          ]),
          l
        );
      })();
    e.default = o;
    function i(l, s) {
      if (!l) throw new Error("StyleSheet: " + s + ".");
    }
  })(i7);
  (function (e) {
    (e.__esModule = !0), (e.default = void 0);
    var t = a(ip),
      n = a(i7);
    function a(l) {
      return l && l.__esModule ? l : { default: l };
    }
    var r = function (s) {
        return s.replace(/\/style/gi, "\\/style");
      },
      o = (function () {
        function l(u) {
          var c = u === void 0 ? {} : u,
            d = c.styleSheet,
            p = d === void 0 ? null : d,
            m = c.optimizeForSpeed,
            f = m === void 0 ? !1 : m,
            v = c.isBrowser,
            g = v === void 0 ? typeof window < "u" : v;
          (this._sheet =
            p || new n.default({ name: "styled-jsx", optimizeForSpeed: f })),
            this._sheet.inject(),
            p &&
              typeof f == "boolean" &&
              (this._sheet.setOptimizeForSpeed(f),
              (this._optimizeForSpeed = this._sheet.isOptimizeForSpeed())),
            (this._isBrowser = g),
            (this._fromServer = void 0),
            (this._indices = {}),
            (this._instancesCounts = {}),
            (this.computeId = this.createComputeId()),
            (this.computeSelector = this.createComputeSelector());
        }
        var s = l.prototype;
        return (
          (s.add = function (c) {
            var d = this;
            this._optimizeForSpeed === void 0 &&
              ((this._optimizeForSpeed = Array.isArray(c.children)),
              this._sheet.setOptimizeForSpeed(this._optimizeForSpeed),
              (this._optimizeForSpeed = this._sheet.isOptimizeForSpeed())),
              this._isBrowser &&
                !this._fromServer &&
                ((this._fromServer = this.selectFromServer()),
                (this._instancesCounts = Object.keys(this._fromServer).reduce(
                  function (g, _) {
                    return (g[_] = 0), g;
                  },
                  {}
                )));
            var p = this.getIdAndRules(c),
              m = p.styleId,
              f = p.rules;
            if (m in this._instancesCounts) {
              this._instancesCounts[m] += 1;
              return;
            }
            var v = f
              .map(function (g) {
                return d._sheet.insertRule(g);
              })
              .filter(function (g) {
                return g !== -1;
              });
            (this._indices[m] = v), (this._instancesCounts[m] = 1);
          }),
          (s.remove = function (c) {
            var d = this,
              p = this.getIdAndRules(c),
              m = p.styleId;
            if (
              (i(m in this._instancesCounts, "styleId: `" + m + "` not found"),
              (this._instancesCounts[m] -= 1),
              this._instancesCounts[m] < 1)
            ) {
              var f = this._fromServer && this._fromServer[m];
              f
                ? (f.parentNode.removeChild(f), delete this._fromServer[m])
                : (this._indices[m].forEach(function (v) {
                    return d._sheet.deleteRule(v);
                  }),
                  delete this._indices[m]),
                delete this._instancesCounts[m];
            }
          }),
          (s.update = function (c, d) {
            this.add(d), this.remove(c);
          }),
          (s.flush = function () {
            this._sheet.flush(),
              this._sheet.inject(),
              (this._fromServer = void 0),
              (this._indices = {}),
              (this._instancesCounts = {}),
              (this.computeId = this.createComputeId()),
              (this.computeSelector = this.createComputeSelector());
          }),
          (s.cssRules = function () {
            var c = this,
              d = this._fromServer
                ? Object.keys(this._fromServer).map(function (m) {
                    return [m, c._fromServer[m]];
                  })
                : [],
              p = this._sheet.cssRules();
            return d.concat(
              Object.keys(this._indices)
                .map(function (m) {
                  return [
                    m,
                    c._indices[m]
                      .map(function (f) {
                        return p[f].cssText;
                      })
                      .join(
                        c._optimizeForSpeed
                          ? ""
                          : `
`
                      ),
                  ];
                })
                .filter(function (m) {
                  return Boolean(m[1]);
                })
            );
          }),
          (s.createComputeId = function () {
            var c = {};
            return function (d, p) {
              if (!p) return "jsx-" + d;
              var m = String(p),
                f = d + m;
              return (
                c[f] || (c[f] = "jsx-" + (0, t.default)(d + "-" + m)), c[f]
              );
            };
          }),
          (s.createComputeSelector = function (c) {
            c === void 0 && (c = /__jsx-style-dynamic-selector/g);
            var d = {};
            return function (p, m) {
              this._isBrowser || (m = r(m));
              var f = p + m;
              return d[f] || (d[f] = m.replace(c, p)), d[f];
            };
          }),
          (s.getIdAndRules = function (c) {
            var d = this,
              p = c.children,
              m = c.dynamic,
              f = c.id;
            if (m) {
              var v = this.computeId(f, m);
              return {
                styleId: v,
                rules: Array.isArray(p)
                  ? p.map(function (g) {
                      return d.computeSelector(v, g);
                    })
                  : [this.computeSelector(v, p)],
              };
            }
            return {
              styleId: this.computeId(f),
              rules: Array.isArray(p) ? p : [p],
            };
          }),
          (s.selectFromServer = function () {
            var c = Array.prototype.slice.call(
              document.querySelectorAll('[id^="__jsx-"]')
            );
            return c.reduce(function (d, p) {
              var m = p.id.slice(2);
              return (d[m] = p), d;
            }, {});
          }),
          l
        );
      })();
    e.default = o;
    function i(l, s) {
      if (!l) throw new Error("StyleSheetRegistry: " + s + ".");
    }
  })(o7);
  (function (e) {
    (e.__esModule = !0), (e.default = o), (e.flush = i);
    var t = S,
      n = a(o7);
    function a(l) {
      return l && l.__esModule ? l : { default: l };
    }
    var r = new n.default();
    function o(l) {
      return typeof window > "u"
        ? (r.add(l), null)
        : ((0, t.useLayoutEffect)(
            function () {
              return (
                r.add(l),
                function () {
                  r.remove(l);
                }
              );
            },
            [l.id, String(l.dynamic)]
          ),
          null);
    }
    o.dynamic = function (l) {
      return l
        .map(function (s) {
          var u = s[0],
            c = s[1];
          return r.computeId(u, c);
        })
        .join(" ");
    };
    function i() {
      var l = r.cssRules();
      return r.flush(), l;
    }
  })(jt);
  var l7 = jt.default || jt;
  l7.flush = jt.flush;
  var nn = {};
  (function (e) {
    (e.__esModule = !0), (e.default = r), (e.flushToHTML = o);
    var t = a(S),
      n = jt.default || jt;
    n.flush = jt.flush;
    function a(i) {
      return i && i.__esModule ? i : { default: i };
    }
    function r(i) {
      return (
        i === void 0 && (i = {}),
        (0, n.flush)().map(function (l) {
          var s = l[0],
            u = l[1];
          return t.default.createElement("style", {
            id: "__" + s,
            key: "__" + s,
            nonce: i.nonce ? i.nonce : void 0,
            dangerouslySetInnerHTML: { __html: u },
          });
        })
      );
    }
    function o(i) {
      return (
        i === void 0 && (i = {}),
        (0, n.flush)().reduce(function (l, s) {
          var u = s[0],
            c = s[1];
          return (
            (l +=
              '<style id="__' +
              u +
              '"' +
              (i.nonce ? ' nonce="' + i.nonce + '"' : "") +
              ">" +
              c +
              "</style>"),
            l
          );
        }, "")
      );
    }
  })(nn);
  var lp = nn.default || nn;
  lp.flushToHTML = nn.flushToHTML;
  var Y = l7;
  function Yt(e) {
    return (
      (Yt =
        typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
          ? function (t) {
              return typeof t;
            }
          : function (t) {
              return t &&
                typeof Symbol == "function" &&
                t.constructor === Symbol &&
                t !== Symbol.prototype
                ? "symbol"
                : typeof t;
            }),
      Yt(e)
    );
  }
  var an = {
      sans: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif',
      mono: "Menlo, Monaco, Lucida Console, Liberation Mono, DejaVu Sans Mono, Bitstream Vera Sans Mono, Courier New, monospace",
      prism:
        'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas,"Liberation Mono", "Courier New", monospace',
    },
    u5 = {
      xs: { min: "0", max: "650px" },
      sm: { min: "650px", max: "900px" },
      md: { min: "900px", max: "1280px" },
      lg: { min: "1280px", max: "1920px" },
      xl: { min: "1920px", max: "10000px" },
    },
    rn = {
      gap: "16pt",
      gapNegative: "-16pt",
      gapHalf: "8pt",
      gapHalfNegative: "-8pt",
      gapQuarter: "4pt",
      gapQuarterNegative: "-4pt",
      pageMargin: "16pt",
      pageWidth: "750pt",
      pageWidthWithMargin: "782pt",
      breakpointMobile: u5.xs.max,
      breakpointTablet: u5.sm.max,
      radius: "6px",
      unit: "16px",
    };
  var cp = {
      accents_1: "#fafafa",
      accents_2: "#eaeaea",
      accents_3: "#999",
      accents_4: "#888",
      accents_5: "#666",
      accents_6: "#444",
      accents_7: "#333",
      accents_8: "#111",
      background: "#fff",
      foreground: "#000",
      selection: "#79ffe1",
      secondary: "#666",
      code: "#f81ce5",
      border: "#eaeaea",
      error: "#e00",
      errorLight: "#ff1a1a",
      errorLighter: "#f7d4d6",
      errorDark: "#c50000",
      success: "#0070f3",
      successLight: "#3291ff",
      successLighter: "#d3e5ff",
      successDark: "#0761d1",
      warning: "#f5a623",
      warningLight: "#f7b955",
      warningLighter: "#ffefcf",
      warningDark: "#ab570a",
      cyan: "#50e3c2",
      cyanLighter: "#aaffec",
      cyanLight: "#79ffe1",
      cyanDark: "#29bc9b",
      violet: "#7928ca",
      violetLighter: "#e3d7fc",
      violetLight: "#8a63d2",
      violetDark: "#4c2889",
      purple: "#f81ce5",
      alert: "#ff0080",
      magenta: "#eb367f",
      link: "#0070f3",
    },
    sp = {
      linkStyle: "none",
      linkHoverStyle: "none",
      dropdownBoxShadow: "0 4px 4px 0 rgba(0, 0, 0, 0.02)",
      scrollerStart: "rgba(255, 255, 255, 1)",
      scrollerEnd: "rgba(255, 255, 255, 0)",
      shadowSmall: "0 5px 10px rgba(0, 0, 0, 0.12)",
      shadowMedium: "0 8px 30px rgba(0, 0, 0, 0.12)",
      shadowLarge: "0 30px 60px rgba(0, 0, 0, 0.12)",
      portalOpacity: 0.25,
    },
    up = an,
    dp = u5,
    pp = rn,
    mp = {
      type: "light",
      font: up,
      layout: pp,
      palette: cp,
      breakpoints: dp,
      expressiveness: sp,
    },
    on = mp;
  var hp = {
      accents_1: "#111",
      accents_2: "#333",
      accents_3: "#444",
      accents_4: "#666",
      accents_5: "#888",
      accents_6: "#999",
      accents_7: "#eaeaea",
      accents_8: "#fafafa",
      background: "#000",
      foreground: "#fff",
      selection: "#f81ce5",
      secondary: "#888",
      code: "#79ffe1",
      border: "#333",
      error: "#e00",
      errorLighter: "#f7d4d6",
      errorLight: "#ff1a1a",
      errorDark: "#c50000",
      success: "#0070f3",
      successLighter: "#d3e5ff",
      successLight: "#3291ff",
      successDark: "#0761d1",
      warning: "#f5a623",
      warningLighter: "#ffefcf",
      warningLight: "#f7b955",
      warningDark: "#ab570a",
      cyan: "#50e3c2",
      cyanLighter: "#aaffec",
      cyanLight: "#79ffe1",
      cyanDark: "#29bc9b",
      violet: "#7928ca",
      violetLighter: "#e3d7fc",
      violetLight: "#8a63d2",
      violetDark: "#4c2889",
      purple: "#f81ce5",
      alert: "#ff0080",
      magenta: "#eb367f",
      link: "#3291ff",
    },
    fp = {
      linkStyle: "none",
      linkHoverStyle: "none",
      dropdownBoxShadow: "0 0 0 1px #333",
      scrollerStart: "rgba(255, 255, 255, 1)",
      scrollerEnd: "rgba(255, 255, 255, 0)",
      shadowSmall: "0 0 0 1px #333",
      shadowMedium: "0 0 0 1px #333",
      shadowLarge: "0 0 0 1px #333",
      portalOpacity: 0.75,
    },
    gp = an,
    vp = u5,
    bp = rn,
    _p = {
      type: "dark",
      font: gp,
      layout: bp,
      palette: hp,
      breakpoints: vp,
      expressiveness: fp,
    },
    Q0 = _p;
  var ln = function (t) {
      return t && Yt(t) === "object";
    },
    Ep = function e(t, n) {
      if (!ln(n) || !ln(t)) return t;
      for (var a = Object.keys(t), r = {}, o = 0, i = a; o < i.length; o++) {
        var l = i[o],
          s = t[l],
          u = n[l];
        Array.isArray(s) && Array.isArray(u)
          ? (r[l] = u.concat(s))
          : ln(s) && ln(u)
          ? (r[l] = e(s, oe({}, u)))
          : u
          ? (r[l] = u)
          : (r[l] = s);
      }
      return r;
    },
    c7 = function () {
      return [on, Q0];
    },
    yp = function () {
      return on;
    },
    cn = function (t) {
      if (!t) return !1;
      var n = c7(),
        a = n.find(function (r) {
          return r.type === t;
        });
      return !a;
    },
    xp = function (t) {
      if (!t) return !1;
      var n = typeof t == "string",
        a = n ? t : t.type;
      return !cn(a);
    },
    wp = function () {
      var t =
        arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [];
      return !!t.find(function (n) {
        return cn(n.type);
      });
    },
    Z0 = function (t, n) {
      if (!cn(n.type)) throw new Error("Duplicate or unavailable theme type");
      return Ep(t, n);
    },
    Ap = function (t) {
      return Z0(Q0, t);
    },
    Mp = function (t) {
      return Z0(on, t);
    },
    zp = {
      isPresetTheme: xp,
      isAvailableThemeType: cn,
      hasUserCustomTheme: wp,
      getPresets: c7,
      getPresetStaticTheme: yp,
      create: Z0,
      createFromDark: Ap,
      createFromLight: Mp,
    },
    sn = zp;
  var Qt = sn;
  var Sp = Qt.getPresetStaticTheme(),
    X0 = S.createContext(Sp),
    s7 = function () {
      return S.useContext(X0);
    };
  var Ue = s7;
  var Cp = function (t) {
      for (var n = Object.keys(t), a = n.length, r = "", o = 0; o < a; o++) {
        var i = n[o],
          l = t[n[o]];
        !l || (r = r ? "".concat(r, " ").concat(String(i)) : String(i));
      }
      return r;
    },
    kp = function (t) {
      return Yt(t) === "object" && !Array.isArray(t);
    },
    Rp = function () {
      var t = arguments.length,
        n = "";
      if (t === 0) return n;
      for (var a = 0; a < t; a++) {
        var r = a < 0 || arguments.length <= a ? void 0 : arguments[a];
        !r ||
          (kp(r)
            ? (n += " ".concat(Cp(r)))
            : (n += " ".concat(String(r).trim())));
      }
      return n.trim();
    },
    u7 = Rp;
  var De = u7;
  var d7 = [
      "width",
      "height",
      "padding",
      "margin",
      "w",
      "h",
      "paddingLeft",
      "paddingRight",
      "paddingTop",
      "paddingBottom",
      "pl",
      "pr",
      "pt",
      "pb",
      "marginLeft",
      "marginRight",
      "marginTop",
      "marginBottom",
      "ml",
      "mr",
      "mt",
      "mb",
      "px",
      "py",
      "mx",
      "my",
      "font",
      "unit",
      "scale",
    ],
    Ke = function (t) {
      return "".concat(t);
    },
    Ip = {
      getScaleProps: function () {},
      getAllScaleProps: function () {
        return {};
      },
      SCALES: {
        pl: Ke,
        pr: Ke,
        pb: Ke,
        pt: Ke,
        px: Ke,
        py: Ke,
        mb: Ke,
        ml: Ke,
        mr: Ke,
        mt: Ke,
        mx: Ke,
        my: Ke,
        width: Ke,
        height: Ke,
        font: Ke,
      },
      unit: "16px",
    },
    J0 = S.createContext(Ip),
    p7 = function () {
      return S.useContext(J0);
    };
  var m7 = function () {
    return Math.random().toString(32).slice(2, 10);
  };
  var h7 = function (t, n) {
    var a = [],
      r = S.Children.map(t, function (i) {
        return S.isValidElement(i) && i.type === n ? (a.push(i), null) : i;
      }),
      o = a.length >= 0 ? a : void 0;
    return [r, o];
  };
  var f7 = function () {
    return Boolean(
      typeof window < "u" && window.document && window.document.createElement
    );
  };
  var g7 = function (t) {
    return t !== void 0 && !Number.isNaN(+t);
  };
  function b7(e, t) {
    var n = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
    if (!n) {
      if (
        Array.isArray(e) ||
        (n = Tp(e)) ||
        (t && e && typeof e.length == "number")
      ) {
        n && (e = n);
        var a = 0,
          r = function () {};
        return {
          s: r,
          n: function () {
            return a >= e.length ? { done: !0 } : { done: !1, value: e[a++] };
          },
          e: function (u) {
            throw u;
          },
          f: r,
        };
      }
      throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
    }
    var o = !0,
      i = !1,
      l;
    return {
      s: function () {
        n = n.call(e);
      },
      n: function () {
        var u = n.next();
        return (o = u.done), u;
      },
      e: function (u) {
        (i = !0), (l = u);
      },
      f: function () {
        try {
          !o && n.return != null && n.return();
        } finally {
          if (i) throw l;
        }
      },
    };
  }
  function Tp(e, t) {
    if (!!e) {
      if (typeof e == "string") return v7(e, t);
      var n = Object.prototype.toString.call(e).slice(8, -1);
      if (
        (n === "Object" && e.constructor && (n = e.constructor.name),
        n === "Map" || n === "Set")
      )
        return Array.from(e);
      if (
        n === "Arguments" ||
        /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
      )
        return v7(e, t);
    }
  }
  function v7(e, t) {
    (t == null || t > e.length) && (t = e.length);
    for (var n = 0, a = new Array(t); n < t; n++) a[n] = e[n];
    return a;
  }
  var _7 = function (t) {
      var n = function (r) {
        if (!Array.isArray(r)) return t[r];
        var o = void 0,
          i = b7(r),
          l;
        try {
          for (i.s(); !(l = i.n()).done; ) {
            var s = l.value,
              u = t[s];
            typeof u < "u" && (o = u);
          }
        } catch (c) {
          i.e(c);
        } finally {
          i.f();
        }
        return o;
      };
      return n;
    },
    E7 = function (t) {
      var n = function () {
        var r = {},
          o = b7(d7),
          i;
        try {
          for (o.s(); !(i = o.n()).done; ) {
            var l = i.value,
              s = t[l];
            typeof s < "u" && (r[l] = s);
          }
        } catch (u) {
          o.e(u);
        } finally {
          o.f();
        }
        return r;
      };
      return n;
    };
  var Np = ["children"],
    Lp = [
      "paddingLeft",
      "pl",
      "paddingRight",
      "pr",
      "paddingTop",
      "pt",
      "paddingBottom",
      "pb",
      "marginTop",
      "mt",
      "marginRight",
      "mr",
      "marginBottom",
      "mb",
      "marginLeft",
      "ml",
      "px",
      "py",
      "mx",
      "my",
      "width",
      "height",
      "font",
      "w",
      "h",
      "margin",
      "padding",
      "unit",
      "scale",
    ],
    Op = function (t) {
      if (t === 1) return t;
      var n = Math.abs((t - 1) / 2);
      return t > 1 ? 1 + n : 1 - n;
    },
    Hp = function (t) {
      var n = x5(function (a, r) {
        var o,
          i,
          l,
          s,
          u,
          c,
          d,
          p,
          m,
          f,
          v,
          g,
          _,
          C,
          y,
          w,
          M,
          E,
          z,
          k,
          O,
          K,
          H,
          V,
          I,
          D,
          J,
          R,
          T,
          P,
          B,
          $,
          b = a.children,
          h = Re(a, Np),
          Le = Ue(),
          le = Le.layout,
          me = h.paddingLeft,
          Ge = h.pl,
          Me = h.paddingRight,
          be = h.pr,
          ae = h.paddingTop,
          ze = h.pt,
          Ce = h.paddingBottom,
          Te = h.pb,
          Pe = h.marginTop,
          $e = h.mt,
          st = h.marginRight,
          Mt = h.mr,
          j = h.marginBottom,
          zt = h.mb,
          _e = h.marginLeft,
          de = h.ml,
          Xe = h.px,
          Fe = h.py,
          ut = h.mx,
          dt = h.my,
          F = h.width,
          G = h.height,
          ee = h.font,
          A = h.w,
          N = h.h,
          q = h.margin,
          re = h.padding,
          Oe = h.unit,
          _t = Oe === void 0 ? le.unit : Oe,
          ge = h.scale,
          Ie = ge === void 0 ? 1 : ge,
          St = Re(h, Lp),
          Se = function (je) {
            return function (dn, $5) {
              dn === 0 && ((dn = 1), ($5 = $5 || 0));
              var xa = Op(Ie) * dn;
              if (typeof je > "u")
                return typeof $5 < "u"
                  ? "".concat($5)
                  : "calc(".concat(xa, " * ").concat(_t, ")");
              if (!g7(je)) return "".concat(je);
              var lc = xa * Number(je);
              return "calc(".concat(lc, " * ").concat(_t, ")");
            };
          },
          xe = {
            unit: _t,
            SCALES: {
              pt: Se(
                (o = (i = ae ?? ze) !== null && i !== void 0 ? i : Fe) !==
                  null && o !== void 0
                  ? o
                  : re
              ),
              pr: Se(
                (l = (s = Me ?? be) !== null && s !== void 0 ? s : Xe) !==
                  null && l !== void 0
                  ? l
                  : re
              ),
              pb: Se(
                (u = (c = Ce ?? Te) !== null && c !== void 0 ? c : Fe) !==
                  null && u !== void 0
                  ? u
                  : re
              ),
              pl: Se(
                (d = (p = me ?? Ge) !== null && p !== void 0 ? p : Xe) !==
                  null && d !== void 0
                  ? d
                  : re
              ),
              px: Se(
                (m =
                  (f =
                    (v = (g = Xe ?? me) !== null && g !== void 0 ? g : Me) !==
                      null && v !== void 0
                      ? v
                      : Ge) !== null && f !== void 0
                    ? f
                    : be) !== null && m !== void 0
                  ? m
                  : re
              ),
              py: Se(
                (_ =
                  (C =
                    (y = (w = Fe ?? ae) !== null && w !== void 0 ? w : Ce) !==
                      null && y !== void 0
                      ? y
                      : ze) !== null && C !== void 0
                    ? C
                    : Te) !== null && _ !== void 0
                  ? _
                  : re
              ),
              mt: Se(
                (M = (E = Pe ?? $e) !== null && E !== void 0 ? E : dt) !==
                  null && M !== void 0
                  ? M
                  : q
              ),
              mr: Se(
                (z = (k = st ?? Mt) !== null && k !== void 0 ? k : ut) !==
                  null && z !== void 0
                  ? z
                  : q
              ),
              mb: Se(
                (O = (K = j ?? zt) !== null && K !== void 0 ? K : dt) !==
                  null && O !== void 0
                  ? O
                  : q
              ),
              ml: Se(
                (H = (V = _e ?? de) !== null && V !== void 0 ? V : ut) !==
                  null && H !== void 0
                  ? H
                  : q
              ),
              mx: Se(
                (I =
                  (D =
                    (J = (R = ut ?? _e) !== null && R !== void 0 ? R : st) !==
                      null && J !== void 0
                      ? J
                      : de) !== null && D !== void 0
                    ? D
                    : Mt) !== null && I !== void 0
                  ? I
                  : q
              ),
              my: Se(
                (T =
                  (P =
                    (B = ($ = dt ?? Pe) !== null && $ !== void 0 ? $ : j) !==
                      null && B !== void 0
                      ? B
                      : $e) !== null && P !== void 0
                    ? P
                    : zt) !== null && T !== void 0
                  ? T
                  : q
              ),
              width: Se(F ?? A),
              height: Se(G ?? N),
              font: Se(ee),
            },
            getScaleProps: _7(h),
            getAllScaleProps: E7(h),
          };
        return S.createElement(
          J0.Provider,
          { value: xe },
          S.createElement(t, oe({}, St, { ref: r }), b)
        );
      });
      return (n.displayName = "Scale".concat(t.displayName || "Wrapper")), n;
    },
    et = Hp;
  var ct = p7;
  var bt = function () {
    for (var t = arguments.length, n = new Array(t), a = 0; a < t; a++)
      n[a] = arguments[a];
    return n;
  };
  var EA = bt(
      "default",
      "secondary",
      "success",
      "warning",
      "error",
      "abort",
      "secondary-light",
      "success-light",
      "warning-light",
      "error-light"
    ),
    yA = bt("default", "secondary", "success", "warning", "error"),
    xA = bt(
      "default",
      "secondary",
      "success",
      "warning",
      "error",
      "dark",
      "lite"
    ),
    wA = bt(
      "default",
      "secondary",
      "success",
      "warning",
      "error",
      "dark",
      "lite",
      "alert",
      "purple",
      "violet",
      "cyan"
    ),
    AA = bt("default", "silent", "prevent"),
    MA = bt("hover", "click"),
    zA = bt(
      "top",
      "topStart",
      "topEnd",
      "left",
      "leftStart",
      "leftEnd",
      "bottom",
      "bottomStart",
      "bottomEnd",
      "right",
      "rightStart",
      "rightEnd"
    ),
    SA = bt("start", "center", "end", "left", "right");
  var Dp = function () {
      var t = ne(!1),
        n = ue(t, 2),
        a = n[0],
        r = n[1];
      return (
        ie(function () {
          r(f7());
        }, []),
        { isBrowser: a, isServer: !a }
      );
    },
    y7 = Dp;
  var x7 = function (t) {
      var n = document.createElement("div");
      return n.setAttribute("id", t), n;
    },
    Pp = function () {
      var t =
          arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : m7(),
        n = arguments.length > 1 ? arguments[1] : void 0,
        a = "geist-ui-".concat(t),
        r = y7(),
        o = r.isBrowser,
        i = ne(o ? x7(a) : null),
        l = ue(i, 2),
        s = l[0],
        u = l[1];
      return (
        ie(function () {
          var c = n ? n() : null,
            d = c || document.body,
            p = d.querySelector("#".concat(a)),
            m = p || x7(a);
          p || d.appendChild(m), u(m);
        }, []),
        s
      );
    },
    w7 = Pp;
  var Fp = [
      "children",
      "className",
      "visible",
      "enterTime",
      "leaveTime",
      "clearTime",
      "name",
    ],
    Vp = {
      visible: !1,
      enterTime: 60,
      leaveTime: 60,
      clearTime: 60,
      className: "",
      name: "transition",
    },
    ea = function (t) {
      var n = t.children,
        a = t.className,
        r = t.visible,
        o = t.enterTime,
        i = t.leaveTime,
        l = t.clearTime,
        s = t.name,
        u = Re(t, Fp),
        c = ne(""),
        d = ue(c, 2),
        p = d[0],
        m = d[1],
        f = ne(r),
        v = ue(f, 2),
        g = v[0],
        _ = v[1];
      return (
        ie(
          function () {
            var C = r ? "enter" : "leave",
              y = r ? o : i;
            r && !g && _(!0), m("".concat(s, "-").concat(C));
            var w = setTimeout(function () {
                m(
                  ""
                    .concat(s, "-")
                    .concat(C, " ")
                    .concat(s, "-")
                    .concat(C, "-active")
                ),
                  clearTimeout(w);
              }, y),
              M = setTimeout(function () {
                r || (m(""), _(!1)), clearTimeout(M);
              }, y + l);
            return function () {
              clearTimeout(w), clearTimeout(M);
            };
          },
          [r, g]
        ),
        !S.isValidElement(n) || !g
          ? null
          : S.cloneElement(
              n,
              oe({}, u, {
                className: ""
                  .concat(n.props.className, " ")
                  .concat(a, " ")
                  .concat(p),
              })
            )
      );
    };
  ea.defaultProps = Vp;
  ea.displayName = "GeistCssTransition";
  var A7 = ea;
  var M7 = {},
    Bp = function (t, n) {
      var a = n ? " [".concat(n, "]") : " ",
        r = "[Geist UI]".concat(a, ": ").concat(t);
      typeof console > "u" || M7[r] || ((M7[r] = !0), console.warn(r));
    },
    ta = Bp;
  var Up = ["children", "type", "color", "className", "spaceRatio"],
    Gp = { type: "default", className: "", spaceRatio: 1 },
    $p = function (t, n, a) {
      var r = {
        default: n.accents_6,
        secondary: n.secondary,
        success: n.success,
        warning: n.warning,
        error: n.error,
      };
      return a || r[t];
    },
    na = function (t) {
      var n = t.children,
        a = t.type,
        r = t.color,
        o = t.className,
        i = t.spaceRatio,
        l = Re(t, Up),
        s = Ue(),
        u = ct(),
        c = u.SCALES,
        d = De("loading-container", o),
        p = ce(
          function () {
            return $p(a, s.palette, r);
          },
          [a, s.palette, r]
        );
      return S.createElement(
        "div",
        oe({}, l, {
          className:
            Y.dynamic([
              [
                "2201634259",
                [
                  c.font(1),
                  c.width(1, "100%"),
                  c.height(1, "100%"),
                  c.pt(0),
                  c.pr(0),
                  c.pb(0),
                  c.pl(0),
                  c.mt(0),
                  c.mr(0),
                  c.mb(0),
                  c.ml(0),
                  s.palette.accents_5,
                  p,
                  i,
                ],
              ],
            ]) +
            " " +
            ((l && l.className != null && l.className) || d || ""),
        }),
        S.createElement(
          "span",
          {
            className:
              Y.dynamic([
                [
                  "2201634259",
                  [
                    c.font(1),
                    c.width(1, "100%"),
                    c.height(1, "100%"),
                    c.pt(0),
                    c.pr(0),
                    c.pb(0),
                    c.pl(0),
                    c.mt(0),
                    c.mr(0),
                    c.mb(0),
                    c.ml(0),
                    s.palette.accents_5,
                    p,
                    i,
                  ],
                ],
              ]) + " loading",
          },
          n &&
            S.createElement(
              "label",
              {
                className: Y.dynamic([
                  [
                    "2201634259",
                    [
                      c.font(1),
                      c.width(1, "100%"),
                      c.height(1, "100%"),
                      c.pt(0),
                      c.pr(0),
                      c.pb(0),
                      c.pl(0),
                      c.mt(0),
                      c.mr(0),
                      c.mb(0),
                      c.ml(0),
                      s.palette.accents_5,
                      p,
                      i,
                    ],
                  ],
                ]),
              },
              n
            ),
          S.createElement("i", {
            className: Y.dynamic([
              [
                "2201634259",
                [
                  c.font(1),
                  c.width(1, "100%"),
                  c.height(1, "100%"),
                  c.pt(0),
                  c.pr(0),
                  c.pb(0),
                  c.pl(0),
                  c.mt(0),
                  c.mr(0),
                  c.mb(0),
                  c.ml(0),
                  s.palette.accents_5,
                  p,
                  i,
                ],
              ],
            ]),
          }),
          S.createElement("i", {
            className: Y.dynamic([
              [
                "2201634259",
                [
                  c.font(1),
                  c.width(1, "100%"),
                  c.height(1, "100%"),
                  c.pt(0),
                  c.pr(0),
                  c.pb(0),
                  c.pl(0),
                  c.mt(0),
                  c.mr(0),
                  c.mb(0),
                  c.ml(0),
                  s.palette.accents_5,
                  p,
                  i,
                ],
              ],
            ]),
          }),
          S.createElement("i", {
            className: Y.dynamic([
              [
                "2201634259",
                [
                  c.font(1),
                  c.width(1, "100%"),
                  c.height(1, "100%"),
                  c.pt(0),
                  c.pr(0),
                  c.pb(0),
                  c.pl(0),
                  c.mt(0),
                  c.mr(0),
                  c.mb(0),
                  c.ml(0),
                  s.palette.accents_5,
                  p,
                  i,
                ],
              ],
            ]),
          })
        ),
        S.createElement(
          Y,
          {
            id: "2201634259",
            dynamic: [
              c.font(1),
              c.width(1, "100%"),
              c.height(1, "100%"),
              c.pt(0),
              c.pr(0),
              c.pb(0),
              c.pl(0),
              c.mt(0),
              c.mr(0),
              c.mb(0),
              c.ml(0),
              s.palette.accents_5,
              p,
              i,
            ],
          },
          ".loading-container.__jsx-style-dynamic-selector{display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;position:relative;font-size:"
            .concat(c.font(1), ";width:")
            .concat(c.width(1, "100%"), ";height:")
            .concat(c.height(1, "100%"), ";min-height:1em;padding:")
            .concat(c.pt(0), " ")
            .concat(c.pr(0), " ")
            .concat(c.pb(0), " ")
            .concat(c.pl(0), ";margin:")
            .concat(c.mt(0), " ")
            .concat(c.mr(0), " ")
            .concat(c.mb(0), " ")
            .concat(
              c.ml(0),
              ";}label.__jsx-style-dynamic-selector{margin-right:0.5em;color:"
            )
            .concat(
              s.palette.accents_5,
              ";line-height:1;}label.__jsx-style-dynamic-selector *{margin:0;}.loading.__jsx-style-dynamic-selector{position:absolute;top:50%;left:50%;width:100%;height:100%;-webkit-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);transform:translate(-50%,-50%);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;background-color:transparent;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;}i.__jsx-style-dynamic-selector{width:0.25em;height:0.25em;border-radius:50%;background-color:"
            )
            .concat(p, ";margin:0 calc(0.25em / 2 * ")
            .concat(
              i,
              ");display:inline-block;-webkit-animation:loading-blink-__jsx-style-dynamic-selector 1.4s infinite both;animation:loading-blink-__jsx-style-dynamic-selector 1.4s infinite both;}i.__jsx-style-dynamic-selector:nth-child(2){-webkit-animation-delay:0.2s;animation-delay:0.2s;}i.__jsx-style-dynamic-selector:nth-child(3){-webkit-animation-delay:0.4s;animation-delay:0.4s;}@-webkit-keyframes loading-blink-__jsx-style-dynamic-selector{0%{opacity:0.2;}20%{opacity:1;}100%{opacity:0.2;}}@keyframes loading-blink-__jsx-style-dynamic-selector{0%{opacity:0.2;}20%{opacity:1;}100%{opacity:0.2;}}"
            )
        )
      );
    };
  na.defaultProps = Gp;
  na.displayName = "GeistLoading";
  var qp = et(na),
    z7 = qp;
  var S7 = z7;
  var Wp = function (t) {
      var n = ne(function () {
          return typeof t == "function" ? t() : t;
        }),
        a = ue(n, 2),
        r = a[0],
        o = a[1],
        i = at(t);
      ie(
        function () {
          i.current = r;
        },
        [r]
      );
      var l = function (u) {
        var c = typeof u == "function" ? u(i.current) : u;
        (i.current = c), o(c);
      };
      return [r, l, i];
    },
    C7 = Wp;
  var k7 = C7;
  var V5 = k7;
  var Kp = function (t) {
      var n = /^#?([a-f\d])([a-f\d])([a-f\d])$/i,
        a = t.replace(n, function (o, i, l, s) {
          return "".concat(i).concat(i).concat(l).concat(l).concat(s).concat(s);
        }),
        r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(a);
      if (!r) throw new Error("Geist UI: Unsupported ".concat(t, " color."));
      return [
        Number.parseInt(r[1], 16),
        Number.parseInt(r[2], 16),
        Number.parseInt(r[3], 16),
      ];
    },
    jp = function (t) {
      if (t.charAt(0) === "#") return Kp(t);
      var n = t.replace(/ /g, ""),
        a = t.substr(0, 4),
        r = n.match(/\((.+)\)/);
      if (!a.startsWith("rgb") || !r)
        throw (
          (console.log(t),
          new Error('Geist UI: Only support ["RGB", "RGBA", "HEX"] color.'))
        );
      return r[1].split(",").map(function (o) {
        return Number.parseFloat(o);
      });
    },
    un = function (t, n) {
      if (!/^#|rgb|RGB/.test(t)) return t;
      var a = jp(t),
        r = ue(a, 3),
        o = r[0],
        i = r[1],
        l = r[2],
        s = n > 1 ? 1 : n < 0 ? 0 : n;
      return "rgba("
        .concat(o, ", ")
        .concat(i, ", ")
        .concat(l, ", ")
        .concat(s, ")");
    };
  var Yp = { x: 0, y: 0 },
    aa = function (t) {
      var n = t.x,
        a = t.y,
        r = t.color,
        o = t.onCompleted,
        i = at(null),
        l = Number.isNaN(+a) ? 0 : a - 10,
        s = Number.isNaN(+n) ? 0 : n - 10;
      return (
        ie(function () {
          if (!!i.current)
            return (
              i.current.addEventListener("animationend", o),
              function () {
                !i.current || i.current.removeEventListener("animationend", o);
              }
            );
        }),
        S.createElement(
          "div",
          { ref: i, className: "jsx-3424889537 drip" },
          S.createElement(
            "svg",
            {
              width: "20",
              height: "20",
              viewBox: "0 0 20 20",
              style: { top: l, left: s },
              className: "jsx-3424889537",
            },
            S.createElement(
              "g",
              {
                stroke: "none",
                strokeWidth: "1",
                fill: "none",
                fillRule: "evenodd",
                className: "jsx-3424889537",
              },
              S.createElement(
                "g",
                { fill: r, className: "jsx-3424889537" },
                S.createElement("rect", {
                  width: "100%",
                  height: "100%",
                  rx: "10",
                  className: "jsx-3424889537",
                })
              )
            )
          ),
          S.createElement(
            Y,
            { id: "3424889537" },
            ".drip.jsx-3424889537{position:absolute;left:0;right:0;top:0;bottom:0;}svg.jsx-3424889537{position:absolute;-webkit-animation:350ms ease-in expand-jsx-3424889537;animation:350ms ease-in expand-jsx-3424889537;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards;width:1rem;height:1rem;}@-webkit-keyframes expand-jsx-3424889537{0%{opacity:0;-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);}30%{opacity:1;}80%{opacity:0.5;}100%{-webkit-transform:scale(28);-ms-transform:scale(28);transform:scale(28);opacity:0;}}@keyframes expand-jsx-3424889537{0%{opacity:0;-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1);}30%{opacity:1;}80%{opacity:0.5;}100%{-webkit-transform:scale(28);-ms-transform:scale(28);transform:scale(28);opacity:0;}}"
          )
        )
      );
    };
  aa.defaultProps = Yp;
  aa.displayName = "GeistButtonDrip";
  var R7 = aa;
  var I7 = function (t) {
    var n = t.color;
    return S.createElement(
      "div",
      { className: "jsx-3416748964 btn-loading" },
      S.createElement(S7, { color: n }),
      S.createElement(
        Y,
        { id: "3416748964" },
        ".btn-loading.jsx-3416748964{position:absolute;top:0;left:0;right:0;bottom:0;z-index:2;background-color:var(--geist-ui-button-bg);}"
      )
    );
  };
  I7.displayName = "GeistButtonLoading";
  var T7 = I7;
  var Qp = ["isRight", "isSingle", "children", "className"],
    Zp = { isRight: !1, className: "" },
    ra = function (t) {
      var n = t.isRight,
        a = t.isSingle,
        r = t.children,
        o = t.className,
        i = Re(t, Qp),
        l = De("icon", { right: n, single: a }, o);
      return S.createElement(
        "span",
        oe({}, i, {
          className:
            "jsx-643337184 " +
            ((i && i.className != null && i.className) || l || ""),
        }),
        r,
        S.createElement(
          Y,
          { id: "643337184" },
          ".icon.jsx-643337184{position:absolute;left:var(--geist-ui-button-icon-padding);right:auto;top:50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;color:var(--geist-ui-button-color);z-index:1;}.right.jsx-643337184{right:var(--geist-ui-button-icon-padding);left:auto;}.icon.jsx-643337184 svg{background:transparent;height:calc(var(--geist-ui-button-height) / 2.35);width:calc(var(--geist-ui-button-height) / 2.35);}.single.jsx-643337184{position:static;-webkit-transform:none;-ms-transform:none;transform:none;}"
        )
      );
    };
  ra.defaultProps = Zp;
  ra.displayName = "GeistButtonIcon";
  var oa = ra;
  var N7 = function (t, n, a) {
      var r = a.icon,
        o = a.iconRight,
        i = r || o,
        l = Boolean(o),
        s = t
          ? "calc(var(--geist-ui-button-height) / 2 + var(--geist-ui-button-icon-padding) * .5)"
          : 0,
        u = De("text", l ? "right" : "left");
      return i
        ? S.Children.count(n) === 0
          ? S.createElement(oa, { isRight: l, isSingle: !0 }, i)
          : S.createElement(
              S.Fragment,
              null,
              S.createElement(oa, { isRight: l }, i),
              S.createElement(
                "div",
                {
                  className:
                    Y.dynamic([["3568181479", [s, s]]]) + " " + (u || ""),
                },
                n,
                S.createElement(
                  Y,
                  { id: "3568181479", dynamic: [s, s] },
                  ".left.__jsx-style-dynamic-selector{padding-left:"
                    .concat(
                      s,
                      ";}.right.__jsx-style-dynamic-selector{padding-right:"
                    )
                    .concat(s, ";}")
                )
              )
            )
        : S.createElement("div", { className: "text" }, n);
    },
    L7 = function (t, n) {
      return n.isButtonGroup
        ? oe({}, t, {
            auto: !0,
            shadow: !1,
            ghost: n.ghost || t.ghost,
            type: n.type || t.type,
            disabled: n.disabled || t.disabled,
          })
        : t;
    };
  var Xp = { isButtonGroup: !1, disabled: !1 },
    Jp = S.createContext(Xp),
    O7 = function () {
      return S.useContext(Jp);
    };
  var em = function (t, n) {
      var a = {
        secondary: {
          bg: t.background,
          border: t.foreground,
          color: t.foreground,
        },
        success: { bg: t.background, border: t.success, color: t.success },
        warning: { bg: t.background, border: t.warning, color: t.warning },
        error: { bg: t.background, border: t.error, color: t.error },
      };
      return a[n] || null;
    },
    ia = function (t, n) {
      var a = n.type,
        r = n.disabled,
        o = n.ghost,
        i = {
          default: { bg: t.background, border: t.border, color: t.accents_5 },
          secondary: {
            bg: t.foreground,
            border: t.foreground,
            color: t.background,
          },
          success: { bg: t.success, border: t.success, color: "#fff" },
          warning: { bg: t.warning, border: t.warning, color: "#fff" },
          error: { bg: t.error, border: t.error, color: "#fff" },
          abort: {
            bg: "transparent",
            border: "transparent",
            color: t.accents_5,
          },
        };
      if (r) return { bg: t.accents_1, border: t.accents_2, color: "#ccc" };
      var l = a?.replace("-light", ""),
        s = i.default;
      return o ? em(t, l) || s : i[l] || s;
    },
    tm = function (t, n) {
      var a = {
          secondary: {
            bg: t.foreground,
            border: t.background,
            color: t.background,
          },
          success: { bg: t.success, border: t.background, color: "white" },
          warning: { bg: t.warning, border: t.background, color: "white" },
          error: { bg: t.error, border: t.background, color: "white" },
        },
        r = n.replace("-light", "");
      return a[r] || null;
    },
    la = function (t, n) {
      var a = n.type,
        r = n.disabled,
        o = n.loading,
        i = n.shadow,
        l = n.ghost,
        s = ia(t, n),
        u = un(s.bg, 0.85),
        c = {
          default: { bg: t.background, border: t.foreground },
          secondary: { bg: t.background, border: t.foreground },
          success: { bg: t.background, border: t.success },
          warning: { bg: t.background, border: t.warning },
          error: { bg: t.background, border: t.error },
          abort: {
            bg: "transparent",
            border: "transparent",
            color: t.accents_5,
          },
          "secondary-light": oe({}, s, { bg: u }),
          "success-light": oe({}, s, { bg: u }),
          "warning-light": oe({}, s, { bg: u }),
          "error-light": oe({}, s, { bg: u }),
        };
      if (r) return { bg: t.accents_1, border: t.accents_2, color: "#ccc" };
      if (o) return oe({}, s, { color: "transparent" });
      if (i) return s;
      var d = (l ? tm(t, a) : c[a]) || c.default;
      return oe({}, d, { color: d.color || d.border });
    },
    H7 = function (t, n) {
      return t
        ? { cursor: "not-allowed", events: "auto" }
        : n
        ? { cursor: "default", events: "none" }
        : { cursor: "pointer", events: "auto" };
    },
    D7 = function (t, n) {
      var a = n.type,
        r = a.endsWith("light"),
        o = la(t, n);
      return r ? un(o.bg, 0.65) : un(t.accents_2, 0.65);
    };
  var nm = [
      "children",
      "disabled",
      "type",
      "loading",
      "shadow",
      "ghost",
      "effect",
      "onClick",
      "auto",
      "icon",
      "htmlType",
      "iconRight",
      "className",
    ],
    am = {
      type: "default",
      htmlType: "button",
      ghost: !1,
      loading: !1,
      shadow: !1,
      auto: !1,
      effect: !0,
      disabled: !1,
      className: "",
    },
    ca = S.forwardRef(function (e, t) {
      var n = Ue(),
        a = ct(),
        r = a.SCALES,
        o = at(null);
      l1(t, function () {
        return o.current;
      });
      var i = ne(!1),
        l = ue(i, 2),
        s = l[0],
        u = l[1],
        c = ne(0),
        d = ue(c, 2),
        p = d[0],
        m = d[1],
        f = ne(0),
        v = ue(f, 2),
        g = v[0],
        _ = v[1],
        C = O7(),
        y = L7(e, C),
        w = y.children,
        M = y.disabled,
        E = y.type,
        z = y.loading,
        k = y.shadow,
        O = y.ghost,
        K = y.effect,
        H = y.onClick,
        V = y.auto,
        I = y.icon,
        D = y.htmlType,
        J = y.iconRight,
        R = y.className,
        T = Re(y, nm),
        P = ce(
          function () {
            return ia(n.palette, y);
          },
          [n.palette, y]
        ),
        B = P.bg,
        $ = P.border,
        b = P.color,
        h = ce(
          function () {
            return la(n.palette, y);
          },
          [n.palette, y]
        ),
        Le = ce(
          function () {
            return H7(M, z);
          },
          [M, z]
        ),
        le = Le.cursor,
        me = Le.events,
        Ge = ce(
          function () {
            return D7(n.palette, y);
          },
          [n.palette, y]
        ),
        Me = function () {
          u(!1), m(0), _(0);
        },
        be = function (Pe) {
          if (!(M || z)) {
            var $e = !k && !O && K;
            if ($e && o.current) {
              var st = o.current.getBoundingClientRect();
              u(!0), m(Pe.clientX - st.left), _(Pe.clientY - st.top);
            }
            H && H(Pe);
          }
        },
        ae = ce(
          function () {
            return N7(V, w, { icon: I, iconRight: J });
          },
          [V, w, I, J]
        ),
        ze = V ? r.pl(1.15) : r.pl(1.375),
        Ce = V ? r.pr(1.15) : r.pr(1.375);
      return S.createElement(
        "button",
        oe({ ref: o, type: D, disabled: M, onClick: be }, T, {
          className:
            Y.dynamic([
              [
                "86551275",
                [
                  r.height(2.5),
                  n.layout.radius,
                  r.font(0.875),
                  b,
                  B,
                  $,
                  le,
                  me,
                  k ? n.expressiveness.shadowSmall : "none",
                  r.pl(0.727),
                  r.height(2.5),
                  b,
                  B,
                  V ? "min-content" : r.width(10.5),
                  V ? "auto" : "initial",
                  r.height(2.5),
                  r.pt(0),
                  Ce,
                  r.pb(0),
                  ze,
                  r.mt(0),
                  r.mr(0),
                  r.mb(0),
                  r.ml(0),
                  h.color,
                  h.color,
                  h.bg,
                  h.border,
                  le,
                  me,
                  k ? n.expressiveness.shadowMedium : "none",
                  k ? "-1px" : "0px",
                ],
              ],
            ]) +
            " " +
            ((T && T.className != null && T.className) || De("btn", R) || ""),
        }),
        z && S.createElement(T7, { color: b }),
        ae,
        s && S.createElement(R7, { x: p, y: g, color: Ge, onCompleted: Me }),
        S.createElement(
          Y,
          {
            id: "86551275",
            dynamic: [
              r.height(2.5),
              n.layout.radius,
              r.font(0.875),
              b,
              B,
              $,
              le,
              me,
              k ? n.expressiveness.shadowSmall : "none",
              r.pl(0.727),
              r.height(2.5),
              b,
              B,
              V ? "min-content" : r.width(10.5),
              V ? "auto" : "initial",
              r.height(2.5),
              r.pt(0),
              Ce,
              r.pb(0),
              ze,
              r.mt(0),
              r.mr(0),
              r.mb(0),
              r.ml(0),
              h.color,
              h.color,
              h.bg,
              h.border,
              le,
              me,
              k ? n.expressiveness.shadowMedium : "none",
              k ? "-1px" : "0px",
            ],
          },
          ".btn.__jsx-style-dynamic-selector{box-sizing:border-box;display:inline-block;line-height:"
            .concat(r.height(2.5), ";border-radius:")
            .concat(n.layout.radius, ";font-weight:400;font-size:")
            .concat(
              r.font(0.875),
              ";-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;outline:none;text-transform:capitalize;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;text-align:center;white-space:nowrap;-webkit-transition:background-color 200ms ease 0ms,box-shadow 200ms ease 0ms, border 200ms ease 0ms,color 200ms ease 0ms;transition:background-color 200ms ease 0ms,box-shadow 200ms ease 0ms, border 200ms ease 0ms,color 200ms ease 0ms;position:relative;overflow:hidden;color:"
            )
            .concat(b, ";background-color:")
            .concat(B, ";border:1px solid ")
            .concat($, ";cursor:")
            .concat(le, ";pointer-events:")
            .concat(me, ";box-shadow:")
            .concat(
              k ? n.expressiveness.shadowSmall : "none",
              ";--geist-ui-button-icon-padding:"
            )
            .concat(r.pl(0.727), ";--geist-ui-button-height:")
            .concat(r.height(2.5), ";--geist-ui-button-color:")
            .concat(b, ";--geist-ui-button-bg:")
            .concat(B, ";min-width:")
            .concat(V ? "min-content" : r.width(10.5), ";width:")
            .concat(V ? "auto" : "initial", ";height:")
            .concat(r.height(2.5), ";padding:")
            .concat(r.pt(0), " ")
            .concat(Ce, " ")
            .concat(r.pb(0), " ")
            .concat(ze, ";margin:")
            .concat(r.mt(0), " ")
            .concat(r.mr(0), " ")
            .concat(r.mb(0), " ")
            .concat(
              r.ml(0),
              ";}.btn.__jsx-style-dynamic-selector:hover,.btn.__jsx-style-dynamic-selector:focus{color:"
            )
            .concat(h.color, ";--geist-ui-button-color:")
            .concat(h.color, ";background-color:")
            .concat(h.bg, ";border-color:")
            .concat(h.border, ";cursor:")
            .concat(le, ";pointer-events:")
            .concat(me, ";box-shadow:")
            .concat(
              k ? n.expressiveness.shadowMedium : "none",
              ";-webkit-transform:translate3d(0px,"
            )
            .concat(k ? "-1px" : "0px", ",0px);-ms-transform:translate3d(0px,")
            .concat(k ? "-1px" : "0px", ",0px);transform:translate3d(0px,")
            .concat(
              k ? "-1px" : "0px",
              ",0px);}.btn.__jsx-style-dynamic-selector .text{position:relative;z-index:1;display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;text-align:center;line-height:inherit;top:-1px;}.btn.__jsx-style-dynamic-selector .text p,.btn.__jsx-style-dynamic-selector .text pre,.btn.__jsx-style-dynamic-selector .text div{margin:0;}"
            )
        )
      );
    });
  ca.defaultProps = am;
  ca.displayName = "GeistButton";
  var rm = et(ca),
    P7 = rm;
  var F7 = P7;
  var sa = {
      padding: "12px 16px",
      margin: "8px 0",
      width: "420px",
      maxWidth: "90vw",
      maxHeight: "75px",
      placement: "bottomRight",
    },
    om = {
      toasts: [],
      toastLayout: sa,
      updateToastLayout: function (t) {
        return t;
      },
      updateToasts: function (t) {
        return t;
      },
      lastUpdateToastId: null,
      updateLastToastId: function () {
        return null;
      },
    },
    ua = S.createContext(om),
    V7 = function () {
      return S.useContext(ua);
    };
  var im = { themes: sn.getPresets() },
    B7 = S.createContext(im);
  var lm = function (t) {
      var n = t.children,
        a = t.themeType,
        r = t.themes,
        o = r === void 0 ? [] : r,
        i = ne({ themes: Qt.getPresets() }),
        l = ue(i, 2),
        s = l[0],
        u = l[1],
        c = ce(
          function () {
            var d = s.themes.find(function (p) {
              return p.type === a;
            });
            return d || Qt.getPresetStaticTheme();
          },
          [s, a]
        );
      return (
        ie(
          function () {
            !(o != null && o.length) ||
              u(function (d) {
                var p = o.filter(function (f) {
                    return Qt.isAvailableThemeType(f.type);
                  }),
                  m = Qt.getPresets().concat(p);
                return oe({}, d, { themes: m });
              });
          },
          [o]
        ),
        S.createElement(
          B7.Provider,
          { value: s },
          S.createElement(X0.Provider, { value: c }, n)
        )
      );
    },
    U7 = lm;
  var G7 = function (t, n) {
      var a = function (o, i) {
        i && i(o, n);
      };
      return !t || !t.length
        ? null
        : t.map(function (r, o) {
            return S.createElement(
              F7,
              {
                auto: !0,
                scale: 1 / 3,
                font: "13px",
                type: r.passive ? "default" : "secondary",
                key: "action-".concat(o),
                onClick: function (l) {
                  return a(l, r.handler);
                },
              },
              r.name
            );
          });
    },
    $7 = function (t, n) {
      var a = {
          default: t.background,
          secondary: t.secondary,
          success: t.success,
          warning: t.warning,
          error: t.error,
        },
        r = !n || n === "default";
      return r
        ? { bgColor: a.default, color: t.foreground }
        : { bgColor: a[n], color: "white" };
    },
    mz = bt("topLeft", "topRight", "bottomLeft", "bottomRight"),
    q7 = function (t) {
      return "".concat(t).toLowerCase().startsWith("top");
    },
    W7 = function (t) {
      return "".concat(t).toLowerCase().endsWith("left");
    },
    K7 = function (t) {
      var n = {
          topLeft: "translate(-60px, -60px)",
          topRight: "translate(60px, -60px)",
          bottomLeft: "translate(-60px, 60px)",
          bottomRight: "translate(60px, 60px)",
        },
        a = {
          topLeft: "translate(-50px, 15px) scale(0.85)",
          topRight: "translate(50px, 15px) scale(0.85)",
          bottomLeft: "translate(-50px, -15px) scale(0.85)",
          bottomRight: "translate(50px, -15px) scale(0.85)",
        };
      return { enter: n[t], leave: a[t] };
    };
  var cm = S.memo(function (e) {
      var t = e.toast,
        n = e.layout,
        a = Ue(),
        r = ce(
          function () {
            return $7(a.palette, t.type);
          },
          [a.palette, t.type]
        ),
        o = r.color,
        i = r.bgColor,
        l = typeof t.text != "string",
        s = n.padding,
        u = n.margin,
        c = n.maxHeight,
        d = n.maxWidth,
        p = n.width,
        m = n.placement,
        f = ce(
          function () {
            return K7(m);
          },
          [m]
        ),
        v = f.enter,
        g = f.leave;
      return S.createElement(
        A7,
        { name: "toast", visible: t.visible, clearTime: 350 },
        S.createElement(
          "div",
          {
            key: t.id,
            className:
              Y.dynamic([
                [
                  "1407001838",
                  [
                    p,
                    d,
                    c,
                    a.palette.foreground,
                    i,
                    o,
                    a.layout.radius,
                    a.expressiveness.shadowSmall,
                    a.layout.gapHalf,
                    v,
                    u,
                    s,
                    u,
                    s,
                    g,
                  ],
                ],
              ]) + " toast",
          },
          l
            ? t.text
            : S.createElement(
                S.Fragment,
                null,
                S.createElement(
                  "div",
                  {
                    className:
                      Y.dynamic([
                        [
                          "1407001838",
                          [
                            p,
                            d,
                            c,
                            a.palette.foreground,
                            i,
                            o,
                            a.layout.radius,
                            a.expressiveness.shadowSmall,
                            a.layout.gapHalf,
                            v,
                            u,
                            s,
                            u,
                            s,
                            g,
                          ],
                        ],
                      ]) + " message",
                  },
                  t.text
                ),
                S.createElement(
                  "div",
                  {
                    className:
                      Y.dynamic([
                        [
                          "1407001838",
                          [
                            p,
                            d,
                            c,
                            a.palette.foreground,
                            i,
                            o,
                            a.layout.radius,
                            a.expressiveness.shadowSmall,
                            a.layout.gapHalf,
                            v,
                            u,
                            s,
                            u,
                            s,
                            g,
                          ],
                        ],
                      ]) + " action",
                  },
                  G7(t.actions, t.cancel)
                )
              ),
          S.createElement(
            Y,
            {
              id: "1407001838",
              dynamic: [
                p,
                d,
                c,
                a.palette.foreground,
                i,
                o,
                a.layout.radius,
                a.expressiveness.shadowSmall,
                a.layout.gapHalf,
                v,
                u,
                s,
                u,
                s,
                g,
              ],
            },
            ".toast.__jsx-style-dynamic-selector{width:"
              .concat(p, ";max-width:")
              .concat(d, ";max-height:")
              .concat(
                c,
                ";display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;color:"
              )
              .concat(a.palette.foreground, ";background-color:")
              .concat(i, ";color:")
              .concat(o, ";border:0;border-radius:")
              .concat(a.layout.radius, ";opacity:1;box-shadow:")
              .concat(
                a.expressiveness.shadowSmall,
                ";-webkit-transition:all 350ms cubic-bezier(0.1,0.2,0.1,1);transition:all 350ms cubic-bezier(0.1,0.2,0.1,1);overflow:hidden;}.message.__jsx-style-dynamic-selector{-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;height:100%;font-size:0.875em;display:-webkit-box;word-break:break-all;padding-right:"
              )
              .concat(
                a.layout.gapHalf,
                ";overflow:hidden;max-height:100%;text-overflow:ellipsis;-webkit-box-orient:vertical;-webkit-line-clamp:2;line-height:1.1rem;}.toast-enter.__jsx-style-dynamic-selector{opacity:0;height:0;padding:0;margin:0;-webkit-transform:"
              )
              .concat(v, ";-ms-transform:")
              .concat(v, ";transform:")
              .concat(
                v,
                ";}.toast-enter-active.__jsx-style-dynamic-selector{opacity:1;height:auto;margin:"
              )
              .concat(u, ";padding:")
              .concat(
                s,
                ";-webkit-transform:translate(0,0);-ms-transform:translate(0,0);transform:translate(0,0);}.toast-leave.__jsx-style-dynamic-selector{opacity:1;-webkit-transform:translate(0,0);-ms-transform:translate(0,0);transform:translate(0,0);height:auto;margin:"
              )
              .concat(u, ";padding:")
              .concat(
                s,
                ";}.toast-leave-active.__jsx-style-dynamic-selector{opacity:0;-webkit-transform:"
              )
              .concat(g, ";-ms-transform:")
              .concat(g, ";transform:")
              .concat(g, ";}")
          )
        )
      );
    }),
    j7 = cm;
  var sm = function () {
      var t = Ue(),
        n = w7("toast"),
        a = V5(!1),
        r = ue(a, 3),
        o = r[1],
        i = r[2],
        l = V7(),
        s = l.toasts,
        u = l.updateToasts,
        c = l.toastLayout,
        d = l.lastUpdateToastId,
        p = ce(
          function () {
            return c;
          },
          [c]
        ),
        m = ce(
          function () {
            return s.map(function (g) {
              return S.createElement(j7, {
                toast: g,
                layout: p,
                key: g._internalIdent,
              });
            });
          },
          [s, p]
        ),
        f = ce(
          function () {
            return De("toasts", {
              top: q7(c.placement),
              left: W7(c.placement),
            });
          },
          [p]
        ),
        v = function (_) {
          if ((o(_), _))
            return u(function (C) {
              return C.map(function (y) {
                return y.visible
                  ? (y._timeout && window.clearTimeout(y._timeout),
                    oe({}, y, { timeout: null }))
                  : y;
              });
            });
          u(function (C) {
            return C.map(function (y, w) {
              return y.visible
                ? (y._timeout && window.clearTimeout(y._timeout),
                  oe({}, y, {
                    _timeout: (function () {
                      var M = window.setTimeout(function () {
                        y.cancel(), window.clearTimeout(M);
                      }, y.delay + w * 100);
                      return M;
                    })(),
                  }))
                : y;
            });
          });
        };
      return (
        ie(
          function () {
            var g = s.findIndex(function (y) {
                return y._internalIdent === d;
              }),
              _ = s[g];
            if (!(!_ || _.visible || !i.current)) {
              var C = s.find(function (y, w) {
                return w < g && y.visible;
              });
              C || !i.current || v(!1);
            }
          },
          [s, d]
        ),
        ie(
          function () {
            var g = null,
              _ = window.setInterval(function () {
                s.length !== 0 &&
                  (g = window.setTimeout(function () {
                    var C = !s.find(function (y) {
                      return y.visible;
                    });
                    C &&
                      u(function () {
                        return [];
                      }),
                      g && clearTimeout(g);
                  }, 350));
              }, 5e3);
            return function () {
              _ && clearInterval(_), g && clearTimeout(g);
            };
          },
          [s]
        ),
        !n || !s || s.length === 0
          ? null
          : Nn(
              S.createElement(
                "div",
                {
                  onMouseEnter: function () {
                    return v(!0);
                  },
                  onMouseLeave: function () {
                    return v(!1);
                  },
                  className:
                    Y.dynamic([
                      [
                        "622610754",
                        [
                          t.layout.gap,
                          t.layout.gap,
                          t.layout.gap,
                          t.layout.gap,
                        ],
                      ],
                    ]) +
                    " " +
                    (f || ""),
                },
                m,
                S.createElement(
                  Y,
                  {
                    id: "622610754",
                    dynamic: [
                      t.layout.gap,
                      t.layout.gap,
                      t.layout.gap,
                      t.layout.gap,
                    ],
                  },
                  ".toasts.__jsx-style-dynamic-selector{position:fixed;width:auto;max-width:100%;right:"
                    .concat(t.layout.gap, ";bottom:")
                    .concat(
                      t.layout.gap,
                      ";z-index:2000;-webkit-transition:all 400ms ease;transition:all 400ms ease;box-sizing:border-box;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;}.top.__jsx-style-dynamic-selector{bottom:unset;-webkit-flex-direction:column-reverse;-ms-flex-direction:column-reverse;flex-direction:column-reverse;top:"
                    )
                    .concat(
                      t.layout.gap,
                      ";}.left.__jsx-style-dynamic-selector{right:unset;left:"
                    )
                    .concat(t.layout.gap, ";}")
                )
              ),
              n
            )
      );
    },
    Y7 = sm;
  var um = function (t) {
      var n = t.themes,
        a = t.themeType,
        r = t.children,
        o = ne(null),
        i = ue(o, 2),
        l = i[0],
        s = i[1],
        u = V5([]),
        c = ue(u, 3),
        d = c[0],
        p = c[1],
        m = c[2],
        f = V5(sa),
        v = ue(f, 3),
        g = v[0],
        _ = v[1],
        C = v[2],
        y = function (k) {
          var O = k(m.current);
          p(O);
        },
        w = function (k) {
          var O = k(C.current);
          _(O);
        },
        M = function (k) {
          s(k());
        },
        E = ce(
          function () {
            return {
              toasts: d,
              toastLayout: g,
              updateToasts: y,
              lastUpdateToastId: l,
              updateToastLayout: w,
              updateLastToastId: M,
            };
          },
          [d, g, l]
        );
      return S.createElement(
        ua.Provider,
        { value: E },
        S.createElement(
          U7,
          { themes: n, themeType: a },
          r,
          S.createElement(Y7, null)
        )
      );
    },
    Q7 = um;
  var da = Q7;
  var dm = { disabledAll: !1, inGroup: !1 },
    pa = S.createContext(dm),
    Z7 = function () {
      return S.useContext(pa);
    };
  var pm = ["className", "children"],
    mm = { className: "" },
    ma = function (t) {
      var n = t.className,
        a = t.children,
        r = Re(t, pm),
        o = Ue(),
        i = ct(),
        l = i.SCALES;
      return S.createElement(
        "span",
        oe({}, r, {
          className:
            Y.dynamic([
              [
                "2489497926",
                [
                  o.palette.accents_3,
                  l.font(0.85, "calc(var(--radio-size) * 0.85)"),
                  l.width(1, "auto"),
                  l.height(1, "auto"),
                  l.pt(0),
                  l.pr(0),
                  l.pb(0),
                  l.pl(0),
                  l.mt(0),
                  l.mr(0),
                  l.mb(0),
                  l.ml(
                    0,
                    "calc(var(--radio-size) + var(--radio-size) * 0.375)"
                  ),
                ],
              ],
            ]) +
            " " +
            ((r && r.className != null && r.className) || n || ""),
        }),
        a,
        S.createElement(
          Y,
          {
            id: "2489497926",
            dynamic: [
              o.palette.accents_3,
              l.font(0.85, "calc(var(--radio-size) * 0.85)"),
              l.width(1, "auto"),
              l.height(1, "auto"),
              l.pt(0),
              l.pr(0),
              l.pb(0),
              l.pl(0),
              l.mt(0),
              l.mr(0),
              l.mb(0),
              l.ml(0, "calc(var(--radio-size) + var(--radio-size) * 0.375)"),
            ],
          },
          "span.__jsx-style-dynamic-selector{color:"
            .concat(o.palette.accents_3, ";font-size:")
            .concat(l.font(0.85, "calc(var(--radio-size) * 0.85)"), ";width:")
            .concat(l.width(1, "auto"), ";height:")
            .concat(l.height(1, "auto"), ";padding:")
            .concat(l.pt(0), " ")
            .concat(l.pr(0), " ")
            .concat(l.pb(0), " ")
            .concat(l.pl(0), ";margin:")
            .concat(l.mt(0), " ")
            .concat(l.mr(0), " ")
            .concat(l.mb(0), " ")
            .concat(
              l.ml(0, "calc(var(--radio-size) + var(--radio-size) * 0.375)"),
              ";}"
            )
        )
      );
    };
  ma.defaultProps = mm;
  ma.displayName = "GeistRadioDescription";
  var hm = et(ma),
    B5 = hm;
  var X7 = function (t, n) {
    var a = {
      default: { label: t.foreground, border: t.border, bg: t.foreground },
      secondary: { label: t.foreground, border: t.border, bg: t.foreground },
      success: { label: t.success, border: t.success, bg: t.success },
      warning: { label: t.warning, border: t.warning, bg: t.warning },
      error: { label: t.error, border: t.error, bg: t.error },
    };
    return n ? a[n] : a.default;
  };
  var fm = [
      "className",
      "checked",
      "onChange",
      "disabled",
      "type",
      "value",
      "children",
    ],
    gm = { type: "default", disabled: !1, className: "" },
    ha = function (t) {
      var n = t.className,
        a = t.checked,
        r = t.onChange,
        o = t.disabled,
        i = t.type,
        l = t.value,
        s = t.children,
        u = Re(t, fm),
        c = Ue(),
        d = ct(),
        p = d.SCALES,
        m = ne(!!a),
        f = ue(m, 2),
        v = f[0],
        g = f[1],
        _ = Z7(),
        C = _.value,
        y = _.disabledAll,
        w = _.inGroup,
        M = _.updateState,
        E = h7(s, B5),
        z = ue(E, 2),
        k = z[0],
        O = z[1];
      w &&
        (a !== void 0 &&
          ta('Remove props "checked" if in the Radio.Group.', "Radio"),
        l === void 0 &&
          ta('Props "value" must be deinfed if in the Radio.Group.', "Radio"),
        ie(
          function () {
            g(C === l);
          },
          [C, l]
        ));
      var K = ce(
          function () {
            return X7(c.palette, i);
          },
          [c.palette, i]
        ),
        H = K.label,
        V = K.border,
        I = K.bg,
        D = ce(
          function () {
            return o || y;
          },
          [o, y]
        ),
        J = function (T) {
          if (!D) {
            var P = {
              target: { checked: !v },
              stopPropagation: T.stopPropagation,
              preventDefault: T.preventDefault,
              nativeEvent: T,
            };
            g(!v), w && M && M(l), r && r(P);
          }
        };
      return (
        ie(
          function () {
            a !== void 0 && g(Boolean(a));
          },
          [a]
        ),
        S.createElement(
          "div",
          {
            className:
              Y.dynamic([
                [
                  "2664604043",
                  [
                    p.font(1),
                    p.width(1, "initial"),
                    p.height(1, "auto"),
                    p.pt(0),
                    p.pr(0),
                    p.pb(0),
                    p.pl(0),
                    p.mt(0),
                    p.mr(0),
                    p.mb(0),
                    p.ml(0),
                    D ? c.palette.accents_4 : H,
                    D ? "not-allowed" : "pointer",
                    V,
                    D ? c.palette.accents_4 : I,
                  ],
                ],
              ]) +
              " " +
              (De("radio", n) || ""),
          },
          S.createElement(
            "label",
            {
              className: Y.dynamic([
                [
                  "2664604043",
                  [
                    p.font(1),
                    p.width(1, "initial"),
                    p.height(1, "auto"),
                    p.pt(0),
                    p.pr(0),
                    p.pb(0),
                    p.pl(0),
                    p.mt(0),
                    p.mr(0),
                    p.mb(0),
                    p.ml(0),
                    D ? c.palette.accents_4 : H,
                    D ? "not-allowed" : "pointer",
                    V,
                    D ? c.palette.accents_4 : I,
                  ],
                ],
              ]),
            },
            S.createElement(
              "input",
              oe({ type: "radio", value: l, checked: v, onChange: J }, u, {
                className:
                  Y.dynamic([
                    [
                      "2664604043",
                      [
                        p.font(1),
                        p.width(1, "initial"),
                        p.height(1, "auto"),
                        p.pt(0),
                        p.pr(0),
                        p.pb(0),
                        p.pl(0),
                        p.mt(0),
                        p.mr(0),
                        p.mb(0),
                        p.ml(0),
                        D ? c.palette.accents_4 : H,
                        D ? "not-allowed" : "pointer",
                        V,
                        D ? c.palette.accents_4 : I,
                      ],
                    ],
                  ]) +
                  " " +
                  ((u && u.className != null && u.className) || ""),
              })
            ),
            S.createElement(
              "span",
              {
                className:
                  Y.dynamic([
                    [
                      "2664604043",
                      [
                        p.font(1),
                        p.width(1, "initial"),
                        p.height(1, "auto"),
                        p.pt(0),
                        p.pr(0),
                        p.pb(0),
                        p.pl(0),
                        p.mt(0),
                        p.mr(0),
                        p.mb(0),
                        p.ml(0),
                        D ? c.palette.accents_4 : H,
                        D ? "not-allowed" : "pointer",
                        V,
                        D ? c.palette.accents_4 : I,
                      ],
                    ],
                  ]) + " name",
              },
              S.createElement("span", {
                className:
                  Y.dynamic([
                    [
                      "2664604043",
                      [
                        p.font(1),
                        p.width(1, "initial"),
                        p.height(1, "auto"),
                        p.pt(0),
                        p.pr(0),
                        p.pb(0),
                        p.pl(0),
                        p.mt(0),
                        p.mr(0),
                        p.mb(0),
                        p.ml(0),
                        D ? c.palette.accents_4 : H,
                        D ? "not-allowed" : "pointer",
                        V,
                        D ? c.palette.accents_4 : I,
                      ],
                    ],
                  ]) +
                  " " +
                  (De("point", { active: v }) || ""),
              }),
              k
            ),
            O && O
          ),
          S.createElement(
            Y,
            {
              id: "2664604043",
              dynamic: [
                p.font(1),
                p.width(1, "initial"),
                p.height(1, "auto"),
                p.pt(0),
                p.pr(0),
                p.pb(0),
                p.pl(0),
                p.mt(0),
                p.mr(0),
                p.mb(0),
                p.ml(0),
                D ? c.palette.accents_4 : H,
                D ? "not-allowed" : "pointer",
                V,
                D ? c.palette.accents_4 : I,
              ],
            },
            "input.__jsx-style-dynamic-selector{opacity:0;visibility:hidden;overflow:hidden;width:1px;height:1px;top:-1000px;right:-1000px;position:fixed;font-size:0;}.radio.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:flex-start;-webkit-box-align:flex-start;-ms-flex-align:flex-start;align-items:flex-start;position:relative;--radio-size:"
              .concat(p.font(1), ";width:")
              .concat(p.width(1, "initial"), ";height:")
              .concat(p.height(1, "auto"), ";padding:")
              .concat(p.pt(0), " ")
              .concat(p.pr(0), " ")
              .concat(p.pb(0), " ")
              .concat(p.pl(0), ";margin:")
              .concat(p.mt(0), " ")
              .concat(p.mr(0), " ")
              .concat(p.mb(0), " ")
              .concat(
                p.ml(0),
                ";}label.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:start;-webkit-justify-content:flex-start;-ms-flex-pack:start;justify-content:flex-start;color:"
              )
              .concat(D ? c.palette.accents_4 : H, ";cursor:")
              .concat(
                D ? "not-allowed" : "pointer",
                ";}.name.__jsx-style-dynamic-selector{font-size:var(--radio-size);font-weight:bold;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;display:-webkit-inline-box;display:-webkit-inline-flex;display:-ms-inline-flexbox;display:inline-flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}.point.__jsx-style-dynamic-selector{height:var(--radio-size);width:var(--radio-size);border-radius:50%;border:1px solid "
              )
              .concat(
                V,
                ";-webkit-transition:all 0.2s ease 0s;transition:all 0.2s ease 0s;position:relative;display:inline-block;-webkit-transform:scale(0.875);-ms-transform:scale(0.875);transform:scale(0.875);margin-right:calc(var(--radio-size) * 0.375);}.point.__jsx-style-dynamic-selector:before{content:'';position:absolute;left:-1px;top:-1px;-webkit-transform:scale(0);-ms-transform:scale(0);transform:scale(0);height:var(--radio-size);width:var(--radio-size);border-radius:50%;background-color:"
              )
              .concat(
                D ? c.palette.accents_4 : I,
                ";}.active.__jsx-style-dynamic-selector:before{-webkit-transform:scale(0.875);-ms-transform:scale(0.875);transform:scale(0.875);-webkit-transition:all 0.2s ease 0s;transition:all 0.2s ease 0s;}"
              )
          )
        )
      );
    };
  ha.defaultProps = gm;
  ha.displayName = "GeistRadio";
  var vm = et(ha),
    U5 = vm;
  var bm = [
      "disabled",
      "onChange",
      "value",
      "children",
      "className",
      "initialValue",
      "useRow",
    ],
    _m = { disabled: !1, className: "", useRow: !1 },
    fa = function (t) {
      var n = t.disabled,
        a = t.onChange,
        r = t.value,
        o = t.children,
        i = t.className,
        l = t.initialValue,
        s = t.useRow,
        u = Re(t, bm),
        c = ct(),
        d = c.SCALES,
        p = ne(l),
        m = ue(p, 2),
        f = m[0],
        v = m[1],
        g = function (y) {
          v(y), a && a(y);
        },
        _ = ce(
          function () {
            return { updateState: g, disabledAll: n, inGroup: !0, value: f };
          },
          [n, f]
        );
      return (
        ie(
          function () {
            r !== void 0 && v(r);
          },
          [r]
        ),
        S.createElement(
          pa.Provider,
          { value: _ },
          S.createElement(
            "div",
            oe({}, u, {
              className:
                Y.dynamic([
                  [
                    "1223822443",
                    [
                      s ? "col" : "column",
                      d.font(1),
                      d.width(1, "auto"),
                      d.height(1, "auto"),
                      d.pt(0),
                      d.pr(0),
                      d.pb(0),
                      d.pl(0),
                      d.mt(0),
                      d.mr(0),
                      d.mb(0),
                      d.ml(0),
                      s ? 0 : "var(--radio-group-gap)",
                      s ? "var(--radio-group-gap)" : 0,
                      d.font(1),
                    ],
                  ],
                ]) +
                " " +
                ((u && u.className != null && u.className) ||
                  De("radio-group", i) ||
                  ""),
            }),
            o
          ),
          S.createElement(
            Y,
            {
              id: "1223822443",
              dynamic: [
                s ? "col" : "column",
                d.font(1),
                d.width(1, "auto"),
                d.height(1, "auto"),
                d.pt(0),
                d.pr(0),
                d.pb(0),
                d.pl(0),
                d.mt(0),
                d.mr(0),
                d.mb(0),
                d.ml(0),
                s ? 0 : "var(--radio-group-gap)",
                s ? "var(--radio-group-gap)" : 0,
                d.font(1),
              ],
            },
            ".radio-group.__jsx-style-dynamic-selector{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:"
              .concat(s ? "col" : "column", ";-ms-flex-direction:")
              .concat(s ? "col" : "column", ";flex-direction:")
              .concat(s ? "col" : "column", ";--radio-group-gap:")
              .concat(d.font(1), ";width:")
              .concat(d.width(1, "auto"), ";height:")
              .concat(d.height(1, "auto"), ";padding:")
              .concat(d.pt(0), " ")
              .concat(d.pr(0), " ")
              .concat(d.pb(0), " ")
              .concat(d.pl(0), ";margin:")
              .concat(d.mt(0), " ")
              .concat(d.mr(0), " ")
              .concat(d.mb(0), " ")
              .concat(
                d.ml(0),
                ";}.radio-group.__jsx-style-dynamic-selector .radio{margin-top:"
              )
              .concat(s ? 0 : "var(--radio-group-gap)", ";margin-left:")
              .concat(s ? "var(--radio-group-gap)" : 0, ";--radio-size:")
              .concat(
                d.font(1),
                ";}.radio-group.__jsx-style-dynamic-selector .radio:first-of-type{margin:0;}"
              )
          )
        )
      );
    };
  fa.defaultProps = _m;
  fa.displayName = "GeistRadioGroup";
  var Em = et(fa),
    J7 = Em;
  U5.Group = J7;
  U5.Description = B5;
  U5.Desc = B5;
  var d5 = U5;
  var ec = function (t, n) {
    var a = {
      default: { bg: t.success },
      secondary: { bg: t.secondary },
      success: { bg: t.success },
      warning: { bg: t.warning },
      error: { bg: t.error },
    };
    return n ? a[n] : a.default;
  };
  var ym = [
      "initialChecked",
      "checked",
      "disabled",
      "onChange",
      "type",
      "className",
    ],
    xm = { type: "default", disabled: !1, initialChecked: !1, className: "" },
    ga = function (t) {
      var n = t.initialChecked,
        a = t.checked,
        r = t.disabled,
        o = t.onChange,
        i = t.type,
        l = t.className,
        s = Re(t, ym),
        u = Ue(),
        c = ct(),
        d = c.SCALES,
        p = ne(n),
        m = ue(p, 2),
        f = m[0],
        v = m[1],
        g = De("toggle", { checked: f, disabled: r }),
        _ = vt(
          function (w) {
            if (!r) {
              var M = {
                target: { checked: !f },
                stopPropagation: w.stopPropagation,
                preventDefault: w.preventDefault,
                nativeEvent: w,
              };
              v(!f), o && o(M);
            }
          },
          [r, f, o]
        ),
        C = ce(
          function () {
            return ec(u.palette, i);
          },
          [u.palette, i]
        ),
        y = C.bg;
      return (
        ie(
          function () {
            a !== void 0 && v(a);
          },
          [a]
        ),
        S.createElement(
          "label",
          oe({}, s, {
            className:
              Y.dynamic([
                [
                  "4106206985",
                  [
                    r ? "not-allowed" : "pointer",
                    d.font(1),
                    d.height(0.875),
                    d.width(1.75),
                    d.pt(0.1875),
                    d.pr(0),
                    d.pb(0.1875),
                    d.pl(0),
                    d.mt(0),
                    d.mr(0),
                    d.mb(0),
                    d.ml(0),
                    u.palette.accents_2,
                    u.palette.background,
                    u.palette.accents_2,
                    u.palette.accents_1,
                    u.palette.accents_2,
                    u.palette.accents_4,
                    u.palette.accents_4,
                    y,
                  ],
                ],
              ]) +
              " " +
              ((s && s.className != null && s.className) || l || ""),
          }),
          S.createElement("input", {
            type: "checkbox",
            disabled: r,
            checked: f,
            onChange: _,
            className: Y.dynamic([
              [
                "4106206985",
                [
                  r ? "not-allowed" : "pointer",
                  d.font(1),
                  d.height(0.875),
                  d.width(1.75),
                  d.pt(0.1875),
                  d.pr(0),
                  d.pb(0.1875),
                  d.pl(0),
                  d.mt(0),
                  d.mr(0),
                  d.mb(0),
                  d.ml(0),
                  u.palette.accents_2,
                  u.palette.background,
                  u.palette.accents_2,
                  u.palette.accents_1,
                  u.palette.accents_2,
                  u.palette.accents_4,
                  u.palette.accents_4,
                  y,
                ],
              ],
            ]),
          }),
          S.createElement(
            "div",
            {
              className:
                Y.dynamic([
                  [
                    "4106206985",
                    [
                      r ? "not-allowed" : "pointer",
                      d.font(1),
                      d.height(0.875),
                      d.width(1.75),
                      d.pt(0.1875),
                      d.pr(0),
                      d.pb(0.1875),
                      d.pl(0),
                      d.mt(0),
                      d.mr(0),
                      d.mb(0),
                      d.ml(0),
                      u.palette.accents_2,
                      u.palette.background,
                      u.palette.accents_2,
                      u.palette.accents_1,
                      u.palette.accents_2,
                      u.palette.accents_4,
                      u.palette.accents_4,
                      y,
                    ],
                  ],
                ]) +
                " " +
                (g || ""),
            },
            S.createElement("span", {
              className:
                Y.dynamic([
                  [
                    "4106206985",
                    [
                      r ? "not-allowed" : "pointer",
                      d.font(1),
                      d.height(0.875),
                      d.width(1.75),
                      d.pt(0.1875),
                      d.pr(0),
                      d.pb(0.1875),
                      d.pl(0),
                      d.mt(0),
                      d.mr(0),
                      d.mb(0),
                      d.ml(0),
                      u.palette.accents_2,
                      u.palette.background,
                      u.palette.accents_2,
                      u.palette.accents_1,
                      u.palette.accents_2,
                      u.palette.accents_4,
                      u.palette.accents_4,
                      y,
                    ],
                  ],
                ]) + " inner",
            })
          ),
          S.createElement(
            Y,
            {
              id: "4106206985",
              dynamic: [
                r ? "not-allowed" : "pointer",
                d.font(1),
                d.height(0.875),
                d.width(1.75),
                d.pt(0.1875),
                d.pr(0),
                d.pb(0.1875),
                d.pl(0),
                d.mt(0),
                d.mr(0),
                d.mb(0),
                d.ml(0),
                u.palette.accents_2,
                u.palette.background,
                u.palette.accents_2,
                u.palette.accents_1,
                u.palette.accents_2,
                u.palette.accents_4,
                u.palette.accents_4,
                y,
              ],
            },
            "label.__jsx-style-dynamic-selector{-webkit-tap-highlight-color:transparent;display:inline-block;vertical-align:middle;white-space:nowrap;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;position:relative;cursor:"
              .concat(r ? "not-allowed" : "pointer", ";--toggle-font-size:")
              .concat(d.font(1), ";--toggle-height:")
              .concat(d.height(0.875), ";width:")
              .concat(d.width(1.75), ";height:var(--toggle-height);padding:")
              .concat(d.pt(0.1875), " ")
              .concat(d.pr(0), " ")
              .concat(d.pb(0.1875), " ")
              .concat(d.pl(0), ";margin:")
              .concat(d.mt(0), " ")
              .concat(d.mr(0), " ")
              .concat(d.mb(0), " ")
              .concat(
                d.ml(0),
                ";}input.__jsx-style-dynamic-selector{overflow:hidden;visibility:hidden;height:0;opacity:0;width:0;position:absolute;background-color:transparent;z-index:-1;}.toggle.__jsx-style-dynamic-selector{height:var(--toggle-height);width:100%;border-radius:var(--toggle-height);-webkit-transition-delay:0.12s;transition-delay:0.12s;-webkit-transition-duration:0.2s;transition-duration:0.2s;-webkit-transition-property:background,border;transition-property:background,border;-webkit-transition-timing-function:cubic-bezier(0,0,0.2,1);transition-timing-function:cubic-bezier(0,0,0.2,1);position:relative;border:1px solid transparent;background-color:"
              )
              .concat(
                u.palette.accents_2,
                ";padding:0;}.inner.__jsx-style-dynamic-selector{width:calc(var(--toggle-height) - 2px);height:calc(var(--toggle-height) - 2px);position:absolute;top:50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%);left:1px;box-shadow:rgba(0,0,0,0.2) 0 1px 2px 0,rgba(0,0,0,0.1) 0 1px 3px 0;-webkit-transition:left 280ms cubic-bezier(0,0,0.2,1);transition:left 280ms cubic-bezier(0,0,0.2,1);border-radius:50%;background-color:"
              )
              .concat(
                u.palette.background,
                ";}.disabled.__jsx-style-dynamic-selector{border-color:"
              )
              .concat(u.palette.accents_2, ";background-color:")
              .concat(
                u.palette.accents_1,
                ";}.disabled.__jsx-style-dynamic-selector>.inner.__jsx-style-dynamic-selector{background-color:"
              )
              .concat(
                u.palette.accents_2,
                ";}.disabled.checked.__jsx-style-dynamic-selector{border-color:"
              )
              .concat(u.palette.accents_4, ";background-color:")
              .concat(
                u.palette.accents_4,
                ";}.checked.__jsx-style-dynamic-selector{background-color:"
              )
              .concat(
                y,
                ";}.checked.__jsx-style-dynamic-selector>.inner.__jsx-style-dynamic-selector{left:calc(100% - (var(--toggle-height) - 2px));box-shadow:none;}"
              )
          )
        )
      );
    };
  ga.defaultProps = xm;
  ga.displayName = "GeistToggle";
  var wm = et(ga),
    tc = wm;
  var va = tc;
  var Am = 0;
  function x(e, t, n, a, r) {
    var o,
      i,
      l = {};
    for (i in t) i == "ref" ? (o = t[i]) : (l[i] = t[i]);
    var s = {
      type: e,
      props: l,
      key: n,
      ref: o,
      __k: null,
      __: null,
      __b: 0,
      __e: null,
      __d: void 0,
      __c: null,
      __h: null,
      constructor: void 0,
      __v: --Am,
      __source: r,
      __self: a,
    };
    if (typeof e == "function" && (o = e.defaultProps))
      for (i in o) l[i] === void 0 && (l[i] = o[i]);
    return W.vnode && W.vnode(s), s;
  }
  function Mm() {
    let [e, t] = ne("auto"),
      n = ce(() => (e === "auto" ? r1() : e), [e]);
    return (
      ie(() => {
        yt().then((a) => t(a.theme));
      }, []),
      x(da, { themeType: n, children: x(zm, { theme: e, onThemeChange: t }) })
    );
  }
  function zm(e) {
    let [t, n] = ne("always"),
      [a, r] = ne(!1);
    ie(() => {
      yt().then((s) => {
        n(s.triggerMode), r(s.clearConversation);
      });
    }, []);
    let o = vt((s) => {
        let u = s.target.checked;
        r(u), a1({ clearConversation: u });
      }, []),
      i = vt((s) => {
        n(s), a1({ triggerMode: s });
      }, []),
      l = vt(
        (s) => {
          let u = document.querySelector(".chat-gpt-container");
          s === "dark"
            ? (u.classList.add("gpt-dark"), u.classList.remove("gpt-light"))
            : s === "light"
            ? (u.classList.add("gpt-light"), u.classList.remove("gpt-dark"))
            : (u.classList.add("gpt-dark"), u.classList.remove("gpt-light")),
            a1({ theme: s }),
            e.onThemeChange(s);
        },
        [e]
      );
    return x("section", {
      className: "settings__list active",
      children: [
        x("div", {
          className: "item",
          children: [
            x("div", {
              className: "item__title",
              children: [
                x("svg", {
                  viewBox: "0 0 24 24",
                  fill: "none",
                  xmlns: "http://www.w3.org/2000/svg",
                  children: [
                    x("g", { id: "SVGRepo_bgCarrier", strokeWidth: "0" }),
                    x("g", {
                      id: "SVGRepo_iconCarrier",
                      children: x("path", {
                        d: "M18.48 18.5368H21M4.68 12L3 12.044M4.68 12C4.68 13.3255 5.75451 14.4 7.08 14.4C8.40548 14.4 9.48 13.3255 9.48 12C9.48 10.6745 8.40548 9.6 7.08 9.6C5.75451 9.6 4.68 10.6745 4.68 12ZM10.169 12.0441H21M12.801 5.55124L3 5.55124M21 5.55124H18.48M3 18.5368H12.801M17.88 18.6C17.88 19.9255 16.8055 21 15.48 21C14.1545 21 13.08 19.9255 13.08 18.6C13.08 17.2745 14.1545 16.2 15.48 16.2C16.8055 16.2 17.88 17.2745 17.88 18.6ZM17.88 5.4C17.88 6.72548 16.8055 7.8 15.48 7.8C14.1545 7.8 13.08 6.72548 13.08 5.4C13.08 4.07452 14.1545 3 15.48 3C16.8055 3 17.88 4.07452 17.88 5.4Z",
                        stroke: "#363853",
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                      }),
                    }),
                  ],
                }),
                x("span", { children: "Trigger Mode" }),
              ],
            }),
            x(d5.Group, {
              value: t,
              onChange: (s) => i(s),
              children: Object.entries(Sr).map(([s, u]) =>
                x("div", {
                  className: "item__child",
                  children: x(
                    d5,
                    {
                      value: s,
                      children: x("div", {
                        className: "radio-content",
                        children: [
                          x("div", { children: u }),
                          x("div", { children: Cr[s] }),
                        ],
                      }),
                    },
                    s
                  ),
                })
              ),
            }),
            x("label", {
              className: "item__child",
              style: {
                borderTop: "1px solid #f1f1f1",
                borderBottom: "1px solid #ababab",
              },
              children: x("div", {
                style: { fontSize: "14px", display: "flex" },
                children: [
                  x(va, { type: "error", onChange: o, checked: a }),
                  x("span", {
                    style: { marginLeft: "10px" },
                    children: "Auto Clear conversations",
                  }),
                ],
              }),
            }),
          ],
        }),
        x("div", {
          className: "item",
          children: [
            x("div", {
              className: "item__title",
              children: [
                x("svg", {
                  viewBox: "0 0 24 24",
                  version: "1.1",
                  xmlns: "http://www.w3.org/2000/svg",
                  xmlnsXlink: "http://www.w3.org/1999/xlink",
                  fill: "#000000",
                  children: [
                    x("g", { id: "SVGRepo_bgCarrier", strokeWidth: "0" }),
                    x("g", {
                      id: "SVGRepo_iconCarrier",
                      children: [
                        x("title", {
                          children: "ic_fluent_dark_theme_24_filled",
                        }),
                        x("desc", { children: "Created with Sketch." }),
                        x("g", {
                          id: "\u{1F50D}-Product-Icons",
                          stroke: "none",
                          strokeWidth: "1",
                          fill: "none",
                          fillRule: "evenodd",
                          children: x("g", {
                            id: "ic_fluent_dark_theme_24_filled",
                            fill: "#212121",
                            fillRule: "nonzero",
                            children: x("path", {
                              d: "M12,22 C17.5228475,22 22,17.5228475 22,12 C22,6.4771525 17.5228475,2 12,2 C6.4771525,2 2,6.4771525 2,12 C2,17.5228475 6.4771525,22 12,22 Z M12,20 L12,4 C16.418278,4 20,7.581722 20,12 C20,16.418278 16.418278,20 12,20 Z",
                              id: "\u{1F3A8}-Color",
                            }),
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
                x("span", { children: "Theme" }),
              ],
            }),
            x(d5.Group, {
              value: e.theme,
              onChange: (s) => l(s),
              children: Object.entries(_5).map(([s, u]) =>
                x("div", {
                  className: "item__child",
                  children: x(d5, { value: u, children: s }, u),
                })
              ),
            }),
          ],
        }),
      ],
    });
  }
  var nc = x5(Mm);
  function Sm(e) {
    let [t, n] = S.useState(!1),
      a = at(),
      r = at();
    ie(() => {
      function i(l) {
        a.current &&
          !a.current.contains(l.target) &&
          !r.current.contains(l.target) &&
          n(!1);
      }
      return (
        document.addEventListener("mousedown", i),
        () => {
          document.removeEventListener("mousedown", i);
        }
      );
    }, [a]);
    let o = (i) => {
      n(!t);
    };
    return x("section", {
      id: "answer",
      className: "markdown-body gpt-inner",
      dir: "auto",
      children: x("div", {
        className: "extension-box",
        children: [
          x("div", {
            className: "extension-header",
            children: [
              x("div", {
                className: "left",
                children: [
                  x("img", { src: r7 }),
                  x("div", { className: "title", children: "ChatGPT" }),
                ],
              }),
              x("div", {
                className: "right",
                children: [
                  x("div", {
                    className: "vote",
                    children: [
                      x("div", {
                        className: "vote__up",
                        children: x("svg", {
                          width: "16",
                          height: "16",
                          xmlns: "http://www.w3.org/2000/svg",
                          children: x("path", {
                            d: "M0 10.8c0 2.4 1.6 4.4 3.5 4.4h2.3c1 .5 2 .8 3.3.8h1c.9 0 1.7 0 2.2-.2 1-.2 1.6-1 1.6-1.8l-.1-.5c.5-.4.8-.9.8-1.5l-.2-.8c.3-.3.5-.8.5-1.3 0-.4 0-.7-.2-1A1.9 1.9 0 0 0 13 6h-2.6c-.2 0-.3 0-.3-.2 0-.8 1.2-2.5 1.2-4 0-1-.7-1.7-1.7-1.7C9 0 8.5.4 8.1 1.3c-.9 1.6-2 3-3.6 5.1H3.2c-1.8 0-3.2 2-3.2 4.4Zm4.2 0c0-1.5.3-2.5 1.3-3.8C6.5 5.6 8 4 9 1.8c.2-.5.4-.6.7-.6.2 0 .4.2.4.5C10.2 3 9 4.6 9 5.7c0 .8.7 1.3 1.6 1.3H13c.4 0 .8.4.8.8 0 .3-.1.6-.4.8-.1.2-.2.3 0 .5.2.3.3.5.3.8 0 .3-.2.6-.5.8-.2.1-.3.4-.1.6l.2.7c0 .4-.2.6-.7.9-.2.1-.2.3-.2.4l.2.7c0 .3-.2.6-.7.7a8 8 0 0 1-2 .2H9c-3 0-5-1.7-5-4.1Zm-3 0c0-1.8.9-3.3 2-3.3h.6c-.5 1-.7 2-.7 3.3 0 1.3.4 2.4 1.3 3.3h-1c-1.2 0-2.3-1.5-2.3-3.3Z",
                            fill: "currentColor",
                          }),
                        }),
                      }),
                      x("div", {
                        className: "vote__down",
                        children: x("svg", {
                          width: "16",
                          height: "16",
                          xmlns: "http://www.w3.org/2000/svg",
                          children: x("path", {
                            d: "M0 10.8c0 2.4 1.6 4.4 3.5 4.4h2.3c1 .5 2 .8 3.3.8h1c.9 0 1.7 0 2.2-.2 1-.2 1.6-1 1.6-1.8l-.1-.5c.5-.4.8-.9.8-1.5l-.2-.8c.3-.3.5-.8.5-1.3 0-.4 0-.7-.2-1A1.9 1.9 0 0 0 13 6h-2.6c-.2 0-.3 0-.3-.2 0-.8 1.2-2.5 1.2-4 0-1-.7-1.7-1.7-1.7C9 0 8.5.4 8.1 1.3c-.9 1.6-2 3-3.6 5.1H3.2c-1.8 0-3.2 2-3.2 4.4Zm4.2 0c0-1.5.3-2.5 1.3-3.8C6.5 5.6 8 4 9 1.8c.2-.5.4-.6.7-.6.2 0 .4.2.4.5C10.2 3 9 4.6 9 5.7c0 .8.7 1.3 1.6 1.3H13c.4 0 .8.4.8.8 0 .3-.1.6-.4.8-.1.2-.2.3 0 .5.2.3.3.5.3.8 0 .3-.2.6-.5.8-.2.1-.3.4-.1.6l.2.7c0 .4-.2.6-.7.9-.2.1-.2.3-.2.4l.2.7c0 .3-.2.6-.7.7a8 8 0 0 1-2 .2H9c-3 0-5-1.7-5-4.1Zm-3 0c0-1.8.9-3.3 2-3.3h.6c-.5 1-.7 2-.7 3.3 0 1.3.4 2.4 1.3 3.3h-1c-1.2 0-2.3-1.5-2.3-3.3Z",
                            fill: "currentColor",
                          }),
                        }),
                      }),
                    ],
                  }),
                  x("div", {
                    className: "settings",
                    children: [
                      x("div", {
                        className: "icon " + (t ? "active" : ""),
                        onClick: o,
                        ref: r,
                        children: x("svg", {
                          width: "20px",
                          height: "20px",
                          viewBox: "0 0 1024 1024",
                          xmlns: "http://www.w3.org/2000/svg",
                          fill: "#000000",
                          children: [
                            x("g", {
                              id: "SVGRepo_bgCarrier",
                              strokeWidth: "0",
                            }),
                            x("g", {
                              id: "SVGRepo_iconCarrier",
                              children: x("path", {
                                fill: "#000000",
                                d: "M600.704 64a32 32 0 0130.464 22.208l35.2 109.376c14.784 7.232 28.928 15.36 42.432 24.512l112.384-24.192a32 32 0 0134.432 15.36L944.32 364.8a32 32 0 01-4.032 37.504l-77.12 85.12a357.12 357.12 0 010 49.024l77.12 85.248a32 32 0 014.032 37.504l-88.704 153.6a32 32 0 01-34.432 15.296L708.8 803.904c-13.44 9.088-27.648 17.28-42.368 24.512l-35.264 109.376A32 32 0 01600.704 960H423.296a32 32 0 01-30.464-22.208L357.696 828.48a351.616 351.616 0 01-42.56-24.64l-112.32 24.256a32 32 0 01-34.432-15.36L79.68 659.2a32 32 0 014.032-37.504l77.12-85.248a357.12 357.12 0 010-48.896l-77.12-85.248A32 32 0 0179.68 364.8l88.704-153.6a32 32 0 0134.432-15.296l112.32 24.256c13.568-9.152 27.776-17.408 42.56-24.64l35.2-109.312A32 32 0 01423.232 64H600.64zm-23.424 64H446.72l-36.352 113.088-24.512 11.968a294.113 294.113 0 00-34.816 20.096l-22.656 15.36-116.224-25.088-65.28 113.152 79.68 88.192-1.92 27.136a293.12 293.12 0 000 40.192l1.92 27.136-79.808 88.192 65.344 113.152 116.224-25.024 22.656 15.296a294.113 294.113 0 0034.816 20.096l24.512 11.968L446.72 896h130.688l36.48-113.152 24.448-11.904a288.282 288.282 0 0034.752-20.096l22.592-15.296 116.288 25.024 65.28-113.152-79.744-88.192 1.92-27.136a293.12 293.12 0 000-40.256l-1.92-27.136 79.808-88.128-65.344-113.152-116.288 24.96-22.592-15.232a287.616 287.616 0 00-34.752-20.096l-24.448-11.904L577.344 128zM512 320a192 192 0 110 384 192 192 0 010-384zm0 64a128 128 0 100 256 128 128 0 000-256z",
                              }),
                            }),
                          ],
                        }),
                      }),
                      x("section", { ref: a, children: t ? x(nc, {}) : null }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          x("div", { className: "extension-body", children: x(Cm, { ...e }) }),
        ],
      }),
    });
  }
  function Cm(e) {
    let [t, n] = ne(!1);
    return e.triggerMode === "always"
      ? x(ba, { ...e })
      : e.triggerMode === "questionMark"
      ? t7(e.question.trim())
        ? x(ba, { ...e })
        : x("div", {
            className: "notice",
            children: [
              x("svg", {
                viewBox: "0 0 128 128",
                xmlns: "http://www.w3.org/2000/svg",
                xmlnsXlink: "http://www.w3.org/1999/xlink",
                "aria-hidden": "true",
                role: "img",
                className: "iconify iconify--noto",
                preserveAspectRatio: "xMidYMid meet",
                fill: "#000000",
                children: [
                  x("g", { id: "SVGRepo_bgCarrier", "stroke-width": "0" }),
                  x("g", {
                    id: "SVGRepo_iconCarrier",
                    children: [
                      x("ellipse", {
                        cx: "64",
                        cy: "116.87",
                        rx: "12.09",
                        ry: "7.13",
                        fill: "#424242",
                      }),
                      x("path", {
                        d: "M64 4C42.92 4 25.82 19.67 25.82 38.99c0 5.04 1.52 10.43 3.75 15.18c3.13 6.68 6.54 11.62 7.54 13.44c2.78 5.06 2.38 10.39 3.15 13.73c1.45 6.24 5.79 8.5 23.73 8.5s21.8-2.15 23.41-7.9c1.1-3.91.03-8.18 2.8-13.23c1-1.82 5.07-7.85 8.21-14.54c2.23-4.75 3.75-10.14 3.75-15.18C102.18 19.67 85.08 4 64 4z",
                        fill: "#ffd600",
                      }),
                      x("ellipse", {
                        cx: "64",
                        cy: "86.13",
                        rx: "21.94",
                        ry: "4.46",
                        fill: "#b26500",
                      }),
                      x("ellipse", {
                        cx: "64",
                        cy: "86.13",
                        rx: "21.94",
                        ry: "4.46",
                        fill: "#b26500",
                      }),
                      x("ellipse", {
                        cx: "64",
                        cy: "86.13",
                        rx: "15.99",
                        ry: "2.06",
                        fill: "#ffa000",
                      }),
                      x("g", {
                        fill: "none",
                        "stroke-width": "2",
                        "stroke-miterlimit": "10",
                        children: [
                          x("path", {
                            d: "M53.3 56.77c-.62 1.56-2.23 4.77-1.39 6.21c1.95 3.35 6.6 4.55 6.6 7.63c0 4.7-3.42 19.93-3.42 19.93",
                            stroke: "#b26500",
                          }),
                          x("path", {
                            d: "M74.03 56.21s2.24 4.8 1.29 6.95c-.71 1.6-4.98 4.18-5.53 4.61c-2.55 2 .84 22.78.84 22.78",
                            stroke: "#b26500",
                          }),
                          x("path", {
                            d: "M53.3 56.77c3.44-6.8 5.21-22.32.84-21.53c-7.37 1.33 1.71 26.83 6.18 23.9s10.01-23.85 3.21-23.93c-6.8-.08.46 26.66 5.08 23.69c3.65-2.35 12.56-23.66 5.24-23.66c-6.23 0 .19 20.97.19 20.97",
                            stroke: "#ffffff",
                          }),
                        ],
                      }),
                      x("path", {
                        d: "M85.89 87.06S80.13 89.84 64 89.84s-21.89-2.78-21.89-2.78s-.36 5.14.83 7.47c1.43 2.8 2.53 3.77 2.53 3.77l.6 2.85l-.24.75c-.31.98-.09 2.06.6 2.83l.52.58l.58 2.74l-.2.55c-.38 1.05-.12 2.22.66 3.02l.38.39l.47 2.24s2.38 5.08 15.16 5.08s15.16-5.08 15.16-5.08l.04-.19l.26-.26c.52-.51.69-1.27.44-1.95l-.15-.39l.62-2.96l1.09-1.15c.54-.57.66-1.41.31-2.11l-.5-.99l.63-2.97l.4-.31c.59-.65.6-1.63.34-2.3c-.2-.53-.04-1.13.37-1.52c.63-.6 1.44-1.51 2.04-2.64c1.23-2.29.84-7.45.84-7.45z",
                        fill: "#82aec0",
                      }),
                      x("path", {
                        d: "M45.47 98.3l.54 2.87c5.82-.03 13.59.26 28.5-2.11c2.69-.61 5.92-1.82 2.35-1.32c0-.01-13.69 1.3-31.39.56z",
                        fill: "#2f7889",
                      }),
                      x("path", {
                        d: "M47.47 108.07c6.44-.11 19.6-.75 33.74-3.82l.63-2.97c-14.79 3.36-28.7 3.96-34.95 4.04l.58 2.75z",
                        fill: "#2f7889",
                      }),
                      x("path", {
                        d: "M80.31 108.49c-13.09 2.84-25.34 3.57-31.97 3.73l.43 2.04s.21 6.33 15.16 6.33s15.16-6.33 15.16-6.33s-6.38 1.82-14.23.93a.63.63 0 0 1-.01-1.26c4.69-.62 10.29-1.54 14.84-2.48l.62-2.96z",
                        fill: "#2f7889",
                      }),
                      x("path", {
                        d: "M42.18 87.06s6.46 2.78 21.76 2.78s21.88-2.78 21.88-2.78",
                        fill: "none",
                        stroke: "#82aec0",
                        "stroke-width": "3.997",
                        "stroke-linecap": "round",
                        "stroke-miterlimit": "10",
                      }),
                      x("path", {
                        d: "M49.88 10.32c3.91-.96 8-.48 10.8 2.92c.79.96 1.4 2.1 1.54 3.34c.28 2.39-1.2 4.65-2.96 6.31c-5.02 4.74-12.15 7.04-15.39 13.58c-.76 1.53-1.36 3.18-2.52 4.43c-1.16 1.25-3.09 2.01-4.6 1.21c-.8-.42-1.35-1.21-1.8-2c-2.84-5.06-2.63-11.51-.13-16.75c2.75-5.74 8.78-11.5 15.06-13.04z",
                        fill: "#ffff8d",
                      }),
                      x("path", {
                        d: "M46.45 91.93c-.88-.4-.53-1.72.43-1.65c3.22.25 8.7.56 15.95.56c7.64 0 14.36-.57 18.28-.99c.97-.1 1.34 1.23.45 1.64c-3.02 1.42-8.55 3.04-18.03 3.04c-9.25 0-14.35-1.37-17.08-2.6z",
                        fill: "#ffd600",
                      }),
                      x("path", {
                        d: "M51.94 102.03c-.67.24-1.36.57-1.7 1.19c-.12.23-.19.49-.14.75c.08.38.43.65.78.82c.7.34 1.49.43 2.26.44c1.59.02 3.17-.28 4.74-.58c.47-.09.95-.18 1.37-.41c.42-.23.78-.62.85-1.09c.1-.63-.35-1.24-.9-1.54c-1.9-1.05-5.34-.27-7.26.42z",
                        fill: "#94d1e0",
                      }),
                      x("path", {
                        d: "M53.43 108.62c-.67.24-1.36.57-1.7 1.19c-.12.23-.19.49-.14.75c.08.38.43.65.78.82c.7.34 1.49.43 2.26.44c1.59.02 3.17-.28 4.74-.58c.47-.09.95-.18 1.37-.41c.42-.23.78-.62.85-1.09c.1-.63-.35-1.24-.9-1.54c-1.9-1.04-5.35-.26-7.26.42z",
                        fill: "#94d1e0",
                      }),
                      x("path", {
                        d: "M50.01 84.2c.91.09 1.87.01 2.64-.48s1.26-1.49.95-2.35c-.16-.45-.51-.81-.85-1.15c-.75-.74-1.5-1.48-2.24-2.22c-.83-.83-1.66-1.65-2.56-2.4c-1.39-1.16-3.26-2.25-5.09-1.4c-1.56.72-1.93 2.14-1.24 3.63c1.47 3.13 4.89 6.01 8.39 6.37z",
                        fill: "#ffff8d",
                      }),
                    ],
                  }),
                ],
              }),
              x("div", { children: "End your query with a question mark (?)" }),
            ],
          })
      : t
      ? x(ba, { ...e })
      : x("div", {
          className: "notice",
          children: [
            x("svg", {
              fill: "#fdac00",
              viewBox: "0 0 96 96",
              xmlns: "http://www.w3.org/2000/svg",
              children: [
                x("g", { id: "SVGRepo_bgCarrier", "stroke-width": "0" }),
                x("g", {
                  id: "SVGRepo_iconCarrier",
                  children: [
                    x("title", {}),
                    x("g", {
                      children: [
                        x("path", {
                          d: "M48,0A24.0275,24.0275,0,0,0,24,24a6,6,0,0,0,12,0,12,12,0,0,1,24,0c0,5.2031-3.0586,8.3965-8.0859,13.0371C47.2617,41.32,42,46.1719,42,54a6,6,0,0,0,12,0c0-2.4434,2.2969-4.6875,6.0469-8.1445C65.0859,41.2031,72,34.834,72,24A24.0275,24.0275,0,0,0,48,0Z",
                        }),
                        x("path", {
                          d: "M48,72A12,12,0,1,0,60,84,12.0119,12.0119,0,0,0,48,72Z",
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
            x("div", {
              className: "click-here",
              children: [
                "Click ",
                x("span", { onClick: () => n(!0), children: "here" }),
                " to ask ChatGPT",
              ],
            }),
          ],
        });
  }
  function ba(e) {
    let [t, n] = ne(null),
      [a, r] = ne(""),
      [o, i] = ne(0),
      [l, s] = ne(!1),
      [u, c] = ne(!1),
      [d, p] = ne(0),
      [m, f] = ne(!1),
      [v, g] = ne(e.question),
      [_, C] = ne(!1),
      y = at({ current: { value: "" } });
    ie(() => {
      yt().then((E) => C(E.clearConversation));
    }, []),
      ie(() => {
        if (!v) return;
        let E = _a.default.runtime.connect(),
          z = (k) => {
            k.text
              ? (n(k),
                k.conversationId &&
                  !t5.conversationId &&
                  (t5.conversationId = k.conversationId))
              : k.error
              ? r(k.error)
              : k.event === "DONE" && (s(!0), p(d + 1));
          };
        return (
          E.onMessage.addListener(z),
          E.postMessage({
            question: v,
            clearConversation: _,
            conversationId: t5.conversationId,
          }),
          () => {
            E.onMessage.removeListener(z), E.disconnect();
          }
        );
      }, [v, o]),
      ie(() => {
        c(l && !!t5.conversationId && d > 1);
      }, [l]),
      ie(() => {
        let E = () => {
          a &&
            (a == "UNAUTHORIZED" || a === "CLOUDFLARE") &&
            (r(""), i((z) => z + 1));
        };
        return (
          window.addEventListener("focus", E),
          () => {
            window.removeEventListener("focus", E);
          }
        );
      }, [a]),
      ie(() => {
        a7().then((E) => f(E));
      }, []);
    let w = vt(() => {
        _a.default.runtime.sendMessage({ type: "OPEN_OPTIONS_PAGE" });
      }, []),
      M = (E) => (E.preventDefault(), s(!1), g(y.current.value), !1);
    return t
      ? x("div", {
          children: [
            x("p", {
              children: x(L5, {
                rehypePlugins: [[J1, { detect: !0 }]],
                children: t.text,
              }),
            }),
            u
              ? x("a", {
                  style: { border: "1px solid #fafafa", borderRadius: "5px" },
                  target: "_blank",
                  className: "btn btn-continue",
                  href: "https://chat.openai.com/chat/" + t5.conversationId,
                  rel: "noreferrer",
                  children: [x(ao, { size: 16 }), "Continue Chat Thread"],
                })
              : null,
            l
              ? x("section", {
                  children: [
                    x("form", {
                      onSubmit: M,
                      children: x("div", {
                        className: "continue-chat",
                        children: [
                          x("input", {
                            className: "input-text",
                            ref: y,
                            required: !0,
                          }),
                          x("button", {
                            role: "button",
                            className: "btn btn-submit",
                            title: "Questioning...",
                            type: "submit",
                            children: x("svg", {
                              viewBox: "0 0 19 19",
                              fill: "none",
                              xmlns: "http://www.w3.org/2000/svg",
                              children: [
                                x("path", {
                                  fillRule: "evenodd",
                                  clipRule: "evenodd",
                                  d: "M18.4069 0.592974C17.8716 0.0593106 17.0839 -0.133883 16.3622 0.094376L1.41676 4.81642C0.604565 5.07315 0.0396862 5.80841 0.00190544 6.65968C-0.0347538 7.50956 0.46273 8.29322 1.24909 8.62034L7.56706 11.2503C7.58459 11.2805 7.60557 11.3094 7.63004 11.3363C7.66573 11.3756 7.70624 11.4079 7.74985 11.4331L10.3799 17.7509C10.7068 18.5373 11.4906 19.0345 12.3406 18.9981C13.1921 18.9603 13.9271 18.3954 14.1839 17.5833C15.5232 13.3452 17.7352 6.3429 18.9055 2.6376C19.134 1.91595 18.9406 1.12799 18.4069 0.592974ZM8.95379 10.8086L11.627 17.2319C11.7365 17.4941 11.9973 17.6603 12.281 17.6481C12.5647 17.6345 12.8095 17.4468 12.8959 17.1764C13.3704 15.6747 13.9542 13.8262 14.5625 11.9005C15.6711 8.39036 16.861 4.62337 17.6175 2.23076C17.6933 1.99028 17.6297 1.72673 17.4512 1.54825C17.273 1.36999 17.0094 1.30641 16.7687 1.38197L16.769 1.38225L1.82297 6.10375C1.55262 6.19017 1.36485 6.43471 1.35129 6.71861C1.33907 7.0023 1.50535 7.26313 1.76755 7.37263L8.27009 10.0787L13.1637 5.63001C13.368 5.44426 13.6842 5.45932 13.87 5.66365C14.0557 5.86798 14.0407 6.1842 13.8363 6.36995L8.95379 10.8086Z",
                                  fill: "url(#paint0_linear_485_11533)",
                                }),
                                x("defs", {
                                  children: x("linearGradient", {
                                    id: "paint0_linear_485_11533",
                                    x1: "9.50648",
                                    y1: "19.0257",
                                    x2: "9.50648",
                                    y2: "0.00157616",
                                    gradientUnits: "userSpaceOnUse",
                                    children: [
                                      x("stop", {
                                        offset: "0.255208",
                                        stopColor: "#00AEFF",
                                      }),
                                      x("stop", {
                                        offset: "0.619792",
                                        stopColor: "#0FB7FE",
                                      }),
                                      x("stop", {
                                        offset: "1",
                                        stopColor: "#35CFFD",
                                      }),
                                    ],
                                  }),
                                }),
                              ],
                            }),
                          }),
                        ],
                      }),
                    }),
                    x("div", {
                      className: "tips",
                      children: [
                        x("svg", {
                          viewBox: "0 0 128 128",
                          xmlns: "http://www.w3.org/2000/svg",
                          xmlnsXlink: "http://www.w3.org/1999/xlink",
                          "aria-hidden": "true",
                          role: "img",
                          className: "iconify iconify--noto",
                          preserveAspectRatio: "xMidYMid meet",
                          fill: "#000000",
                          children: [
                            x("g", {
                              id: "SVGRepo_bgCarrier",
                              strokeWidth: "0",
                            }),
                            x("g", {
                              id: "SVGRepo_iconCarrier",
                              children: [
                                x("ellipse", {
                                  cx: "64",
                                  cy: "116.87",
                                  rx: "12.09",
                                  ry: "7.13",
                                  fill: "#424242",
                                }),
                                x("path", {
                                  d: "M64 4C42.92 4 25.82 19.67 25.82 38.99c0 5.04 1.52 10.43 3.75 15.18c3.13 6.68 6.54 11.62 7.54 13.44c2.78 5.06 2.38 10.39 3.15 13.73c1.45 6.24 5.79 8.5 23.73 8.5s21.8-2.15 23.41-7.9c1.1-3.91.03-8.18 2.8-13.23c1-1.82 5.07-7.85 8.21-14.54c2.23-4.75 3.75-10.14 3.75-15.18C102.18 19.67 85.08 4 64 4z",
                                  fill: "#ffd600",
                                }),
                                x("ellipse", {
                                  cx: "64",
                                  cy: "86.13",
                                  rx: "21.94",
                                  ry: "4.46",
                                  fill: "#b26500",
                                }),
                                x("ellipse", {
                                  cx: "64",
                                  cy: "86.13",
                                  rx: "21.94",
                                  ry: "4.46",
                                  fill: "#b26500",
                                }),
                                x("ellipse", {
                                  cx: "64",
                                  cy: "86.13",
                                  rx: "15.99",
                                  ry: "2.06",
                                  fill: "#ffa000",
                                }),
                                x("g", {
                                  fill: "none",
                                  strokeWidth: "2",
                                  strokeMiterlimit: "10",
                                  children: [
                                    x("path", {
                                      d: "M53.3 56.77c-.62 1.56-2.23 4.77-1.39 6.21c1.95 3.35 6.6 4.55 6.6 7.63c0 4.7-3.42 19.93-3.42 19.93",
                                      stroke: "#b26500",
                                    }),
                                    x("path", {
                                      d: "M74.03 56.21s2.24 4.8 1.29 6.95c-.71 1.6-4.98 4.18-5.53 4.61c-2.55 2 .84 22.78.84 22.78",
                                      stroke: "#b26500",
                                    }),
                                    x("path", {
                                      d: "M53.3 56.77c3.44-6.8 5.21-22.32.84-21.53c-7.37 1.33 1.71 26.83 6.18 23.9s10.01-23.85 3.21-23.93c-6.8-.08.46 26.66 5.08 23.69c3.65-2.35 12.56-23.66 5.24-23.66c-6.23 0 .19 20.97.19 20.97",
                                      stroke: "#ffffff",
                                    }),
                                  ],
                                }),
                                x("path", {
                                  d: "M85.89 87.06S80.13 89.84 64 89.84s-21.89-2.78-21.89-2.78s-.36 5.14.83 7.47c1.43 2.8 2.53 3.77 2.53 3.77l.6 2.85l-.24.75c-.31.98-.09 2.06.6 2.83l.52.58l.58 2.74l-.2.55c-.38 1.05-.12 2.22.66 3.02l.38.39l.47 2.24s2.38 5.08 15.16 5.08s15.16-5.08 15.16-5.08l.04-.19l.26-.26c.52-.51.69-1.27.44-1.95l-.15-.39l.62-2.96l1.09-1.15c.54-.57.66-1.41.31-2.11l-.5-.99l.63-2.97l.4-.31c.59-.65.6-1.63.34-2.3c-.2-.53-.04-1.13.37-1.52c.63-.6 1.44-1.51 2.04-2.64c1.23-2.29.84-7.45.84-7.45z",
                                  fill: "#82aec0",
                                }),
                                x("path", {
                                  d: "M45.47 98.3l.54 2.87c5.82-.03 13.59.26 28.5-2.11c2.69-.61 5.92-1.82 2.35-1.32c0-.01-13.69 1.3-31.39.56z",
                                  fill: "#2f7889",
                                }),
                                x("path", {
                                  d: "M47.47 108.07c6.44-.11 19.6-.75 33.74-3.82l.63-2.97c-14.79 3.36-28.7 3.96-34.95 4.04l.58 2.75z",
                                  fill: "#2f7889",
                                }),
                                x("path", {
                                  d: "M80.31 108.49c-13.09 2.84-25.34 3.57-31.97 3.73l.43 2.04s.21 6.33 15.16 6.33s15.16-6.33 15.16-6.33s-6.38 1.82-14.23.93a.63.63 0 0 1-.01-1.26c4.69-.62 10.29-1.54 14.84-2.48l.62-2.96z",
                                  fill: "#2f7889",
                                }),
                                x("path", {
                                  d: "M42.18 87.06s6.46 2.78 21.76 2.78s21.88-2.78 21.88-2.78",
                                  fill: "none",
                                  stroke: "#82aec0",
                                  strokeWidth: "3.997",
                                  strokeLinecap: "round",
                                  strokeMiterlimit: "10",
                                }),
                                x("path", {
                                  d: "M49.88 10.32c3.91-.96 8-.48 10.8 2.92c.79.96 1.4 2.1 1.54 3.34c.28 2.39-1.2 4.65-2.96 6.31c-5.02 4.74-12.15 7.04-15.39 13.58c-.76 1.53-1.36 3.18-2.52 4.43c-1.16 1.25-3.09 2.01-4.6 1.21c-.8-.42-1.35-1.21-1.8-2c-2.84-5.06-2.63-11.51-.13-16.75c2.75-5.74 8.78-11.5 15.06-13.04z",
                                  fill: "#ffff8d",
                                }),
                                x("path", {
                                  d: "M46.45 91.93c-.88-.4-.53-1.72.43-1.65c3.22.25 8.7.56 15.95.56c7.64 0 14.36-.57 18.28-.99c.97-.1 1.34 1.23.45 1.64c-3.02 1.42-8.55 3.04-18.03 3.04c-9.25 0-14.35-1.37-17.08-2.6z",
                                  fill: "#ffd600",
                                }),
                                x("path", {
                                  d: "M51.94 102.03c-.67.24-1.36.57-1.7 1.19c-.12.23-.19.49-.14.75c.08.38.43.65.78.82c.7.34 1.49.43 2.26.44c1.59.02 3.17-.28 4.74-.58c.47-.09.95-.18 1.37-.41c.42-.23.78-.62.85-1.09c.1-.63-.35-1.24-.9-1.54c-1.9-1.05-5.34-.27-7.26.42z",
                                  fill: "#94d1e0",
                                }),
                                x("path", {
                                  d: "M53.43 108.62c-.67.24-1.36.57-1.7 1.19c-.12.23-.19.49-.14.75c.08.38.43.65.78.82c.7.34 1.49.43 2.26.44c1.59.02 3.17-.28 4.74-.58c.47-.09.95-.18 1.37-.41c.42-.23.78-.62.85-1.09c.1-.63-.35-1.24-.9-1.54c-1.9-1.04-5.35-.26-7.26.42z",
                                  fill: "#94d1e0",
                                }),
                                x("path", {
                                  d: "M50.01 84.2c.91.09 1.87.01 2.64-.48s1.26-1.49.95-2.35c-.16-.45-.51-.81-.85-1.15c-.75-.74-1.5-1.48-2.24-2.22c-.83-.83-1.66-1.65-2.56-2.4c-1.39-1.16-3.26-2.25-5.09-1.4c-1.56.72-1.93 2.14-1.24 3.63c1.47 3.13 4.89 6.01 8.39 6.37z",
                                  fill: "#ffff8d",
                                }),
                              ],
                            }),
                          ],
                        }),
                        x("div", {
                          children: u
                            ? x("section", {
                                children:
                                  'Click "Continue Chat Thread" to view all conversations',
                              })
                            : x("section", {
                                children: [
                                  "Tip: you can configure Search Engine 2.0 in",
                                  " ",
                                  x("a", {
                                    href: "#",
                                    onClick: w,
                                    children: "settings",
                                  }),
                                ],
                              }),
                        }),
                      ],
                    }),
                  ],
                })
              : null,
          ],
        })
      : a === "UNAUTHORIZED" || a === "CLOUDFLARE"
      ? x("section", {
          className: "notice",
          children: [
            x("svg", {
              viewBox: "-2 0 32 32",
              fill: "none",
              xmlns: "http://www.w3.org/2000/svg",
              children: [
                x("g", { id: "SVGRepo_bgCarrier", "stroke-width": "0" }),
                x("g", {
                  id: "SVGRepo_iconCarrier",
                  children: [
                    x("path", {
                      d: "M13.6466 31.9999C16.1714 31.9999 18.2181 29.9532 18.2181 27.4285C18.2181 24.9038 16.1714 22.8571 13.6466 22.8571C11.1219 22.8571 9.0752 24.9038 9.0752 27.4285C9.0752 29.9532 11.1219 31.9999 13.6466 31.9999Z",
                      fill: "#FF7700",
                    }),
                    x("path", {
                      "fill-rule": "evenodd",
                      "clip-rule": "evenodd",
                      d: "M21.1892 6.17181C19.8652 4.84783 18.3669 3.94466 16.6944 3.46231V3.04762C16.6944 2.20605 16.3968 1.48771 15.8018 0.892626C15.2066 0.297542 14.4883 0 13.6467 0C12.8052 0 12.0868 0.297542 11.4917 0.892626C10.8967 1.48771 10.5991 2.20605 10.5991 3.04762V3.46231C8.92652 3.94466 7.42824 4.84783 6.10426 6.17181C4.02147 8.2546 2.98007 10.7688 2.98007 13.7143V21.9429L0.491411 24.9292C0.302152 25.1564 0.184215 25.4165 0.137601 25.7097C0.108531 26.0029 0.156694 26.2834 0.282088 26.5512C0.407483 26.8188 0.594914 27.032 0.844382 27.1906C1.09385 27.3492 1.3664 27.4286 1.66203 27.4286H25.6314C25.927 27.4286 26.1996 27.3492 26.4491 27.1906C26.6986 27.032 26.886 26.8188 27.0114 26.5512C27.1368 26.2834 27.1806 26.0029 27.1427 25.7097C27.1048 25.4165 26.9912 25.1564 26.802 24.9292L24.3134 21.9429V13.7143C24.3134 10.7688 23.272 8.2546 21.1892 6.17181Z",
                      fill: "url(#paint0_radial_103_1590)",
                    }),
                    x("defs", {
                      children: x("radialGradient", {
                        id: "paint0_radial_103_1590",
                        cx: "0",
                        cy: "0",
                        r: "1",
                        gradientUnits: "userSpaceOnUse",
                        gradientTransform:
                          "translate(9.12995 7.54174) rotate(53.71) scale(21.2682 20.9501)",
                        children: [
                          x("stop", { "stop-color": "#FADF73" }),
                          x("stop", {
                            offset: "0.457142",
                            "stop-color": "#FFD500",
                          }),
                          x("stop", { offset: "1", "stop-color": "#FC9900" }),
                        ],
                      }),
                    }),
                  ],
                }),
              ],
            }),
            x("div", {
              children: x("p", {
                className: "gpt-inner",
                children: [
                  "to use Search Engine 2.0 please login at:",
                  " ",
                  x("a", {
                    href: "https://chat.openai.com",
                    target: "_blank",
                    rel: "noreferrer",
                    children: "chat.openai.com",
                  }),
                  n7() &&
                    o > 0 &&
                    x("span", {
                      children: [
                        x("br", {}),
                        "Still not working? Follow",
                        " ",
                        x("a", {
                          href: "https://github.com/rakiburrahamanCS",
                          children: "Brave Troubleshooting",
                        }),
                      ],
                    }),
                ],
              }),
            }),
          ],
        })
      : a
      ? x("p", {
          className: "gpt-inner",
          children: [
            "Failed to load response from ChatGPT:",
            x("br", {}),
            " ",
            a,
          ],
        })
      : x("p", {
          className: "gpt-loading gpt-inner",
          children: "Waiting for ChatGPT response...",
        });
  }
  var ac = Tn(Sm);
  function km(e) {
    return x(ac, { question: e.question, triggerMode: e.triggerMode });
  }
  var rc = km;
  var Ea = {
    google: {
      inputQuery: ["input[name='q']"],
      sidebarContainerQuery: ["#rhs"],
      appendContainerQuery: ["#rcnt"],
    },
    bing: {
      inputQuery: ["[name='q']"],
      sidebarContainerQuery: ["#b_context"],
      appendContainerQuery: ["#b_content"],
      watchRouteChange: (e) => {
        var t;
        return (
          (t = document.querySelector("#sb_form")) == null ||
            t.addEventListener("submit", function (n) {
              n.target.submit();
            }),
          !1
        );
      },
    },
    yahoo: {
      inputQuery: ["input[name='p']"],
      sidebarContainerQuery: [
        "#right",
        ".Contents__inner.Contents__inner--sub",
      ],
      appendContainerQuery: ["#cols", "#contents__wrap"],
    },
    duckduckgo: {
      inputQuery: ["input[name='q']"],
      sidebarContainerQuery: [".results--sidebar.js-results-sidebar"],
      appendContainerQuery: ["#links_wrapper"],
    },
    baidu: {
      inputQuery: ["input[name='wd']"],
      sidebarContainerQuery: ["#content_right"],
      appendContainerQuery: ["#container"],
      watchRouteChange(e) {
        let t = document.getElementById("wrapper_wrapper");
        new MutationObserver(function (a) {
          for (let r of a)
            if (r.type === "childList") {
              for (let o of r.addedNodes)
                if ("id" in o && o.id === "container") {
                  e();
                  return;
                }
            }
        }).observe(t, { childList: !0 });
      },
    },
    kagi: {
      inputQuery: ["input[name='q']"],
      sidebarContainerQuery: [".right-content-box._0_right_sidebar"],
      appendContainerQuery: ["#_0_app_content"],
    },
    yandex: {
      inputQuery: ["input[name='text']"],
      sidebarContainerQuery: ["#search-result-aside"],
      appendContainerQuery: [],
    },
    naver: {
      inputQuery: ["input[name='query']"],
      sidebarContainerQuery: ["#sub_pack"],
      appendContainerQuery: ["#content"],
    },
    brave: {
      inputQuery: ["input[name='q']"],
      sidebarContainerQuery: ["#side-right"],
      appendContainerQuery: [],
    },
    searx: {
      inputQuery: ["input[name='q']"],
      sidebarContainerQuery: ["#sidebar_results"],
      appendContainerQuery: [],
    },
  };
  async function Rm(e, t) {
    var s, u;
    let n = document.createElement("section"),
      a = document.createElement("div");
    n.appendChild(a);
    let r = n;
    r.className = "chat-gpt-container";
    let o = await yt(),
      i;
    o.theme === "auto" ? (i = r1()) : (i = o.theme),
      i === "dark" ? r.classList.add("gpt-dark") : r.classList.add("gpt-light");
    let l = en(t.sidebarContainerQuery);
    if (l)
      (s = l.getElementsByClassName(r.className)[0]) == null || s.remove(),
        l.prepend(r);
    else {
      r.classList.add("sidebar-free");
      let c = en(t.appendContainerQuery);
      c &&
        ((u = c.getElementsByClassName(r.className)[0]) == null || u.remove(),
        c.appendChild(r));
    }
    Ct(x(rc, { question: e, triggerMode: o.triggerMode || "always" }), r);
  }
  var Im = new RegExp(Object.keys(Ea).join("|")),
    oc,
    ya = (oc = location.hostname.match(Im)) == null ? void 0 : oc[0],
    p5 = ya ? Ea[ya] : null;
  function ic() {
    if (!p5) return !1;
    let e = en(p5.inputQuery);
    e && e.value && (console.debug("Mount ChatGPT on", ya), Rm(e.value, p5));
  }
  ic();
  p5 && p5.watchRouteChange && p5.watchRouteChange(ic);
})();
